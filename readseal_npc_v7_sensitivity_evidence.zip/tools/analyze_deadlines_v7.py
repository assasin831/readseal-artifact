"""Recount fixed, previously validated executions at alternative receipt cutoffs."""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np

DEADLINES_MS = [80, 90, 100, 110, 120, 130, 150, 200]
BOOTSTRAP_SEED = 260915071
BOOTSTRAP_REPLICATES = 20000


def sha(data):
    return hashlib.sha256(data).hexdigest()


def counts(latency_ns, deadlines_ms):
    values = np.asarray(latency_ns, dtype=np.int64)
    assert values.ndim == 1 and (values >= 0).all()
    return [int(np.count_nonzero(values <= round(d * 1e6))) for d in deadlines_ms]


def analyze(archive, primary):
    expected = json.loads(primary.read_text())
    assert expected['status'] == 'COMPLETE' and len(expected['rows']) == 96
    rows, checked, all_requests = [], 0, 0
    with ZipFile(archive) as z:
        for old in expected['rows']:
            name = old['run']
            rb, sb = z.read(name + '/report.json'), z.read(name + '/sink.json')
            assert sha(rb) == old['run_sha256'] == expected['raw_inventory'][name + '/report.json']
            assert sha(sb) == old['sink_sha256'] == expected['raw_inventory'][name + '/sink.json']
            report, sink = json.loads(rb), json.loads(sb)
            assert report['status'] == 'COMPLETE'
            assert report['wrong_outputs'] == report['source_unknown'] == 0
            producers = {p['tick']: p for p in report['producer']}
            assert len(producers) == len(report['producer'])
            assert len({(r['tick'], r['consumer']) for r in sink}) == len(sink)
            cohort = []
            for r in sink:
                p = producers[r['tick']]
                assert r['cohort'] == p['cohort'] and r['scheduled_ns'] == p['scheduled_ns']
                assert p['enqueued'][r['consumer']]
                assert r['published'] and r['output_equal'] and r['finite'] and r['provenance_verified']
                assert r['source_id'] == r['observed_source'] == p['source_id']
                assert r['sequence'] == r['observed_sequence'] == p['sequence']
                assert r['identity']['sequence'] == r['sequence']
                assert r['actual_hashes'] == report['references'][r['source_id']]['hashes']
                assert r['matching_reference_sources'] == [r['source_id']]
                assert r['scheduled_ns'] <= r['admission_ns'] <= r['output_done_ns'] <= r['publish_ns']
                assert r['verified_timely'] == (r['publish_ns'] - r['scheduled_ns'] <= 100000000)
                if r['cohort']:
                    cohort.append(r)
            latency = [r['publish_ns'] - r['scheduled_ns'] for r in cohort]
            timely = counts(latency, DEADLINES_MS)
            assert len(cohort) == old['publications'] == report['publications']
            assert timely[2] == old['timely'] == report['timely']
            assert sum(sum(p['enqueued']) for p in producers.values() if p['cohort']) == len(cohort)
            assert old['arrivals'] == 1440
            arrival_ticks = [p for p in report['producer'] if p['cohort']]
            alternating = None
            if old['condition'] == 'r1-cap0' and old['method'] == 'manual-full':
                mask = [all(p['enqueued']) for p in arrival_ticks]
                alternating = all(a != b for a, b in zip(mask, mask[1:]))
                assert alternating and sum(mask) == 180
            rows.append(dict(run=name, condition=old['condition'], method=old['method'],
                repeat=old['repeat'], arrivals=old['arrivals'], received=len(cohort),
                timely=timely, goodput_hz=[v / 12 for v in timely],
                latency_ns=latency, alternating_admission_observed=alternating,
                run_sha256=sha(rb), sink_sha256=sha(sb)))
            checked += 2
            all_requests += len(sink)
    rng, summary = np.random.default_rng(BOOTSTRAP_SEED), []
    for condition in sorted({r['condition'] for r in rows}):
        rr = [r for r in rows if r['condition'] == condition]
        by = {m: sorted([r for r in rr if r['method'] == m], key=lambda r: r['repeat'])
              for m in sorted({r['method'] for r in rr})}
        assert all([r['repeat'] for r in v] == list(range(6)) for v in by.values())
        sample = rng.integers(0, 6, size=(BOOTSTRAP_REPLICATES, 6))
        arrays = {m: np.asarray([r['goodput_hz'] for r in v]) for m, v in by.items()}
        effects = {}
        for method in ['manual-full', 'manual-early', 'auto-early']:
            diff = arrays['auto-batched'] - arrays[method]
            effects[method] = dict(mean=diff.mean(axis=0).tolist(),
                ci95=np.quantile(diff[sample].mean(axis=1), [.025, .975], axis=0).T.tolist())
        summary.append(dict(condition=condition,
            means={m: a.mean(axis=0).tolist() for m, a in arrays.items()},
            grouped_minus=effects))
    return dict(status='COMPLETE', schema='readseal-fixed-trace-deadline-sensitivity-v7',
        inference_executed=False, cuda_used=False, schedule_changed=False,
        interpretation='Post-hoc receipt-cutoff sensitivity on unchanged executions; not deadline-aware rescheduling or jitter robustness.',
        source_archive_sha256=sha(archive.read_bytes()), primary_sha256=sha(primary.read_bytes()),
        script_sha256=sha(Path(__file__).read_bytes()), source_json_files_verified=checked,
        requests_verified_including_warmup_and_drain=all_requests,
        deadlines_ms=DEADLINES_MS, bootstrap_replicates=BOOTSTRAP_REPLICATES,
        bootstrap_seed=BOOTSTRAP_SEED, sampling_unit='six paired whole-repetition blocks; pointwise intervals',
        rows=rows, summary=summary)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--archive', type=Path, required=True)
    p.add_argument('--primary', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    result = analyze(args.archive, args.primary)
    with args.output.open('x', encoding='utf-8') as f:
        json.dump(result, f, separators=(',', ':'))
        f.write('\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ['rows', 'summary']}))
