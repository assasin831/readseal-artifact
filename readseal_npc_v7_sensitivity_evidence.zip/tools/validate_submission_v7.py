"""CPU-only reconstruction and submission checks; never imports the GPU runtime."""
import argparse
import hashlib
import json
import re
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
FROZEN = {
    'loadscan_v7.json': 'd319ba93775b32a1711836843130bc9e1cf0c251d826bae6fac8978b807174ae',
    'loadscan_diagnostic_v7.json': '8f0b8d4418770d372b46015bfad2a90fcb1f1ba44364aded31f7937c3fa8e3b2',
    'loadscan_controller_v7.json': '91b1d71e2a1ddecb2749b590dffba4676523ef05d0f957507e41a2f8ad885ce1',
    'npc_loadscan_v7_formal_prepared_final1.json': 'dacc08dd2ef4a174a8c3f54ef2f330485a7654ad0c3ca515be45b7570201ad87',
    'npc_loadscan_v7_formal_campaign_final1.json': 'd20dbe9d39a42a06ae5f787eea5c0267125d812b7f90b8ea79ee47608e54bd3b',
    'grouped.json': '8abb23d796a4176e6c850e8994ea429d9d0eff14757e28ea9cd49f8778e7120a',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(output, archive=None, manuscript=True):
    checked = []

    def check(ok, label):
        if not ok:
            raise AssertionError(label)
        checked.append(label)

    def close(a, b, label):
        check(np.allclose(a, b, rtol=0, atol=1e-9), label)

    def read(name):
        return json.loads((ROOT / 'evidence' / name).read_text())

    for name, digest in FROZEN.items():
        check(sha(ROOT/'evidence'/name) == digest, 'frozen hash: '+name)
    load = read('loadscan_v7.json')
    prep = read('npc_loadscan_v7_formal_prepared_final1.json')
    camp = read('npc_loadscan_v7_formal_campaign_final1.json')
    check(load['status'] == camp['status'] == 'COMPLETE' and prep['status'] == 'PREPARED', 'complete run/analysis and frozen prepared lineage')
    check(load['prepared_sha256'] == camp['prepared_sha256'] == FROZEN['npc_loadscan_v7_formal_prepared_final1.json'], 'prepared binding')
    check(load['campaign_report_sha256'] == FROZEN['npc_loadscan_v7_formal_campaign_final1.json'], 'campaign binding')
    check(prep['plan'] == camp['plan'] == load['plan'], 'identical frozen plan')
    check(prep['schedule'] == camp['schedule'], 'identical prepared schedule')
    plan = load['plan']
    check(plan['bootstrap_replicates'] == 20000 and plan['repetitions'] == 6, 'replication units')
    check(len(load['rows']) == len(camp['runs']) == len(camp['schedule']) == 72, '72 complete runs')
    membership = {(rate, cap, method, rep) for rate in (20,30,40) for cap in (0,8)
                  for method in ('auto-batched','manual-full') for rep in range(6)}
    actual = set()
    for row, entry, wanted in zip(load['rows'], camp['runs'], camp['schedule']):
        cell = entry['cell']
        actual.add((cell['rate_hz'], cell['outstanding_cap'], entry['method'], entry['repeat']))
        check(all(entry[k] == v for k,v in wanted.items()), 'scheduled entry')
        check(row['run'] == entry['name'] and row['method'] == entry['method'] and row['repeat'] == entry['repeat'], 'run identity')
        check(row['run_sha256'] == entry['report_sha256'], 'run hash')
        for file, field in [('report.json','run_sha256'), ('sink.json','sink_sha256')]:
            key = 'continuation/runs/'+row['run']+'/'+file
            check(load['raw_inventory'][key] == row[field], 'frozen raw inventory '+file)
        check(row['arrivals'] == cell['rate_hz'] * 12 * 4, 'offered count')
        check(row['timely'] + row['correct_late'] == row['publications'], 'receipt accounting')
        check(row['arrivals'] == sum(row[k] for k in ('publications','pool_exhausted','credit_exhausted','queue_loss','producer_late')), 'all outcomes')
        close(row['goodput_hz'], row['timely']/12, 'goodput denominator')
        check(row['queue_loss'] == row['producer_late'] == 0, 'no queue loss or producer lateness')
        check(row['gpu_uuid'] == prep['gpu_uuid'] == camp['gpu_uuid'] and not row['observed'], 'GPU lineage and uninstrumented run')
        check(row['complete_native_and_child_outputs'] and row['credit_reconstruction'], 'output and credit validation recorded')
    check(actual == membership and len(actual) == 72, 'exact full factorial')
    check(sum(r['arrivals'] for r in load['rows']) == 103680, 'total offered')
    check(sum(r['publications'] for r in load['rows']) == 68304, 'total receipts')
    check(load['no_source_unknown_or_wrong_output'] and load['no_inference_retry'], 'frozen success assertions')
    rng = np.random.default_rng(plan['bootstrap_seed'])
    for summary in load['summary']:
        by = {m: sorted([r for r in load['rows'] if r['condition'] == summary['condition'] and r['method'] == m], key=lambda r:r['repeat'])
              for m in ('auto-batched','manual-full')}
        check(all([r['repeat'] for r in rows] == list(range(6)) for rows in by.values()), 'paired repeats')
        samples = rng.integers(0,6,size=(20000,6))
        for key, reported in summary['metrics'].items():
            a,b = (np.array([r[key] for r in by[m]]) for m in ('auto-batched','manual-full'))
            close([a.mean(),b.mean(),(a-b).mean()], [reported['a_mean'],reported['b_mean'],reported['paired_difference']], 'load means: '+key)
            close(np.quantile((a-b)[samples].mean(axis=1), [.025,.975]), reported['pointwise_ci95'], 'load bootstrap: '+key)
    check(len(read('loadscan_diagnostic_v7.json')['rows']) == 23, 'diagnostics kept separate')

    cut, primary = read('deadlines_v7.json'), read('grouped.json')
    check(cut['status'] == 'COMPLETE' and len(cut['rows']) == 96, 'complete cutoff analysis')
    check(cut['deadlines_ms'] == [80,90,100,110,120,130,150,200], 'eight cutoffs')
    check(cut['primary_sha256'] == FROZEN['grouped.json'], 'cutoff source lineage')
    check(cut['script_sha256'] == sha(ROOT/'tools/analyze_deadlines_v7.py'), 'cutoff code lineage')
    check(not any(cut[k] for k in ('inference_executed','cuda_used','schedule_changed')), 'no new execution')
    check(cut['source_json_files_verified'] == 192 and cut['requests_verified_including_warmup_and_drain'] == 96764, 'full raw audit coverage')
    old_by = {r['run']:r for r in primary['rows']}
    for row in cut['rows']:
        old = old_by[row['run']]
        values = np.array(row['latency_ns'], dtype=np.int64)
        recounted = [int(np.sum(values <= d * 1000000)) for d in cut['deadlines_ms']]
        check((values >= 0).all() and len(values) == row['received'] == old['publications'], 'finite received latency')
        check(recounted == row['timely'], 'inclusive integer cutoff recount')
        check(recounted[2] == old['timely'], 'original cutoff unchanged')
        check(all(a <= b for a,b in zip(recounted,recounted[1:])), 'monotone cutoff CDF')
        check(row['run_sha256'] == old['run_sha256'] and row['sink_sha256'] == old['sink_sha256'], 'original raw hashes')
        close(np.array(recounted)/12,row['goodput_hz'],'cutoff goodput')
        if row['condition'] == 'r1-cap0' and row['method'] == 'manual-full':
            check(row['alternating_admission_observed'] is True, 'directly audited admission pattern')
    rng = np.random.default_rng(cut['bootstrap_seed'])
    for s in cut['summary']:
        rows = [r for r in cut['rows'] if r['condition'] == s['condition']]
        arrays = {}
        for m in sorted(s['means']):
            group = sorted([r for r in rows if r['method'] == m],key=lambda r:r['repeat'])
            check([r['repeat'] for r in group] == list(range(6)), 'cutoff paired repeat membership')
            arrays[m] = np.array([r['goodput_hz'] for r in group])
            close(arrays[m].mean(axis=0),s['means'][m],'cutoff means')
        sample = rng.integers(0,6,size=(20000,6))
        for m in ('manual-full','manual-early','auto-early'):
            diff = arrays['auto-batched'] - arrays[m]
            close(diff.mean(axis=0),s['grouped_minus'][m]['mean'],'cutoff paired effect')
            close(np.quantile(diff[sample].mean(axis=1),[.025,.975],axis=0).T,s['grouped_minus'][m]['ci95'],'cutoff 20000 intervals')
    if archive:
        from analyze_deadlines_v7 import analyze
        check(analyze(archive,ROOT/'evidence/grouped.json') == cut, 'full 192-file deadline reconstruction')

    for name, nruns in [('grouped',96),('confirmatory',54)]:
        data=read(name+'.json')
        proof=read(name+'_validation.json')
        check(proof['status']=='COMPLETE' and proof['analysis_sha256']==sha(ROOT/'evidence'/(name+'.json')), 'primary/confirmation proof')
        check(len(data['rows'])==nruns,'separate old window membership')
        lookup={(r['repeat'],r['condition'],r['method']):r for r in data['rows']}
        check(len(lookup)==nruns,'unique old window cells')
        draws=np.random.default_rng(data['plan']['bootstrap_seed']).integers(0,6,size=(20000,6))
        for condition in data['primary']['conditions']:
            arrays={}
            for method in data['plan']['methods']:
                rr=[lookup[(rep,condition['condition'],method)] for rep in range(6)]
                for metric in ('goodput_hz','mean_protected_mib','device_peak_mib','peak_outstanding'):
                    values=np.array([r[metric] for r in rr]); arrays[method,metric]=values
                    reported=condition['methods'][method][metric]
                    close(values,reported['runs'],'Fig2 per-repeat values')
                    close(values.mean(),reported['mean'],'Fig2 means')
                    close(np.quantile(values[draws].mean(axis=1),[.025,.975]),reported['interval'],'Fig2 intervals')
            for pair,metrics in condition['paired_differences'].items():
                a,b=pair.split('_minus_')
                for metric,reported in metrics.items():
                    delta=arrays[a,metric]-arrays[b,metric]
                    close(delta,reported['runs'],'Fig2 paired values')
                    close(np.quantile(delta[draws].mean(axis=1),[.025,.975]),reported['interval'],'Fig2 paired intervals')
    cost=read('executor_cost.json')
    check(cost['status']=='COMPLETE' and cost['timed_invocations']==19200 and len(cost['cases'])==12,'cost case coverage')
    overheads=[]
    for case in cost['cases']:
        a=np.asarray(case['process_block_medians_ms'])
        check(a.shape==(8,2,4) and np.isfinite(a).all() and (a>0).all(),'cost shape and values')
        means=a.mean(axis=(0,1))
        for i,method in enumerate(cost['methods']):
            close(means[i],case['methods'][method]['mean_block_median_ms'],'Table4 means')
        ratio=means[1]/means[2]
        close(ratio,case['contrasts']['auto-batched_vs_manual-early']['ratio'],'cost ratio')
        overheads.append((ratio-1)*100)
    check([f'{min(overheads):.1f}',f'{max(overheads):.1f}']==['5.8','22.9'],'abstract full cost range')
    check(read('public_model_cpu_validation.json')['report_sha256']==sha(ROOT/'evidence/public_model_cpu.json'),'public model validation binding')

    source_hashes={}
    if manuscript:
        from pypdf import PdfReader
        text = (ROOT/'main.tex').read_text() + ''.join(p.read_text() for p in (ROOT/'sections').glob('*.tex'))
        for value in ['5.8--22.9', '78.50', '45.14/78.82', '103,680', '8/85', '12/224', 'Declared topology', 'post-hoc', 'not an equivalence test']:
            check(value in text,'required explicit claim: '+value)
        check('structural ceiling' not in text and 'device service remains unchanged' not in text,'removed overstrong causal statements')
        check('Rui~Zhou\\thanks{Corresponding author:' in text,'corresponding author preserved')
        for path in (ROOT/'figures').glob('*manifest.json'):
            record=json.loads(path.read_text())
            for name,digest in record.get('outputs',{}).items():
                check(sha(ROOT/'figures'/name)==digest,'figure manifest '+name)
        pdf=PdfReader(ROOT/'main.pdf')
        check(len(pdf.pages)==12,'12 pages including references')
        check(len(re.findall(r'\\bibitem\{', (ROOT/'main.bbl').read_text()))==22,'22 cited references')
        log=(ROOT/'main.log').read_text(errors='replace')
        check(not re.search(r'Overfull|undefined|Rerun to get|Label\(s\) may have changed',log),'no overflow or unresolved references')
        source_hashes={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in
                       [ROOT/'main.tex',ROOT/'references.bib',ROOT/'llncs.cls',ROOT/'splncs04.bst',*sorted((ROOT/'sections').glob('*.tex'))]}
    result=dict(status='COMPLETE',checks=len(checked),inference_executed=False,cuda_used=False,
                raw_deadline_archive_reconstructed=bool(archive),pdf_sha256=sha(ROOT/'main.pdf') if manuscript else None,
                manuscript_checked=manuscript,validator_sha256=sha(Path(__file__)),
                source_hashes=source_hashes,load_runs=72,cutoff_runs=96,deadlines_ms=cut['deadlines_ms'],
                scope='Frozen aggregate/lineage/statistical reconstruction and manuscript checks; not an independent team replication or a new GPU execution.')
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('x') as f:
        json.dump(result,f,indent=2)
        f.write('\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--archive',type=Path)
    parser.add_argument('--evidence-only',action='store_true',help='Check data without requiring a built manuscript.')
    args=parser.parse_args()
    run(args.output,args.archive,not args.evidence_only)
