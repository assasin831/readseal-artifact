import unittest
from analyze_deadlines_v7 import counts


class DeadlineTests(unittest.TestCase):
    def test_inclusive_cutoff(self):
        self.assertEqual(counts([99999999, 100000000, 100000001], [100]), [2])

    def test_monotone_and_empty(self):
        self.assertEqual(counts([], [80, 100, 200]), [0, 0, 0])
        self.assertEqual(counts([80000000, 150000000], [80, 100, 200]), [1, 1, 2])

    def test_reject_negative_duration(self):
        with self.assertRaises(AssertionError):
            counts([-1], [100])


if __name__ == '__main__':
    unittest.main()
