# ReadSeal NPC V7: Sensitivity Evidence

Requires Python 3.10+ and NumPy. No GPU, PyTorch or LaTeX installation needed:

```sh
python -m unittest discover -s tools -p test_deadlines_v7.py -v
python tools/validate_submission_v7.py --evidence-only --output validation-new.json
```

The checker reconstructs per-run means and 20,000 paired-repeat intervals for
the new 72-run load window, both old 96/54-run windows, and eight deadline cutoffs
over 96 primary runs. It checks all isolated-cost cases and frozen lineage.
Output paths must be fresh. `SOURCE_INVENTORY.json` inventories every file.
The file inventory is not a digital signature.

For full deadline reconstruction, download the unchanged `npc-followup-v6`
archive at https://github.com/assasin831/readseal-artifact and extract its
`grouped_requests.zip`:

```sh
python tools/validate_submission_v7.py --evidence-only --archive /path/to/grouped_requests.zip --output validation-with-raw-new.json
```

The added raw check verifies all 192 original JSON files and recomputes the
deadline result. This is CPU reconstruction, not new inference or a new team's
replication. Load-window raw records are not included here; their hashes and
the completed remote audit are preserved in the compact frozen aggregates.
See `ARTIFACT_V7.md` for findings, failures kept separate, and unmeasured scope.

Existing notices retain their terms. No new broad license or rights over
third-party dependencies are asserted by this packaging operation.
