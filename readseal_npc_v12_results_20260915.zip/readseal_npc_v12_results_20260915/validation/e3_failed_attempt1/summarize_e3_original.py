"""Count declared review-field changes, not edits by humans or lines of code."""
import csv
import hashlib
import json
from pathlib import Path
import statistics

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'results/npc_v12_cpu_attempt1'
EV=ROOT/'paper/readseal_npc_2026_v11_submission/evidence'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def csv_write(path,rows):
    with path.open('x',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)


def main():
    out=BASE/'e3'
    out.mkdir(exist_ok=False)
    raw=json.loads((BASE/'raw/maintenance_report.json').read_text())
    proof=json.loads((EV/'maintenance_validation.json').read_text())
    assert raw['status']==proof['status']=='COMPLETE'
    assert sha(BASE/'raw/maintenance_report.json')==proof['report_sha256']
    timing=json.loads((BASE/'raw/e3_reanalysis_report.json').read_text())
    assert timing['status']=='COMPLETE' and len(timing['rows'])==20 and timing['cuda_initialized'] is False
    ts={r['key']:r for r in timing['rows']}
    for r in ts.values():
        assert len(r['raw_nanoseconds'])==12 and min(r['raw_nanoseconds'])>0
        assert statistics.median(r['raw_nanoseconds'])/1e9==r['reanalysis_seconds']
    snapshots={(r['model'],r['edit']):r for r in proof['snapshots']}
    reviews={(r['model'],r['edit']):r['review'] for r in raw['cases']}
    stale={(r['model'],r['edit']):r for r in raw['stale_reviews']}
    rows=[]
    def add(key,model,before,after,fields,operative,stale_text,timekey,source,notes):
        t=ts[timekey]
        rows.append(dict(case=key,model=model,prefix_total_before=before,prefix_total_after=after,
            manual_fields_changed=';'.join(fields),manual_edit_count=len(fields),
            stale_rule_outcome=stale_text,readseal_edits=0,reanalysis_seconds=t['reanalysis_seconds'],
            manual_runtime_fields_changed=';'.join(operative),manual_runtime_field_count=len(operative),
            count_unit='changed fields in frozen review records, NOT patch lines or observed human edits',
            readseal_edit_scope='manual source-reader/boundary annotations supplied to the constructor only',
            common_work_excluded='export, model replacement, topology, native contracts, operator review, output dependencies',
            timing_scope=timing['plan']['timer'],timing_repetitions=12,
            loaded_prefix_total_timed=f'{t["prefix_operations"]}/{t["total_operations"]}',
            source=source,notes=notes))
    def location(s):
        return f'{s["prefix_operations"]}/{s["total_operations"]}'
    for model in ['transfusion','resnet']:
        for edit in ['alias_chain','early_read','middle_read','late_read','late_alias_read','remove_late_read','private_probe']:
            rejected=stale[model,edit]
            assert rejected['rejected']
            previous=rejected['previous']
            before,after=reviews[model,previous],reviews[model,edit]
            fields=[f for f in ('readers','boundary','graph_sha256') if before[f]!=after[f]]
            operative=[f for f in fields if f in ('boundary','graph_sha256')]
            assert 'graph_sha256' in operative
            t=ts[f'{model}:{edit}']; snap=snapshots[model,edit]
            assert t['readers']==snap['readers'] and t['boundary']==snap['boundary']
            assert location(t)==location(snap)
            add(f'{model}:{previous}->{edit}',model,location(snapshots[model,previous]),location(snap),fields,operative,
                'MEASURED: stale graph-hash rejection before execution',f'{model}:{edit}',
                'maintenance_report.json + maintenance_validation.json',
                'The readers list is a frozen review record, not consulted by EvolvedManual execution; graph hash can be regenerated mechanically. No observed developer error.')
    fold=json.loads((BASE/'raw/fold_construction.json').read_text())
    gate=json.loads((BASE/'raw/fold_gate_report_preserved_failed.json').read_text())
    fv=json.loads((EV/'folding_validation.json').read_text())
    assert fv['status']=='COMPLETE' and sha(BASE/'raw/fold_gate_report_preserved_failed.json')==fv['original_report_sha256']
    assert len(gate['stale_review_rejections'])==2
    def fold_row(model):
        entry=next(m for m in fold['models'] if m['model']==model)
        def desc(art):
            calls=[n for n in art['graph'] if n[0]=='call_function']
            names=[n[1] for n in calls]
            boundary='convolution' if model=='transfusion' else 'add'
            return dict(boundary=boundary,prefix_operations=names.index(boundary)+1,total_operations=len(names),
                graph_sha256=hashlib.sha256(json.dumps(art['graph'],sort_keys=True).encode()).hexdigest())
        a,b=desc(entry['base_artifact']),desc(entry['transformed_artifact'])
        assert a['graph_sha256']!=b['graph_sha256'] and a['boundary']==b['boundary']
        assert any(r['model']==model for r in gate['stale_review_rejections'])
        add(model+':base->BN-folded',model,location(a),location(b),['graph_sha256'],['graph_sha256'],
            'MEASURED: stale deployment graph-hash rejection; corrected independent validation preserves failed campaign ending',
            model+':folded','fold_construction.json + folding_validation.json + preserved gate report',
            'Semantic boundary unchanged; refreshed binding still required. Folded and original outputs were compared at frozen tolerance, not claimed bit-identical.')
    fold_row('transfusion')
    public=json.loads((EV/'public_model_cpu.json').read_text())
    pv=json.loads((EV/'public_model_cpu_validation.json').read_text())
    assert pv['status']=='COMPLETE' and sha(EV/'public_model_cpu.json')==pv['report_sha256']
    assert public['stale_review_rejected_by_hash'] and not public['cuda_initialized']
    a,b=(next(c for c in public['cases'] if c['model']==m)['review'] for m in ['resnet18','resnet50'])
    fields=[f for f in ('boundary','graph_sha256') if a[f]!=b[f]]
    add('public:ResNet18->ResNet50','resnet18->resnet50',f'{a["reviewed_call_index_1based"]}/{a["total_calls"]}',
        f'{b["reviewed_call_index_1based"]}/{b["total_calls"]}',fields,fields,
        'MEASURED CPU: old review rejected by graph hash','resnet50:public',
        'public_model_cpu.json + public_model_cpu_validation.json',
        'Controlled public-model substitution, not production migration. Saved in-memory node counts differ from reloaded exports; timed counts are reported separately.')
    assert len(rows)==16
    csv_write(out/'E3_maintenance_16_transitions.csv',rows)
    core=list(rows)
    fold_row('resnet')
    csv_write(out/'E3_additional_resnet_folding.csv',rows[-1:])
    times=[dict(case=r['key'],model=r['model'],prefix_ops=r['prefix_operations'],total_ops=r['total_operations'],
        median_seconds=r['reanalysis_seconds'],mean_seconds=r['mean_seconds'],min_seconds=r['min_seconds'],
        max_seconds=r['max_seconds'],repetitions=12,scope=timing['plan']['timer']) for r in timing['rows']]
    csv_write(out/'E3_all_20_snapshot_timings.csv',times)
    result=dict(status='COMPLETE',transitions=16,additional_folding_transitions=1,timed_snapshots=20,
        synthetic_transitions=14,synthetic_unique_graphs=proof['unique_graphs'],
        manual_review_fields_total=sum(r['manual_edit_count'] for r in core),
        manual_runtime_fields_total=sum(r['manual_runtime_field_count'] for r in core),
        runtime_boundary_changes=sum('boundary' in r['manual_runtime_fields_changed'].split(';') for r in core),
        generated_binding_refreshes=sum('graph_sha256' in r['manual_runtime_fields_changed'].split(';') for r in core),
        readseal_manual_boundary_annotations=0,developer_effort_measured=False,developer_bug_rate_measured=False,
        avoided_incorrect_stale_mapping=True,
        warning='The six stream-only overwrite failures belong to a different ablation. None is attributed to the complete stale-guarded manual baseline.',
        inference_executed=False,cuda_used=False,files={p.name:sha(p) for p in out.glob('*.csv')},
        sources={str(p):sha(p) for p in [BASE/'raw/maintenance_report.json',BASE/'raw/e3_reanalysis_report.json',
            BASE/'raw/fold_construction.json',BASE/'raw/fold_gate_report_preserved_failed.json',
            EV/'maintenance_validation.json',EV/'folding_validation.json',EV/'public_model_cpu.json',EV/'public_model_cpu_validation.json']},
        script_sha256=sha(Path(__file__)))
    (out/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
    (out/'COMPLETE').write_text('E3 transition reconstruction complete\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('files','sources')}))


if __name__=='__main__':
    main()
