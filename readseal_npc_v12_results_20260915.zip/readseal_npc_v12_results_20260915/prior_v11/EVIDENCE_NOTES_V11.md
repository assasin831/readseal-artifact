# ReadSeal V11: evidence details accompanying the narrative revision

V11 changes exposition, not experiments. All input evidence, model exports,
figure PDFs, design equations, protocol rules, and safety premises are unchanged
from V10. This note retains details condensed from the main text. The immutable
public evidence entry point remains:

https://github.com/assasin831/readseal-artifact/tree/npc-submission-v10

## Measurement and scope

- All four mechanisms were implemented by the paper's authors. Manual early is
  structurally separate from the checked executor, not an independent team's
  replication or a developer study.
- The recorded environment does not establish every historical host detail:
  CPU model, Python patch version, operating-system version, and driver version
  are not all available for every campaign. Unrecorded fields are not inferred.
- The evaluated scope is one GPU architecture, fixed shapes, reviewed functional
  operators, declared topology, and single-stream children. Safety additionally
  depends on the operator, execution, and deployment premises in Section 4.
- Correctness checks, synthetic edit cases, and a public architecture substitution
  do not quantify developer effort, real bug frequency, or production migration.
  No burst/jitter workload or deployment-prevalence study is claimed.

## Maintenance and executable binding

The 14 stale manual-hash cases are constructed consistency failures, not observed
developer mistakes. A matching graph hash alone is not a semantic proof of the
manual release boundary. Both mechanisms still depend on supplied topology,
native contracts, and output dependencies. Sources: `maintenance_validation.json`,
`folding_validation.json`, and `public_model_cpu*.json` in `evidence/`.

The ResNet-18 exports 12/123 and 8/85 identify the same last source-reading residual
addition. The reloaded export includes 38 unused BatchNorm tuple-index nodes;
this difference is unrelated to the separate batch-normalization-folding case.
The graph extraction and reconstruction are in `evidence/export_audit/`.
These counts locate structural boundaries; they are not elapsed-time fractions
or measurements of developer effort.

The 22 rejected CUDA binding cases cover metadata, publication identity,
certificate, code, globals, state-version, and program substitutions. Rejection
precedes the affected stage. A rejected suffix can follow a completed prefix;
abort drains started work and suppresses output publication. Sources:
`evidence/binding.json` and `evidence/binding_validation.json`.

## Delivery accounting and confirmation

The 96-run primary campaign and 54-run confirmatory campaign are separately
analyzed windows; their request populations are not pooled.

- One-slot Full retention: all six primary runs alternate accept/busy. Of 8,640
  offers, 4,320 receipts are timely and none late. The resulting 60.00 bundles/s
  is an observed interaction with periodic arrivals, not a universal service cap.
- Uncapped two-slot Grouped/Full: 5,688/5,700 receipts, of which 3,893/495 are late.
  Lateness accounts for 47.19 of the 47.36 bundles/s goodput loss; the remaining
  approximately 0.17 bundles/s reflects the receipt-count difference.
- Confirmatory one-slot Grouped-minus-Full differences are 18.40 [18.10, 18.61]
  bundles/s uncapped and 18.51 [18.32, 18.67] at K=8. The main text reports their
  18.40--18.51 range; Figure 2b retains the individual intervals.
- Confirmatory R=2,K=8: the difference is 0.01 [-0.06, 0.08] bundles/s. This is a
  measured paired interval, not a prespecified equivalence test.
- Neither delivery window establishes a Grouped-over-Original goodput gain.
  The added 63.3 MiB source slot fits the tested device; the experiment does not
  establish memory exhaustion or the prevalence of one-slot constraints.

Sources: `evidence/grouped.json`, `evidence/confirmatory.json`, and their validation
records. Lower protected storage measures earlier availability of allocated
buffers. Both device peaks remain 5,142 MiB; release does not deallocate the pool.

## Trace and cutoff interpretation

The uncapped two-slot Grouped/Full queue-wait bounds are
49.89--49.96 / 24.15--24.21 ms. Exact enqueue instants were not logged. Host
admission and output-wait timestamps identify upstream waiting as the dominant
observed difference; they do not isolate device service time or establish that
every executor effect is equal. Source: `evidence/grouped_trace.json`.

The eight-cutoff analysis uses the same 192 primary report/sink files. It changes
the receipt cutoff, not execution, admission, or scheduling. It is not a new
deadline-aware scheduler experiment. `tools/validate_submission_v7.py` can
reconstruct the counts from the hash-bound `grouped_requests.zip` in the public
follow-up evidence archive.

## Instrumented profiling

The 2,560-call instrumented profile reports Grouped/Manual admission times of
0.67/0.34 ms for the head and 0.71/0.39 ms for ResNet. Instrumentation itself adds
7--34% wall time. Overlapping host/device costs are not additive, so these figures
are diagnostic, not replacements for the isolated, uninstrumented measurements
in Table 3. Sources: `evidence/profile.json`, `profile_validation.json`,
`executor_cost.json`, and `v10_data_manifest.json`.

## Revision checks

`qa/evidence_reconstruction_v11.json` records a fresh CPU-only reconstruction of
the saved evidence. `qa/submission_v11.json` records manuscript, template,
reference, font, numeric-table, and unchanged-input checks. Neither constitutes
new model execution or independent-team replication.
