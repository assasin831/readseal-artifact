"""Verify bounded static-survey dispositions and export a plotting table."""
import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def main(root, output):
    report = read(root / 'report.json')
    plan = read(root / 'plan.json')
    assert report['status'] == 'COMPLETE_SURVEY' and (root / 'COMPLETE').is_file()
    assert report['plan'] == plan and plan['weights'] is None
    assert not report['gpu_used'] and not report['cuda_initialized']
    assert not report['accuracy_measured']
    assert len(report['rows']) == len(plan['models']) == 14
    assert [r['model'] for r in report['rows']] == plan['models']
    assert dict(collections.Counter(r['status'] for r in report['rows'])) == report['counts']
    rows, files = [], {}
    for row in report['rows']:
        folder = root / row['model']
        if row['status'] != 'NOT_RUN_BUDGET':
            assert read(folder / 'record.json') == row
            files[str((folder / 'record.json').relative_to(root))] = sha(folder / 'record.json')
        assert row['supported'] == (row['status'] == 'SUPPORTED_STATIC')
        assert len(row['unsupported_ops']) == len(set(row['unsupported_ops']))
        if row.get('graph_sha256'):
            assert sha(folder / 'graph.txt') == row['graph_sha256']
            assert sha(folder / 'graph_code.py') == row['graph_code_sha256']
            files[str((folder / 'graph.txt').relative_to(root))] = row['graph_sha256']
            files[str((folder / 'graph_code.py').relative_to(root))] = row['graph_code_sha256']
            assert row['total_ops'] == sum(row['operator_counts'].values())
            assert min(row['operator_counts'].values()) > 0
            assert set(row['unsupported_ops']).issubset(row['operator_counts'])
        if row['supported']:
            assert not row['unsupported_ops'] and not row['unsupported_reasons']
            assert row['boundary'] in row['readers']
            assert 0 < row['prefix_ops'] <= row['total_ops']
            assert row['private_carry_checked']
            assert ('%' + row['boundary'] + ' ') in (folder / 'graph.txt').read_text()
        elif row['status'] == 'UNSUPPORTED_OPERATOR':
            assert row['unsupported_ops']
            assert set(row['unsupported_ops']) == set(row['unsupported_reasons'])
        elif row['status'] == 'UNSUPPORTED_PLAN':
            assert not row['unsupported_ops'] and row['reason']
        else:
            assert row['status'] in ('EXPORT_OR_HARNESS_FAILURE', 'NOT_RUN_BUDGET')
        rows.append(dict(model=row['model'], supported=row['supported'],
            unsupported_ops=';'.join(row['unsupported_ops']), prefix_ops=row['prefix_ops'],
            total_ops=row['total_ops'], status=row['status'], interface=row.get('interface', ''),
            input_shape=json.dumps(row.get('input_shape')), boundary=row.get('boundary', ''),
            failure_type=row.get('failure_type', ''), reason=row.get('reason', ''),
            scope='CPU export/static lowering only; weights=None; no numerical or GPU validation'))
    output.mkdir(exist_ok=False)
    with (output / 'E6_operator_coverage.csv').open('x', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    validation = dict(status='COMPLETE', models=14, dispositions=report['counts'],
        report_sha256=sha(root / 'report.json'), plan_sha256=sha(root / 'plan.json'),
        csv_sha256=sha(output / 'E6_operator_coverage.csv'), verified_files=files,
        independent_scope='Plan, dispositions, graph files, boundaries and counts reconstructed; the local host does not rerun Torch export or the remote analyzer.',
        supported_does_not_imply_numerical_or_gpu_validation=True,
        source_sha256=sha(Path(__file__)))
    (output / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n')
    (output / 'COMPLETE').write_text('Static survey disposition audit complete\n')
    print(json.dumps({k: v for k, v in validation.items() if k != 'verified_files'}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--raw-root', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    main(args.raw_root, args.output)
