"""Lossless content-addressed evidence transfer; original files remain untouched."""
import argparse
import collections
import io
import json
from pathlib import Path, PurePosixPath
import shutil
import tarfile
from archive_results import REMOTE, MEMBERS, sha


def pack():
    ordinary = REMOTE / 'results/npc_v12_results_all_20260915_attempt1.tar.json'
    prior = json.loads(ordinary.read_text())
    assert prior['status'] == 'COMPLETE'
    output = REMOTE / 'results/npc_v12_results_cas_20260915_attempt1.tar.gz'
    assert not output.exists() and not output.with_suffix('.json').exists()
    files, dirs, blobs = [], [], {}
    for name in MEMBERS:
        root = REMOTE / name
        for path in [root, *sorted(root.rglob('*'))]:
            assert not path.is_symlink() and path.resolve().is_relative_to(REMOTE)
            rel = path.relative_to(REMOTE).as_posix()
            if path.is_dir():
                dirs.append(rel)
                continue
            assert path.is_file()
            digest = sha(path)
            size = path.stat().st_size
            files.append(dict(path=rel, sha256=digest, bytes=size))
            if digest in blobs:
                assert blobs[digest].stat().st_size == size
            else:
                blobs[digest] = path
    manifest = dict(schema='readseal-evidence-cas-v1', files=files, directories=dirs,
        original_root=str(REMOTE), members=MEMBERS, ordinary_archive_record=prior,
        scope='Lossless file-content deduplication only; no observation, source or record removed.',
        restore='Restore every manifest path by copying the exact blob bytes; no symbolic or hard links required.')
    data = (json.dumps(manifest, indent=2) + '\n').encode()
    with tarfile.open(output, 'x:gz', compresslevel=1) as tar:
        info = tarfile.TarInfo('manifest.json'); info.size = len(data); info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
        for digest, path in sorted(blobs.items()):
            tar.add(path, arcname='blobs/' + digest, recursive=False)
    record = dict(status='COMPLETE', archive=str(output), sha256=sha(output), bytes=output.stat().st_size,
        file_count=len(files), unique_blobs=len(blobs),
        uncompressed_file_bytes=sum(r['bytes'] for r in files),
        unique_blob_bytes=sum(p.stat().st_size for p in blobs.values()),
        manifest_sha256=__import__('hashlib').sha256(data).hexdigest(), script_sha256=sha(Path(__file__)))
    output.with_suffix('.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record))


def restore(archive, output, digest):
    assert sha(archive) == digest and not output.exists()
    blobroot = output.with_name(output.name + '_cas_blobs')
    assert not blobroot.exists()
    expected = None; seen = set(); manifest = None
    with tarfile.open(archive, 'r|gz') as tar:
        for member in tar:
            assert member.isfile(), 'only regular files are allowed'
            stream = tar.extractfile(member)
            if manifest is None:
                assert member.name == 'manifest.json'
                manifest = json.load(stream)
                assert manifest['schema'] == 'readseal-evidence-cas-v1'
                names = [r['path'] for r in manifest['files']] + manifest['directories']
                assert len(names) == len(set(n.casefold() for n in names))
                for name in names:
                    p = PurePosixPath(name)
                    assert not p.is_absolute() and '..' not in p.parts and ':' not in name
                    assert any(p.is_relative_to(PurePosixPath(m)) for m in MEMBERS)
                    assert (output / name).resolve().is_relative_to(output.resolve())
                expected = {r['sha256']: r['bytes'] for r in manifest['files']}
                assert all(len(h) == 64 and set(h).issubset('0123456789abcdef') for h in expected)
                blobroot.mkdir(parents=True)
                continue
            assert member.name.startswith('blobs/')
            h = member.name[6:]
            assert h in expected and h not in seen and member.size == expected[h]
            target = blobroot / h
            with target.open('xb') as f:
                shutil.copyfileobj(stream, f, 1 << 20)
            assert sha(target) == h
            seen.add(h)
    assert seen == set(expected)
    output.mkdir(parents=True)
    for name in manifest['directories']:
        (output / name).mkdir(parents=True, exist_ok=True)
    for row in manifest['files']:
        destination = output / row['path']
        assert not destination.exists()
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(blobroot / row['sha256'], destination)
        assert destination.stat().st_size == row['bytes'] and sha(destination) == row['sha256']
    record = dict(status='COMPLETE', files_restored=len(manifest['files']),
        unique_blobs=len(seen), every_restored_file_hash_verified=True,
        archive_sha256=digest, archive=str(archive), output=str(output),
        original_file_bytes=sum(r['bytes'] for r in manifest['files']), source_sha256=sha(Path(__file__)))
    (output.parent / (output.name + '_restore_validation.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('pack', 'restore'))
    parser.add_argument('--archive', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--sha256')
    a = parser.parse_args()
    if a.mode == 'pack': pack()
    else: restore(a.archive, a.output, a.sha256)
