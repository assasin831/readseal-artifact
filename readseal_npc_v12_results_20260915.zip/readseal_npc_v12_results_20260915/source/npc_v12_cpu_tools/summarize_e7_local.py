import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'results/npc_v12_cpu_attempt1'
path=BASE/'raw/host_environment.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads(path.read_text())
prepared=json.loads((BASE/'raw/prepared.json').read_text())
remote='/www/readseal_ipdps_revision_v6/results/npc_v12_short_20260915_attempt1/host_environment.json'
assert prepared['bindings'][remote]==sha(path) and not d['cuda_initialized']
assert d['torch']=='2.1.2+cu121' and d['cuda_build']=='12.1' and d['tensorrt']=='10.3.0'
cpu={r['field'].rstrip(':'):r['data'] for r in json.loads(d['commands']['cpu'])['lscpu']}
out=BASE/'e7'
out.mkdir(exist_ok=False)
lines=['E7 - dated host inventory', 'UTC: '+d['utc'],
    'CPU: '+cpu['Model name'], 'Logical CPUs: '+cpu['CPU(s)'],
    'Sockets / cores per socket / threads per core: '+ ' / '.join(cpu[k] for k in ['Socket(s)','Core(s) per socket','Thread(s) per core']),
    'Kernel: '+d['kernel'], 'Python: '+d['python'], 'Interpreter: '+d['executable'],
    'PyTorch: '+d['torch'], 'CUDA build: '+d['cuda_build'],
    'cuDNN reported integer: '+str(d['cudnn']), 'TensorRT: '+d['tensorrt'],
    'GPU binding: '+d['gpu_binding'], '', d['commands']['gpu'],d['os_release'],
    'Experiment settings: one intra-op thread; TF32 disabled; cuDNN benchmark disabled.',
    'GPU1 MIG configuration was preserved; no compute processes were present at preparation.',
    'This inventory describes the new V12 window. Missing CPU/OS/driver fields for older',
    'campaigns remain unrecorded; same GPU UUID and matched software/source hashes do not',
    'retroactively establish every historical host setting.',
    'JSON SHA-256: '+sha(path)]
(out/'E7_host_environment.txt').write_text('\n'.join(lines)+'\n')
(out/'validation.json').write_text(json.dumps(dict(status='COMPLETE',inference_executed=False,
    source_sha256=sha(path),prepared_sha256=sha(BASE/'raw/prepared.json'),
    report_sha256=sha(out/'E7_host_environment.txt'),script_sha256=sha(Path(__file__))),indent=2)+'\n')
(out/'COMPLETE').write_text('Dated E7 inventory validated\n')
print(json.dumps(dict(status='COMPLETE',cpu=cpu['Model name'],threads=cpu['CPU(s)'])))
