"""Assemble verified V12 writing inputs without modifying the manuscript."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil
import zipfile
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
CPU = ROOT / 'results/npc_v12_cpu_attempt1'
PAPER = ROOT / 'paper/readseal_npc_2026_v11_submission'
STAGES = {'e3': 'e3_fix1', 'e4': 'e4', 'e7': 'e7'}


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_text())


def copy(source, target):
    assert source.is_file() and not target.exists()
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    assert sha(source) == sha(target)


def table(path, rows):
    with path.open('x', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def compact(row):
    v = row['metrics']['goodput_hz']
    lo, hi = v['pointwise_ci95']
    return f'{v["a_mean"]:.3f} | {v["b_mean"]:.3f} | {v["paired_difference"]:+.3f} [{lo:+.3f}, {hi:+.3f}]'


def main(raw, local_validation, archive, output):
    assert not output.exists() and not output.with_suffix('.zip').exists()
    delivery = read(local_validation / 'validation.json')
    assert delivery['status'] == 'COMPLETE' and delivery['runs'] == 150
    restored = raw.parents[1]
    restore_validation = restored.with_name(restored.name + '_restore_validation.json')
    assert read(restore_validation)['status'] == 'COMPLETE'
    assert read(restore_validation)['every_restored_file_hash_verified']
    analyses = {phase: read(raw / phase / 'audit/analysis.json') for phase in ('e1', 'e2')}
    assert len(analyses['e1']['rows']) == 108 and len(analyses['e2']['rows']) == 36
    assert all(a['status'] == 'COMPLETE' for a in analyses.values())
    for name in STAGES.values():
        assert read(CPU / name / 'validation.json')['status'] == 'COMPLETE'
    output.mkdir(parents=True)
    e12 = output / 'E1_E2'; e12.mkdir()
    for phase in ('e1', 'e2'):
        copy(raw / phase / 'audit/analysis.json', e12 / (phase.upper() + '_analysis.json'))
        copy(raw / phase / 'audit/runs.csv', e12 / (phase.upper() + '_runs.csv'))
    shutil.copytree(local_validation, output / 'validation/gpu_independent_local')
    copy(restore_validation, output / 'validation/raw_restore.json')
    for name, folder in STAGES.items():
        shutil.copytree(CPU / folder, output / name.upper())
    shutil.copytree(CPU / 'e3', output / 'validation/e3_failed_attempt1')
    e6 = CPU / 'e6'
    if e6.exists():
        assert read(e6 / 'validation.json')['status'] == 'COMPLETE'
        shutil.copytree(e6, output / 'E6')
    shutil.copytree(PAPER / 'evidence', output / 'prior_v11/evidence')
    copy(PAPER / 'EVIDENCE_NOTES_V11.md', output / 'prior_v11/EVIDENCE_NOTES_V11.md')
    for filename in ('maintenance_report.json', 'fold_construction.json',
                     'fold_gate_report_preserved_failed.json', 'e3_reanalysis_report.json',
                     'host_environment.json', 'prepared.json'):
        copy(CPU / 'raw' / filename, output / 'cpu_raw' / filename)
    for p in sorted((CPU / 'raw').glob('profile_r*.json')):
        copy(p, output / 'cpu_raw' / p.name)
    for source in ('npc_v12_short', 'npc_v12_cpu_tools'):
        shutil.copytree(ROOT / 'prototype' / source, output / 'source' / source,
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    copy(ROOT / 'REVISION_PLAN_V12.md', output / 'planning/REVISION_PLAN_V12.md')
    (output / 'raw').mkdir()
    (output / 'raw/ARCHIVE.json').write_text(json.dumps(dict(
        separately_distributed_archive=archive.name, original_local_path=str(archive),
        restored_local_root=str(restored), format='readseal-evidence-cas-v1',
        sha256=sha(archive), bytes=archive.stat().st_size,
        note='The full GPU/CPU raw archive is distributed separately to keep this writing package small.'), indent=2) + '\n')
    source_bytes = read(raw / 'e1' / analyses['e1']['rows'][0]['run'] / 'report.json')['source_bytes']
    rows = []
    for phase, analysis in analyses.items():
        for condition in sorted({r['condition'] for r in analysis['rows']}):
            for method in ('auto-batched', 'manual-early', 'manual-full'):
                rr = [r for r in analysis['rows'] if r['condition'] == condition and r['method'] == method]
                assert len(rr) == 6
                r = rr[0]
                row = dict(experiment=phase, condition=condition, method=method, repeats=6,
                    model=r['model'], late=r['late'], ring=r['ring'], cap=r['cap'], rate_hz=r['rate_hz'],
                    offered_recipient_bundles_hz=r['rate_hz'] * 4)
                for field in ('goodput_hz', 'publications', 'timely', 'correct_late', 'producer_late',
                              'pool_exhausted', 'credit_exhausted', 'queue_loss', 'mean_protected_mib',
                              'protected_byte_seconds', 'device_peak_mib', 'source_hold_mean_ms',
                              'private_after_read_mean_ms', 'planned_to_admit_mean_ms',
                              'execution_mean_ms', 'receipt_mean_ms', 'receipt_p95_ms'):
                    row[field + '_mean'] = float(np.mean([x[field] for x in rr]))
                row['protected_interval_fraction_mean'] = row['mean_protected_mib_mean'] * 2**20 / (source_bytes * r['ring'])
                assert 0 <= row['protected_interval_fraction_mean'] <= 1
                chosen = next(s for s in analysis['summary'] if s['condition'] == condition and
                    method in (s['a_method'], s['b_method']))
                key = 'a_pointwise_ci95' if method == chosen['a_method'] else 'b_pointwise_ci95'
                row['goodput_pointwise_ci95_low'], row['goodput_pointwise_ci95_high'] = chosen['metrics']['goodput_hz'][key]
                rows.append(row)
    table(e12 / 'E1_E2_method_means.csv', rows)
    formal = [r for a in analyses.values() for r in a['rows']]
    totals = {k: int(sum(r[k] for r in formal)) for k in ('arrivals', 'publications', 'timely',
        'correct_late', 'producer_late', 'pool_exhausted', 'credit_exhausted', 'queue_loss')}
    assert totals['arrivals'] == totals['publications'] + sum(totals[k] for k in
        ('producer_late', 'pool_exhausted', 'credit_exhausted', 'queue_loss'))
    assert totals['publications'] == totals['timely'] + totals['correct_late']
    e3 = read(CPU / STAGES['e3'] / 'validation.json')
    guide = [
        '# ReadSeal V12: Verified Results for Writing', '',
        'This package adds experiments and analysis, not a rewritten manuscript. The V11 paper is unchanged.', '',
        '## Start Here',
        '- E1_E2/E1_runs.csv: 108 new formal runs, R=1, K=0, rates 10/15/20/25/30/40 Hz.',
        '- E1_E2/E2_runs.csv: 36 separate new formal runs, R=1, K=0, 30 Hz, base and late-read variants.',
        '- E1_E2/E1_E2_method_means.csv: means, goodput error bars, source hold, occupancy and lateness diagnostics.',
        '- validation/gpu_independent_local/E1_E2_paired_summary.csv: paired differences and pointwise 95% intervals.',
        '- E3/: review-field changes, 20 CPU constructor timing snapshots, and explicit counting scope.',
        '- E4/: normal host phases, separate inclusive profiles, and diagnostic comparisons.',
        '- E7/: dated environment for this window only.',
        '- prior_v11/: all compact evidence used by the V11 manuscript; retained as separate measurement windows.',
        '- cpu_raw/: underlying CPU records. raw/ARCHIVE.json identifies the separately distributed full raw archive.',
        '- source/: the new experiment, audit and packaging programs.', '',
        'DATA_DICTIONARY.md defines counts, timestamps, units and missing values.', '',
        '## Measurement Contract',
        'There are six paired whole-run repetitions per condition. Each formal run has 2 s warm-up, '
        '12 s measured planned-arrival cohort and a complete drain. Four recipients are offered per source publication. '
        'A goodput event is a delivered recipient bundle with verified source identity, matching reference outputs '
        'and receipt within 100 ms of its planned arrival. Publication-rate Hz is not recipient-bundle Hz. '
        'All new GPU runs use the full TransFusion-head A/B/C pipeline and the frozen GPU0 implementation.',
        'Intervals use 20,000 paired whole-run bootstrap draws (n=6 pairs), not per-request independent samples. '
        'They are pointwise, not simultaneous curve bands. Six smoke runs are not pooled into formal estimates. '
        'The overlapping E1 30 Hz base condition and E2 base condition remain separate fresh observations.', '',
        '## E1: One-Slot Rate Curve',
        '| Source rate (Hz) | ReadSeal goodput | Full-retention goodput | Paired difference [95% CI] |',
        '|---:|---:|---:|---:|']
    for rate in (10, 15, 20, 25, 30, 40):
        c = next(r['condition'] for r in analyses['e1']['rows'] if r['rate_hz'] == rate)
        item = next(s for s in analyses['e1']['summary'] if s['condition'] == c and
                    s['a_method'] == 'auto-batched' and s['b_method'] == 'manual-full')
        guide.append(f'| {rate} | {compact(item)} |')
    guide += ['', '## E2: Delayed Source Read',
        '| Variant | ReadSeal goodput | Full-retention goodput | Paired difference [95% CI] |',
        '|---|---:|---:|---:|']
    for late in (False, True):
        c = next(r['condition'] for r in analyses['e2']['rows'] if r['late'] == late)
        item = next(s for s in analyses['e2']['summary'] if s['condition'] == c and
                    s['a_method'] == 'auto-batched' and s['b_method'] == 'manual-full')
        guide.append(f'| {"Late read" if late else "Base"} | {compact(item)} |')
    guide += ['', '## E3: Maintenance, Not Developer Labor',
        f'The primary table has {e3["transitions"]} transitions: 14 constructed edits, one head BN-folding transformation '
        'and one controlled public ResNet-18 to ResNet-50 substitution. A second BN-folding row is reported separately.',
        f'The records change {e3["manual_review_fields_total"]} review fields, of which '
        f'{e3["manual_runtime_fields_total"]} are runtime-used fields. These include '
        f'{e3["runtime_boundary_changes"]} boundary changes and {e3["generated_binding_refreshes"]} binding refreshes.',
        'A review readers-list is documentary, not consulted by the complete manual executor. A hash refresh can be '
        'mechanically generated. Neither count is observed human editing effort, developer error rate or lines of code. '
        'ReadSeal uses no manually supplied source-reader/boundary annotations in these constructors; export, native '
        'contracts, topology, operator review and output dependencies remain application work. Stale-guarded complete '
        'manual implementations reject stale bindings; failures of the stream-only ablation are not attributed to them.',
        'CPU timing reports the median of 12 BatchProgram constructor calls after one warm-up. It includes '
        'analysis/lowering, owned weight clones and binding, but excludes original tracing/export, I/O, model execution '
        'and GPU copies. It is not GPU deployment latency or developer time.', '',
        'The first local E3 summarizer compared reader-list enumeration order instead of membership. '
        'Its failed attempt and source are preserved under validation/e3_failed_attempt1. '
        'The corrected summarizer checks unique reader membership plus exact boundaries and operation counts. '
        'No constructor timing or GPU inference was repeated for this correction.', '',
        '## E4: Cost Attribution Boundaries',
        'The phase table reconstructs all normal timing records from four diagnostic profiling processes. '
        'The inclusive cProfile table is separate because nested functions and waits must not be summed. '
        'This is isolated child execution, not the complete pipeline. Enrollment was not separately instrumented '
        'and is recorded as missing, not free. Diagnostic admission-gap/wall-gap ratios do not identify removable '
        'overhead or a safe binding-cache speedup bound. Do not subtract this window from an older performance table.', '',
        '## E5 and E6',
        'E5 ResNet complete-pipeline delivery was not run: the frozen pipeline factory only supports TransFusion. '
        'Accepting a model field in a condition does not make that pipeline implemented. Older isolated ResNet costs '
        'and public CPU model-substitution results remain available in prior_v11; they are not ResNet delivery measurements.']
    if e6.exists():
        v = read(e6 / 'validation.json')
        guide += ['E6 is a bounded static survey of 14 predeclared torchvision model tails with weights=None, '
                  'fixed CPU interface examples and the unchanged operator registry. Dispositions: ' +
                  json.dumps(v['dispositions'], sort_keys=True) + '. '
                  'SUPPORTED_STATIC means export/analysis/lowering passed, not numerical equivalence, GPU correctness, '
                  'performance, pretrained accuracy or production support. Export failures remain distinct from unsupported operators.']
    else:
        guide.append('E6 optional static survey is not included; do not invent a coverage denominator or success count.')
    guide += ['', '## Claims These Results Do Not Establish',
        '- A source-hold mean measured on accepted work is not a load-independent service time or precise saturation threshold.',
        '- A rate curve can expose periodic arrival/release phase effects; it does not establish robustness to arrival jitter.',
        '- A late-read boundary removes opportunities for source reuse, but its measured delivery effect also depends on admission and contention. Do not require the difference to equal zero.',
        '- Borrowed-byte occupancy is not freed allocation. Early release must not be described as a measured device-peak reduction without the device-peak data supporting it.',
        '- Explicit admission was helpful in tested overload conditions; an optimal or universally necessary K is not proved.',
        '- A CI including zero does not prove equivalence; a manual baseline by the same authors is not an independent developer study.',
        '- New and old measurement windows must not be pooled post hoc, and unfavorable conditions must not be omitted.', '',
        '## Formal Data Accounting', '```json', json.dumps(totals, indent=2), '```',
        'All 144 formal and six smoke runs passed the frozen request/output validator and full remote reconstruction. '
        'A separate local implementation also reconstructs receipts, loss accounting, source reuse, sample arrays, '
        'raw hashes and paired confidence intervals. Reference .pt containers are hash-checked locally; the remote '
        'Torch validators deserialize and verify their tensors. No GPU inference was retried.', '',
        '## Reproducibility',
        'The separately distributed raw archive preserves absolute original input paths and their hashes. It is an evidence archive, '
        'not a standalone image with all external model weights and runtime dependencies. Prior compact evidence '
        'and EVIDENCE_NOTES_V11 identify old measurement sources. SHA256SUMS.txt covers every file except itself '
        'and the final outer zip. PACKAGE_VALIDATION.json records stage validation hashes.', '']
    guide += ['The raw archive uses a content-addressed manifest plus unique blobs. Every original file was restored '
        'and hash-checked locally. raw/ARCHIVE.json identifies both the archive and the restored directory. '
        'To restore elsewhere, use source/npc_v12_cpu_tools/archive_cas.py with mode restore, --archive, '
        '--output pointing to a new directory, and --sha256 from raw/ARCHIVE.json. '
        'The original ordinary archive and intentionally interrupted large transfer remain preserved; neither is '
        'used in the delivered analysis. Content-addressed packaging does not deduplicate observations or alter statistical weights.', '']
    (output / 'RESULTS_FOR_WRITING.md').write_text('\n'.join(guide))
    dictionary = '''# V12 Data Dictionary

## E1/E2 Counts and Units
- One source publication can be offered to four recipients. Each delivered recipient bundle contains the required composition outputs. Counts are not numbers of individual tensors.
- `rate_hz` is the planned source-publication rate. Offered recipient-bundle rate is four times this value.
- `arrivals` counts measured planned recipient offers, including rejected offers.
- `publications` in the inherited schema counts delivered recipient bundles, NOT accepted source publications.
- `timely` counts delivered, source-verified, reference-matching bundles received by the 100 ms deadline.
- `correct_late` counts valid delivered bundles received after the deadline. It is distinct from wrong output and unknown source.
- `producer_late`, `pool_exhausted`, `credit_exhausted` are rejected recipient offers. A producer-level rejection contributes four offers. `queue_loss` counts individual failed recipient enqueues.
- Counts reconcile as arrivals = publications + rejected offers + queue_loss, and publications = timely + correct_late.
- `goodput_hz` = timely / 12 seconds in formal runs; smoke uses its separately frozen shorter duration.
- `cap=0` disables the additional outstanding-credit bound; the finite ring and recipient queues still exist. It does not mean an infinite system queue.

## Time and Storage
- `publish_ns` records sink receipt immediately after Queue.get returns. It includes output copying and IPC before receipt. Source/output correctness is checked after that timestamp. Oracle hashing time is not added to the receipt deadline.
- Timeline CSVs use milliseconds relative to measured-cohort start. Negative timestamps are warm-up. `cohort` is defined by the planned arrival, not completion time. All admitted work is drained.
- `source_hold_mean_ms` is commit_end to the last recipient release_end for measured accepted source publications with receipts. Producer reservation/write time before commit is excluded. This conditional mean is not load-independent service time.
- `read_done_ns` is a host timestamp after the method's first completion event is synchronized. Full retention's first event covers full computation; it is not an independently measured physical last-shared-load timestamp for that method.
- `private_after_read_mean_ms` is output_done minus this policy-specific read_done timestamp. It is a host-observed interval, not isolated GPU kernel time. Across-method subtraction must respect that distinction.
- `planned_to_admit_mean_ms` includes upstream waiting before admitted execution. `execution_mean_ms` is admission to observed output completion, not pure GPU kernel time.
- `receipt_p95_ms_mean` is the mean of six within-run 95th percentiles, not the 95th percentile of pooled requests.
- `protected_byte_seconds` integrates the union of logical protected intervals per slot (commit_begin to final return), clipped to the measured window.
- `mean_protected_mib` divides that integral by window seconds and 2^20. `protected_interval_fraction_mean` additionally divides by ring capacity in source bytes. The local audit's shorter field name `occupied_fraction` denotes this same protected-interval fraction, not total slot-busy time, GPU utilization or allocated-memory utilization.
- `device_peak_mib` is the inherited measured device-memory peak. Reduced logical borrowing does not imply allocator deallocation or a reduced peak.

## Statistics
- Each condition/method has six whole-run repetitions. Paired differences align repeat IDs. There are 20,000 bootstrap draws of six paired runs.
- Intervals are pointwise 95% percentile intervals, not simultaneous bands, capacity bounds, or equivalence tests. A zero-width interval means the six observed values coincided, not that all deployment uncertainty is zero.
- E1 and E2 are separate measurement windows. Their overlapping base/30 Hz conditions are not pooled. Earlier V11 windows remain separate.

## E3/E4/E6
- E3 `manual_edit_count` counts changed review fields, not human edits, lines of code or elapsed labor. Runtime-used fields exclude the documentary readers list. Binding hashes may be regenerated mechanically.
- E3 `readseal_edits=0` refers only to manual source-reader/boundary annotations supplied to these constructors, not all integration work.
- E3 times are CPU constructor medians after one warm-up and 12 measured calls. Tracing/export, disk reads, deserialization, execution and GPU copies are excluded.
- E4 normal phases and inclusive cProfile counters are separate tables. Nested/inclusive counters are not additive. Missing enrollment instrumentation is blank with an explanatory note, not a zero-cost estimate.
- E6 `supported=True` means CPU export, unchanged-registry checks, analysis and lowering passed for the declared tail/interface with weights=None. No numerical-equivalence, GPU, accuracy or production-support inference follows. Unsupported operators are recorded explicitly.
- CSV blanks mean unavailable or inapplicable, never an implied zero. JSON carries explicit booleans, nulls, frozen parameters and lineage.
'''
    (output / 'DATA_DICTIONARY.md').write_text(dictionary)
    validation = dict(status='COMPLETE', experiments=dict(e1=108, e2=36, smoke=6,
        e3_transitions=16, e3_timed_snapshots=20, e4_profile_processes=4, e5='NOT_RUN_FACTORY_UNSUPPORTED',
        e6='STATIC_SURVEY' if e6.exists() else 'NOT_INCLUDED', e7='DATED_HOST_RECORD'),
        formal_counts=totals, gpu_local_validation_sha256=sha(local_validation / 'validation.json'),
        stage_validation_sha256={name: sha(CPU / STAGES.get(name,name) / 'validation.json') for name in
            ('e3', 'e4', 'e7') + (('e6',) if e6.exists() else ())},
        raw_archive_sha256=sha(archive), source_sha256=sha(Path(__file__)),
        paper_modified=False, inference_retried=False)
    (output / 'PACKAGE_VALIDATION.json').write_text(json.dumps(validation, indent=2) + '\n')
    files = sorted(p for p in output.rglob('*') if p.is_file())
    with (output / 'SHA256SUMS.txt').open('x') as f:
        for p in files:
            f.write(sha(p) + '  ' + p.relative_to(output).as_posix() + '\n')
    with zipfile.ZipFile(output.with_suffix('.zip'), 'x') as z:
        for p in sorted(output.rglob('*')):
            if p.is_file():
                compression = zipfile.ZIP_STORED if p.suffix in ('.gz', '.zip') else zipfile.ZIP_DEFLATED
                z.write(p, arcname=output.name + '/' + p.relative_to(output).as_posix(), compress_type=compression)
    with zipfile.ZipFile(output.with_suffix('.zip')) as z:
        assert z.testzip() is None
    print(json.dumps(dict(status='COMPLETE', directory=str(output), zip=str(output.with_suffix('.zip')),
                         zip_sha256=sha(output.with_suffix('.zip')), files=len(files) + 1,
                         formal_counts=totals)))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--raw-root', type=Path, required=True)
    p.add_argument('--local-validation', type=Path, required=True)
    p.add_argument('--raw-archive', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    main(a.raw_root, a.local_validation, a.raw_archive, a.output)
