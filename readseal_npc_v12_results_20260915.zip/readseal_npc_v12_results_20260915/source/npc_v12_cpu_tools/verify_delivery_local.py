"""Portable second audit of raw V12 receipts, sample arrays, and paired CIs."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'npc_v12_short'))
from protocol import PLAN,schedule


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''):
            h.update(chunk)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_text())


def inspect_run(folder):
    r=read(folder/'report.json'); c=r['cell']
    assert r['status']=='COMPLETE' and (folder/'COMPLETE').is_file()
    assert r['wrong_outputs']==r['source_unknown']==0
    sink=read(folder/'sink.json'); producers=r['producer']
    by_tick={p['tick']:p for p in producers}
    assert len(by_tick)==len(producers)
    workers={}
    for i in range(c['consumers']):
        data=read(folder/f'consumer-{i}.json')
        assert sha(folder/f'consumer-{i}-artifact.json')==data['artifact_sha256']
        for row in data['rows']:
            key=row['tick'],row['consumer']
            assert key not in workers
            workers[key]=row
    delivered={(s['tick'],s['consumer']):s for s in sink}
    expected={(p['tick'],i) for p in producers for i,e in enumerate(p['enqueued']) if e}
    assert len(delivered)==len(sink) and set(delivered)==set(workers)==expected
    refs=[v['hashes'] for v in r['references']]
    assert len(refs)==len({tuple(v) for v in refs})==3
    for key,s in delivered.items():
        w=workers[key]; p=by_tick[key[0]]
        for k in ('sequence','slot','source_id','scheduled_ns','identity','cohort'):
            assert w[k]==s[k]
        assert s['actual_hashes']==refs[s['source_id']]
        assert s['matching_reference_sources']==[s['source_id']]
        assert s['sequence']==p['sequence']==s['observed_sequence']
        assert s['source_id']==p['source_id']==s['observed_source']
        assert s['identity']==dict(epoch=987654,sequence=s['sequence'],generation=s['sequence']*2)
        assert all(s[k] for k in ('output_equal','provenance_verified','finite','published'))
        assert s['deadline_met']==s['verified_timely']==(s['publish_ns']-s['scheduled_ns']<=round(c['deadline_ms']*1e6))
        times=[p['write_done_ns'],p['commit_begin_ns'],s['received_ns'],s['admission_ns'],s['read_done_ns'],
               s['release_begin_ns'],s['release_end_ns'],s['output_done_ns'],s['sink_enqueue_ns'],s['publish_ns']]
        assert times==sorted(times)
    for p in producers:
        assert p['scheduled_ns']==r['origin_ns']+round(p['tick']*1e9/c['rate_hz'])
        assert p['cohort']==(r['cohort_start_ns']<=p['scheduled_ns']<r['cohort_end_ns'])
    samples=0
    for p in folder.glob('sample-*.npz'):
        _,sid=(int(k[1:]) for k in p.stem.split('-')[1:])
        with np.load(p,allow_pickle=False) as z:
            hs=[hashlib.sha256(z[f'output_{i}'].tobytes()).hexdigest() for i in range(len(z.files))]
            assert all(np.isfinite(z[k]).all() for k in z.files)
            assert hs==refs[sid]
            samples+=len(hs)
    assert samples>0
    intervals=[]; previous={};reuse=0
    for p in producers:
        if 'sequence' not in p:
            continue
        if p['slot'] in previous:
            old=previous[p['slot']]
            for i,yes in enumerate(old['enqueued']):
                if yes:
                    assert workers[old['tick'],i]['read_done_ns']<=p['write_start_ns']
                    reuse+=1
        previous[p['slot']]=p
        finish=max(workers[p['tick'],i]['release_end_ns'] if yes else p['cancel_returns_ns'][str(i)]
                   for i,yes in enumerate(p['enqueued']))
        intervals.append(dict(slot=p['slot'],sequence=p['sequence'],start_ns=p['commit_begin_ns'],end_ns=finish))
    assert intervals==r['intervals']
    held_ns=0
    for slot in range(c['ring']):
        events=[]
        for iv in intervals:
            lo=max(iv['start_ns'],r['cohort_start_ns']);hi=min(iv['end_ns'],r['cohort_end_ns'])
            if iv['slot']==slot and hi>lo:
                events.extend([(lo,1),(hi,-1)])
        active=0;last=r['cohort_start_ns']
        for t,d in sorted(events):
            if active:held_ns+=t-last
            active+=d;last=t
            assert active>=0
        assert active==0
    bs=held_ns*r['source_bytes']/1e9
    assert abs(bs-r['protected_byte_seconds'])<1e-4
    ss=[s for s in sink if s['cohort']]; pp=[p for p in producers if p['cohort']]
    losses={k:sum(p['drop_reason']==k for p in pp)*c['consumers']
            for k in ('producer_late','pool_exhausted','credit_exhausted')}
    queue_loss=sum(sum(not x for x in p['enqueued']) for p in pp if p['drop_reason'] is None)
    timely=sum(s['deadline_met'] for s in ss)
    assert r['arrivals']==len(pp)*c['consumers']==len(ss)+queue_loss+sum(losses.values())
    assert r['publications']==len(ss) and r['timely']==timely
    for mem in r['memory_samples']:
        assert all(q['gpu']==r['gpu_uuid'] and q['pid'] in r['worker_pids'] for q in mem['compute'])
    grouped={}
    for s in ss:grouped.setdefault(s['tick'],[]).append(s)
    holds=[(max(x['release_end_ns'] for x in arr)-by_tick[t]['commit_end_ns'])/1e6 for t,arr in grouped.items()]
    phases=np.array([[(s['admission_ns']-s['scheduled_ns'])/1e6,(s['output_done_ns']-s['admission_ns'])/1e6,
                     (s['publish_ns']-s['scheduled_ns'])/1e6,(s['output_done_ns']-s['read_done_ns'])/1e6] for s in ss])
    metrics=dict(arrivals=r['arrivals'],publications=len(ss),timely=timely,correct_late=len(ss)-timely,
        **losses,queue_loss=queue_loss,goodput_hz=timely/c['measure_seconds'],protected_byte_seconds=bs,
        mean_protected_mib=bs/c['measure_seconds']/2**20,device_peak_mib=r['device_peak_bytes']/2**20,
        planned_to_admit_mean_ms=float(phases[:,0].mean()),execution_mean_ms=float(phases[:,1].mean()),
        receipt_mean_ms=float(phases[:,2].mean()),receipt_p95_ms=float(np.percentile(phases[:,2],95)),
        source_hold_mean_ms=float(np.mean(holds)),private_after_read_mean_ms=float(phases[:,3].mean()))
    return metrics,dict(sample_tensors=samples,received=len(sink),reuse_checks=reuse,
        observed_accepted_publications=len(grouped),occupied_fraction=held_ns/(r['cohort_end_ns']-r['cohort_start_ns'])/c['ring'])


def timelines(folder, entry, phase):
    report=read(folder/'report.json');sink=read(folder/'sink.json')
    origin=report['cohort_start_ns'];cell=report['cell']
    common=dict(experiment=phase,run=entry['name'],repeat=entry['repeat'],method=entry['method'],
                late=cell['late'],rate_hz=cell['rate_hz'],ring=cell['ring'],cap=cell['outstanding_cap'])
    by_tick={}
    recipients=[]
    for s in sink:
        by_tick.setdefault(s['tick'],[]).append(s)
        row=dict(common,tick=s['tick'],consumer=s['consumer'],cohort=s['cohort'],
            sequence=s['sequence'],source_id=s['source_id'],deadline_met=s['deadline_met'])
        for key in ('scheduled','admission','read_done','release_end','output_done','publish'):
            row[key+'_relative_ms']=(s[key+'_ns']-origin)/1e6
        row['receipt_latency_ms']=(s['publish_ns']-s['scheduled_ns'])/1e6
        recipients.append(row)
    publications=[];holds=[]
    for p in report['producer']:
        ss=by_tick.get(p['tick'],[])
        row=dict(common,tick=p['tick'],cohort=p['cohort'],scheduled_relative_ms=(p['scheduled_ns']-origin)/1e6,
            drop_reason=p['drop_reason'] or '',sequence=p.get('sequence'),slot=p.get('slot'),
            accepted_recipients=sum(p['enqueued']),commit_relative_ms=None,last_release_relative_ms=None,
            source_hold_ms=None)
        if ss:
            finish=max(s['release_end_ns'] for s in ss)
            row.update(commit_relative_ms=(p['commit_end_ns']-origin)/1e6,
                last_release_relative_ms=(finish-origin)/1e6,source_hold_ms=(finish-p['commit_end_ns'])/1e6)
            if p['cohort']:holds.append(row['source_hold_ms'])
        publications.append(row)
    cohort=[p for p in report['producer'] if p['cohort']]
    pattern=[p['drop_reason'] for p in cohort]
    alternating=(set(pattern)=={None,'pool_exhausted'} and all(a!=b for a,b in zip(pattern,pattern[1:])))
    diagnostic=dict(common,source_publications_offered=len(cohort),source_publications_with_receipts=len(holds),
        pool_rejection_fraction=sum(x=='pool_exhausted' for x in pattern)/len(pattern),
        exact_alternating_accept_pool_busy=alternating,hold_samples=len(holds),
        hold_mean_ms=float(np.mean(holds)),hold_p05_ms=float(np.percentile(holds,5)),
        hold_median_ms=float(np.median(holds)),hold_p95_ms=float(np.percentile(holds,95)),
        hold_max_ms=float(max(holds)),
        scope='accepted measured publications, commit_end to last recipient release_end; not load-independent service time')
    return publications,recipients,diagnostic


def main(root,out):
    out.mkdir(exist_ok=False)
    frozen=read(root/'prepared.json');control=read(root/'controller/status.json')
    assert frozen['plan']==PLAN and control['status']=='COMPLETE'
    assert {r['phase'] for r in control['completed_stages']}=={'smoke','e1','e2'}
    checks=[];nci=0;flat=[];summary=[];publication_rows=[];recipient_rows=[];mechanism_rows=[]
    for phase in ('smoke','e1','e2'):
        path=root/phase
        report=read(path/'report.json');analysis=read(path/'audit/analysis.json')
        assert report['status']==analysis['status']=='COMPLETE'
        assert report['schedule']==frozen['schedules'][phase]==schedule(phase)
        assert len(report['runs'])==len(analysis['rows'])==PLAN['expected_runs'][phase]
        assert report['prepared_sha256']==sha(root/'prepared.json')==analysis['prepared_sha256']
        assert analysis['campaign_report_sha256']==sha(path/'report.json')
        assert next(r['analysis_sha256'] for r in control['completed_stages'] if r['phase']==phase)==sha(path/'audit/analysis.json')
        for rel,digest in analysis['raw_inventory'].items():
            p=(path/rel).resolve()
            assert p.is_relative_to(path.resolve()) and sha(p)==digest
        assert sha(path/'audit/runs.csv')==analysis['csv_sha256']
        for entry,wanted,row in zip(report['runs'],schedule(phase),analysis['rows']):
            assert all(entry[k]==v for k,v in wanted.items()) and row['run']==entry['name']
            folder=path/entry['name']
            assert sha(folder/'report.json')==entry['report_sha256']
            assert sha(path/(entry['name']+'-validation')/'validation.json')==entry['validation_sha256']
            metric,diagnostic=inspect_run(folder)
            for key,value in metric.items():
                assert np.isclose(row[key],value,rtol=1e-12,atol=1e-6),(phase,row['run'],key)
            checks.append(dict(phase=phase,run=row['run'],**diagnostic))
            flat.append(dict(row,**diagnostic))
            if phase!='smoke':
                pp,rr,dd=timelines(folder,entry,phase)
                publication_rows.extend(pp);recipient_rows.extend(rr);mechanism_rows.append(dd)
        if phase=='smoke':
            continue
        rng=np.random.default_rng(PLAN['bootstrap_seed']+(phase=='e2'))
        for entry in analysis['summary']:
            a=sorted([r for r in analysis['rows'] if r['condition']==entry['condition'] and r['method']==entry['a_method']],key=lambda x:x['repeat'])
            b=sorted([r for r in analysis['rows'] if r['condition']==entry['condition'] and r['method']==entry['b_method']],key=lambda x:x['repeat'])
            assert [r['repeat'] for r in a]==[r['repeat'] for r in b]==list(range(6))
            ix=rng.integers(0,6,size=(20000,6))
            for key,v in entry['metrics'].items():
                av,bv=np.array([r[key] for r in a]),np.array([r[key] for r in b])
                assert np.isclose(av.mean(),v['a_mean']) and np.isclose(bv.mean(),v['b_mean'])
                assert np.isclose((av-bv).mean(),v['paired_difference'])
                for values,label in [(av-bv,'pointwise_ci95'),(av,'a_pointwise_ci95'),(bv,'b_pointwise_ci95')]:
                    assert np.allclose(np.quantile(values[ix].mean(axis=1),[.025,.975]),v[label],rtol=1e-12,atol=1e-12)
                    nci+=1
                summary.append(dict(experiment=phase,condition=entry['condition'],a_method=entry['a_method'],
                    b_method=entry['b_method'],metric=key,repeats=6,a_mean=v['a_mean'],b_mean=v['b_mean'],
                    paired_difference=v['paired_difference'],ci95_low=v['pointwise_ci95'][0],ci95_high=v['pointwise_ci95'][1]))
    with (out/'E1_E2_paired_summary.csv').open('x',newline='') as stream:
        w=csv.DictWriter(stream,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    for filename,rows in [('E1_E2_publication_timeline.csv',publication_rows),
                          ('E1_E2_recipient_timeline.csv',recipient_rows),
                          ('E1_E2_hold_diagnostics.csv',mechanism_rows)]:
        with (out/filename).open('x',newline='') as stream:
            writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    result=dict(status='COMPLETE',runs=len(checks),phase_counts=PLAN['expected_runs'],
        confidence_intervals_recomputed=nci,raw_reconstruction=checks,controller_sha256=sha(root/'controller/status.json'),
        no_gpu_used=True,no_inference_executed=True,
        reference_scope='Reference .pt containers are hash-verified locally and tensor-deserialized by the frozen remote Torch validators. NumPy sample arrays are independently hashed and checked locally.',
        timeline_reference='milliseconds relative to the start of each measured cohort; negative values are warm-up',
        csv_sha256={p.name:sha(p) for p in out.glob('*.csv')},script_sha256=sha(Path(__file__)))
    (out/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
    (out/'COMPLETE').write_text('Independent local delivery reconstruction complete\n')
    print(json.dumps({k:v for k,v in result.items() if k!='raw_reconstruction'}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--raw-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();main(a.raw_root,a.output)
