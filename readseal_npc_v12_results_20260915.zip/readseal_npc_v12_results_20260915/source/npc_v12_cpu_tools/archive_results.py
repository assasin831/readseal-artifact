"""Archive only completed new evidence, or safely extract it on the local host."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

REMOTE = Path('/www/readseal_ipdps_revision_v6')
MEMBERS = (
    'results/npc_v12_short_20260915_attempt1',
    'results/npc_v12_e3_reanalysis_20260915_attempt1',
    'results/npc_v12_e6_coverage_20260915_attempt1',
    'prototype_npc_v12_short_20260915_attempt1',
    'prototype_npc_v12_cpu_tools_20260915_attempt1',
)


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def archive():
    output = REMOTE / 'results/npc_v12_results_all_20260915_attempt1.tar.gz'
    assert not output.exists() and not output.with_suffix('.json').exists()
    c = json.loads((REMOTE / MEMBERS[0] / 'controller/status.json').read_text())
    assert c['status'] == 'COMPLETE'
    assert json.loads((REMOTE / MEMBERS[1] / 'report.json').read_text())['status'] == 'COMPLETE'
    assert json.loads((REMOTE / MEMBERS[2] / 'report.json').read_text())['status'] == 'COMPLETE_SURVEY'
    files = []
    for member in MEMBERS:
        root = REMOTE / member
        assert root.is_dir()
        for p in root.rglob('*'):
            assert not p.is_symlink() and p.resolve().is_relative_to(REMOTE)
            if p.is_file(): files.append(p)
    with tarfile.open(output, 'x:gz', compresslevel=1) as tar:
        for member in MEMBERS:
            tar.add(REMOTE / member, arcname=member)
    record = dict(status='COMPLETE', archive=str(output), sha256=sha(output),
        bytes=output.stat().st_size, file_count=len(files),
        uncompressed_file_bytes=sum(p.stat().st_size for p in files), members=MEMBERS,
        script_sha256=sha(Path(__file__)))
    output.with_suffix('.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record))


def extract(path, output, digest):
    assert sha(path) == digest and not output.exists()
    with tarfile.open(path, 'r:gz') as tar:
        members = tar.getmembers()
        for member in members:
            p = PurePosixPath(member.name)
            assert not p.is_absolute() and '..' not in p.parts and ':' not in member.name
            assert member.isfile() or member.isdir()
            assert (output / member.name).resolve().is_relative_to(output.resolve())
        output.mkdir(parents=True)
        tar.extractall(output, members=members, filter='data')
    print(json.dumps(dict(status='COMPLETE', extracted=str(output), members=len(members),
                          archive_sha256=digest)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('archive', 'extract'))
    parser.add_argument('--archive', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--sha256')
    args = parser.parse_args()
    if args.mode == 'archive': archive()
    else: extract(args.archive, args.output, args.sha256)
