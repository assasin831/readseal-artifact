"""E3 bounded CPU-only plan reconstruction after the GPU campaign is complete."""
import datetime
import gc
import hashlib
import json
import os
from pathlib import Path
import statistics
import sys
import time
import traceback

ROOT=Path('/www/readseal_ipdps_revision_v6')
GPU_CAMPAIGN=ROOT/'results/npc_v12_short_20260915_attempt1'
OUTPUT=ROOT/'results/npc_v12_e3_reanalysis_20260915_attempt1'
sys.path.insert(0,str(ROOT/'prototype_borrowplan_v11_grouped_attempt1'))
from launch_grouped_formal import DEPS,sha,compute
sys.path.extend(str(p) for p in DEPS if str(p) not in sys.path)
import torch
from batch_backend import BatchProgram
from variants import edited_export, structural_hash, SUPPORTED
from study_common import MODELS


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def describe(program):
    calls=[n for n in program._capsule.plan.nodes if n.name not in program._capsule.placeholder_names]
    readers=sorted(dict(program.plan.obligations)[program.root])
    names=[n.name for n in calls]
    boundary=max((names.index(n),n) for n in readers)
    return dict(readers=readers,boundary=boundary[1],prefix_operations=boundary[0]+1,
                total_operations=len(calls))


def main():
    control=json.loads((GPU_CAMPAIGN/'controller/status.json').read_text())
    assert control['status']=='COMPLETE' and {r['phase'] for r in control['completed_stages']}=={'smoke','e1','e2'}
    assert not compute(), 'CPU reanalysis waits until formal timings finish on a quiet host'
    OUTPUT.mkdir(exist_ok=False)
    result=dict(status='RUNNING',utc_start=utc(),cuda_used=False,inference_executed=False,
        cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),rows=[],
        plan=dict(warmups=1,repetitions=12,threads=1,
            timer='perf_counter_ns around BatchProgram(exported, CPU example) only',
            includes='analysis, lowering, owned weight clones, captured-code binding and prepared grouping',
            excludes='disk read, deserialization, original export/tracing, model execution, GPU copies, application integration',
            not_developer_time=True,not_gpu_deployment_construction_latency=True,
            models='16 edited snapshots + 2 folded snapshots + 2 public ResNet tails',
            randomized=False,safety_and_reconstruction_first=True),
        prerequisite_sha256=sha(GPU_CAMPAIGN/'controller/status.json'))
    try:
        assert torch.__version__=='2.1.2+cu121'
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        maintenance_path=ROOT/'results/borrowplan_v10_maintenance_attempt1/report.json'
        maintenance=json.loads(maintenance_path.read_text())
        assert maintenance['status']=='COMPLETE'
        reviews={(r['model'],r['edit']):r['review'] for r in maintenance['cases']}
        assert len(reviews)==16
        sources={str(maintenance_path):sha(maintenance_path),str(Path(__file__)):sha(Path(__file__))}
        cases=[]
        for model in ('transfusion','resnet'):
            path=MODELS[model][0]
            for edit in SUPPORTED:
                cases.append(dict(key=f'{model}:{edit}',model=model,edit=edit,path=path,kind='synthetic'))
        construction_path=ROOT/'results/borrowplan_v11_public_deployment_cpu_attempt1/report.json'
        construction=json.loads(construction_path.read_text())
        assert construction['status']=='COMPLETE'
        sources[str(construction_path)]=sha(construction_path)
        for entry in construction['models']:
            path=construction_path.parent/entry['export_file']
            assert sha(path)==entry['export_sha256']
            cases.append(dict(key=f'{entry["model"]}:folded',model=entry['model'],path=path,kind='folded'))
        public_path=ROOT/'results/npc_v6_public_model_cpu_staged_attempt2/report.json'
        public=json.loads(public_path.read_text())
        assert public['status']=='COMPLETE' and public['cuda_initialized'] is False
        sources[str(public_path)]=sha(public_path)
        for entry in public['cases']:
            rel=entry['model']+'/tail.pt2'
            path=public_path.parent/rel
            assert sha(path)==public['files'][rel]
            cases.append(dict(key=entry['model']+':public',model=entry['model'],path=path,kind='public',
                              expected_readers=entry['readers'],expected_boundary=entry['auto_boundary']))
        for case in cases:
            path=case['path']; sources[str(path)]=sha(path)
            if case['kind']=='synthetic':
                exported=edited_export(path,case['model'],case['edit'])
                review=reviews[case['model'],case['edit']]
                assert structural_hash(exported.graph)==review['graph_sha256']
            else:
                exported=torch.export.load(path)
            root=next(n for n in exported.graph.nodes if n.name==exported.graph_signature.user_inputs[0])
            meta=root.meta['val']
            example=torch.empty_strided(tuple(meta.shape),tuple(meta.stride()),dtype=meta.dtype,device='cpu')
            warm=BatchProgram(exported,example)
            expected=describe(warm)
            if case['kind']=='synthetic':
                assert expected['readers']==review['readers'] and expected['boundary']==review['boundary']
            if case['kind']=='public':
                assert expected['readers']==sorted(case['expected_readers']) and expected['boundary']==case['expected_boundary']
            del warm
            times=[]
            for repeat in range(12):
                gc.collect()
                begin=time.perf_counter_ns()
                program=BatchProgram(exported,example)
                elapsed=time.perf_counter_ns()-begin
                assert describe(program)==expected and elapsed>0
                times.append(elapsed)
                del program
            assert not torch.cuda.is_initialized() and not compute()
            result['rows'].append(dict(key=case['key'],kind=case['kind'],model=case['model'],
                export=str(path),export_sha256=sha(path),loaded_graph_sha256=structural_hash(exported.graph),
                **expected,raw_nanoseconds=times,reanalysis_seconds=statistics.median(times)/1e9,
                mean_seconds=statistics.mean(times)/1e9,min_seconds=min(times)/1e9,max_seconds=max(times)/1e9,
                reanalysis_statistic='median of 12 CPU constructor calls after one warm-up',
                manual_release_annotations_supplied_to_constructor=False))
            (OUTPUT/'progress.json').write_text(json.dumps(dict(completed=len(result['rows']),total=len(cases),last=case['key']))+'\n')
            print(json.dumps(dict(status='CASE_COMPLETE',key=case['key'],median_ms=statistics.median(times)/1e6)),flush=True)
            del exported,example
        assert len(result['rows'])==20
        for dep in DEPS:
            if dep.name.startswith('prototype_'):
                sources.update({str(p):sha(p) for p in dep.glob('*.py')})
        result.update(status='COMPLETE',sources=sources,torch=torch.__version__,python=sys.version,
                      cuda_initialized=torch.cuda.is_initialized())
    except BaseException:
        result.update(status='FAILED',traceback=traceback.format_exc())
        traceback.print_exc()
    result['utc_end']=utc()
    (OUTPUT/'report.json').write_text(json.dumps(result,indent=2)+'\n')
    (OUTPUT/result['status']).write_text(result['status']+'\n')
    print(json.dumps(dict(status=result['status'],cases=len(result['rows']),sha256=sha(OUTPUT/'report.json'))))
    return int(result['status']!='COMPLETE')


if __name__=='__main__':
    raise SystemExit(main())
