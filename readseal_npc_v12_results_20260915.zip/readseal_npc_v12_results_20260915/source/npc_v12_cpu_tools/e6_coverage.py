"""Bounded, CPU-only operator survey; no claim of GPU or numerical validation."""
import collections
import datetime
import gc
import inspect
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback

ROOT=Path('/www/readseal_ipdps_revision_v6')
OUT=ROOT/'results/npc_v12_e6_coverage_20260915_attempt1'
sys.path.insert(0,str(ROOT/'prototype_borrowplan_v11_grouped_attempt1'))
from launch_grouped_formal import DEPS,sha
sys.path.extend(str(p) for p in DEPS if str(p) not in sys.path)
sys.path.insert(0,str(ROOT/'vendor'))
import torch
from torch import nn
import torchvision
from torchvision import models
import export_backend
from export_backend import Program,summary
from segmented_backend import lower
from core import Rejected

MODELS=('resnet18','resnet34','resnet50','resnet101','resnext50_32x4d','wide_resnet50_2',
        'vgg16','densenet121','mobilenet_v2','mobilenet_v3_small','efficientnet_b0',
        'regnet_y_400mf','convnext_tiny','shufflenet_v2_x1_0')


class SpatialMean(nn.Module):
    def forward(self,x):
        return x.mean([2,3])


def parts(model,name):
    flat=nn.Flatten(1)
    if name.startswith(('resnet','resnext','wide_resnet')):
        return (nn.Sequential(model.conv1,model.bn1,model.relu,model.maxpool),
            nn.Sequential(model.layer1,model.layer2,model.layer3,model.layer4,model.avgpool,flat,model.fc),
            'after conv1/bn1/relu/maxpool, before layer1')
    if name=='vgg16':
        return model.features[:5],nn.Sequential(model.features[5:],model.avgpool,flat,model.classifier),'after first maxpool (features[0:5])'
    if name=='densenet121':
        return (nn.Sequential(*list(model.features.children())[:4]),
            nn.Sequential(*list(model.features.children())[4:],nn.ReLU(inplace=True),nn.AdaptiveAvgPool2d(1),flat,model.classifier),
            'after conv0/norm0/relu0/pool0, before denseblock1')
    if name in ('mobilenet_v2','mobilenet_v3_small','efficientnet_b0'):
        pool=nn.AdaptiveAvgPool2d(1) if name=='mobilenet_v2' else model.avgpool
        return model.features[0],nn.Sequential(model.features[1:],pool,flat,model.classifier),'after features[0]'
    if name=='regnet_y_400mf':
        return model.stem,nn.Sequential(model.trunk_output,model.avgpool,flat,model.fc),'after stem, before trunk_output'
    if name=='convnext_tiny':
        return model.features[0],nn.Sequential(model.features[1:],model.avgpool,model.classifier),'after features[0] patch embedding'
    if name=='shufflenet_v2_x1_0':
        return nn.Sequential(model.conv1,model.maxpool),nn.Sequential(model.stage2,model.stage3,model.stage4,model.conv5,SpatialMean(),model.fc),'after conv1/maxpool, before stage2'
    raise ValueError(name)


def alarm_handler(*_):
    raise TimeoutError('per-case 180 second CPU budget')


def main():
    prerequisite=ROOT/'results/npc_v12_e3_reanalysis_20260915_attempt1/report.json'
    assert json.loads(prerequisite.read_text())['status']=='COMPLETE'
    assert os.environ.get('CUDA_VISIBLE_DEVICES')==''
    assert torch.__version__=='2.1.2+cu121' and torchvision.__version__.startswith('0.16.2')
    OUT.mkdir(exist_ok=False)
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    signal.signal(signal.SIGALRM,alarm_handler)
    plan=dict(models=MODELS,seed=260915200,weights=None,pretrained=False,
        image_shape=[1,3,224,224],threads=1,per_case_budget_seconds=180,total_budget_seconds=900,
        mode='eval, requires_grad=False; one declared stem interface per architecture',
        no_network=True,registry_unchanged=True,registry_sha256=sha(Path(export_backend.__file__)),
        supported_definition='all exported operations satisfy the existing registry and Program+lower succeeds',
        scope='CPU stem construction/execution, export and static analysis/lowering only. No GPU, numerical equivalence, performance or deployment correctness claim.',
        no_retry=True)
    (OUT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    result=dict(status='RUNNING',plan=plan,rows=[],torch=torch.__version__,torchvision=torchvision.__version__,
                prerequisite_sha256=sha(prerequisite),script_sha256=sha(Path(__file__)))
    started=time.monotonic()
    for i,name in enumerate(MODELS):
        row=dict(model=name,supported=False,unsupported_ops=[],prefix_ops=None,total_ops=None)
        if time.monotonic()-started>=900:
            row['status']='NOT_RUN_BUDGET'
            result['rows'].append(row)
            continue
        folder=OUT/name;folder.mkdir()
        signal.alarm(180)
        model=stem=tail=example=exported=program=modules=None
        try:
            torch.manual_seed(plan['seed']+i)
            model=getattr(models,name)(weights=None).eval().requires_grad_(False)
            source=Path(inspect.getfile(type(model)))
            row['model_source']=str(source);row['model_source_sha256']=sha(source)
            stem,tail,interface=parts(model,name)
            stem.eval();tail.eval()
            with torch.no_grad():
                example=stem(torch.zeros(1,3,224,224)).detach().contiguous()
            row.update(interface=interface,input_shape=list(example.shape),input_stride=list(example.stride()),
                       input_dtype=str(example.dtype),cpu_stem_executed=True)
            exported=torch.export.export(tail,(example,))
            graph=exported.graph
            (folder/'graph.txt').write_text(str(graph)+'\n')
            (folder/'graph_code.py').write_text(exported.graph_module.code+'\n')
            counts=collections.Counter(str(n.target) for n in graph.nodes if n.op=='call_function')
            row['operator_counts']=dict(sorted(counts.items()))
            row['total_ops']=sum(counts.values())
            reasons={}
            for node in graph.nodes:
                if node.op=='call_function':
                    try:summary(node)
                    except Rejected as exc:reasons[str(node.target)]=str(exc)
            row['unsupported_ops']=sorted(reasons)
            row['unsupported_reasons']=reasons
            if reasons:
                row['status']='UNSUPPORTED_OPERATOR'
            else:
                try:
                    program=Program(exported,example)
                    modules,groups,live=lower(program)
                    calls=[n for n in program.graph.nodes if n.op=='call_function']
                    readers=set(dict(program.plan.obligations)[program.root])
                    index=max(k for k,n in enumerate(calls) if n.name in readers)
                    row.update(status='SUPPORTED_STATIC',supported=True,prefix_ops=index+1,
                               boundary=calls[index].name,readers=sorted(readers),private_carry_checked=True)
                except Rejected as exc:
                    row.update(status='UNSUPPORTED_PLAN',reason=str(exc))
            row['graph_sha256']=sha(folder/'graph.txt')
            row['graph_code_sha256']=sha(folder/'graph_code.py')
        except BaseException as exc:
            row.update(status='EXPORT_OR_HARNESS_FAILURE',failure_type=type(exc).__name__,traceback=traceback.format_exc())
        finally:
            signal.alarm(0)
        assert not torch.cuda.is_initialized(), 'CPU-only survey initialized CUDA'
        row['elapsed_seconds']=time.monotonic()-started
        (folder/'record.json').write_text(json.dumps(row,indent=2)+'\n')
        result['rows'].append(row)
        (OUT/'progress.json').write_text(json.dumps(dict(completed=len(result['rows']),total=len(MODELS),last=name,status=row['status']))+'\n')
        print(json.dumps(dict(model=name,status=row['status'],unsupported_ops=row['unsupported_ops'])),flush=True)
        del model,stem,tail,example,exported,program,modules
        gc.collect()
    assert len(result['rows'])==14
    result.update(status='COMPLETE_SURVEY',gpu_used=False,cuda_initialized=torch.cuda.is_initialized(),
        counts=dict(collections.Counter(r['status'] for r in result['rows'])),elapsed_seconds=time.monotonic()-started,
        not_a_random_sample_of_deployments=True,accuracy_measured=False)
    (OUT/'report.json').write_text(json.dumps(result,indent=2)+'\n')
    (OUT/'COMPLETE').write_text('All predeclared survey dispositions recorded; not all models necessarily supported.\n')
    print(json.dumps(dict(status=result['status'],counts=result['counts'],sha256=sha(OUT/'report.json'))))


if __name__=='__main__':
    main()
