"""E4: reconstruct raw diagnostics; never turn inclusive profiles into speedup."""
import csv
import hashlib
import json
from pathlib import Path
import statistics as st
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'results/npc_v12_cpu_attempt1'
EV=ROOT/'paper/readseal_npc_2026_v11_submission/evidence'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def dump_csv(path,rows):
    with path.open('x',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        w.writeheader();w.writerows(rows)


def main():
    out=BASE/'e4'
    out.mkdir(exist_ok=False)
    campaign=json.loads((EV/'profile_campaign.json').read_text())
    saved=json.loads((EV/'profile.json').read_text())
    assert campaign['status']==saved['status']=='COMPLETE'
    assert sha(EV/'profile_campaign.json')==saved['campaign_report_sha256']
    records=[]; inventory={}
    for repeat in range(4):
        path=BASE/f'raw/profile_r{repeat}.json'
        assert sha(path)==campaign['runs'][repeat]['report_sha256']
        inventory[str(path)]=sha(path)
        data=json.loads(path.read_text())
        assert data['status']=='COMPLETE' and data['repeat']==repeat
        for case in data['cases']:
            keys={(r['trial'],r['method'],r['profiled']) for r in case['records']}
            assert len(keys)==len(case['records'])==160
            for row in case['records']:
                assert row['exact'] and row['wall_ns']>0
                phases={p['name']:p['ns']/1e6 for p in row['phases']}
                assert all(v>=0 and np.isfinite(v) for v in phases.values())
                assert sum(phases.values())<=row['wall_ns']/1e6
                records.append(dict(row,repeat=repeat,case=case['key'],phase_ms=phases))
    assert len(records)==saved['records_checked']==2560
    # Reconstruct every previously published phase estimate from raw records.
    for s in saved['summary']:
        rr=[r for r in records if r['case']==s['case'] and r['method']==s['method'] and not r['profiled']]
        for phase,value in s['phase_ms'].items():
            estimate=st.mean(st.median(r['phase_ms'][phase] for r in rr if r['repeat']==i) for i in range(4))
            assert abs(estimate-value)<1e-12
    rows=[];calls=[]; comparisons=[]
    for case in sorted({r['case'] for r in records}):
        normal={m:[r for r in records if r['case']==case and r['method']==m and not r['profiled']]
                for m in ('auto-batched','manual-early')}
        prof={m:[r for r in records if r['case']==case and r['method']==m and r['profiled']]
                for m in normal}
        assert all(len(v)==80 for v in list(normal.values())+list(prof.values()))
        for phase in normal['auto-batched'][0]['phase_ms']:
            a,b=([r['phase_ms'][phase] for r in normal[m]] for m in normal)
            note='Arithmetic mean of 80 calls/method in four processes; ordinary host phase timer, not cProfile; includes GPU overlap/waits.'
            rows.append(dict(case=case,phase=phase,readseal_ms_mean=st.mean(a),manual_ms_mean=st.mean(b),
                calls=80,note=note,readseal_mean_run_median_ms=st.mean(st.median(r['phase_ms'][phase] for r in normal['auto-batched'] if r['repeat']==i) for i in range(4)),
                manual_mean_run_median_ms=st.mean(st.median(r['phase_ms'][phase] for r in normal['manual-early'] if r['repeat']==i) for i in range(4))))
        rows.append(dict(case=case,phase='enrollment_separate',readseal_ms_mean=None,manual_ms_mean=None,
            calls=0,note='Not separately instrumented in this child-only profile; complete A/B/C enrollment is outside its scope. Missing is not zero.',
            readseal_mean_run_median_ms=None,manual_mean_run_median_ms=None))
        for kind in ['guard','state_token','event_record','event_query','event_synchronize']:
            estimates={}
            for method,rr in prof.items():
                vals=[];ns=[]
                for r in rr:
                    def match(f):
                        leaf=Path(f['file']).name
                        if kind=='guard':
                            return f['name']=='guard' and leaf==('batch_backend.py' if method=='auto-batched' else 'manual_static.py')
                        if kind=='state_token':
                            return f['name']=='state_token' and leaf in ('owned_backend.py','manual_static.py')
                        return f['name']==kind.removeprefix('event_') and leaf=='streams.py'
                    funcs=[f for f in r['functions'] if match(f)]
                    vals.append(sum(f['inclusive_seconds'] for f in funcs)*1000)
                    ns.append(sum(f['calls'] for f in funcs))
                estimates[method]=dict(mean_ms=st.mean(vals),calls_per_invocation=sorted(set(ns)))
            calls.append(dict(case=case,phase=kind,readseal_ms_mean=estimates['auto-batched']['mean_ms'],
                manual_ms_mean=estimates['manual-early']['mean_ms'],calls=80,
                readseal_calls_per_invocation=json.dumps(estimates['auto-batched']['calls_per_invocation']),
                manual_calls_per_invocation=json.dumps(estimates['manual-early']['calls_per_invocation']),
                note='cProfile inclusive host times; nested functions and GPU overlap. Not additive with phases or other inclusive functions.'))
        sg={m:next(s for s in saved['summary'] if s['case']==case and s['method']==m) for m in normal}
        gap=sg['auto-batched']['wall_ms']-sg['manual-early']['wall_ms']
        admission_gap=sg['auto-batched']['phase_ms']['admission']-sg['manual-early']['phase_ms']['admission']
        comparisons.append(dict(case=case,same_diagnostic_window_wall_gap_ms=gap,
            admission_phase_gap_ms=admission_gap,
            descriptive_admission_gap_over_wall_gap=admission_gap/gap if gap else None,
            readseal_cprofile_slowdown_ratio=sg['auto-batched']['profile_slowdown_ratio'],
            manual_cprofile_slowdown_ratio=sg['manual-early']['profile_slowdown_ratio'],
            interpretation='Ratio of diagnostic differences, not a causal fraction or a bound on removable cost. No cross-window Table 3 subtraction.',
            safe_binding_cache_speedup_bound=None,
            missing_bound_reason='Concurrent mutation/identity semantics must be preserved; profile alone does not establish a safe cache or wall-time saving.'))
    dump_csv(out/'E4_host_phases.csv',rows)
    dump_csv(out/'E4_profile_inclusive.csv',calls)
    dump_csv(out/'E4_diagnostic_comparisons.csv',comparisons)
    proof=dict(status='COMPLETE',raw_records=2560,reconstructed_saved_phases=True,
        inference_executed=False,cuda_used=False,inventory=inventory,
        phase_statistic='arithmetic means requested by plan plus separately labeled mean-of-four-run-medians',
        primary_isolated_cost_unchanged=True,no_additive_cprofile_claim=True,
        files={p.name:sha(p) for p in out.glob('*.csv')},
        evidence_sha256={n:sha(EV/n) for n in ['profile.json','profile_campaign.json','executor_cost.json']},
        script_sha256=sha(Path(__file__)))
    (out/'validation.json').write_text(json.dumps(proof,indent=2)+'\n')
    (out/'COMPLETE').write_text('E4 raw diagnostic reconstruction complete\n')
    print(json.dumps(dict(status='COMPLETE',raw_records=2560,phase_rows=len(rows),profile_rows=len(calls))))


if __name__=='__main__':
    main()
