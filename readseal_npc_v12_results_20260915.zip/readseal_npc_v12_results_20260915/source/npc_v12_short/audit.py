"""CPU request reconstruction, paired statistics, and writing-ready flat tables."""
import csv
import json
from pathlib import Path
import sys
import traceback
import numpy as np
import campaign as c
from protocol import PLAN, METHODS, schedule

sys.path.extend(str(p) for p in c.original.DEPS if str(p) not in sys.path)
import validate_grouped_pipeline as validator

METRICS = ['goodput_hz','mean_protected_mib','device_peak_mib',
           'planned_to_admit_mean_ms','execution_mean_ms','receipt_mean_ms','receipt_p95_ms',
           'source_hold_mean_ms','private_after_read_mean_ms']


def aggregate(rows, phase):
    if phase == 'smoke':
        return []
    rng = np.random.default_rng(PLAN['bootstrap_seed'] + (phase == 'e2'))
    groups=[]
    for condition in sorted({r['condition'] for r in rows}):
        rr=[r for r in rows if r['condition']==condition]
        for am,bm in [('auto-batched','manual-full'),('auto-batched','manual-early'),('manual-early','manual-full')]:
            a=sorted([r for r in rr if r['method']==am],key=lambda x:x['repeat'])
            b=sorted([r for r in rr if r['method']==bm],key=lambda x:x['repeat'])
            assert [r['repeat'] for r in a]==[r['repeat'] for r in b]==list(range(6))
            ix=rng.integers(0,6,size=(20000,6))
            estimates={}
            for key in METRICS:
                av,bv=np.array([r[key] for r in a]),np.array([r[key] for r in b])
                estimates[key]=dict(a_mean=float(av.mean()),b_mean=float(bv.mean()),
                    paired_difference=float((av-bv).mean()),
                    pointwise_ci95=np.quantile((av-bv)[ix].mean(axis=1),[.025,.975]).tolist(),
                    a_pointwise_ci95=np.quantile(av[ix].mean(axis=1),[.025,.975]).tolist(),
                    b_pointwise_ci95=np.quantile(bv[ix].mean(axis=1),[.025,.975]).tolist())
            groups.append(dict(condition=condition,a_method=am,b_method=bm,repeats=6,metrics=estimates))
    return groups


def main(phase):
    folder=c.BASE/phase
    output=folder/'audit'
    output.mkdir(exist_ok=False)
    result=dict(status='RUNNING',phase=phase,rows=[],inference_executed=False,cuda_used=False)
    try:
        report=json.loads((folder/'report.json').read_text())
        frozen=json.loads((c.BASE/'prepared.json').read_text())
        assert report['status']=='COMPLETE' and report['active'] is None
        assert (folder/'COMPLETE').is_file() and not list(folder.rglob('FAILED'))
        expected=schedule(phase)
        assert report['schedule']==frozen['schedules'][phase]==expected
        assert len(report['runs'])==len(expected)
        assert report['prepared_sha256']==c.sha(c.BASE/'prepared.json')
        assert report['bindings']==frozen['bindings']
        assert all(c.sha(p)==h for p,h in frozen['bindings'].items())
        validator.validate_abc.cell=validator.cell
        inventory={}
        for entry,wanted in zip(report['runs'],expected):
            assert all(entry[k]==v for k,v in wanted.items())
            run=folder/entry['name']
            vp=folder/(entry['name']+'-validation')/'validation.json'
            assert c.sha(run/'report.json')==entry['report_sha256'] and c.sha(vp)==entry['validation_sha256']
            recorded=json.loads(vp.read_text())
            assert recorded['status']=='COMPLETE'
            checked=validator.validate_admission.audit(run)
            checked['validator_sha256']=c.sha(validator.__file__)
            assert all(recorded[k]==v for k,v in checked.items())
            raw=json.loads((run/'report.json').read_text())
            assert raw['cell']==wanted['cell'] and raw['method']==wanted['method']
            assert raw['gpu_uuid']==frozen['gpu_uuid']==c.original.GPU
            assert raw['wrong_outputs']==raw['source_unknown']==0
            assert all(c.sha(p)==h for p,h in raw['input_hashes'].items())
            assert raw['arrivals']==wanted['cell']['rate_hz']*wanted['cell']['measure_seconds']*4
            sink=[r for r in json.loads((run/'sink.json').read_text()) if r['cohort']]
            assert sink, 'no completed cohort; do not infer latency from an empty sample'
            times=np.array([[(r['admission_ns']-r['scheduled_ns'])/1e6,
                (r['output_done_ns']-r['admission_ns'])/1e6,
                (r['publish_ns']-r['scheduled_ns'])/1e6,
                (r['output_done_ns']-r['read_done_ns'])/1e6] for r in sink])
            assert times.shape==(checked['publications'],4) and np.isfinite(times).all() and (times>=0).all()
            # Each publication is protected until the last recipient returns its read.
            groups={}
            for row in sink:
                groups.setdefault(row['tick'],[]).append(row)
            producers={r['tick']:r for r in raw['producer']}
            hold=[]
            for tick,rr in groups.items():
                p=producers[tick]
                assert len(rr)==sum(p['enqueued'])
                # Reserve/commit field selection is verified against the actual frozen producer schema.
                start=p['commit_end_ns']
                end=max(r['release_end_ns'] for r in rr)
                assert end>=start
                hold.append((end-start)/1e6)
            checked.update(run=entry['name'],experiment=phase,condition=entry['condition']['id'],
                repeat=entry['repeat'],observed=False,model=wanted['cell']['model'],late=wanted['cell']['late'],
                ring=wanted['cell']['ring'],cap=wanted['cell']['outstanding_cap'],rate_hz=wanted['cell']['rate_hz'],
                planned_to_admit_mean_ms=float(times[:,0].mean()),execution_mean_ms=float(times[:,1].mean()),
                receipt_mean_ms=float(times[:,2].mean()),receipt_p95_ms=float(np.percentile(times[:,2],95)),
                source_hold_mean_ms=float(np.mean(hold)),private_after_read_mean_ms=float(times[:,3].mean()),
                source_hold_definition='commit_end to last recipient release_end for measured accepted publications',
                inference_seconds=entry['inference_seconds'],total_seconds=entry['total_seconds'])
            result['rows'].append(checked)
            for path in sorted(run.rglob('*')):
                if path.is_file():
                    inventory[str(path.relative_to(folder))]=c.sha(path)
            inventory[str(vp.relative_to(folder))]=c.sha(vp)
        fields=['run','repeat','method','model','late','ring','cap','rate_hz','arrivals','publications',
            'timely','correct_late','producer_late','pool_exhausted','credit_exhausted','queue_loss',
            'goodput_hz','mean_protected_mib','protected_byte_seconds','device_peak_mib',
            'planned_to_admit_mean_ms','execution_mean_ms','receipt_mean_ms','receipt_p95_ms',
            'source_hold_mean_ms','private_after_read_mean_ms']
        assert all(all(k in r for k in fields) for r in result['rows']), 'requested CSV fields absent'
        with (output/'runs.csv').open('x',newline='') as stream:
            writer=csv.DictWriter(stream,fieldnames=fields,extrasaction='ignore')
            writer.writeheader()
            writer.writerows(result['rows'])
        result.update(status='COMPLETE',summary=aggregate(result['rows'],phase),plan=PLAN,
            campaign_report_sha256=c.sha(folder/'report.json'),prepared_sha256=c.sha(c.BASE/'prepared.json'),
            all_frozen_hashes_verified=True,raw_inventory=inventory,
            no_source_unknown_or_wrong_output=True,no_inference_retry=True,distinct_from_old_windows=True,
            script_sha256=c.sha(__file__),csv_sha256=c.sha(output/'runs.csv'))
    except BaseException:
        result.update(status='FAILED',traceback=traceback.format_exc())
        traceback.print_exc()
    c.write(output/'analysis.json',result)
    (output/result['status']).write_text(result['status']+'\n')
    print(json.dumps(dict(status=result['status'],rows=len(result['rows']),sha256=c.sha(output/'analysis.json'))))
    return int(result['status']!='COMPLETE')


if __name__=='__main__':
    raise SystemExit(main(sys.argv[1]))
