"""Dated environment snapshot, not retroactive historical metadata."""
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys


def collect():
    commands = {
        'cpu': ['lscpu', '-J'],
        'gpu': ['nvidia-smi','--query-gpu=index,name,uuid,driver_version,mig.mode.current,memory.total','--format=csv'],
        'compute': ['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv'],
        'memory': ['free','-b'],
        'disk': ['df','-B1','/www/readseal_ipdps_revision_v6'],
    }
    import torch
    import tensorrt
    return dict(schema='dated-readseal-host-inventory-v1',
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        os_release=Path('/etc/os-release').read_text(), kernel=platform.release(),
        python=sys.version, executable=sys.executable, torch=torch.__version__,
        cuda_build=torch.version.cuda, cudnn=torch.backends.cudnn.version(),
        tensorrt=tensorrt.__version__, cuda_initialized=torch.cuda.is_initialized(),
        snapshot_scope='Current V12 host only; does not manufacture absent historical metadata',
        commands={key:subprocess.check_output(cmd,text=True) for key,cmd in commands.items()},
        gpu_binding='GPU-f3b314a8-3058-e0be-694c-76f4227afb7d',
        planned_threads=1, planned_tf32=False, planned_cudnn_benchmark=False,
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())


if __name__ == '__main__':
    value=collect()
    assert value['torch'].startswith('2.1.2') and value['cuda_build']=='12.1'
    assert value['tensorrt'].startswith('10.3') and not value['cuda_initialized']
    with Path(sys.argv[1]).open('x') as stream:
        json.dump(value,stream,indent=2)
    print(json.dumps(dict(status='COMPLETE',kind='E7',torch=value['torch'],tensorrt=value['tensorrt'])))
