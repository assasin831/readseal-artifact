"""Frozen, separate E1/E2 windows; expectations are hypotheses, not gates."""
import random

COMMON = dict(model='transfusion', late=False, consumers=4, queue=2,
              deadline_ms=100, warmup_seconds=2, measure_seconds=12,
              ring=1, outstanding_cap=0)
METHODS = ('auto-batched', 'manual-early', 'manual-full')
CONDITIONS = {
    'e1': [dict(id=f'r1-cap0-hz{rate}', rate_hz=rate) for rate in (10, 15, 20, 25, 30, 40)],
    'e2': [dict(id=f'r1-cap0-hz30-late{int(late)}', rate_hz=30, late=late) for late in (False, True)],
}
PLAN = dict(schema='npc-v12-short-experiments-1', repetitions=6,
    order_seeds=dict(smoke=260915121, e1=260915122, e2=260915123),
    bootstrap_seed=260915124, bootstrap_replicates=20000,
    methods=list(METHODS), conditions=CONDITIONS, common=COMMON,
    expected_runs=dict(smoke=6, e1=108, e2=36), both_gpus_quiet=True,
    no_inference_retry=True, guard_elision=False,
    instrumentation='unchanged frozen V11 complete A/B/C delivery harness',
    inference_unit='six paired whole-run repetitions within each experiment and condition',
    intervals='pointwise percentile paired bootstrap; not simultaneous or equivalence intervals',
    independence='E2 base is measured afresh in E2; never pooled with E1 or older windows',
    failure_policy='preserve and stop on any inference/validator failure; no automatic retry',
    foreign_compute_policy='stop before next unstarted inference; quarantine an interrupted run',
    hypotheses=['E1: benefits depend on arrival period and retention duration',
                'E2: a later last source read can reduce the value of early release'],
    excluded_extensions=['35 Hz', 'middle boundary', 'E5 ResNet delivery: frozen factory rejects ResNet'],
    no_outcome_gate=True)


def schedule(phase):
    rng = random.Random(PLAN['order_seeds'][phase])
    rows = []
    repeats = range(1) if phase == 'smoke' else range(6)
    conditions = CONDITIONS['e2'] if phase == 'smoke' else CONDITIONS[phase]
    for repeat in repeats:
        ordered = list(conditions)
        rng.shuffle(ordered)
        for condition in ordered:
            methods = list(METHODS)
            rng.shuffle(methods)
            for method in methods:
                cell = dict(COMMON, **condition)
                if phase == 'smoke':
                    cell.update(warmup_seconds=1, measure_seconds=2)
                rows.append(dict(name=f'{phase}-r{repeat:02d}-{condition["id"]}-{method}',
                    repeat=repeat, method=method, condition=condition, cell=cell, observed=False))
    assert len(rows) == len({r['name'] for r in rows}) == PLAN['expected_runs'][phase]
    return rows
