# ReadSeal NPC V12 Short Experiments

Frozen before inference on 2026-09-15. Existing scripts, input snapshots,
failed attempts, and completed windows are immutable. Use the unchanged
complete TransFusion A/B/C runner and its independent receipt validator.

## Experiments

- Smoke: both base/late variants, all three methods, 1 s warm-up, 2 s measurement.
- E1: one slot, no global cap, rates 10/15/20/25/30/40 publication Hz,
  three methods, six independently randomized paired whole-run repetitions.
  Exactly 108 runs, no optional 35 Hz extension.
- E2: one slot, no cap, 30 publication Hz, base/late, three methods,
  six paired repetitions. Exactly 36 fresh runs. Base30 overlaps E1 in
  configuration but is a distinct window; never combine these samples.
- Each publication is offered to four recipients. Deadline 100 ms from planned
  arrival to independently checked receiver receipt. Queue depth two, warm-up
  two seconds, measured arrival window 12 seconds, full final drain.
- 20,000 paired whole-run bootstrap draws; pointwise 95% intervals. No
  request-level pseudoreplication, old-window pooling, or outcome-driven gate.

Run exclusively on original GPU0 UUID. Require both GPUs free of compute,
the original GPU lock, adequate disk, and all frozen hashes before every run.
Preserve any failure and stop; never retry inference. Stop before unstarted
inference if foreign work appears. Do not modify other jobs or MIG configuration.
CPU audits must pass before moving from smoke to E1, and E1 to E2.

E7 is a dated current-host snapshot, not reconstructed historical metadata.
Source hold uses commit completion to the last recipient return; it excludes
producer reserve/copy time and is not an isolated consumer service rate.
Host timestamps include waits; they are not direct device-kernel timings.

E5 is not part of this dispatch: the frozen complete-pipeline factory explicitly
asserts model == transfusion. A ResNet child-only benchmark is not a substitute.
E3/E4 CPU work is carried out locally while formal GPU timings run. No expected
benefit, approximate capacity, or zero-edit labor claim is an acceptance gate.
