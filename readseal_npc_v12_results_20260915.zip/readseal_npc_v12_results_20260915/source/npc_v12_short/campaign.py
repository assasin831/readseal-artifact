"""Fresh-only serial campaign using the unchanged validated GPU executor."""
import argparse
import datetime
import fcntl
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback

ROOT = Path('/www/readseal_ipdps_revision_v6')
HERE = Path(__file__).resolve().parent
OLD = ROOT/'prototype_borrowplan_v11_grouped_attempt1'
BASE = ROOT/'results/npc_v12_short_20260915_attempt1'
sys.path.insert(0, str(OLD))
import launch_grouped_formal as original
from protocol import PLAN, schedule

sha = original.sha


def write(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def duplicates():
    found = []
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            args = (proc/'cmdline').read_bytes().split(bytes([0]))
            scripts = [Path(a.decode(errors='replace')).name for a in args
                if a.endswith(b'.py') and any(n in a for n in
                (b'run_grouped', b'run_observed', b'campaign.py', b'launch_grouped', b'supervisor.py'))]
            if scripts and int(proc.name) != os.getpid():
                found.append(dict(pid=int(proc.name), scripts=scripts))
        except OSError:
            pass
    return found


def preflight():
    with (ROOT/'borrowplan_gpu0.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        busy, dup = original.compute(), duplicates()
        assert not busy and not dup, (busy, dup)
        free = shutil.disk_usage(ROOT).free
        assert free > 20*2**30
        print(json.dumps(dict(status='IDLE', utc=utc(), free_gib=free/2**30, duplicates=dup)))


def prepare():
    preflight()
    prior_path = ROOT/'results/borrowplan_v11_grouped_formal_attempt1/report.json'
    prior = json.loads(prior_path.read_text())
    assert prior['status'] == 'COMPLETE' and len(prior['runs']) == 96
    assert all(sha(p) == h for p, h in prior['bindings'].items())
    bindings = dict(prior['bindings'])
    for path in [prior_path, *sorted(HERE.glob('*.py')), HERE/'PROTOCOL.md']:
        bindings[str(path)] = sha(path)
    previous = ROOT/'results/npc_loadscan_v7_continue_20260915/formal/audit/analysis.json'
    proof = json.loads(previous.read_text())
    assert proof['status'] == 'COMPLETE' and len(proof['rows']) == 72
    bindings[str(previous)] = sha(previous)
    BASE.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1',
               OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
               PYTHONPATH=':'.join(map(str, original.DEPS)))
    subprocess.run([sys.executable, '-B', str(HERE/'host_inventory.py'), str(BASE/'host_environment.json')],
                   cwd=ROOT, env=env, check=True)
    bindings[str(BASE/'host_environment.json')] = sha(BASE/'host_environment.json')
    frozen = dict(status='PREPARED', utc=utc(), plan=PLAN,
        schedules={p:schedule(p) for p in ('smoke','e1','e2')},
        bindings=bindings, gpu_uuid=original.GPU, inference_executed=False)
    write(BASE/'prepared.json', frozen)
    (BASE/'PREPARED').write_text('No inference executed\n')
    print(json.dumps(dict(status='PREPARED', sha256=sha(BASE/'prepared.json'), counts=PLAN['expected_runs'])))


def dispatch():
    preflight()
    frozen = json.loads((BASE/'prepared.json').read_text())
    assert frozen['plan'] == PLAN and all(sha(p)==h for p,h in frozen['bindings'].items())
    launch = BASE/'controller'
    launch.mkdir(exist_ok=False)
    with (launch/'launcher.log').open('x') as log:
        child = subprocess.Popen([sys.executable, '-B', '-u', str(Path(__file__)), 'run'],
            cwd=ROOT, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
            start_new_session=True, close_fds=True)
    write(launch/'dispatch.json', dict(pid=child.pid, utc=utc(), no_retry=True))
    print(json.dumps(dict(status='DISPATCHED', pid=child.pid, output=str(BASE))))


def run():
    frozen = json.loads((BASE/'prepared.json').read_text())
    result = dict(status='RUNNING', utc_start=utc(), active=None, completed_stages=[])
    control = BASE/'controller'
    code = 2
    current = None
    folder = None
    try:
        with (ROOT/'borrowplan_gpu0.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            assert not original.compute() and not duplicates()
            for phase in ('smoke', 'e1', 'e2'):
                assert frozen['schedules'][phase] == schedule(phase)
                folder = BASE/phase
                folder.mkdir(exist_ok=False)
                current = dict(status='RUNNING', utc_start=utc(), phase=phase, runs=[], active=None,
                    schedule=frozen['schedules'][phase], plan=PLAN, bindings=frozen['bindings'],
                    prepared_sha256=sha(BASE/'prepared.json'), gpu_uuid=original.GPU)
                env = dict(os.environ, PYTHONPATH=':'.join(map(str, [HERE]+original.DEPS)),
                    CUDA_VISIBLE_DEVICES=original.GPU, PYTHONDONTWRITEBYTECODE='1',
                    OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
                    CUDA_CACHE_PATH=str(folder/'cuda-cache'))
                for item in current['schedule']:
                    assert all(sha(p)==h for p,h in frozen['bindings'].items()), 'frozen input changed'
                    busy = original.compute()
                    if busy:
                        current.update(status='PAUSED_BEFORE_INFERENCE', next_unstarted=item['name'])
                        raise RuntimeError('foreign compute before inference; do not repeat completed runs')
                    assert shutil.disk_usage(ROOT).free > 15*2**30
                    current['active'] = item['name']
                    result['active'] = dict(phase=phase, run=item['name'])
                    write(folder/'report.json', current)
                    write(control/'status.json', result)
                    start = time.monotonic()
                    cmd = [sys.executable, '-B', str(OLD/'run_grouped_admission.py'),
                        '--output', str(folder/item['name']), '--cell', json.dumps(item['cell']),
                        '--method', item['method']]
                    with (folder/(item['name']+'.log')).open('x') as log:
                        rc = subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
                    inference_seconds = time.monotonic()-start
                    assert rc == 0, item['name']+' inference failed; never retry'
                    vp = folder/(item['name']+'-validation')
                    with (folder/(item['name']+'-validation.log')).open('x') as log:
                        rc = subprocess.run([sys.executable,'-B',str(OLD/'validate_grouped_pipeline.py'),
                            '--run',str(folder/item['name']),'--output',str(vp),'--kind','cell'],
                            cwd=ROOT,env=dict(env,CUDA_VISIBLE_DEVICES=''),stdout=log,stderr=subprocess.STDOUT).returncode
                    assert rc == 0, item['name']+' validator failed; preserve inference'
                    current['runs'].append(dict(item, inference_seconds=inference_seconds,
                        total_seconds=time.monotonic()-start,
                        report_sha256=sha(folder/item['name']/'report.json'),
                        validation_sha256=sha(vp/'validation.json')))
                    current['active'] = None
                    write(folder/'report.json', current)
                    print(json.dumps(dict(status='RUN_COMPLETE',phase=phase,completed=len(current['runs']),
                        total=len(current['schedule']),name=item['name'],seconds=time.monotonic()-start)),flush=True)
                current.update(status='COMPLETE', utc_end=utc())
                write(folder/'report.json',current)
                (folder/'COMPLETE').write_text('COMPLETE\n')
                with (folder/'audit.log').open('x') as log:
                    rc = subprocess.run([sys.executable,'-B',str(HERE/'audit.py'),phase],cwd=ROOT,
                        env=dict(env,CUDA_VISIBLE_DEVICES=''),stdout=log,stderr=subprocess.STDOUT).returncode
                assert rc == 0, phase+' independent audit failed; no next-stage inference'
                result['completed_stages'].append(dict(phase=phase,analysis_sha256=sha(folder/'audit/analysis.json')))
                result['active'] = None
                write(control/'status.json',result)
        result['status'], code = 'COMPLETE', 0
    except BaseException:
        result.update(status='FAILED',traceback=traceback.format_exc())
        if current is not None and current['status']=='RUNNING':
            current.update(status='FAILED',traceback=traceback.format_exc())
            write(folder/'report.json',current)
            (folder/'FAILED').write_text('FAILED\n')
        elif current is not None and current['status']=='PAUSED_BEFORE_INFERENCE':
            write(folder/'report.json',current)
            (folder/current['status']).write_text(current['status']+'\n')
        traceback.print_exc()
    result['utc_end'] = utc()
    write(control/'status.json', result)
    (control/result['status']).write_text(result['status']+'\n')
    (control/'exit_code').write_text(str(code)+'\n')
    return code


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('action',choices=['preflight','prepare','dispatch','run'])
    a = p.parse_args()
    if a.action == 'run':
        raise SystemExit(run())
    globals()[a.action]()
