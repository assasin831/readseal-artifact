import ast
from collections import Counter
from pathlib import Path
import unittest
from protocol import PLAN, schedule


class ProtocolTests(unittest.TestCase):
    def test_counts_and_disjoint_names(self):
        all_names=[]
        for phase,n in [('smoke',6),('e1',108),('e2',36)]:
            rows=schedule(phase)
            self.assertEqual(len(rows),n)
            self.assertEqual(rows,schedule(phase))
            self.assertEqual(set(Counter((r['condition']['id'],r['method']) for r in rows).values()),
                             {1 if phase=='smoke' else 6})
            all_names.extend(r['name'] for r in rows)
        self.assertEqual(len(all_names),len(set(all_names)))

    def test_fixed_inputs(self):
        for phase in ['e1','e2']:
            for row in schedule(phase):
                cell=row['cell']
                self.assertEqual([cell[k] for k in ['model','ring','outstanding_cap','consumers','queue','deadline_ms','warmup_seconds','measure_seconds']],
                                 ['transfusion',1,0,4,2,100,2,12])
        self.assertEqual({r['cell']['rate_hz'] for r in schedule('e1')},{10,15,20,25,30,40})
        self.assertEqual({r['cell']['late'] for r in schedule('e2')},{False,True})
        self.assertEqual(PLAN['bootstrap_replicates'],20000)
        self.assertTrue(PLAN['no_inference_retry'])

    def test_sources_parse(self):
        for p in Path(__file__).parent.glob('*.py'):
            ast.parse(p.read_text(),filename=str(p))


if __name__=='__main__':
    unittest.main()
