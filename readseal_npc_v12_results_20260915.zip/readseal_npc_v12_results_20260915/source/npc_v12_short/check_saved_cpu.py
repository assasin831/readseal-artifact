"""Exercise the unchanged validators and new diagnostics on saved real runs."""
import json
import audit

c=audit.c
root=c.ROOT/'results/borrowplan_v11_grouped_formal_attempt1'
report=json.loads((root/'report.json').read_text())
audit.validator.validate_abc.cell=audit.validator.cell
tested=[]
for method in audit.METHODS:
    entry=next(r for r in report['runs'] if r['method']==method)
    run=root/entry['name']
    checked=audit.validator.validate_admission.audit(run)
    sink=[r for r in json.loads((run/'sink.json').read_text()) if r['cohort']]
    raw=json.loads((run/'report.json').read_text())
    producers={r['tick']:r for r in raw['producer']}
    assert all(r['release_end_ns']>=producers[r['tick']]['commit_end_ns'] for r in sink)
    assert all(r['output_done_ns']>=r['read_done_ns'] for r in sink)
    assert checked['publications']==len(sink)
    tested.append(dict(method=method,run=entry['name'],receipts=len(sink)))
print(json.dumps(dict(status='COMPLETE',cases=tested,inference_executed=False,cuda_used=False)))
