# ReadSeal NPC 2026 V12 修改方案（截稿前冲刺版）

写于 2026-09-15。目标：在不做长实验的前提下，(1) 重建论文体系，(2) 用 3–4 个短实验把"头条数字依赖人为约束"和"核心卖点无证据"两个硬伤补成"有条件、可预测的收益"，(3) 按时提交。

## 0. 时间与原则

- NPC 截稿一般按 AoE 计：9 月 15 日 23:59 AoE = 北京时间 9 月 16 日 20:00，与"明天晚上 8 点"一致。下文一律按"距截稿 N 小时（T−N）"写。**如果你现在看的是北京时间（约 23:00），只剩约 21 小时，GPU 实验必须今晚睡前 dispatch，让它无人值守跑完。**
- 所有新实验必须与 V10 冻结数据同机同环境（GPU0 A100、PyTorch 2.1.2、CUDA 12.1、TensorRT 10.3、同一 `run_grouped_admission.py`），否则不能与旧数字放在一张图里。
- 任何实验若在预算内没跑完/没过 validator，就不进论文，写进 limitations；不补数、不外推。
- 论文体系重构不依赖新实验：即使 E1/E2 全失败，V12 也按新结构重写，只是删掉对应段落。
- T−3 h 必须提交，剩余时间只允许改错字。

## 1. 论文体系重构

导师和师兄说"没有形成体系"，具体指：全文是事实的堆砌，没有一条主线把"问题—洞察—机制—保证—评估"串起来，术语太多且不定义，评估各段之间没有相互回应。下面把体系钉死。

### 1.1 一句话主论点（全文都为它服务）

> 在共享槽池的 GPU 流水线里，**槽的释放策略就是一个隐式的准入控制器**。Full retention 把释放绑在输出完成上，池子小的时候会以一种与到达相位耦合的方式拒绝发布；手工提前释放解开了这个耦合，但边界随模型变化而失效；ReadSeal 通过"推导 + 登记 + 绑定"的借用计划让提前释放既安全又可维护——代价是检查开销，并且必须用显式准入（K）取代被拿掉的隐式准入。

这句话同时解释了论文所有的正面结果（一槽 78.5 vs 60.0）、负面结果（两槽无上限 −47）、以及"加槽加 K 后持平"的结果。这就是体系。

### 1.2 概念体系（术语表，全文只允许这 8 个）

| 术语 | 定义（Sect. 3.1 一次性给出） |
| --- | --- |
| slot / pool | 可复用的显存缓冲；R 个 slot 构成 pool |
| publication k | 放进某个 slot 的第 k 个输入版本 |
| reader（recipient） | 声明要读 publication 的组件（A、B、C） |
| borrow | reader 对一个 publication 的存储访问权，持续到它最后一次读完成 |
| read boundary | 子图中最后一次读共享输入的操作；之前是 read prefix，之后是 private suffix |
| borrowing plan | 一个 reader 的推导边界 + 登记的 reader 集 + 绑定令牌 |
| enrollment | 执行前把所有声明 reader 登记为 pending，拒绝迟到登记 |
| binding | 把 plan 绑到实际运行的代码、模型状态、输入版本 |

删除或降级的词：lease、descriptor（只在 Table 1 出现一次）、credit（改说"每个 reader 最多 4 个在途请求"）、cohort、sink（改说"结果接收端"）、Original / Grouped / auto-batched（正文统一叫 ReadSeal，脚注说明 artifact 里还有一个逐阶段执行器）、"540 tensors"、"38 unused tuple-index nodes"、epoch rotation / 2^63。

### 1.3 需求 → 机制 → 评估问题 的映射（体系的骨架）

| 需求（Sect. 3.4） | 机制（Sect. 4） | 评估问题（Sect. 6） |
| --- | --- | --- |
| R1 完整性：任何释放前必须计入所有声明的 reader，包括尚未提交的 | enrollment（4.3） | Q1：未来读者覆写测试 |
| R2 精确性：在最后一次源读之后释放，而不是输出完成之后 | read-set analysis（4.2） | Q2：何时提前释放带来收益（新 E1/E2） |
| R3 一致性：边界必须对实际运行的代码/状态/输入成立 | binding（4.3） | Q1：14 张图 + BN fold + 架构替换 + 22 个拒绝案例 + 维护负担表（新 E3） |
| 代价 | 检查执行器（4.4） | Q3：开销与分解（E4） |
| 释放 ≠ 调度 | 与准入控制的关系（6.5） | Q4：无上限两槽的反转，K=8 恢复 |

正文里每个评估小节开头一句话点明它回答哪个 Q、对应哪个 R。

### 1.4 新章节结构与页数预算（共 12 页含参考文献）

**摘要（0.5 页）**：问题 2 句 → 洞察 1 句（两种生命周期；释放即隐式准入）→ 系统 2 句（推导/登记/绑定）→ 结果 3 句（维护：X/16 次变更手工规则要改而 ReadSeal 不用；收益：一槽 78.5 vs 60.0，收益随负载和边界位置变化，两槽消失；代价：6–23%，需配准入）→ 结论 1 句。

**1 Introduction（1.3 页）**
- P1 场景：多组件 GPU 推理流水线跨进程共享大张量（BEV 63.3 MiB），零拷贝把生命周期问题交给中间件。
- P2 危险：未来读者。A/B/C 例子 4 句话；基于流的跟踪覆盖不了未提交的 reader。
- P3 两种现有做法和代价：Full retention（安全，但槽被私有计算占着，池子变成粗粒度隐式准入）vs 手工提前释放（快，但残差、clone、BN 折叠、换架构都要重新看边界）。
- P4 洞察：两种生命周期——结果在数值上永远依赖输入，但只在最后一次源读之前借用它的存储；这个边界可以从图推导、在运行时检查。
- P5 ReadSeal 一段话。
- P6 结果 3 句（含诚实框架：小池/早边界才有收益；代价；需 K）。
- P7 贡献 C1–C3 + 范围一句。

**2 Related Work（0.6 页）**：保留三段，压缩；补零拷贝中间件（ROS 2 / iceoryx、Cyber RT）、PipeSwitch 类显存移交、`cudaMallocAsync` 流序分配器；一句话说明与 Rust 借用检查的类比与区别。

**3 Problem: Two Lifetimes of a Shared Tensor（1.1 页）**
- 3.1 系统模型与术语表（1.2 节那 8 个词）；Fig. 1 = 现有 architecture 图，作为贯穿全文的 running example。
- 3.2 未来读者危险：失败序列；为什么 record_stream / 提交时引用计数不够。
- 3.3 两种生命周期与 read boundary；Full = 输出完成时释放；Manual = 手工边界。
- 3.4 需求 R1–R3 + 信任边界预告。

**4 ReadSeal Design（2.3 页）**
- 4.1 总览：borrowing plan 含什么；生命周期 admit → submit → return source → publish；derive / check / trust 三分；R1–R3 到机制的映射。
- 4.2 推导边界：Eq. 1–2，在 running example（x→view→conv→tail，加 `add(z,x)` 反例）上走一遍；42 个 overload 与拒绝规则；prefix/suffix 切分；一个 event 覆盖所有读。
- 4.3 登记与绑定：执行前登记、拒绝迟到；绑定令牌（代码、globals、模型存储/版本、输入元数据、程序身份）；不匹配时在受影响阶段之前拒绝，abort 排空。
- 4.4 释放协议：Table 1（5 行，压缩）；进程共享保护位；producer join；publish 交付 admitted identity。实现一句话：PyTorch 2.1.2 / ATen、TensorRT native contract、CUDA IPC、events。脚注：artifact 里还有逐阶段执行器，所有结果用合并执行器。

**5 Safety Guarantee and Trust Boundary（0.5 页）**：三条前提、Proposition 1、证明概要（缩短）、契约之外的东西。删 epoch rotation 细节（一句"64 位序列号"）。

**6 Evaluation（4.0 页）**
- 6.0 路线图：Q1–Q4。
- 6.1 Setup：平台（补 CPU/驱动/OS，E7）、两个 workload、流水线参数（4 个 reader、每个 reader 跑 A/B/C、30 pub/s → 120 bundles/s、D=100 ms、深度 2 队列、每 reader 4 个在途、可选全局上限 K）、三种机制（ReadSeal / Manual / Full，其余全部匹配）、Eq. 3、统计方法。
- 6.2 Q1 变更下的正确性与维护（R1–R3）：(a) 未来读者覆写测试；(b) 14 张图 + BN fold + 架构替换：Table 2 加两列"手工规则需改的字段数 / ReadSeal 需改"，加一句每张图重分析耗时（E3）；(c) 22 个绑定拒绝。结论句。
- 6.3 Q2 何时提前释放改善交付：(a) 释放即隐式准入：占用率 λ·T_hold/R 论证，用 protected storage 反推的实测 T_hold；(b) 一槽：78.50 vs 60.00，accept/busy 交替（Fig. 2a）；(c) **新** R=1 速率扫描（Fig. 3a，E1）：收益在哪里出现、哪里消失，Manual ≈ ReadSeal；(d) **新** 边界位置扫描（Fig. 3b，E2）：late 变体收益趋近 0；(e) 两槽：78.25 vs 78.24，protected storage −34 MiB，峰值不变。结论：收益 = f(池大小, 负载, 边界位置)。
- 6.4 Q3 检查的代价：Table 3 + 分解（E4）；摊销空间。
- 6.5 Q4 提前释放需要显式准入：两槽无上限 −47（迟到解释）、负载扫描（Fig. 4a）、cutoff 敏感性（Fig. 4b 或一段文字）、K=8 恢复。结论：安全复用 ≠ 调度策略。
- 6.6 局限与威胁：单 GPU 架构、固定形状、周期到达、两个模型、无开发者研究、算子覆盖（若做了 E6）。

**7 Conclusion（0.25 页）** + Credits（0.15）+ References（1.3，23 → 最多 27 条）。

合计约 12.1 页，重写时在 4 和 6 里压。

### 1.5 图表规划

| 编号 | 内容 | 状态 |
| --- | --- | --- |
| Fig. 1 | 现有 architecture.pdf，作为 running example，图题重写 | 保留 |
| Fig. 2 | 现有 delivery.pdf；为省页可只留 (a)，(b) 独立窗口改为正文一句话 | 保留/裁剪 |
| Fig. 3 | **新**：(a) R=1 goodput vs 发布率，三种机制 + 虚线 offered load 与容量；(b) 收益 vs 边界位置（base / [middle] / late） | 新增（E1/E2） |
| Fig. 4 | 现有 sensitivity.pdf（R=2 负载扫描 + cutoff） | 保留，可缩为单栏 |
| Table 1 | 协议 5 行 | 压缩 |
| Table 2 | 边界计数 + 新增"手工规则需改字段数 / ReadSeal 需改"两列 | 扩展（E3） |
| Table 3 | 隔离执行时间 + 一行/一小表开销分解 | 扩展（E4） |

### 1.6 写作规范（重写时逐条对照）

1. 每节开头 2–3 句路线图；每个评估小节按 问题 → 设置 → 结果 → 结论 四步；每段首句是结论句（加粗短语）。
2. 三种机制固定命名 ReadSeal / Manual / Full；正文不出现 Original、Grouped、auto-batched。
3. 每个数字必须能在图或表里找到；解释不了来源的计数一律删。
4. 术语只用 1.2 节那 8 个；其余首次出现即定义，或不用。
5. 图题自解释：x/y 含义、单位、误差条是什么、n 是多少。
6. 短句、主动语态，每段不超过 6 句；删掉所有"密码句"（如 "Sequence validation cannot authorize races"）。
7. 摘要里的开销同时给对 Manual 和对 Full 的数字，不只报有利的那个。
8. 修掉已知小错：Eq. (3) 结尾逗号；ResNet-18 "8/85" 与 "12/123" 统一成一个导出；Fig. 2 下半 "vs. Manual" 标记加大。

## 2. 实验计划（按优先级；GPU 总用时约 1.5–2 h）

现有 harness 已支持所需全部参数：`run_grouped_admission.py --cell {...} --method {...}`，cell 字段 `model / late / consumers / queue / deadline_ms / warmup_seconds / measure_seconds / ring / outstanding_cap / rate_hz`，方法 `auto-batched`（= ReadSeal）、`manual-early`、`manual-full`。做法：复制 `prototype/npc_loadscan_v7_continue`，只改 `protocol.py` 的 `CONDITIONS / METHODS / COMMON`，沿用 supervisor 的 smoke → formal → audit 链。每 run 约 27 s（V7 实测）。

### E1 R=1 发布率扫描（必做，GPU ≈ 50–60 min）

- cell：`model=transfusion, late=False, consumers=4, queue=2, deadline_ms=100, warmup=2, measure=12, ring=1, outstanding_cap=0`，`rate_hz ∈ {10, 15, 20, 25, 30, 40}`（有余力加 35）。
- 方法：`auto-batched, manual-early, manual-full`；6 次随机化配对重复 → 108 runs（加 35 Hz 为 126）。
- 目的：把一槽结果从一个点变成一条曲线，并检验占用率预测：Full 的槽保持时间 T_hold ≈ 50 ms，因此发布周期 < 50 ms（> 20 Hz）时 Full 开始拒绝；ReadSeal 应跟随 min(offered, 容量≈78)。
- 写法（两种结果都能写）：若 Full 呈锯齿（25 Hz ≈ 50、30 Hz = 60、40 Hz 接近 78），写"耦合释放使池子成为相位相关的准入控制器"；若单调，写"收益随负载超过池占用上限而增大"。若 ≤ 20 Hz 无差异，直接写"低于占用上限时三者交付全部请求"——这正是主论点。
- 进论文：Fig. 3a、6.3(c)、摘要一句。

### E2 边界位置扫描（必做，GPU ≈ 16–25 min）

- cell：同 E1，`rate_hz=30, ring=1, cap=0`，`late ∈ {False, True}`；三种方法；6 次重复 → 36 runs。
- 若能在 30 分钟内让 delivery harness 加载 "middle source clone"（144/289）快照并通过 smoke，则加 middle → 54 runs；否则两点 + Table 2 的结构位置足够。
- 目的：证明收益由边界之后剩余的工作量决定：late 变体（288/289）收益应趋近 0（ReadSeal ≈ Full ≈ 60），base 为 +18.5。这同时是诚实的最坏情况。
- 进论文：Fig. 3b、6.3(d)。

### E3 维护负担表（必做，CPU 桌面工作 1–2 h）

- 数据源：`evidence/maintenance_validation.json`、`folding_validation.json`、`public_model_cpu*.json`、手工规则文件。
- 对 16 个变更案例（14 张图 + BN fold + ResNet-50 替换）填：(i) 手工规则必须改哪些字段（reader 列表 / 边界算子名 / 图哈希）及改动条数；(ii) 用陈旧规则会怎样：被 stale hash 拦下（14 例）/ 产生错误输出（仅流跟踪的 6 例覆写失败）/ 不适用；(iii) ReadSeal 需改 0 处，仅重导出 + 重分析，记录每张图 CPU 分析耗时（秒级）。
- 进论文：Table 2 新增两列 + 6.2(b) 一句量化结论，替换现在那句读者看不懂的 "Fourteen constructed stale-hash cases test edit consistency"。

### E4 开销分解（必做，CPU 桌面工作 ≈ 1 h）

- 数据源：`evidence/profile.json`（2,560 次插桩调用）、`executor_cost.json`。
- 输出：ReadSeal vs Manual 每阶段 host 时间——admission/绑定检查、enrollment、submit 检查、event 记录/查询、source return、publish；标注插桩本身 +7–34%，作为诊断数据，Table 3 的隔离总时间不变。
- 再算一句：检查开销占 Table 3 差值的比例（如 head 上 admission 0.67−0.34 = 0.33 ms 占 0.85 ms 差值的约 40%），并给出"按模型版本缓存绑定令牌"的摊销上界，作为 future work。

### E5 ResNet 子图 delivery（可选，GPU ≈ 15–30 min，先 smoke）

- ResNet 单次约 3–4 ms，Full 的 T_hold ≈ 15–20 ms，所以要 > 50 Hz 才看得到一槽差异。先 smoke `rate_hz ∈ {60, 90}` 各 1 run，确认 `producer_late = 0` 且 validator 通过；通过后 `{60, 90} × {auto-batched, manual-full} × 6 = 24 runs`。
- smoke 失败或总用时超过 45 min 就放弃，不进论文。

### E6 算子覆盖调查（可选，CPU 2–3 h，可后台跑）

- 对 torchvision 0.16.2 的 12–15 个分类模型（resnet18/34/50/101、resnext50、wide_resnet50、vgg16、densenet121、mobilenet_v2/v3、efficientnet_b0、regnet_y_400mf、convnext_tiny、shufflenet_v2、vit_b_16、swin_t）在 stem 接口做导出 + 分析，记录：是否被 42 个 overload 完全支持、不支持的算子名、prefix/total。
- 结果好放 6.2，结果差放 6.6 作为覆盖率声明。T−12 h 决定是否纳入。

### E7 主机信息（必做，5 min）

`lscpu | head -20`、`nvidia-smi --query-gpu=name,driver_version --format=csv`、`python -V`、`cat /etc/os-release`、`pip show torch tensorrt`。补上 V9 审计承认的环境缺口；若旧实验同机，写"same host"。

### 明确不做（写进 6.6）

Jetson/Orin 平台、开发者研究、抖动/突发到达、torch.compile / CUDA Graph 兼容、多流子图。

## 3. 数据交付格式（发给我什么）

- E1 / E2 / E5：与 `results/npc_loadscan_v7_formal_analysis_final1.json` 同 schema 的 analysis JSON（`rows` + `summary` 含配对差与 CI），外加一份扁平 CSV，列：`run, repeat, method, model, late, ring, cap, rate_hz, arrivals, publications, timely, correct_late, producer_late, pool_exhausted, credit_exhausted, queue_loss, goodput_hz, mean_protected_mib, protected_byte_seconds`；runner 若输出 admission 等待 / 接收延迟 / 峰值显存，也一并给。
- E3：CSV，列：`case, model, prefix_total_before, prefix_total_after, manual_fields_changed, manual_edit_count, stale_rule_outcome, readseal_edits, reanalysis_seconds`。
- E4：CSV，列：`phase, readseal_ms_mean, manual_ms_mean, calls, note`。
- E6：CSV，列：`model, supported, unsupported_ops, prefix_ops, total_ops`。
- E7：纯文本。
- 我这边负责：v12 全部 LaTeX、Fig. 3 的绘图脚本（读你的 JSON/CSV，不手抄数字）、Table 2/3 扩列、编译到 12 页、跑你现有的 `qa_submission` 检查。

## 4. 时间表（T = 截稿）

| 时段 | 你 | 我 |
| --- | --- | --- |
| T−33 → T−31 | 与导师/师兄 15 分钟确认 1.1–1.4；复制 v7_continue 写 protocol_v8（E1+E2）；smoke 2 runs；dispatch（GPU ≈ 1.3 h，自动 audit） | 用现有数据开始写 v12 骨架，新数字留占位符 |
| T−31 → T−28 | 做 E3、E4、E7；GPU 完成后立刻把 analysis JSON + CSV 发我；有余力 smoke E5 | 继续写 Sect. 1–5 |
| T−28 → T−20 | 睡觉（如果你在北京时间，这段就是夜里） | 完成 v12 全文初稿 + Fig. 3 脚本 |
| T−20 → T−16 | 看初稿 | 填入 E1/E2 数据、出 Fig. 3、编译到 12 页，发导师/师兄 |
| T−16 → T−10 | 收导师意见；决定 E5/E6 是否纳入 | 回炉修改、参考文献、QA |
| T−10 → T−5 | 通读 | 定稿、打包 zip、页数/字体/引用检查 |
| T−5 → T−3 | **提交**（留 3 h 缓冲） | 只改错字 |

## 5. 现在需要你确认的 3 件事

1. 结构：Related Work 是否仍按之前要求放在 Introduction 之后（我按"是"写）；正文是否同意去掉 Original 执行器（我按"去掉"写）。
2. 题目不变（可选替换：*ReadSeal: Checked Borrowing Plans for Safe Early Reuse of Shared GPU Tensors*）。
3. 你当前的本地时间，用来把上表换算成钟点。
