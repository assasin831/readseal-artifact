"""New observations around the unchanged formal producer/consumer protocol."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace

ROOT = Path('/www/readseal_ipdps_revision_v6')
sys.path.insert(0, str(ROOT/'prototype_borrowplan_v11_grouped_attempt1'))
from launch_grouped_formal import DEPS
sys.path.extend(str(p) for p in DEPS if str(p) not in sys.path)
import run_grouped_admission as original
from queue_observer import ObservedContext
import queue_observer


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--cell', required=True)
    p.add_argument('--method', choices=original.METHODS, required=True)
    a = p.parse_args()
    assert a.output.resolve().is_relative_to(ROOT) and not a.output.exists()
    assert not original.compute_pids(), 'foreign GPU compute; no inference launched'
    original.configure()
    cell = json.loads(a.cell)
    ctx = ObservedContext(original.base.mp.get_context('spawn'), cell['queue'])
    original.base.mp = SimpleNamespace(get_context=lambda mode: ctx if mode == 'spawn' else None)
    original.base.make_program = original.factory
    original.base.consumer = original.consumer
    original.base.source_inventory = original.inventory
    result = original.base.measure_cell(a.output, cell, a.method)
    assert len(ctx.command_queues) == cell['consumers']
    observations = dict(schema='per-recipient-queue-api-spans-v1',
        scope='put call brackets and get-return observation, not transport linearization or kernel start',
        records=[r for q in ctx.command_queues for r in q.records],
        sources={str(Path(m)):hashlib.sha256(Path(m).read_bytes()).hexdigest()
                 for m in (__file__,queue_observer.__file__,original.__file__)})
    with (a.output/'queue_observations.json').open('x') as out:
        json.dump(observations, out, indent=2)
        out.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
