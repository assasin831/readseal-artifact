"""Re-audit the frozen Grouped campaign; no inference, no modified old files."""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile
import traceback

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
OLD = ROOT / 'prototype/borrowplan_v11'
sys.path.insert(0, str(OLD))
import analyze_existing_traces as trace

PINS = {
    'raw_release_attempt1/inventory.json': '8851225f0c9b0b6b1b1ddd05baca439ed871af7c2ea548a920fc586fda361616',
    'raw_release_attempt1/evidence.tar.gz': '5822b90b602419f06215f38beded3a13fc8854a071f279b0735e0db1ca84a45c',
    'grouped_aggregate_attempt1/analysis.json': '8abb23d796a4176e6c850e8994ea429d9d0eff14757e28ea9cd49f8778e7120a',
}
METHODS = ('auto-batched', 'auto-early', 'manual-early', 'manual-full')
SEED = 26091406


def sha(p):
    return trace.sha(p)


def summarize(rows):
    draws = np.random.default_rng(SEED).integers(0, 6, size=(20000, 6))
    result = []
    for condition in sorted({r['condition'] for r in rows}):
        subsets = {}
        group = dict(condition=condition, methods={}, grouped_minus_full={})
        for method in METHODS:
            rr = sorted((r for r in rows if r['condition'] == condition and r['method'] == method),
                        key=lambda r: r['repeat'])
            assert [r['repeat'] for r in rr] == list(range(6))
            subsets[method] = rr
            metrics = ('goodput_hz', 'conditional_receipt_fraction_late', 'phase_mean_ms',
                       'phase_p50_ms', 'phase_p95_ms', 'offered_timely_fraction')
            item = {m: trace.estimate([r[m] for r in rr], draws) for m in metrics}
            item['occupancy'] = {k: trace.estimate([r['occupancy'][k]['mean'] for r in rr], draws)
                                 for k in rr[0]['occupancy']}
            item['received'] = sum(r['received'] for r in rr)
            item['timely'] = sum(r['timely'] for r in rr)
            item['losses'] = {k: sum(r['losses'][k] for r in rr) for k in rr[0]['losses']}
            group['methods'][method] = item
        for metric in ('goodput_hz', 'phase_mean_ms', 'conditional_receipt_fraction_late'):
            diff = (np.asarray([r[metric] for r in subsets['auto-batched']]) -
                    np.asarray([r[metric] for r in subsets['manual-full']]))
            group['grouped_minus_full'][metric] = trace.estimate(diff, draws)
        result.append(group)
    return result


def run(output):
    output.mkdir(parents=True, exist_ok=False)
    report = dict(status='RUNNING', inference_executed=False, cuda_used=False,
                  interpretation='Post-hoc Grouped-specific mechanism analysis, not a new performance trial',
                  rows=[], pins=PINS, script_sha256=sha(__file__),
                  trace_helper_sha256=sha(trace.__file__))
    try:
        for rel, expected in PINS.items():
            assert sha(OLD/'evidence'/rel) == expected, rel
        old = json.loads((OLD/'evidence/grouped_aggregate_attempt1/analysis.json').read_text())
        assert old['status'] == 'COMPLETE' and len(old['rows']) == 96
        inv = json.loads((OLD/'evidence/raw_release_attempt1/inventory.json').read_text())['files']
        wanted = {}
        for row in old['rows']:
            rel = PurePosixPath(row['path']).relative_to('/www/readseal_ipdps_revision_v6')
            for name, field in [('report.json', 'run_sha256'), ('sink.json', 'sink_sha256')]:
                path = str(rel/name)
                assert inv[path]['sha256'] == row[field]
                wanted[path] = inv[path]
        blobs = {e['blob'] for e in wanted.values()}
        raw = {}
        with tarfile.open(OLD/'evidence/raw_release_attempt1/evidence.tar.gz', 'r|gz') as archive:
            for member in archive:
                if member.name in blobs:
                    assert member.isfile() and member.name not in raw
                    content = archive.extractfile(member).read()
                    assert hashlib.sha256(content).hexdigest() == PurePosixPath(member.name).name
                    raw[member.name] = content
        assert set(raw) == blobs
        report['raw_bindings'] = wanted
        request_checks = 0
        for row in old['rows']:
            rel = PurePosixPath(row['path']).relative_to('/www/readseal_ipdps_revision_v6')
            loaded = []
            for name in ('report.json', 'sink.json'):
                entry = wanted[str(rel/name)]
                content = raw[entry['blob']]
                assert len(content) == entry['bytes']
                loaded.append(json.loads(content))
            checked = trace.audit_run(*loaded, row)
            assert checked['goodput_hz'] == row['goodput_hz']
            request_checks += len(loaded[1])
            report['rows'].append(checked)
        assert len({(r['repeat'], r['condition'], r['method']) for r in report['rows']}) == 96
        assert {r['method'] for r in report['rows']} == set(METHODS)
        report.update(status='COMPLETE', request_records_reaudited=request_checks,
                      summary=summarize(report['rows']), phase_order=trace.PHASES,
                      bootstrap_replicates=20000, bootstrap_seed=SEED,
                      sampling_unit='paired complete repetition; six repeats; pointwise intervals',
                      timing_scope='host observations, not GPU kernel service times',
                      queue_scope='bounds using producer commit_end and producer_done; no exact enqueue point',
                      source_return_scope='per-recipient release completion, not the last global pool-bit clear',
                      metrics_population='received cohort requests; drops separately accounted from all offers')
    except BaseException:
        report.update(status='FAILED', traceback=traceback.format_exc())
        traceback.print_exc()
    (output/'analysis.json').write_text(json.dumps(report, indent=2)+'\n')
    (output/report['status']).write_text(report['status']+'\n')
    print(json.dumps(dict(status=report['status'], runs=len(report['rows']),
                          sha256=sha(output/'analysis.json'))))
    return 0 if report['status'] == 'COMPLETE' else 1


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    assert a.output.resolve().is_relative_to(ROOT.resolve())
    raise SystemExit(run(a.output))
