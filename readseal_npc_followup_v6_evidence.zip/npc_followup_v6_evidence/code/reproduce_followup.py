"""Validate the compact reviewer bundle with NumPy only; no CUDA or inference."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import sys
import zipfile
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import grouped_trace as gt


def run(root, output):
    checks = 0
    def check(ok, name):
        nonlocal checks
        assert ok, name
        checks += 1
    inv=json.loads((root/'INVENTORY.json').read_text())['files']
    for p,h in inv.items():
        check(gt.sha(root/p)==h, 'inventory '+p)
    primary=json.loads((root/'grouped_primary.json').read_text())
    direct=json.loads((root/'grouped_trace.json').read_text())
    check(gt.sha(root/'grouped_primary.json')==gt.PINS['grouped_aggregate_attempt1/analysis.json'], 'primary binding')
    check(primary['status']=='COMPLETE' and len(primary['rows'])==96, 'full grid')
    rows=[]
    with zipfile.ZipFile(root/'grouped_requests.zip') as raw:
        check(len(raw.namelist())==192, 'raw files')
        for expected in primary['rows']:
            loaded=[]
            for name,key in [('report.json','run_sha256'),('sink.json','sink_sha256')]:
                content=raw.read(expected['run']+'/'+name)
                check(hashlib.sha256(content).hexdigest()==expected[key], 'raw '+name)
                loaded.append(json.loads(content))
            rows.append(gt.trace.audit_run(*loaded,expected))
    check(rows==direct['rows'], 'exact request analysis')
    check(gt.summarize(rows)==direct['summary'], 'all 20000-replicate intervals')
    with zipfile.ZipFile(root/'public_model_outputs.zip') as raw:
        d=json.loads(raw.read('report.json'))
        v=json.loads(raw.read('validation.json'))
        m=json.loads(raw.read('manifest.json'))
        digest=hashlib.sha256(raw.read('report.json')).hexdigest()
        check(digest==v['report_sha256']==m['report_sha256'], 'model report binding')
        check(v['status']=='COMPLETE' and v['checks']==141, 'independent remote validation')
        check(d['tests']==12 and not d['cuda_initialized'], 'CPU scope')
        for r in m['outputs']:
            blob=raw.read(r['file'])
            check(hashlib.sha256(blob).hexdigest()==r['npz_sha256'], 'NPZ digest')
            with np.load(io.BytesIO(blob), allow_pickle=False) as arrays:
                a,b,c=[arrays[k] for k in ('actual','export_expected','expected')]
                check(a.shape==b.shape==c.shape==(1,1000), 'output shape')
                check(np.isfinite(a).all() and np.array_equal(a,b), 'exact finite output')
                check(np.allclose(a,c,rtol=1e-5,atol=1e-6), 'eager tolerance')
                check(hashlib.sha256(a.tobytes()).hexdigest()==r['actual_sha256'], 'actual hash')
    result=dict(status='COMPLETE',checks=checks,runs=96,requests=96764,cpu_model_outputs=12,
        inference_executed=False,cuda_used=False,bootstrap_replicates=20000,
        scope='raw-request analysis and saved-output reconstruction, not re-execution of models')
    with output.open('x') as f: json.dump(result,f,indent=2)
    print(json.dumps(result))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--bundle',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    run(a.bundle,a.output)
