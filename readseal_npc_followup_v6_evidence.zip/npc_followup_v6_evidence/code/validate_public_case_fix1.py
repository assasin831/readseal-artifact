"""Independent CPU recheck of saved public-model evidence; no model execution."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import traceback

import torch

ROOT = Path('/www/readseal_ipdps_revision_v6')


def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def th(t):
    return hashlib.sha256(t.contiguous().numpy().tobytes()).hexdigest()


def main(run, output):
    output.mkdir(parents=True, exist_ok=False)
    result = dict(status='RUNNING', inference_executed=False, cuda_used=False, checks=0)
    def check(ok, why):
        assert ok, why
        result['checks'] += 1
    try:
        torch.set_num_threads(1)
        check(os.environ.get('CUDA_VISIBLE_DEVICES') == '', 'CPU isolation')
        expected = '361d86e0442084cc781f0d4d24683322e50cd217952ff8773603d9833ed348db'
        check(len(expected) == 64 and sha(run/'report.json') == expected, 'frozen report')
        d = json.loads((run/'report.json').read_text())
        check(d['status'] == 'COMPLETE' and (run/'COMPLETE').exists() and not (run/'FAILED').exists(), 'markers')
        check(d['tests'] == 12 and not d['cuda_initialized'] and not d['performance_claim'], 'scope')
        for p,h in d['inputs'].items():
            check(sha(p) == h, 'input '+p)
        for p,h in d['implementation_sources'].items():
            check(sha(p) == h, 'implementation '+p)
        for p,h in d['files'].items():
            check(sha(run/p) == h, 'raw '+p)
        bank_path = ROOT/'inputs/resnet_transfer_v2/feature_bank.pt'
        bank = torch.load(bank_path, map_location='cpu', weights_only=True)
        check([c['model'] for c in d['cases']] == ['resnet18','resnet50'], 'models')
        for c in d['cases']:
            model = c['model']
            check(c['auto_boundary'] == c['review']['boundary'], 'boundary agreement')
            check((c['review']['reviewed_call_index_1based'],c['review']['total_calls']) ==
                  ((8,85) if model == 'resnet18' else (12,224)), 'fixed call counts')
            check(c['review']['no_automatic_analysis_used_for_review'], 'manual provenance')
            check(c['review']['developer_time_measured'] is False, 'no time study')
            tests = c['cpu_tests']
            check({(r['source_id'],r['method']) for r in tests} ==
                  {(sid,m) for sid in range(3) for m in ('automatic-lowered','manual-lowered')}, 'test grid')
            for r in tests:
                raw = torch.load(run/model/r['raw_file'], map_location='cpu', weights_only=True)
                check(torch.equal(raw['original'], bank[r['source_id']:r['source_id']+1]), 'actual bank row')
                check(th(raw['original']) == r['source_before'], 'source before')
                check(th(torch.full_like(raw['original'],12345.0)) == r['source_after'], 'overwrite value')
                check(r['source_before'] != r['source_after'], 'changed source')
                check(torch.equal(raw['actual'], raw['export_expected']), 'exact functional output')
                check(bool(torch.isfinite(raw['actual']).all()), 'finite')
                torch.testing.assert_close(raw['actual'], raw['expected'], rtol=1e-5, atol=1e-6)
                check(th(raw['actual']) == r['output_sha256'], 'actual output hash')
                check(r['overwrite_between_prefix_and_suffix'] and not r['carry_aliases_source'], 'recorded execution protocol')
        check(not torch.cuda.is_initialized(), 'no GPU initialized')
        result.update(status='COMPLETE', report_sha256=sha(run/'report.json'),
                      validator_sha256=sha(__file__), tests=12,
                      scope='saved-array/source hash validation; CPU synchronous protocol, no CUDA claim')
    except BaseException:
        result.update(status='FAILED', traceback=traceback.format_exc())
        traceback.print_exc()
    (output/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
    (output/result['status']).write_text(result['status']+'\n')
    print(json.dumps(result))
    return int(result['status'] != 'COMPLETE')


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--run', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    assert a.run.resolve().is_relative_to(ROOT) and a.output.resolve().is_relative_to(ROOT)
    raise SystemExit(main(a.run, a.output))
