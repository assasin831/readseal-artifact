"""Transparent queue-call observations, explicitly not a transport enqueue clock."""
import queue
import time


class ObservedQueue:
    def __init__(self, underlying, consumer):
        self.underlying = underlying
        self.consumer = consumer
        self.records = []

    def put_nowait(self, item):
        if item.get('op') != 'request':
            return self.underlying.put_nowait(item)
        message = dict(item)
        before = time.perf_counter_ns()
        message['queue_put_begin_ns'] = before
        ok = False
        try:
            self.underlying.put_nowait(message)
            ok = True
        finally:
            after = time.perf_counter_ns()
            self.records.append(dict(tick=item['tick'], consumer=self.consumer,
                queue_put_begin_ns=before, queue_put_end_ns=after, accepted=ok))

    def get(self, *args, **kwargs):
        value = self.underlying.get(*args, **kwargs)
        if value.get('op') == 'request':
            return dict(value, queue_get_return_ns=time.perf_counter_ns())
        return value

    def put(self, *args, **kwargs):
        return self.underlying.put(*args, **kwargs)


def queue_bounds(record, received_ns):
    before, after = record['queue_put_begin_ns'], record['queue_put_end_ns']
    assert record['accepted'] and before <= after and before <= received_ns
    # The receiver can run before put() returns; lower bound is then zero.
    return max(0, received_ns-after), received_ns-before


class ObservedContext:
    def __init__(self, context, command_capacity):
        self.context, self.command_capacity = context, command_capacity
        self.command_queues = []

    def Queue(self, *args, **kwargs):
        q = self.context.Queue(*args, **kwargs)
        size = kwargs.get('maxsize', args[0] if args else 0)
        if size == self.command_capacity:
            q = ObservedQueue(q, len(self.command_queues))
            self.command_queues.append(q)
        return q

    def __getattr__(self, name):
        return getattr(self.context, name)
