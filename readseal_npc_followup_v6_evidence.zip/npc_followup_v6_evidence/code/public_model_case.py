"""CPU public architecture substitution; not a GPU timing or developer study."""
import argparse
import hashlib
import importlib
import inspect
import json
import os
from pathlib import Path
import sys
import traceback
import urllib.request

ROOT = Path('/www/readseal_ipdps_revision_v6')
sys.path.insert(0, str(ROOT/'vendor'))
sys.path.insert(0, str(ROOT/'prototype_borrowplan_v11_grouped_attempt1'))
from launch_grouped_formal import DEPS
sys.path.extend(str(p) for p in DEPS if str(p) not in sys.path)
import torch
import torchvision
from export_backend import Program
from segmented_backend import lower
from manual_static import manual_partition, graph_records
from torch.utils._pytree import tree_flatten

SOURCE_URL = 'https://raw.githubusercontent.com/pytorch/vision/v0.16.2/torchvision/models/resnet.py'
WEIGHTS_URL = 'https://download.pytorch.org/models/resnet50-0676ba61.pth'


def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def download(url, path):
    # One request, fresh destination, preserve partial download on any failure.
    with path.open('xb') as out, urllib.request.urlopen(url, timeout=90) as response:
        while True:
            b = response.read(1 << 20)
            if not b:
                break
            out.write(b)


class Tail(torch.nn.Module):
    def __init__(self, model):
        super().__init__()
        self.layer1, self.layer2 = model.layer1, model.layer2
        self.layer3, self.layer4 = model.layer3, model.layer4
        self.avgpool, self.fc = model.avgpool, model.fc

    def forward(self, x):
        x = self.layer4(self.layer3(self.layer2(self.layer1(x))))
        return self.fc(torch.flatten(self.avgpool(x), 1))


def manual_review(exported, model):
    """Source-reviewed rule, written before invoking the automatic analyzer.

    R18 first identity branch is the original x, retained through residual add.
    R50 layer1[0] has a 64->256 projection, so the last source read is that
    branch's convolution, not the later private residual addition.
    """
    calls = [n for n in exported.graph.nodes if n.op == 'call_function']
    root = next(n for n in exported.graph.nodes if n.name == exported.graph_signature.user_inputs[0])
    if model == 'resnet18':
        choices = [n for n in calls if str(n.target) == 'aten.add.Tensor' and root in n.all_input_nodes]
        assert len(choices) == 1
        rule = 'first BasicBlock: retain identity x through layer1[0] residual addition'
    else:
        names = exported.graph_signature.inputs_to_parameters
        choices = []
        for n in calls:
            if str(n.target) != 'aten.convolution.default' or n.args[0] is not root:
                continue
            weight = names.get(n.args[1].name, '')
            if 'downsample' in weight:
                choices.append(n)
        assert len(choices) == 1
        rule = 'first Bottleneck: source becomes private at layer1[0].downsample[0] convolution'
    stop = choices[0]
    return dict(model=model, boundary=stop.name, source_rule=rule,
                graph_sha256=hashlib.sha256(json.dumps(graph_records(exported.graph), sort_keys=True).encode()).hexdigest(),
                reviewed_call_index_1based=calls.index(stop)+1,
                total_calls=len(calls), no_automatic_analysis_used_for_review=True,
                common_human_obligations=['operator/schema soundness', 'fixed input interface',
                    'complete external reader enrollment', 'native/stream discipline', 'output dependencies'],
                declaration_maintenance=['export hash', 'semantic source-read closure'],
                developer_time_measured=False, observed_production_migration=False)


def tensor_hash(t):
    return hashlib.sha256(t.detach().contiguous().numpy().tobytes()).hexdigest()


def main(output):
    output.mkdir(parents=True, exist_ok=False)
    result = dict(status='RUNNING', cuda_used=False, gpu_inference=False,
                  performance_claim=False, developer_study=False, cases=[],
                  public_sources=[SOURCE_URL, WEIGHTS_URL], runner_sha256=sha(__file__))
    try:
        assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
        assert torch.__version__ == '2.1.2+cu121' and torchvision.__version__ == '0.16.2+cu121'
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        torch.manual_seed(26091406)
        src = importlib.import_module('torchvision.models.resnet')
        download(SOURCE_URL, output/'public_resnet.py')
        assert sha(src.__file__) == sha(output/'public_resnet.py'), 'installed model differs from public pin'
        checkpoint18 = ROOT/'inputs/resnet_transfer_v2/resnet18-f37072fd.pth'
        assert sha(checkpoint18) == 'f37072fd47e89c5e827621c5baffa7500819f7896bbacec160b1a16c560e07ec'
        download(WEIGHTS_URL, output/'resnet50-0676ba61.pth')
        checkpoint50 = output/'resnet50-0676ba61.pth'
        assert sha(checkpoint50).startswith('0676ba61')
        bank_path = ROOT/'inputs/resnet_transfer_v2/feature_bank.pt'
        bank = torch.load(bank_path, map_location='cpu', weights_only=True)
        assert bank.shape[0] >= 3 and tuple(bank.shape[1:]) == (64,56,56)
        result['inputs'] = {str(p):sha(p) for p in (checkpoint18, checkpoint50, bank_path, Path(src.__file__))}
        result['versions'] = dict(torch=torch.__version__, torchvision=torchvision.__version__)
        reviews = {}
        for name, constructor, checkpoint in [('resnet18', src.resnet18, checkpoint18),
                                               ('resnet50', src.resnet50, checkpoint50)]:
            full = constructor(weights=None).eval()
            full.load_state_dict(torch.load(checkpoint, map_location='cpu', weights_only=True))
            model = Tail(full).eval()
            sample = bank[:1].clone()
            with torch.no_grad():
                exported = torch.export.export(model, (sample,))
            folder = output/name
            folder.mkdir()
            torch.export.save(exported, folder/'tail.pt2')
            (folder/'graph_code.py').write_text(exported.graph_module.code)
            review = manual_review(exported, name)
            reviews[name] = review
            (folder/'manual_review.json').write_text(json.dumps(review, indent=2)+'\n')
            manual_graphs, manual_carry = manual_partition(exported.graph, review['boundary'])
            manual_modules = [torch.fx.GraphModule(torch.nn.Module(), g) for g in manual_graphs]
            program = Program(exported, sample)
            modules, groups, live = lower(program)
            calls = [n for n in program.graph.nodes if n.op == 'call_function']
            readers = set(dict(program.plan.obligations)[program.root])
            auto_boundary = [n.name for n in calls if n.name in readers][-1]
            assert auto_boundary == review['boundary']
            assert set(live) == set(manual_carry)
            assert all(not dict(program.plan.facts)[n].borrows for n in live)
            entry = dict(model=name, review=review, auto_boundary=auto_boundary,
                         readers=sorted(readers), live=list(live), cpu_tests=[],
                         export_sha256=sha(folder/'tail.pt2'), plan_sha256=program.plan.sha256,
                         groups=[list(g) for g in groups], private_carry_static=True)
            for sid in range(3):
                original = bank[sid:sid+1].clone()
                with torch.inference_mode():
                    expected = model(original).clone()
                    export_expected = exported(original).clone()
                torch.testing.assert_close(export_expected, expected, rtol=1e-5, atol=1e-6)
                for label, pair in [('automatic-lowered', modules), ('manual-lowered', manual_modules)]:
                    x = original.clone()
                    args = tuple(x if n.name == program.root else program.state[n.name]
                                 for n in program.graph.nodes if n.op == 'placeholder')
                    with torch.inference_mode():
                        carry = pair[0](*args)
                        leaves, _ = tree_flatten(carry)
                        assert not any(isinstance(t, torch.Tensor) and
                            t.untyped_storage().data_ptr() == x.untyped_storage().data_ptr() for t in leaves)
                        before = tensor_hash(x)
                        x.fill_(12345.0)
                        after = tensor_hash(x)
                        assert before != after
                        actual = tuple(pair[1](*carry))
                    assert len(actual) == 1 and torch.isfinite(actual[0]).all()
                    assert torch.equal(actual[0], export_expected), 'lowered output differs from full functional export'
                    path = folder/f's{sid}-{label}.pt'
                    torch.save(dict(expected=expected, export_expected=export_expected,
                                    actual=actual[0], original=original), path)
                    entry['cpu_tests'].append(dict(source_id=sid, method=label, source_before=before,
                        source_after=after, output_sha256=tensor_hash(actual[0]), raw_file=path.name,
                        raw_sha256=sha(path), exact_to_functional_export=True, close_to_eager=True,
                        overwrite_between_prefix_and_suffix=True, carry_aliases_source=False))
            result['cases'].append(entry)
            print(name, review['boundary'], review['reviewed_call_index_1based'], '/', review['total_calls'], flush=True)
        assert reviews['resnet18']['source_rule'] != reviews['resnet50']['source_rule']
        result.update(status='COMPLETE', tests=sum(len(r['cpu_tests']) for r in result['cases']),
                      cuda_initialized=torch.cuda.is_initialized(),
                      scope='CPU synchronous lowering with real source overwrite; not CUDA async runtime validation',
                      input_scope='three recorded R18-stem features reused at common interface; no R50 accuracy claim',
                      stale_review_rejected_by_hash=reviews['resnet18']['graph_sha256'] != reviews['resnet50']['graph_sha256'])
        assert not result['cuda_initialized']
        result['implementation_sources'] = {str(Path(sys.modules[n].__file__)):sha(sys.modules[n].__file__)
            for n in ('export_backend', 'segmented_backend', 'manual_static', 'core', 'torch_backend')}
    except BaseException:
        result.update(status='FAILED', traceback=traceback.format_exc())
        traceback.print_exc()
    result['files'] = {str(p.relative_to(output)):sha(p) for p in output.rglob('*') if p.is_file()}
    (output/'report.json').write_text(json.dumps(result, indent=2)+'\n')
    (output/result['status']).write_text(result['status']+'\n')
    print(json.dumps(dict(status=result['status'], tests=result.get('tests',0), sha256=sha(output/'report.json'))))
    return 0 if result['status'] == 'COMPLETE' else 1


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    assert a.output.resolve().is_relative_to(ROOT)
    raise SystemExit(main(a.output))
