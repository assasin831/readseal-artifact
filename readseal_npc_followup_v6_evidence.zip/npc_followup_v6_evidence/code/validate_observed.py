"""CPU-only tighter queue-span audit layered on the frozen pipeline validator."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import traceback

ROOT = Path('/www/readseal_ipdps_revision_v6')
sys.path.insert(0, str(ROOT/'prototype_borrowplan_v11_grouped_attempt1'))
from launch_grouped_formal import DEPS
sys.path.extend(str(p) for p in DEPS if str(p) not in sys.path)
import validate_grouped_pipeline as original
from queue_observer import queue_bounds
import numpy as np


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main(run, output):
    output.mkdir(parents=True, exist_ok=False)
    result = dict(status='RUNNING', inference_executed=False, cuda_used=False)
    try:
        original.validate_abc.cell = original.cell
        prior = original.validate_admission.audit(run)
        report = json.loads((run/'report.json').read_text())
        sink = json.loads((run/'sink.json').read_text())
        observations = json.loads((run/'queue_observations.json').read_text())
        assert all(sha(p) == h for p,h in observations['sources'].items())
        spans = {(r['tick'],r['consumer']):r for r in observations['records']}
        assert len(spans) == len(observations['records'])
        accepted = {k for k,r in spans.items() if r['accepted']}
        assert accepted == {(r['tick'],r['consumer']) for r in sink}
        producers = {r['tick']:r for r in report['producer']}
        phases = []
        for r in sink:
            s = spans[r['tick'],r['consumer']]
            producer = producers[r['tick']]
            before, after = s['queue_put_begin_ns'], s['queue_put_end_ns']
            received = r['queue_get_return_ns']
            assert producer['commit_end_ns'] <= before <= after <= producer['producer_done_ns']
            assert before <= received <= r['received_ns'] <= r['admission_ns']
            assert r['queue_put_begin_ns'] == before
            lo,hi = queue_bounds(s, received)
            if r['cohort']:
                phases.append([lo/1e6,hi/1e6,(after-before)/1e6,
                    (r['admission_ns']-r['scheduled_ns'])/1e6,
                    (r['output_done_ns']-r['admission_ns'])/1e6,
                    (r['publish_ns']-r['release_end_ns'])/1e6,
                    (r['publish_ns']-r['scheduled_ns'])/1e6])
        arr = np.asarray(phases)
        assert arr.shape == (prior['publications'],7) and np.isfinite(arr).all() and (arr>=0).all()
        result.update(status='COMPLETE', original_validation=prior,
            queue_records=len(spans), receipts=len(sink), phase_mean_ms=arr.mean(axis=0).tolist(),
            phase_p95_ms=np.percentile(arr,95,axis=0).tolist(),
            phase_order=['queue_lower','queue_upper','put_call','planned_to_admit','admit_to_output',
                         'recipient_return_to_receipt','planned_to_receipt'],
            report_sha256=sha(run/'report.json'), observation_sha256=sha(run/'queue_observations.json'),
            validator_sha256=sha(__file__))
    except BaseException:
        result.update(status='FAILED',traceback=traceback.format_exc())
        traceback.print_exc()
    (output/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
    (output/result['status']).write_text(result['status']+'\n')
    print(json.dumps(dict(status=result['status'], receipts=result.get('receipts'))))
    return int(result['status'] != 'COMPLETE')


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--run', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    assert a.run.resolve().is_relative_to(ROOT) and a.output.resolve().is_relative_to(ROOT)
    raise SystemExit(main(a.run, a.output))
