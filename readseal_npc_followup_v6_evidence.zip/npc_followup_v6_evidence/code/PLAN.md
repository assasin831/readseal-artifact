# NPC V6 evidence plan

Status: CPU audits and experiment preparation. V5 and all older attempts immutable.

## Immediate evidence

1. Reconstruct the 96-run Grouped campaign from its hash-bound archived raw requests.
   Analyze Grouped, not just Original. Keep the exact host-timestamp definitions;
   queue residence is bracketed in these existing logs, not directly observed.
   This is post-hoc analysis, not newly executed inference or a causal identification
   of GPU service time. Resample six paired repeats, not individual requests.
2. Public model substitution case: torchvision 0.16.2 ResNet-18 to ResNet-50 at
   the common 1x64x56x56 stem-output interface. BasicBlock retains the source
   through the first residual addition; Bottleneck's first block projects the
   identity with downsample(x). Review source-level lifetime obligations before
   examining automatic output. No artificial late read, no invented user history.
   Use a CPU-only feasibility/export gate first. Do not equate edited lines with
   labor, and do not claim a real production migration or classifier quality gain.
3. New exact host-queue instrumentation and a small rate/cap scan. Preserve
   protocol and guards. Benchmark instrument overhead before a formal matrix.
   A multiprocessing Queue.put is not a device service start or transport-delivery
   timestamp. Record its brackets explicitly unless a separately validated
   queue adapter supplies a defined linearization point.

## Scope controls

- Formal performance requires both GPUs free of compute, before and during runs.
  At the first current audit GPU0 was free; GPU1 had unrelated PID 890877.
  Do not stop or change it. CPU-only work proceeds with GPU visibility disabled.
- No automatic resumption of paused V12 or old monitoring automation.
- No GPU inference retries, no overwriting or deleting old outputs.
- Do not create memory pressure simply to force the one-slot result. A budget
  sensitivity is not deployment necessity. MIG's existence by itself does not
  prove that an extra 63.3 MiB slot is unaffordable.
- Raw evidence, exact outcomes and negative cases precede any new paper claim.

## Public sources to pin

- https://raw.githubusercontent.com/pytorch/vision/v0.16.2/torchvision/models/resnet.py
- https://docs.nvidia.com/datacenter/tesla/mig-user-guide/supported-mig-profiles.html

The experiment-selected model substitution is a reproducible public architecture
case, not a developer study and not an observed deployment upgrade.
