"""Exploratory V11 reanalysis of immutable V10 host-event traces, without inference."""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile
import traceback

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
OLD = ROOT / 'prototype/borrowplan_v10/evidence'
INVENTORY_SHA = 'ca4ed6f8f90ca85168956d7638df6147b218ab0a25db5d44380a656b62fc1d37'
ARCHIVE_SHA = 'ebead6169f1a3eb73c1dc4976bc4ddb0e06e4ad6f801b081232feddc5270d4cf'
ADMISSION_SHA = '42f4692cbfaf2a8e0ed245f5c5adfbeb9c2e89ed0e127e54a9dbbeef02f5f99e'
COST_SHA = '6e23e6b86f129bfb0bf187b5dad36e98bd1b0fae54f280b4c6daa8e5244504d4'
PHASES = ('pre_admission_ms', 'admitted_to_output_ms', 'output_to_receipt_ms',
          'receipt_latency_ms', 'queue_wait_lower_ms', 'queue_wait_upper_ms',
          'read_completion_to_receipt_ms')
CDF_GRID = np.arange(0, 301, 2, dtype=float)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def read_bound(path, expected):
    assert sha(path) == expected, str(path)
    return json.loads(Path(path).read_text(encoding='utf-8'))


class Archive:
    def __init__(self, wanted):
        folder = OLD / 'release_raw_attempt1'
        self.inventory = read_bound(folder / 'inventory.json', INVENTORY_SHA)['files']
        assert sha(folder / 'evidence.tar.gz') == ARCHIVE_SHA
        blobs = {self.inventory[p]['blob'] for p in wanted}
        self.data = {}
        with tarfile.open(folder / 'evidence.tar.gz', 'r|gz') as tar:
            for member in tar:
                if member.name not in blobs:
                    continue
                assert member.isfile() and member.name not in self.data
                raw = tar.extractfile(member).read()
                assert hashlib.sha256(raw).hexdigest() == PurePosixPath(member.name).name
                self.data[member.name] = raw
        assert set(self.data) == blobs, 'missing archived blobs'

    def load(self, path):
        entry = self.inventory[path]
        raw = self.data[entry['blob']]
        assert len(raw) == entry['bytes']
        return json.loads(raw)


def occupation(intervals, begin, end, bins=120):
    """Exact clipped interval integral, with finite-width time-bin means."""
    assert end > begin and (end - begin) % bins == 0
    width = (end - begin) // bins
    area = np.zeros(bins, dtype=np.int64)
    events = defaultdict(int)
    for start, stop in intervals:
        assert isinstance(start, int) and isinstance(stop, int) and stop >= start
        left, right = max(begin, start), min(end, stop)
        if right <= left:
            continue
        events[left] += 1
        events[right] -= 1
        first, last = (left - begin) // width, (right - begin - 1) // width
        for b in range(first, last + 1):
            lo, hi = begin + b * width, begin + (b + 1) * width
            area[b] += min(right, hi) - max(left, lo)
    current = peak = total = 0
    previous = begin
    for t in sorted(events):
        total += current * (t - previous)
        current += events[t]
        assert current >= 0
        peak = max(peak, current)
        previous = t
    assert current == 0 and total == int(area.sum())
    return dict(mean=total / (end - begin), peak=peak,
                bins=(area / width).tolist())


def phases(producer, receipt):
    r = receipt
    assert producer['commit_end_ns'] <= producer['producer_done_ns']
    stamps = [r[x] for x in ('scheduled_ns', 'received_ns', 'admission_ns',
                            'read_done_ns', 'release_begin_ns', 'release_end_ns',
                            'output_done_ns', 'sink_enqueue_ns', 'publish_ns')]
    assert all(a <= b for a, b in zip(stamps, stamps[1:])), 'nonmonotone host events'
    assert producer['commit_end_ns'] <= r['received_ns']
    values = [(r['admission_ns'] - r['scheduled_ns']) / 1e6,
              (r['output_done_ns'] - r['admission_ns']) / 1e6,
              (r['publish_ns'] - r['output_done_ns']) / 1e6,
              (r['publish_ns'] - r['scheduled_ns']) / 1e6,
              max(0, r['received_ns'] - producer['producer_done_ns']) / 1e6,
              (r['received_ns'] - producer['commit_end_ns']) / 1e6,
              (r['publish_ns'] - r['read_done_ns']) / 1e6]
    assert np.isclose(sum(values[:3]), values[3], rtol=1e-12, atol=1e-9)
    assert values[4] <= values[5]
    return values


def audit_run(report, sink, expected):
    assert report['status'] == 'COMPLETE'
    assert report['wrong_outputs'] == report['source_unknown'] == 0
    assert report['final_outstanding'] == 0
    assert report['method'] == expected['method']
    begin, end = report['cohort_start_ns'], report['cohort_end_ns']
    producers = {r['tick']: r for r in report['producer']}
    assert len(producers) == len(report['producer'])
    wanted = {(r['tick'], c) for r in producers.values()
              for c, ok in enumerate(r['enqueued']) if ok}
    keys = [(r['tick'], r['consumer']) for r in sink]
    assert len(keys) == len(set(keys)) and set(keys) == wanted
    matrices = []
    intervals = defaultdict(list)
    for r in sink:
        p = producers[r['tick']]
        for k in ('sequence', 'source_id', 'scheduled_ns', 'cohort', 'slot'):
            assert r[k] == p[k]
        assert r['observed_sequence'] == p['sequence']
        assert r['observed_source'] == p['source_id']
        assert r['identity'] == dict(epoch=987654, sequence=p['sequence'], generation=2*p['sequence'])
        assert r['finite'] and r['published'] and r['output_equal'] and r['provenance_verified']
        assert r['actual_hashes'] == report['references'][p['source_id']]['hashes']
        met = r['publish_ns'] - r['scheduled_ns'] <= round(report['cell']['deadline_ms'] * 1e6)
        assert r['deadline_met'] == r['verified_timely'] == met
        values = phases(p, r)
        if r['cohort']:
            matrices.append(values)
        # Insertion is bracketed, not directly observed. Receiver can run before
        # the producer has finished enqueueing other recipients.
        intervals['queue_lower'].append((min(p['producer_done_ns'], r['received_ns']), r['received_ns']))
        intervals['queue_upper'].append((p['commit_end_ns'], r['received_ns']))
        intervals['active_to_output'].append((r['admission_ns'], r['output_done_ns']))
        intervals['output_to_receipt'].append((r['output_done_ns'], r['publish_ns']))
        intervals['returned_input_to_receipt'].append((r['release_end_ns'], r['publish_ns']))
        intervals['outstanding_lower'].append((min(p['producer_done_ns'], r['received_ns']), r['publish_ns']))
        intervals['outstanding_upper'].append((p['commit_end_ns'], r['publish_ns']))
    matrix = np.asarray(matrices)
    assert matrix.shape[1] == len(PHASES) and np.isfinite(matrix).all() and (matrix >= 0).all()
    selected = [r for r in sink if r['cohort']]
    assert len(selected) == report['publications'] == expected['publications']
    timely = sum(r['verified_timely'] for r in selected)
    assert timely == report['timely'] == expected['timely']
    n = report['cell']['consumers']
    offered = sum(p['cohort'] for p in producers.values()) * n
    assert offered == report['arrivals'] == expected['arrivals']
    assert offered == timely + expected['correct_late'] + sum(expected[k] for k in
        ('producer_late', 'pool_exhausted', 'credit_exhausted', 'queue_loss'))
    occ = {k: occupation(v, begin, end) for k, v in intervals.items()}
    assert occ['queue_lower']['mean'] <= occ['queue_upper']['mean']
    latency = matrix[:, 3]
    return dict(repeat=expected['repeat'], condition=expected['condition'], method=expected['method'],
        path=expected['path'], offered=offered, received=len(selected), timely=timely,
        goodput_hz=timely/report['cell']['measure_seconds'],
        conditional_receipt_fraction_late=float(np.mean(latency > report['cell']['deadline_ms'])),
        phase_mean_ms=matrix.mean(axis=0).tolist(), phase_p50_ms=np.percentile(matrix, 50, axis=0).tolist(),
        phase_p95_ms=np.percentile(matrix, 95, axis=0).tolist(), occupancy=occ,
        latency_cdf=[float(np.mean(latency <= t)) for t in CDF_GRID],
        offered_timely_fraction=timely/offered, losses={k: expected[k] for k in
          ('correct_late', 'producer_late', 'pool_exhausted', 'credit_exhausted', 'queue_loss')})


def estimate(values, draws):
    v = np.asarray(values, dtype=float)
    return dict(mean=np.mean(v, axis=0).tolist(),
                interval=np.percentile(v[draws].mean(axis=1), [2.5, 97.5], axis=0).tolist())


def summarize(rows, repeats):
    rng = np.random.default_rng(111101)
    draws = rng.integers(0, len(repeats), size=(20000, len(repeats)))
    result = []
    for condition in sorted({r['condition'] for r in rows}):
        for method in ('auto-early', 'manual-early', 'manual-full'):
            by_rep = {r['repeat']: r for r in rows if r['condition'] == condition and r['method'] == method}
            assert set(by_rep) == set(range(6))
            rr = [by_rep[r] for r in repeats]
            item = dict(condition=condition, method=method)
            for metric in ('goodput_hz', 'conditional_receipt_fraction_late', 'phase_mean_ms',
                           'phase_p50_ms', 'phase_p95_ms', 'offered_timely_fraction'):
                item[metric] = estimate([r[metric] for r in rr], draws)
            item['occupancy'] = {k: estimate([r['occupancy'][k]['mean'] for r in rr], draws)
                                 for k in rr[0]['occupancy']}
            item['occupancy_mean_bins'] = {k: np.mean([r['occupancy'][k]['bins'] for r in rr], axis=0).tolist()
                                           for k in rr[0]['occupancy']}
            item['latency_cdf_mean_repetitions'] = np.mean([r['latency_cdf'] for r in rr], axis=0).tolist()
            result.append(item)
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert args.output.resolve().is_relative_to(ROOT)
    args.output.mkdir(parents=True, exist_ok=False)
    result = dict(status='RUNNING', kind='exploratory reanalysis; no new inference', rows=[])
    try:
        old = read_bound(OLD / 'admission_aggregate_attempt1/analysis.json', ADMISSION_SHA)
        cost = read_bound(OLD / 'batch_analysis_attempt1/analysis.json', COST_SHA)
        wanted = []
        for r in old['rows']:
            rel = PurePosixPath(r['path']).relative_to('/www/readseal_ipdps_revision_v6')
            wanted.extend([str(rel / 'report.json'), str(rel / 'sink.json')])
        archive = Archive(wanted)
        for index, r in enumerate(old['rows']):
            base = str(PurePosixPath(r['path']).relative_to('/www/readseal_ipdps_revision_v6'))
            result['rows'].append(audit_run(archive.load(base+'/report.json'), archive.load(base+'/sink.json'), r))
            print('AUDITED', index+1, r['run'], flush=True)
        assert len(result['rows']) == 108
        assert sum(r['offered'] for r in result['rows']) == 155520
        assert sum(r['received'] for r in result['rows']) == 87752
        assert sum(r['timely'] for r in result['rows']) == 80407
        result['primary_all_repetitions'] = summarize(result['rows'], list(range(6)))
        result['sensitivity_exclude_repeat1'] = summarize(result['rows'], [0, 2, 3, 4, 5])
        absolute = []
        for case in cost['cases']:
            raw = np.asarray(case['process_block_medians_ms'])
            assert raw.shape == (8, 2, 4) and np.isfinite(raw).all()
            for i, method in enumerate(cost['methods']):
                assert np.isclose(raw[:, :, i].mean(), case['methods'][method]['mean_block_median_ms'])
            absolute.append(dict(key=case['key'], times_ms=case['methods'],
                                 paired_contrasts=case['contrasts']))
        result.update(status='COMPLETE', absolute_costs=absolute, phase_order=PHASES,
            latency_cdf_grid_ms=CDF_GRID.tolist(), bootstrap_replicates=20000, bootstrap_seed=111101,
            sampling_unit='paired full repetition; intervals pointwise; CDF conditional on receipt',
            queue_measurement='bounds from commit_end to producer_done; no exact enqueue timestamp',
            timing_scope='host observation; not exact kernel service time',
            lineage=dict(inventory=INVENTORY_SHA, archive=ARCHIVE_SHA, admission=ADMISSION_SHA, cost=COST_SHA),
            script_sha256=sha(__file__))
    except BaseException:
        result.update(status='FAILED', traceback=traceback.format_exc(), script_sha256=sha(__file__))
        traceback.print_exc()
    (args.output / 'analysis.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    (args.output / result['status']).write_text(result['status']+'\n', encoding='utf-8')
    return int(result['status'] != 'COMPLETE')


if __name__ == '__main__':
    raise SystemExit(main())
