"""Compact output-only reviewer evidence; omit checkpoint and source activations."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import zipfile
import numpy as np
import torch


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main(run, output):
    output.mkdir(parents=True, exist_ok=False)
    d = json.loads((run/'report.json').read_text())
    assert d['status'] == 'COMPLETE'
    check = run.parent/'npc_v6_public_model_cpu_validation_fix1/validation.json'
    v = json.loads(check.read_text())
    assert v['status'] == 'COMPLETE' and v['report_sha256'] == sha(run/'report.json')
    shutil.copyfile(run/'report.json', output/'report.json')
    shutil.copyfile(check, output/'validation.json')
    evidence = []
    for c in d['cases']:
        model = c['model']
        folder = output/model
        folder.mkdir()
        for name in ('manual_review.json','graph_code.py'):
            shutil.copyfile(run/model/name, folder/name)
        for r in c['cpu_tests']:
            raw = run/model/r['raw_file']
            assert sha(raw) == r['raw_sha256']
            loaded = torch.load(raw, map_location='cpu', weights_only=True)
            name = Path(r['raw_file']).with_suffix('.npz').name
            np.savez_compressed(folder/name, **{k:loaded[k].numpy() for k in ('expected','export_expected','actual')})
            evidence.append(dict(file=model+'/'+name, raw_pt_sha256=sha(raw),
                                 npz_sha256=sha(folder/name), actual_sha256=r['output_sha256']))
    manifest = dict(status='COMPLETE', outputs=evidence, report_sha256=sha(run/'report.json'),
                    excludes=['pretrained checkpoints','source activation tensors','full exported model states'],
                    scope='output-array checks are CPU-only; full execution reproduction requires the pinned inputs/runtime')
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(output.with_suffix('.zip'),'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(output.rglob('*')):
            if p.is_file(): z.write(p,p.relative_to(output).as_posix())
    print(json.dumps(dict(status='COMPLETE', files=len(evidence), bytes=output.with_suffix('.zip').stat().st_size)))


if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--run',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    root=Path('/www/readseal_ipdps_revision_v6')
    assert a.run.resolve().is_relative_to(root) and a.output.resolve().is_relative_to(root)
    main(a.run,a.output)
