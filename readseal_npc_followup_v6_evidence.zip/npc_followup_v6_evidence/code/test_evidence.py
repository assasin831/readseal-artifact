import copy
import json
from pathlib import Path
import queue
import unittest
import multiprocessing as mp

import numpy as np

from queue_observer import ObservedQueue, queue_bounds
import grouped_trace as gt


def receive_once(commands, results):
    results.put(commands.get(timeout=10))


class QueueTests(unittest.TestCase):
    def test_spawn_transfer(self):
        ctx = mp.get_context('spawn')
        q, result = ObservedQueue(ctx.Queue(2), 0), ctx.Queue()
        child = ctx.Process(target=receive_once, args=(q, result))
        child.start()
        q.put_nowait(dict(op='request', tick=17))
        got = result.get(timeout=15)
        child.join(15)
        self.assertEqual(child.exitcode, 0)
        self.assertEqual(got['tick'], 17)
        self.assertEqual(got['queue_put_begin_ns'], q.records[0]['queue_put_begin_ns'])

    def test_success_keeps_original_and_brackets(self):
        q = ObservedQueue(queue.Queue(2), 3)
        original = dict(op='request', tick=1, sequence=7)
        q.put_nowait(original)
        got = q.get()
        self.assertEqual(original, dict(op='request', tick=1, sequence=7))
        self.assertEqual(got['sequence'], 7)
        self.assertTrue(q.records[0]['accepted'])
        self.assertEqual(got['queue_put_begin_ns'], q.records[0]['queue_put_begin_ns'])

    def test_full_is_not_silently_dropped(self):
        q = ObservedQueue(queue.Queue(1), 0)
        q.put_nowait(dict(op='request', tick=0))
        with self.assertRaises(queue.Full):
            q.put_nowait(dict(op='request', tick=1))
        self.assertEqual([r['accepted'] for r in q.records], [True, False])

    def test_receiver_can_finish_before_put_returns(self):
        r = dict(accepted=True, queue_put_begin_ns=10, queue_put_end_ns=30)
        self.assertEqual(queue_bounds(r, 20), (0,10))
        self.assertEqual(queue_bounds(r, 50), (20,40))
        with self.assertRaises(AssertionError):
            queue_bounds(r, 9)

    def test_stop_passthrough(self):
        q = ObservedQueue(queue.Queue(1), 0)
        q.put(dict(op='stop'))
        self.assertEqual(q.get(), dict(op='stop'))
        self.assertFalse(q.records)


class TraceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        p = gt.ROOT/'results/npc_v6_grouped_trace_attempt1/analysis.json'
        cls.data = json.loads(p.read_text())

    def test_complete_matrix_and_receipt_count(self):
        d = self.data
        self.assertEqual(d['status'], 'COMPLETE')
        self.assertEqual(len(d['rows']), 96)
        self.assertEqual(d['request_records_reaudited'], 96764)
        self.assertFalse(d['inference_executed'])

    def test_mean_phase_decomposition(self):
        for r in self.data['rows']:
            p = r['phase_mean_ms']
            self.assertAlmostEqual(sum(p[:3]), p[3], places=8)
            self.assertLessEqual(p[4], p[5])
            self.assertEqual(r['offered'], r['timely']+sum(r['losses'].values()))

    def test_summary_direct_reconstruction(self):
        for condition in self.data['summary']:
            for method, item in condition['methods'].items():
                rows = [r for r in self.data['rows'] if r['condition'] == condition['condition'] and r['method'] == method]
                self.assertEqual(len(rows), 6)
                for k in ('goodput_hz', 'phase_mean_ms'):
                    np.testing.assert_allclose(item[k]['mean'], np.mean([r[k] for r in rows], axis=0), rtol=0, atol=1e-12)
                self.assertEqual(item['received'], sum(r['received'] for r in rows))

    def test_pairing_is_complete(self):
        rows = copy.deepcopy(self.data['rows'])
        rows.pop()
        with self.assertRaises(AssertionError):
            gt.summarize(rows)

    def test_bootstrap_reproducibility(self):
        self.assertEqual(gt.summarize(self.data['rows']), self.data['summary'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
