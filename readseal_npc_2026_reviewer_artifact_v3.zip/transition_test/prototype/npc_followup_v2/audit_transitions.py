"""Deterministic CPU transition checks of the unchanged composed Lease.

Completion witnesses are explicit test doubles, not evidence about CUDA kernels.
"""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys

LOCAL=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(LOCAL/'prototype/borrowplan_v1'))
from core import Binding, Lease, Node, Rejected, Summary, TensorSpec, compile_plan, digest


class Event:
    def __init__(self,done=False): self.done=done
    def query(self): return self.done


spec=TensorSpec((4,),(1,),'float32','cpu')
nodes=(Node('A',('x',),Summary((0,),completion='input_consumed',implementation='native-a')),
       Node('B',('x',),Summary((),(0,),completion='synchronous',implementation='view')),
       Node('C',('B',),Summary((0,),implementation='generated-c')))
plan=compile_plan(('x',),nodes,('A','C'),{'x':spec},'owned-v1')
binding=Binding('source-allocation',16,7,10,20,digest(asdict(spec)),spec)
records=[]


def fresh(): return Lease(plan,{'x':binding},'owned-v1',{'x':binding.version})
def check(name,condition):
    assert condition,name
    records.append(dict(test=name,passed=True))
def rejects(name,fn):
    try: fn()
    except Rejected as error:
        records.append(dict(test=name,passed=True,rejection=str(error)))
    else: raise AssertionError(name)


a,ao,c,co=Event(True),Event(),Event(),Event()
l=fresh()
check('all_future_nodes_enrolled_at_construction',l.states=={'A':'pending','B':'pending','C':'pending'})
rejects('unenrolled_reader_rejected',lambda:l.begin('D'))
l.begin('A');l.submitted('A',a,ao);l.begin('B');l.submitted('B',Event(True))
check('A_read_done_C_pending_still_protected',not l.can_release(binding.allocation))
l.begin('C');l.submitted('C',c,co)
rejects('duplicate_C_submission_rejected',lambda:l.begin('C'))
c.done=True
check('both_read_obligations_done_source_returnable',l.can_release(binding.allocation))
check('read_join_is_not_output_join',not l.can_publish())
ao.done=co.done=True
identity=l.publish_identity()
check('private_results_retain_admitted_identity',all(v['x'].version==(7,10,20) for v in identity.values()))
rejects('duplicate_output_handoff_rejected',l.publish_identity)

l=fresh();l.begin('A');l.submitted('A',Event(True),Event())
l.abort()
check('abort_cancels_only_pending_readers',l.states=={'A':'submitted','B':'cancelled','C':'cancelled'})
check('read_discharge_distinct_from_private_drain',l.can_release(binding.allocation) and not l.can_publish())
l=fresh();l.begin('A');l.abort()
check('partial_submission_unknown_completion_keeps_hold',l.states['A']=='started' and not l.can_release(binding.allocation))
l=fresh();l.begin('A');l.submitted('A',Event(False),Event(False));l.abort()
check('abort_without_covering_completion_keeps_hold',not l.can_release(binding.allocation))
rejects('changed_executable_old_plan_rejected',lambda:Lease(plan,{'x':binding},'owned-v2',{'x':binding.version}))
check('unchanged_executable_old_plan_valid',fresh().plan==plan)
rejects('publication_mismatch_rejected',lambda:Lease(plan,{'x':binding},'owned-v1',{'x':(7,11,22)}))

out=Path(__file__).parent/'transition_validation.json'
assert not out.exists()
src=LOCAL/'prototype/borrowplan_v1/core.py'
out.write_text(json.dumps(dict(status='COMPLETE',cpu_only=True,cuda_executed=False,
    tests=records,count=len(records),core_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    scope='Composed Lease transitions with trusted event test doubles. Not a kernel or producer-pool proof.'),indent=2)+'\n')
print(json.dumps(dict(status='COMPLETE',checks=len(records))))
