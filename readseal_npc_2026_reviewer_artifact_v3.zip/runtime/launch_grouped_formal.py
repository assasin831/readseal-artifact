"""Frozen 96-run campaign; quiet-host gates, no retries or implicit continuation."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import traceback

ROOT = Path('/www/readseal_ipdps_revision_v6')
SOURCE = Path(__file__).resolve().parent
GPU = 'GPU-f3b314a8-3058-e0be-694c-76f4227afb7d'
DEPS = [SOURCE] + [ROOT/p for p in (
    'prototype_borrowplan_v10_admission_attempt1', 'prototype_borrowplan_v8_abc_attempt1',
    'prototype_borrowplan_v10_batch_attempt1', 'prototype_borrowplan_v7_followups_attempt1',
    'prototype_borrowplan_v7_formal_attempt1', 'prototype_borrowplan_v6_resnet_scope_attempt1',
    'prototype_borrowplan_v6_witness_attempt1', 'prototype_borrowplan_v5_prepared_attempt1',
    'prototype_borrowplan_v5_owned_attempt2', 'prototype_borrowplan_v4_segmented_attempt1',
    'prototype_borrowplan_v1_attempt2', 'prototype_borrowplan_v2_composition_attempt2',
    'prototype_borrowplan_v3_attempt1', 'sdk_trt_10_3_attempt2/packages', 'experiments')]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def compute():
    return subprocess.check_output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid',
                                    '--format=csv,noheader'], text=True).strip()


def save(folder, result):
    (folder/'report.json').write_text(json.dumps(result, indent=2)+'\n')


def schedule(plan):
    rng = random.Random(plan['order_seed'])
    records = []
    for repeat in range(plan['repetitions']):
        for condition in plan['conditions']:
            methods = list(plan['methods'])
            rng.shuffle(methods)
            for method in methods:
                records.append(dict(name=f'r{repeat:02d}-{condition["id"]}-{method}',
                                    repeat=repeat, condition=condition, method=method,
                                    cell=dict(plan['common'], **condition)))
    assert len(records) == len({r['name'] for r in records}) == 96
    return records


def prepare(output, validation):
    proof = json.loads(validation.read_text())
    assert proof['status'] == 'COMPLETE' and proof['cases'] == 24
    assert proof['exact_output_tensors'] == 252 and not proof['inference_executed']
    gate = ROOT/'results/borrowplan_v11_grouped_gate_attempt1/report.json'
    assert sha(gate) == proof['report_sha256']
    gate_report = json.loads(gate.read_text())
    assert gate_report['status'] == 'COMPLETE'
    plan_path = SOURCE/'grouped_formal_plan.json'
    plan = json.loads(plan_path.read_text())
    assert plan['both_gpus_quiet'] and plan['no_inference_retry'] and not plan['guard_elision']
    bindings = dict(gate_report['sources'], **gate_report['input_hashes'])
    for dep in DEPS:
        if dep.name.startswith('prototype_'):
            bindings.update({str(p): sha(p) for p in dep.glob('*.py')})
    for path in (plan_path, SOURCE/'GROUPED_PIPELINE_PLAN.md', validation, gate,
                 ROOT/'inputs/transfusion_borrowplan_v2/head_export.pt2'):
        bindings[str(path)] = sha(path)
    assert all(sha(p) == h for p, h in bindings.items())
    output.mkdir(parents=True, exist_ok=False)
    report = dict(status='PREPARED', inference_executed=False, gpu_uuid=GPU, plan=plan,
                  schedule=schedule(plan), bindings=bindings, validation=str(validation),
                  validation_sha256=sha(validation), sources_frozen=True)
    save(output, report)
    (output/'PREPARED').write_text('No inference launched\n')
    print(json.dumps(dict(status='PREPARED', runs=96, report_sha256=sha(output/'report.json'))))
    return 0


def launch(output, prepared):
    frozen = json.loads(prepared.read_text())
    assert frozen['status'] == 'PREPARED' and not frozen['inference_executed']
    assert all(sha(p) == h for p, h in frozen['bindings'].items()), 'frozen input changed'
    # A busy host creates no inference/result attempt. The hourly monitor may
    # inspect again later; this is not a failed-inference retry.
    busy = compute()
    if busy:
        print(json.dumps(dict(status='WAITING_FOR_QUIET_HOST', inference_executed=False,
                              compute=busy)))
        return 3
    with (ROOT/'borrowplan_gpu0.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert not compute(), 'compute appeared before launch'
        output.mkdir(parents=True, exist_ok=False)
        (output/'pid').write_text(str(os.getpid())+'\n')
        report = dict(status='RUNNING', runs=[], prepared=str(prepared),
                      prepared_sha256=sha(prepared), schedule=frozen['schedule'],
                      plan=frozen['plan'], bindings=frozen['bindings'], active=None)
        env = dict(os.environ, PYTHONPATH=':'.join(map(str, DEPS)), CUDA_VISIBLE_DEVICES=GPU,
                   PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
                   OPENBLAS_NUM_THREADS='1', CUDA_CACHE_PATH=str(output/'cuda-cache'))
        try:
            for item in frozen['schedule']:
                assert all(sha(p) == h for p, h in frozen['bindings'].items()), 'frozen input changed'
                busy = compute()
                if busy:
                    report.update(status='PAUSED_BEFORE_INFERENCE', compute=busy,
                                  next_unstarted=item['name'], active=None)
                    break
                report['active'] = item['name']
                save(output, report)
                command = [sys.executable, '-B', str(SOURCE/'run_grouped_admission.py'),
                           '--output', str(output/item['name']), '--cell', json.dumps(item['cell']),
                           '--method', item['method']]
                with (output/(item['name']+'.log')).open('x') as log:
                    code = subprocess.run(command, cwd=ROOT, env=env, stdout=log,
                                          stderr=subprocess.STDOUT).returncode
                assert code == 0, item['name']+' failed; no inference retry'
                target = output/(item['name']+'-validation')
                command = [sys.executable, '-B', str(SOURCE/'validate_grouped_pipeline.py'),
                           '--kind', 'cell', '--run', str(output/item['name']), '--output', str(target)]
                with (output/(item['name']+'-validation.log')).open('x') as log:
                    code = subprocess.run(command, cwd=ROOT, env=dict(env, CUDA_VISIBLE_DEVICES=''),
                                          stdout=log, stderr=subprocess.STDOUT).returncode
                assert code == 0, item['name']+' validation failed; preserve inference'
                report['runs'].append(dict(item, report_sha256=sha(output/item['name']/'report.json'),
                                          validation_sha256=sha(target/'validation.json')))
                report['active'] = None
                save(output, report)
                print('COMPLETE', item['name'], flush=True)
            else:
                report.update(status='COMPLETE', active=None)
        except BaseException:
            report.update(status='FAILED', traceback=traceback.format_exc())
            traceback.print_exc()
        save(output, report)
        (output/report['status']).write_text(report['status']+'\n')
        return 0 if report['status'] == 'COMPLETE' else 2


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    action = p.add_mutually_exclusive_group(required=True)
    action.add_argument('--prepare', type=Path, metavar='GATE_VALIDATION')
    action.add_argument('--prepared', type=Path, metavar='FROZEN_REPORT')
    a = p.parse_args()
    assert a.output.resolve().is_relative_to(ROOT)
    return prepare(a.output, a.prepare) if a.prepare else launch(a.output, a.prepared)


if __name__ == '__main__':
    raise SystemExit(main())
