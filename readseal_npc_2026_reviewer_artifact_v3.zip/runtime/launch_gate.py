"""Fresh, locked, no-retry correctness gate for the new segmented candidate."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback

ROOT = Path("/www/readseal_ipdps_revision_v6")
SOURCE = ROOT / "prototype_borrowplan_v4_segmented_attempt1"
RUN = ROOT / "results/borrowplan_v4_segmented_correctness_attempt1"
VALIDATION = ROOT / "results/borrowplan_v4_segmented_validation_attempt1"
LAUNCH = ROOT / "results/borrowplan_v4_segmented_correctness_attempt1-launch"
GPU = "GPU-f3b314a8-3058-e0be-694c-76f4227afb7d"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not any(p.exists() for p in (RUN, VALIDATION, LAUNCH))
    with (ROOT / "borrowplan_gpu0.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        LAUNCH.mkdir()
        report = dict(status="RUNNING", pid=os.getpid(), launcher_sha256=sha(Path(__file__)), sources={})
        try:
            for name in ("segmented_backend.py", "check_segmented.py", "test_lowering.py", "validate_segmented.py"):
                report["sources"][name] = sha(SOURCE / name)
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
                       PYTHONPATH=":".join(str(p) for p in (SOURCE, ROOT / "prototype_borrowplan_v2_execution_attempt4", ROOT / "prototype_borrowplan_v1_attempt2")))
            def run(name, command, gpu):
                for file, expected in report["sources"].items():
                    assert sha(SOURCE / file) == expected
                with (LAUNCH / (name + ".log")).open("x") as log:
                    code = subprocess.run([sys.executable, "-B"] + command, cwd=ROOT,
                                          env=dict(env, CUDA_VISIBLE_DEVICES=gpu), stdout=log, stderr=subprocess.STDOUT).returncode
                report[name + "_exit_code"] = code
                assert code == 0, name + " failed; no retry"
            run("cpu", [str(SOURCE / "test_lowering.py")], "")
            common = ["--export", str(ROOT / "inputs/transfusion_borrowplan_v2/head_export.pt2"),
                      "--cases", str(ROOT / "inputs/transfusion_borrowplan_v2_oracle")]
            run("gpu", [str(SOURCE / "check_segmented.py"), *common, "--output", str(RUN), "--cost-validation",
                        str(ROOT / "results/borrowplan_v3_cost_formal_validation_attempt1/validation.json")], GPU)
            run("validation", [str(SOURCE / "validate_segmented.py"), *common, "--run", str(RUN), "--output", str(VALIDATION)], "")
            report["status"] = "COMPLETE"
            (LAUNCH / "COMPLETE").write_text("Correctness-only candidate gate passed.\n")
        except BaseException as exc:
            report.update(status="FAILED", error=str(exc))
            (LAUNCH / "FAILED").write_text(type(exc).__name__ + "\n")
            (LAUNCH / "traceback.txt").write_text(traceback.format_exc())
        (LAUNCH / "report.json").write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps(report), flush=True)
        return 0 if report["status"] == "COMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
