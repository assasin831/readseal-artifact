"""Construction and ownership tests on the real export; no model inference."""
import argparse
from dataclasses import FrozenInstanceError
import json
from pathlib import Path

import torch
from core import Rejected
from owned_witness import WitnessProgram as OwnedProgram
from test_prepared_lease import main as differential_test
from test_witness_lease import main as witness_test


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--export', type=Path, required=True)
    p.add_argument('--cases', type=Path, required=True)
    a = p.parse_args()
    differential_test()
    witness_test()
    torch.set_num_threads(1)
    checks = []

    def reject(label, fn):
        try:
            fn()
        except (Rejected, FrozenInstanceError):
            checks.append(label)
        else:
            raise AssertionError(label + ' was accepted')

    x = torch.load(a.cases / 'case_0.pt', map_location='cpu')['input']
    for late in (False, True):
        exported = torch.export.load(a.export)
        program = OwnedProgram(exported, x, late_read=late)
        capsule = program._capsule
        assert {n for g in capsule.groups for n in g} == {n.name for n in program.plan.nodes}
        assert len([n for g in capsule.groups for n in g]) == len(program.plan.nodes)
        readers = set(dict(program.plan.obligations)[program.root])
        assert readers <= set(capsule.groups[0]) and not readers.intersection(capsule.groups[1])
        assert not any(dict(program.plan.facts)[name].borrows for name in capsule.live)
        checks += [f'{late}-full-coverage', f'{late}-all-future-readers', f'{late}-private-boundary']
        original_allocations = {t.untyped_storage().data_ptr() for t in exported.state_dict.values()}
        assert all(t.untyped_storage().data_ptr() not in original_allocations for _, t in capsule.state)
        checks.append(f'{late}-owned-allocations')
        snapshot = program.artifact
        snapshot['groups'][0].clear()
        snapshot['modules'][0]['code'] = 'return x'
        assert program.artifact['groups'][0] and program.artifact['modules'][0]['code'] != 'return x'
        checks.append(f'{late}-detached-audit')
        first = next(iter(exported.state_dict.values()))
        with torch.no_grad():
            first.add_(1)
        program.guard()
        checks.append(f'{late}-caller-state-isolated')
        first_node = next(n for n in exported.graph.nodes if n.op == 'call_function')
        first_node.target = torch.ops.aten.neg.default
        program.guard()
        checks.append(f'{late}-caller-graph-isolated')
        reject(f'{late}-program-read-only', lambda: setattr(program, 'executable', 'changed'))
        reject(f'{late}-plan-read-only', lambda: setattr(program.plan, 'obligations', ()))
        f = capsule.functions[0].invoke
        original_code = f.__code__
        f.__code__ = (lambda x: x).__code__
        reject(f'{late}-changed-code', program.guard)
        f.__code__ = original_code
        f.__globals__['unexpected'] = object()
        reject(f'{late}-changed-globals', program.guard)
        del f.__globals__['unexpected']
        program.guard()
        with torch.no_grad():
            capsule.state[0][1].add_(1)
        reject(f'{late}-owned-state-version', program.guard)
    print(json.dumps(dict(status='COMPLETE', checks=len(checks), cases=checks, gpu_inference=False)))


if __name__ == '__main__':
    main()
