"""CPU-only structural and failure-path checks before any GPU smoke."""
import copy
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import torch
from core import Node, Rejected, compile_plan
from export_backend import summary
from segmented_backend import lower, module_fingerprint, SegmentedExecution
from torch_backend import spec


def example(alias=False, late=False, escape=False):
    graph = torch.fx.Graph()
    x = graph.placeholder("x")
    operand = graph.call_function(torch.ops.aten.view.default, (x, [4])) if alias else x
    private = graph.call_function(torch.ops.aten.clone.default, (operand,))
    result = graph.call_function(torch.ops.aten.relu.default, (private,))
    outputs = [result]
    if late:
        clone = graph.call_function(torch.ops.aten.clone.default, (x,))
        outputs.append(graph.call_function(torch.ops.aten.mean.default, (clone,)))
    if escape:
        outputs.append(x)
    graph.output(tuple(outputs))
    calls = [n for n in graph.nodes if n.op == "call_function"]
    nodes = [Node(n.name, tuple(d.name for d in n.all_input_nodes), summary(n)) for n in calls]
    plan = compile_plan(("x",), nodes, tuple(n.name for n in outputs), {"x": spec(torch.zeros(4))}, "example")
    return SimpleNamespace(graph=graph, root="x", plan=plan, operations={n.name: n for n in calls})


class LoweringTests(unittest.TestCase):
    def test_base(self):
        p = example()
        modules, groups, live = lower(p)
        self.assertEqual(tuple(map(len, groups)), (1, 1))
        x = torch.arange(-2., 2.)
        expected = torch.fx.GraphModule(torch.nn.Module(), copy.deepcopy(p.graph))(x)
        boundary = modules[0](x)
        x.fill_(99)
        self.assertTrue(torch.equal(modules[1](*boundary)[0], expected[0]))

    def test_alias_chain(self):
        p = example(alias=True)
        modules, groups, live = lower(p)
        self.assertEqual(tuple(map(len, groups)), (2, 1))
        self.assertEqual(len(dict(p.plan.obligations)["x"]), 2)
        self.assertNotIn("x", live)

    def test_late_read_extends_prefix(self):
        p = example(late=True)
        modules, groups, live = lower(p)
        self.assertEqual(tuple(map(len, groups)), (3, 1))
        self.assertTrue(set(dict(p.plan.obligations)["x"]).issubset(groups[0]))
        self.assertNotIn("x", live)

    def test_escape_rejected(self):
        with self.assertRaisesRegex(Rejected, "output borrow"):
            lower(example(escape=True))

    def test_graph_change_detectable(self):
        module = lower(example())[0][1]
        before = module_fingerprint(module)
        next(n for n in module.graph.nodes if n.op == "call_function").target = torch.ops.aten.sigmoid.default
        module.recompile()
        self.assertNotEqual(before, module_fingerprint(module))

    def test_hooks_rejected(self):
        module = lower(example())[0][0]
        module.register_forward_hook(lambda *args: None)
        with self.assertRaisesRegex(Rejected, "hook-free"):
            module_fingerprint(module)

    def test_failed_execution_denies_retry(self):
        obj = object.__new__(SegmentedExecution)
        obj.stage, obj.failed, obj.lease = 0, True, SimpleNamespace(aborted=False)
        with self.assertRaisesRegex(Rejected, "out-of-order"):
            obj.submit(0, None)

    def test_unknown_partial_enqueue_quarantined(self):
        class Context:
            def __enter__(self):
                return self
            def __exit__(self, *args):
                return False
        obj = object.__new__(SegmentedExecution)
        obj.stage, obj.failed, obj.stream = 0, False, None
        obj.lease = SimpleNamespace(aborted=False)
        obj.program = SimpleNamespace(guard=lambda: None, checked=SimpleNamespace())
        obj.ready = object()
        stream = SimpleNamespace(wait_event=lambda _: (_ for _ in ()).throw(RuntimeError("synthetic enqueue failure")))
        with patch("torch.cuda.stream", return_value=Context()):
            with self.assertRaisesRegex(RuntimeError, "synthetic"):
                obj.submit(0, stream)
        self.assertTrue(obj.failed)
        self.assertFalse(obj.lease.aborted)


if __name__ == "__main__":
    unittest.main(verbosity=2)
