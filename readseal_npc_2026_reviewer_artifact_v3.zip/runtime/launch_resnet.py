"""Fresh serial second-model gate after the immutable cost campaign ends."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback

ROOT = Path('/www/readseal_ipdps_revision_v6')
SOURCE = ROOT / 'prototype_borrowplan_v6_resnet_scope_attempt1'
OUT = ROOT / 'results/borrowplan_v6_resnet_witness_attempt1'
GPU = 'GPU-f3b314a8-3058-e0be-694c-76f4227afb7d'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    launch = OUT.with_name(OUT.name + '-launch')
    validation = OUT.with_name(OUT.name + '-validation')
    assert not OUT.exists() and not validation.exists()
    launch.mkdir(parents=True, exist_ok=False)
    (launch/'pid').write_text(str(os.getpid())+'\n')
    code = 1
    try:
        with (ROOT/'borrowplan_gpu0.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            cost = ROOT / 'results/borrowplan_v6_cost_campaign_attempt1'
            assert (cost/'COMPLETE').exists() and json.loads((cost/'report.json').read_text())['status'] == 'COMPLETE'
            assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader'],text=True).strip()
            original = ROOT/'prototype_borrowplan_v2_execution_attempt4/export_backend.py'
            assert sha(original) == 'ee6e4efed939bf44845be4c84a2b758a9310067d124e14f2bb9c2ec702092232'
            deps = [SOURCE] + [ROOT/n for n in ('prototype_borrowplan_v6_witness_attempt1','prototype_borrowplan_v5_prepared_attempt1',
                'prototype_borrowplan_v5_owned_attempt2','prototype_borrowplan_v4_segmented_attempt1',
                'prototype_borrowplan_v6_multiprocess_attempt2','prototype_borrowplan_v3_cost_attempt2',
                'prototype_borrowplan_v1_attempt2','prototype_borrowplan_v2_composition_attempt2')]
            env = dict(os.environ, PYTHONPATH=':'.join(map(str,deps)), CUDA_VISIBLE_DEVICES=GPU, PYTHONDONTWRITEBYTECODE='1',
                       OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', CUDA_CACHE_PATH=str(launch/'cuda-cache'))
            probe = ROOT/'results/borrowplan_v6_resnet_export_probe_attempt2'
            metadata = dict(sources={p.name:sha(p) for p in SOURCE.iterdir() if p.is_file()},
                            cost_campaign_sha256=sha(cost/'report.json'), export_probe_sha256=sha(probe/'report.json'))
            (launch/'invocation.json').write_text(json.dumps(metadata,indent=2)+'\n')
            commands = [
                ('cpu.log', [sys.executable,'-B',str(SOURCE/'test_scope.py'),'--original-backend',str(original),'--export-run',str(probe)], False),
                ('run.log', [sys.executable,'-B',str(SOURCE/'run_resnet_witness.py'),'--export-run',str(probe),'--output',str(OUT)], True),
                ('validation.log', [sys.executable,'-B',str(SOURCE/'validate_resnet_witness.py'),'--run',str(OUT),'--output',str(validation)], False)]
            for name, command, gpu in commands:
                for path, expected in metadata['sources'].items():
                    assert sha(SOURCE/path) == expected
                with (launch/name).open('x') as log:
                    code = subprocess.run(command,cwd=ROOT,env=env if gpu else dict(env,CUDA_VISIBLE_DEVICES=''),
                                          stdout=log,stderr=subprocess.STDOUT).returncode
                assert code == 0, name+' failed; no retry'
    except BaseException:
        code = 1
        (launch/'traceback.txt').write_text(traceback.format_exc())
        traceback.print_exc()
    (launch/'exit_code').write_text(str(code)+'\n')
    (launch/('COMPLETE' if code==0 else 'FAILED')).write_text('No retry performed.\n')
    print(json.dumps(dict(status=code,launcher=str(launch))))
    return code


if __name__=='__main__':
    raise SystemExit(main())
