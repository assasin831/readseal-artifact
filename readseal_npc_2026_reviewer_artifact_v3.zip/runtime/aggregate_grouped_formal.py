"""CPU-only full campaign re-audit and paired-repeat estimates; no inference."""
import argparse
import hashlib
import json
from pathlib import Path
import random
import traceback

import numpy as np

ROOT = Path('/www/readseal_ipdps_revision_v6')
PREPARED_SHA = '7c176daae5d064999cac4de6ddf46ad9219b033001307f1a9b6ea1231312766d'
METRICS = ('goodput_hz', 'mean_protected_mib', 'device_peak_mib', 'peak_outstanding')
LOSSES = ('arrivals', 'publications', 'timely', 'correct_late', 'producer_late',
          'pool_exhausted', 'credit_exhausted', 'queue_loss')
COMPARISONS = (('auto-batched', 'auto-early'), ('auto-batched', 'manual-early'),
               ('auto-batched', 'manual-full'), ('auto-early', 'manual-early'),
               ('auto-early', 'manual-full'))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def schedule(plan):
    rng = random.Random(plan['order_seed'])
    result = []
    for repeat in range(plan['repetitions']):
        for condition in plan['conditions']:
            methods = list(plan['methods'])
            rng.shuffle(methods)
            for method in methods:
                result.append(dict(name=f'r{repeat:02d}-{condition["id"]}-{method}',
                                   repeat=repeat, condition=condition, method=method,
                                   cell=dict(plan['common'], **condition)))
    return result


def summarize(rows, plan):
    conditions = [x['id'] for x in plan['conditions']]
    methods = plan['methods']
    repeats = list(range(plan['repetitions']))
    keys = [(x['repeat'], x['condition'], x['method']) for x in rows]
    assert len(keys) == len(set(keys)), 'duplicate run'
    assert set(keys) == {(r, c, m) for r in repeats for c in conditions for m in methods}, 'matrix mismatch'
    lookup = dict(zip(keys, rows))
    values = np.asarray([[[[lookup[r, c, m][k] for k in METRICS]
                           for m in methods] for c in conditions] for r in repeats])
    assert np.isfinite(values).all() and (values >= 0).all()
    # One shared draw matrix preserves run-repeat pairing across every contrast.
    draws = np.random.default_rng(plan['bootstrap_seed']).integers(
        0, len(repeats), size=(plan['bootstrap_replicates'], len(repeats)))
    boots, means = values[draws].mean(axis=1), values.mean(axis=0)

    def estimate(point, samples):
        return dict(mean=float(point), interval=np.percentile(samples, [2.5, 97.5]).tolist())

    result = dict(repetitions=repeats, bootstrap_seed=plan['bootstrap_seed'],
                  bootstrap_replicates=plan['bootstrap_replicates'], conditions=[],
                  intervals='Pointwise paired-repeat percentile 95%; no request-level resampling',
                  interpretation='Six repeats in one host window; no multiplicity correction or cross-host claim')
    for ci, condition in enumerate(conditions):
        group = dict(condition=condition, methods={}, paired_differences={})
        for mi, method in enumerate(methods):
            subset = [lookup[r, condition, method] for r in repeats]
            data = {metric: dict(estimate(means[ci, mi, ki], boots[:, ci, mi, ki]),
                                 runs=values[:, ci, mi, ki].tolist())
                    for ki, metric in enumerate(METRICS)}
            data['losses'] = {k: sum(x[k] for x in subset) for k in LOSSES}
            for phase in ('phase_p50_ms', 'phase_p95_ms'):
                data['mean_run_' + phase] = np.mean([x[phase] for x in subset], axis=0).tolist()
            group['methods'][method] = data
        for first, second in COMPARISONS:
            a, b = methods.index(first), methods.index(second)
            group['paired_differences'][first + '_minus_' + second] = {
                k: dict(estimate(means[ci, a, ki] - means[ci, b, ki],
                                 boots[:, ci, a, ki] - boots[:, ci, b, ki]),
                        runs=(values[:, ci, a, ki] - values[:, ci, b, ki]).tolist())
                for ki, k in enumerate(METRICS)}
        result['conditions'].append(group)
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--prepared', type=Path, required=True)
    p.add_argument('--run', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    assert a.output.resolve().is_relative_to(ROOT)
    a.output.mkdir(parents=True, exist_ok=False)
    result = dict(status='RUNNING', script_sha256=sha(__file__), inference_executed=False,
                  cuda_used=False, rows=[], raw_inventory={})
    try:
        import validate_grouped_pipeline as validator
        assert sha(a.prepared) == PREPARED_SHA
        frozen = json.loads(a.prepared.read_text())
        report_path = a.run/'report.json'
        report_sha = sha(report_path)
        report = json.loads(report_path.read_text())
        assert frozen['status'] == 'PREPARED' and not frozen['inference_executed']
        assert report['status'] == 'COMPLETE' and report['active'] is None
        assert (a.run/'COMPLETE').is_file() and not list(a.run.rglob('FAILED'))
        assert not (a.run/'PAUSED_BEFORE_INFERENCE').exists()
        assert Path(report['prepared']) == a.prepared and report['prepared_sha256'] == PREPARED_SHA
        assert report['plan'] == frozen['plan'] and report['bindings'] == frozen['bindings']
        assert all(sha(path) == digest for path, digest in frozen['bindings'].items())
        plan = report['plan']
        assert plan['repetitions'] == 6 and plan['bootstrap_replicates'] == 20000
        assert plan['bootstrap_seed'] == 111203 and plan['order_seed'] == 111202
        assert plan['both_gpus_quiet'] and plan['no_inference_retry'] and not plan['guard_elision']
        expected = schedule(plan)
        assert len(expected) == 96 and frozen['schedule'] == report['schedule'] == expected
        bare = [{k: v for k, v in x.items() if k not in ('report_sha256', 'validation_sha256')}
                for x in report['runs']]
        assert bare == expected
        actual_dirs = {x.name for x in a.run.iterdir() if x.is_dir() and x.name.startswith('r0')}
        assert actual_dirs == {x['name'] + suffix for x in expected for suffix in ('', '-validation')}
        assert len(list(a.run.glob('*-validation/validation.json'))) == 96
        validator.validate_abc.cell = validator.cell
        for entry in report['runs']:
            run = a.run/entry['name']
            validation = a.run/(entry['name']+'-validation')
            assert sha(run/'report.json') == entry['report_sha256']
            assert sha(validation/'validation.json') == entry['validation_sha256']
            assert (validation/'COMPLETE').is_file()
            checked = validator.validate_admission.audit(run)
            recorded = json.loads((validation/'validation.json').read_text())
            reconstructed = dict(checked, status='COMPLETE', cuda_used=False, inference_executed=False,
                                 report_sha256=sha(run/'report.json'), validator_sha256=sha(validator.__file__))
            assert recorded == reconstructed, 'per-run independent validation disagreement'
            raw = json.loads((run/'report.json').read_text())
            assert raw['cell'] == entry['cell'] and raw['method'] == entry['method']
            assert raw['gpu_uuid'] == frozen['gpu_uuid']
            assert raw['wrong_outputs'] == raw['source_unknown'] == 0
            assert raw['device_peak_bytes'] == max(s['device_used_bytes'] for s in raw['memory_samples'])
            for path, digest in raw['input_hashes'].items():
                assert sha(path) == digest
            receipts = [x for x in json.loads((run/'sink.json').read_text()) if x['cohort']]
            phases = np.asarray([[(x['admission_ns']-x['scheduled_ns'])/1e6,
                                  (x['output_done_ns']-x['admission_ns'])/1e6,
                                  (x['publish_ns']-x['output_done_ns'])/1e6,
                                  (x['publish_ns']-x['scheduled_ns'])/1e6] for x in receipts])
            assert len(phases) > 0 and np.isfinite(phases).all() and (phases >= 0).all()
            checked.update(run=entry['name'], path=str(run), repeat=entry['repeat'],
                           condition=entry['condition']['id'],
                           phase_p50_ms=np.percentile(phases, 50, axis=0).tolist(),
                           phase_p95_ms=np.percentile(phases, 95, axis=0).tolist())
            result['rows'].append(checked)
            for folder in (run, validation):
                for path in sorted(folder.rglob('*')):
                    if path.is_file():
                        result['raw_inventory'][str(path.relative_to(a.run))] = sha(path)
            print('VALID', entry['name'], flush=True)
        assert sha(report_path) == report_sha
        assert all(sha(path) == digest for path, digest in frozen['bindings'].items())
        result.update(status='COMPLETE', primary=summarize(result['rows'], plan), plan=plan,
                      prepared_sha256=PREPARED_SHA, campaign_report_sha256=report_sha,
                      gpu_uuid=frozen['gpu_uuid'], frozen_bindings=frozen['bindings'],
                      inference_retries=0, independent_run_reaudits=96,
                      total_arrivals=sum(x['arrivals'] for x in result['rows']),
                      total_publications=sum(x['publications'] for x in result['rows']),
                      total_timely=sum(x['timely'] for x in result['rows']),
                      phase_population='Cohort receipts only; loss accounting includes all offered outputs')
    except BaseException:
        result.update(status='FAILED', traceback=traceback.format_exc())
        traceback.print_exc()
    (a.output/'analysis.json').write_text(json.dumps(result, indent=2)+'\n')
    (a.output/result['status']).write_text(result['status']+'\n')
    return int(result['status'] != 'COMPLETE')


if __name__ == '__main__':
    raise SystemExit(main())
