"""One new process family per frozen formal condition and method."""
import argparse
import json
from pathlib import Path
import owned_witness
from run_streaming import measure_cell
from study_common import configure,compute_pids


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--cell',required=True)
    p.add_argument('--method',required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    assert not compute_pids(),'foreign GPU compute before cell; no launch'
    configure()
    print(json.dumps(measure_cell(a.output,json.loads(a.cell),a.method)),flush=True)
