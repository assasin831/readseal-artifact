"""V9 experiment utilities; predecessor implementations remain immutable."""
import hashlib
import json
import sys
from pathlib import Path
import time

from study_common import ROOT, GPU

now = time.monotonic_ns


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def inventory():
    paths = set(Path(__file__).parent.glob('*.py'))
    for module in list(sys.modules.values()):
        path = getattr(module, '__file__', None)
        if path and Path(path).suffix == '.py' and str(path).startswith(str(ROOT / 'prototype_')):
            paths.add(Path(path))
    paths.update(ROOT / p for p in (
        'results/borrowplan_v2_native_composition_attempt1/native.engine',
        'results/borrowplan_v2_native_composition_attempt1/report.json'))
    return {str(p): sha(p) for p in sorted(paths)}


def save(folder, value):
    (Path(folder) / 'report.json').write_text(json.dumps(value, indent=2) + '\n')


class Join:
    def __init__(self, events):
        self.events = tuple(events)
        self.observed = []

    def synchronize(self):
        self.observed = []
        for event in self.events:
            event.synchronize()
            self.observed.append(now())

    def query(self):
        return all(event.query() for event in self.events)
