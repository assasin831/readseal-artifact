"""CPU saved-output and independent graph-boundary audit. No inference rerun."""
import argparse
import hashlib
import json
from pathlib import Path
import traceback

import torch
from export_backend import Program


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser()
    for name in ("run", "output", "export", "cases"):
        p.add_argument("--" + name, type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    result = dict(status="RUNNING", checks=0, performance_claim=False, validator_sha256=sha(__file__))

    def check(condition):
        assert condition, "check " + str(result["checks"] + 1)
        result["checks"] += 1

    try:
        report = json.loads((a.run / "report.json").read_text())
        result["report_sha256"] = sha(a.run / "report.json")
        check(report["status"] == "COMPLETE" and report["performance_claim"] is False)
        check((a.run / "COMPLETE").is_file() and not (a.run / "FAILED").exists())
        check(len(report["cases"]) == 6)
        check({(c["source"], c["late"]) for c in report["cases"]} == {(i, b) for i in range(3) for b in (False, True)})
        for path, expected in report["sources"].items():
            check(sha(path) == expected)
        check(report["export_sha256"] == sha(a.export))
        check(report["preflight_compute"] == [])
        check(all(c["gpu"] == report["gpu_uuid"] for c in report["postflight_compute"]))
        exported = torch.export.load(a.export)
        inventory = json.loads((a.cases / "report.json").read_text())
        boundaries = {}
        for case in report["cases"]:
            sid, late = case["source"], case["late"]
            source = a.cases / f"case_{sid}.pt"
            replacement = a.cases / f"case_{(sid + 1) % 3}.pt"
            check(case["source_hashes"] == [sha(source), sha(replacement)])
            check(sha(source) == inventory["files"][source.name])
            check(sha(replacement) == inventory["files"][replacement.name])
            x = torch.load(source, map_location="cpu")["input"]
            program = Program(exported, x, late_read=late)
            # Independently propagate schema alias facts, without calling lower().
            borrowed = {program.root: True}
            readers = []
            calls = []
            for node in program.graph.nodes:
                if node.op == "placeholder":
                    borrowed.setdefault(node.name, False)
                elif node.op == "call_function":
                    calls.append(node.name)
                    incoming = any(borrowed[d.name] for d in node.all_input_nodes)
                    if incoming:
                        readers.append(node.name)
                    if isinstance(node.target, torch._ops.OpOverload):
                        aliases = any(r.alias_info is not None for r in node.target._schema.returns)
                    else:
                        check(str(node.target) == "<built-in function getitem>")
                        aliases = True
                    borrowed[node.name] = incoming and aliases
            check(set(readers) == set(case["readers"]))
            boundary = max(calls.index(n) for n in readers) + 1
            expected_prefix = [n.name for n in program.graph.nodes if n.op == "placeholder" and n.name != program.root] + calls[:boundary]
            check(case["stage_operations"] == [expected_prefix, calls[boundary:]])
            check(case["prefix_submitted"] == expected_prefix)
            check(case["private_pending_before_overwrite"] == calls[boundary:] and bool(calls[boundary:]))
            produced = {program.root, *expected_prefix}
            suffix = [n for n in program.graph.nodes if n.name in set(calls[boundary:]) or n.op == "output"]
            live = {d.name for n in suffix for d in n.all_input_nodes if d.name in produced}
            check(case["boundary_values"] == [n.name for n in program.graph.nodes if n.name in live])
            check(not any(borrowed[n] for n in live))
            check(case["same_slot_overwritten_before_private_stage"] and case["old_publication_preserved"])
            check(set(case["negative_controls"]) == {"suffix_before_prefix", "premature_output", "duplicate_prefix",
                  "output_before_private_stage", "repeat_publish", "output_after_publish", "changed_generated_code"})
            check(all(case["negative_controls"].values()))
            file = a.run / case["output_file"]
            check(file.parent == a.run and sha(file) == case["output_sha256"])
            data = torch.load(file, map_location="cpu")
            check(len(data["actual"]) == len(data["expected"]) == (10 if late else 9))
            for actual, expected in zip(data["actual"], data["expected"]):
                check(torch.equal(actual, expected) and bool(torch.isfinite(actual).all()))
            boundaries[sid, late] = boundary
        for sid in range(3):
            check(boundaries[sid, True] > boundaries[sid, False])
        result.update(status="COMPLETE", cases=6, numerical_output_pairs=57, negative_controls=42,
                      limitations="Saved-output audit, not independent kernel reexecution; single-process adapter only")
        (a.output / "COMPLETE").write_text("Structural lowering and saved outputs validated.\n")
    except BaseException as exc:
        result.update(status="FAILED", error=str(exc))
        (a.output / "FAILED").write_text(type(exc).__name__ + "\n")
        (a.output / "traceback.txt").write_text(traceback.format_exc())
        traceback.print_exc()
    (a.output / "validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)
    return 0 if result["status"] == "COMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
