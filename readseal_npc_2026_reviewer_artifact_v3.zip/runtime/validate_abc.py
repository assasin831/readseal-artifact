"""Independent full-output reconstruction for complete native/checked composition."""
import argparse
import hashlib
import json
from pathlib import Path
import traceback
import torch
from validate_streaming import audit_cell
from common import sha


def gate(folder):
    r = json.loads((folder/'report.json').read_text())
    assert r['status'] == 'COMPLETE' and (folder/'COMPLETE').exists()
    assert len(r['cases']) == 18
    assert len({(x['method'],x['late'],x['source']) for x in r['cases']}) == 18
    tensors = 0
    for c in r['cases']:
        assert c['admitted_ns'] <= c['return_ns'] <= c['overwrite_done_ns'] <= c['published_ns']
        assert sha(folder/(c['key']+'.pt')) == c['sha256']
        pairs = torch.load(folder/(c['key']+'.pt'),map_location='cpu')
        assert len(pairs['actual']) == len(pairs['expected']) == (11 if c['late'] else 10)
        assert pairs['actual'][0].shape == (1,128)
        for x,y in zip(pairs['actual'],pairs['expected']):
            assert x.shape == y.shape and x.dtype == y.dtype and torch.isfinite(x).all() and torch.equal(x,y)
            tensors += 1
        a = c['artifact']
        assert a['native']['sdk'] == '10.3.0'
        if c['method'] == 'auto-early':
            assert set(a['obligations']['source']) == {'A','C'}
        else:
            assert a['complete_enrollment'] == ['A','C']
            assert not a['automatic_plan_consumed'] and not a['checked_child_consumed']
            assert a['child']['no_readseal_analysis_or_executor']
        assert c['identity'] == dict(epoch=987654,sequence=c['source']+1,generation=2*(c['source']+1))
    for p,h in {**r['sources'],**r['input_hashes']}.items():
        assert sha(p) == h
    return dict(cases=18, exact_output_tensors=tensors)


def cell(folder):
    out = audit_cell(folder)
    r = json.loads((folder/'report.json').read_text())
    n = r['cell']['consumers']
    for i in range(n):
        art = json.loads((folder/f'consumer-{i}-artifact.json').read_text())
        assert art['native']['engine_sha256'] == 'e16e10603b9a5508995331576c2f8863ecbfb380041742eb400024789d5fbc97'
        if r['method'] == 'auto-early':
            assert set(art['obligations']['source']) == {'A','C'}
        else:
            assert not art['automatic_plan_consumed'] and not art['checked_child_consumed']
            assert art['full'] == (r['method'] == 'manual-full')
        worker = json.loads((folder/f'consumer-{i}.json').read_text())
        for x in worker['rows']:
            c = x['composition']
            assert x['admission_ns'] <= c['enrolled_ns'] <= c['a_submitted_ns'] <= c['c_prefix_submitted_ns'] <= x['read_done_ns']
            assert x['native_shape'] == [1,128] and x['complete_ab_outputs']
    for ref in r['references']:
        assert len(ref['hashes']) == (11 if r['cell']['late'] else 10)
    out.update(complete_native_and_child_outputs=True, gpu_uuid=r['gpu_uuid'])
    return out


if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--run',type=Path,required=True); p.add_argument('--output',type=Path,required=True)
    p.add_argument('--kind',choices=['gate','cell'],required=True)
    a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=False)
    result=dict(status='RUNNING',validator_sha256=sha(__file__))
    try:
        result.update((gate if a.kind=='gate' else cell)(a.run))
        result.update(status='COMPLETE',report_sha256=sha(a.run/'report.json'))
    except BaseException:
        result.update(status='FAILED',traceback=traceback.format_exc()); traceback.print_exc()
    (a.output/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
    (a.output/result['status']).write_text(result['status']+'\n')
    print(json.dumps(result),flush=True)
    raise SystemExit(0 if result['status']=='COMPLETE' else 1)
