"""Single-process overwritten-source gate; deliberately emits no timing data."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import traceback

import torch
import core
import export_backend
import torch_backend
import segmented_backend
from core import Rejected
from segmented_backend import SegmentedProgram

GPU = "GPU-f3b314a8-3058-e0be-694c-76f4227afb7d"


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for data in iter(lambda: f.read(1 << 20), b""):
            h.update(data)
    return h.hexdigest()


def rejects(fn):
    try:
        fn()
    except Rejected:
        return True
    raise AssertionError("negative control was accepted")


def compute():
    raw = subprocess.check_output(["nvidia-smi", "--query-compute-apps=gpu_uuid,pid", "--format=csv,noheader"], text=True)
    return [dict(gpu=line.split(",")[0].strip(), pid=int(line.split(",")[1])) for line in raw.splitlines() if line.strip()]


def main():
    parser = argparse.ArgumentParser()
    for name in ("export", "cases", "output", "cost-validation"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    report = dict(status="RUNNING", performance_claim=False, scope="Six single-process overwritten-source conformance cases", cases=[])
    try:
        assert os.environ.get("CUDA_VISIBLE_DEVICES") == GPU
        report["preflight_compute"] = compute()
        assert not report["preflight_compute"], "host is not idle; no inference launched"
        gate = json.loads(args.cost_validation.read_text())
        assert gate["status"] == "COMPLETE" and gate["measured_pairs"] == 3000
        assert sha(args.cost_validation) == "1b76305ee669bd414e7c0371afd061859e5eb49d3fc33c9a4db511c18b62407d"
        report.update(cost_validation_sha256=sha(args.cost_validation), runner_sha256=sha(__file__), gpu_uuid=GPU,
                      sources={str(Path(m.__file__).resolve()): sha(m.__file__)
                               for m in (core, export_backend, torch_backend, segmented_backend)},
                      torch=torch.__version__, export_sha256=sha(args.export))
        assert report["export_sha256"] == "8efaa67aa6884d0c9aec6fff442e9a50b683a290d856abef390db1f034ccabbd"
        torch.set_num_threads(1)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        exported = torch.export.load(args.export)
        inventory = json.loads((args.cases / "report.json").read_text())
        for source in (0, 1, 2):
            inputs = []
            source_hashes = []
            for sid in (source, (source + 1) % 3):
                path = args.cases / f"case_{sid}.pt"
                assert sha(path) == inventory["files"][path.name]
                source_hashes.append(sha(path))
                inputs.append(torch.load(path, map_location="cpu")["input"].cuda())
            old, replacement = inputs
            assert not torch.equal(old, replacement)
            for late in (False, True):
                x = old.clone()
                program = SegmentedProgram(exported, x, late_read=late)
                p = program.checked
                direct = torch.fx.GraphModule(torch.nn.Module(), copy.deepcopy(p.graph))
                values = tuple(old if n.name == p.root else p.state[n.name]
                               for n in p.graph.nodes if n.op == "placeholder")
                with torch.inference_mode():
                    expected = tuple(t.detach().clone() for t in direct(*values))
                torch.cuda.synchronize()
                stream = torch.cuda.Stream()
                publication = dict(epoch=19, sequence=source + 1, generation=2)
                execution = program.start(x, publication)
                binding = execution.lease.bindings[p.root]
                assert not execution.lease.can_release(binding.allocation)
                negatives = dict(suffix_before_prefix=rejects(lambda: execution.submit(1, stream)),
                                 premature_output=rejects(execution.outputs))
                done = execution.submit(0, stream)
                negatives["duplicate_prefix"] = rejects(lambda: execution.submit(0, stream))
                done.synchronize()
                assert execution.lease.can_release(binding.allocation)
                assert not execution.lease.can_publish()
                negatives["output_before_private_stage"] = rejects(execution.outputs)
                prefix_submitted = [n for n, state in execution.lease.states.items() if state == "submitted"]
                future_pending = [n for n, state in execution.lease.states.items() if state == "pending"]
                assert future_pending
                address = x.data_ptr()
                with torch.inference_mode():
                    x.copy_(replacement)
                torch.cuda.synchronize()
                assert x.data_ptr() == address and torch.equal(x, replacement)
                execution.submit(1, stream).synchronize()
                actual = execution.outputs()
                assert len(actual) == len(expected)
                assert all(torch.equal(a, b) and bool(torch.isfinite(a).all()) for a, b in zip(actual, expected))
                identity = execution.lease.publish_identity()
                for output, lineage in identity.items():
                    if p.root in lineage:
                        assert lineage[p.root].version == (19, source + 1, 2)
                negatives["repeat_publish"] = rejects(execution.lease.publish_identity)
                negatives["output_after_publish"] = rejects(execution.outputs)
                # Changing generated executable code invalidates the registered stages.
                original = program.modules[1].forward
                program.modules[1].forward = (lambda self, *a: a).__get__(program.modules[1])
                negatives["changed_generated_code"] = rejects(program.guard)
                program.modules[1].forward = original
                program.guard()
                name = f"source-{source}-{'late' if late else 'base'}.pt"
                torch.save(dict(actual=tuple(t.detach().cpu() for t in actual), expected=tuple(t.detach().cpu() for t in expected)), args.output / name)
                case = dict(source=source, late=late, exact=True, source_hashes=source_hashes, output_file=name,
                            output_sha256=sha(args.output / name), original_plan_sha256=p.plan.sha256,
                            module_sha256=program.module_hashes, stage_operations=program.groups,
                            boundary_values=program.live, readers=dict(p.plan.obligations)[p.root],
                            prefix_submitted=prefix_submitted, private_pending_before_overwrite=future_pending,
                            same_slot_overwritten_before_private_stage=True, old_publication_preserved=True,
                            negative_controls=negatives)
                report["cases"].append(case)
                print("COMPLETE " + name, flush=True)
        report["postflight_compute"] = compute()
        assert all(row["gpu"] == GPU and row["pid"] == os.getpid() for row in report["postflight_compute"])
        report["status"] = "COMPLETE"
        (args.output / "COMPLETE").write_text("Six overwritten-source cases; no performance claim.\n")
    except BaseException as exc:
        report.update(status="FAILED", error=str(exc))
        (args.output / "FAILED").write_text(type(exc).__name__ + "\n")
        (args.output / "traceback.txt").write_text(traceback.format_exc())
        traceback.print_exc()
    (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(dict(status=report["status"], cases=len(report["cases"]))))
    return 0 if report["status"] == "COMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
