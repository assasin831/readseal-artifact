"""V10 grouped checked child inside the unchanged native/alias/export pipeline."""
import torch

from auto_composition import AutoComposition
from batch_backend import BatchProgram
from native_loader import FrozenNative
from native_composition import compose
from study_common import ROOT, MODELS


class GroupedComposition(AutoComposition):
    def __init__(self, example, late):
        self.child = BatchProgram(torch.export.load(MODELS['transfusion'][0]),
                                  example, late_read=late)
        self.native = FrozenNative(ROOT/'results/borrowplan_v2_native_composition_attempt1')
        self.plan = compose(self.child, example, self.native)
        self.artifact = dict(schema='readseal-grouped-abc-v11', child=self.child.artifact,
                             native=self.native.receipt, plan_sha256=self.plan.sha256,
                             obligations=dict(self.plan.obligations),
                             escapes=dict(self.plan.escapes), executable=self.plan.executable,
                             grouping_only=True, guard_elision=False)
