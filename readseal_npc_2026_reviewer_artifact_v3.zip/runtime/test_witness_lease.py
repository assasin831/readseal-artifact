"""Differential and query-count checks under the explicit monotone event contract."""
from dataclasses import asdict
import json
import random

from core import Binding, Lease, Node, Summary, TensorSpec, compile_plan, digest, Rejected
from prepared_lease import prepare
from witness_lease import WitnessLease


class Event:
    def __init__(self):
        self.done, self.queries = False, 0

    def query(self):
        self.queries += 1
        return self.done


def main():
    rng = random.Random(76001)
    checks = 0
    shape = TensorSpec((4,), (1,), 'float32', 'cpu')
    binding = Binding('A', 16, 1, 2, 4, digest(asdict(shape)), shape)
    for count in (2, 8, 64):
        for split_witness in (False, True):
            nodes = tuple(Node('n' + str(i), ('x' if i == 0 else 'n' + str(i-1),),
                Summary((0,), (0,) if i == 0 else (),
                        completion='input_consumed' if split_witness else 'operation_complete', implementation='trusted-op'))
                for i in range(count))
            plan = compile_plan(('x',), nodes, (nodes[-1].name,), {'x': shape}, 'bound-code')
            certificate = prepare(plan)
            for trial in range(100):
                old = Lease(plan, {'x': binding}, plan.executable, {'x': binding.version})
                new = WitnessLease(certificate, {'x': binding}, plan.executable, {'x': binding.version})
                reads, outputs = (Event(), Event()), (Event(), Event())
                for i, node in enumerate(nodes):
                    old.begin(node.name)
                    new.begin(node.name)
                    stage = int(i >= count // 2)
                    old.submitted(node.name, reads[stage], outputs[stage] if split_witness else None)
                    new.submitted(node.name, reads[stage], outputs[stage] if split_witness else None)
                    assert old.can_publish() == new.can_publish()
                    checks += 1
                events = list(reads) + (list(outputs) if split_witness else [])
                rng.shuffle(events)
                for event in events:
                    event.done = True
                    assert old.can_release('A') == new.can_release('A')
                    assert old.can_publish() == new.can_publish()
                    checks += 2
                before = sum(e.queries for e in events)
                for _ in range(20):
                    assert new.can_publish()
                    checks += 1
                assert sum(e.queries for e in events) == before
                checks += 1
                if trial % 2:
                    old.abort()
                    new.abort()
                    assert not old.can_publish() and not new.can_publish()
                else:
                    assert old.publish_identity() == new.publish_identity()
                    assert not old.can_publish() and not new.can_publish()
                checks += 1
    print(json.dumps(dict(status='COMPLETE', checks=checks, traces=600, seed=76001,
                          contract='monotone single-record events only; no external witness mutation')))


if __name__ == '__main__':
    main()
