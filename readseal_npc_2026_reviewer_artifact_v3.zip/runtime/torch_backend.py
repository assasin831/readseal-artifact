"""Checked execution of a finite FX graph, not inference from an eager trace.

Only the exact built-in types/functions below execute. CUDA operations run on
explicit caller-owned streams; complete-operation events are backend witnesses.
There is no opaque/TensorRT integration yet and no arbitrary callback executor.
"""
from dataclasses import asdict, dataclass, replace
import copy
import hashlib
import inspect
import operator
from pathlib import Path

import torch
from torch import nn
from torch.fx import Node as FxNode, symbolic_trace
from torch.fx.node import map_arg

from core import Binding, Lease, Node, Rejected, Summary, TensorSpec, compile_plan, digest


def spec(tensor):
    if type(tensor) is not torch.Tensor or tensor.layout != torch.strided or tensor.requires_grad:
        raise Rejected("only ordinary dense inference tensors are supported")
    if tensor.numel() == 0:
        raise Rejected("empty borrowed allocation not supported")
    return TensorSpec(tuple(tensor.shape), tuple(tensor.stride()), str(tensor.dtype),
                      str(tensor.device), tensor.storage_offset())


def allocation(tensor):
    return str(tensor.device) + ":" + str(tensor.untyped_storage().data_ptr())


def bind(tensor, sequence=2, epoch=1, generation=2):
    shape = spec(tensor)
    return Binding(allocation(tensor), tensor.untyped_storage().nbytes(), epoch, sequence,
                   generation, digest(asdict(shape)), shape)


FRESH_MODULES = (nn.Conv1d, nn.Conv2d, nn.BatchNorm1d, nn.BatchNorm2d,
                 nn.Linear, nn.MaxPool2d, nn.AvgPool2d, nn.AdaptiveAvgPool2d)
FRESH_FUNCTIONS = (operator.add, operator.sub, operator.mul, torch.add, torch.sub,
                   torch.mul, torch.cat, torch.sigmoid)
MAY_ALIAS_METHODS = ("reshape", "flatten", "contiguous")
VIEW_METHODS = ("view", "permute", "transpose", "unsqueeze", "squeeze", "detach")


def inspect_module(module):
    if module.training or "forward" in module.__dict__:
        raise Rejected("training or instance-overridden module")
    if module._forward_hooks or module._forward_pre_hooks or module._backward_hooks:
        raise Rejected("module hooks are outside the executable graph")


def summary_for(gm, node):
    count = len(node.all_input_nodes)
    all_inputs = tuple(range(count))
    if node.op == "get_attr":
        return Summary((), implementation="frozen-get-attr")
    if node.op == "call_module":
        m = gm.get_submodule(node.target)
        inspect_module(m)
        if type(m) in FRESH_MODULES:
            if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d)) and not m.track_running_stats:
                raise Rejected("batch-dependent normalization is outside initial scope")
            return Summary(all_inputs, implementation=type(m).__module__ + "." + type(m).__name__)
        if type(m) is nn.ReLU:
            return Summary(all_inputs, all_inputs if m.inplace else (),
                           all_inputs if m.inplace else (), implementation="torch.nn.ReLU")
        if type(m) is nn.Identity:
            return Summary((), all_inputs, completion="synchronous", implementation="torch.nn.Identity")
        if type(m) is nn.Flatten:
            return Summary(all_inputs, all_inputs, implementation="torch.nn.Flatten-may-alias")
        raise Rejected("unknown module: " + type(m).__qualname__)
    if node.op == "call_function":
        if node.target in FRESH_FUNCTIONS:
            if node.kwargs.get("out") is not None:
                raise Rejected("out= mutation is not supported")
            return Summary(all_inputs, implementation=str(node.target))
        if node.target is torch.flatten:
            return Summary(all_inputs, all_inputs, implementation="torch.flatten-may-alias")
        raise Rejected("unknown function: " + str(node.target))
    if node.op == "call_method":
        if node.target in MAY_ALIAS_METHODS:
            return Summary(all_inputs, (0,), implementation="tensor." + node.target + "-may-alias")
        if node.target in VIEW_METHODS:
            return Summary((), (0,), completion="synchronous", implementation="tensor." + node.target)
        if node.target in ("clone", "sum", "mean"):
            return Summary(all_inputs, implementation="tensor." + node.target)
        raise Rejected("unknown method: " + str(node.target))
    raise Rejected("unsupported FX node kind: " + node.op)


def canonical_arg(value):
    if isinstance(value, FxNode):
        return {"node": value.name}
    if isinstance(value, (tuple, list)):
        return [canonical_arg(v) for v in value]
    if isinstance(value, dict):
        return {k: canonical_arg(v) for k, v in value.items()}
    if value is None or type(value) in (str, bool, int, float):
        return value
    if isinstance(value, (torch.dtype, torch.device)):
        return str(value)
    raise Rejected("unsupported graph constant: " + type(value).__name__)


def signature(gm):
    # This expensive prototype guard is intentionally not advertised as cheap.
    from torch.nn.modules import module as module_state
    if module_state._global_forward_hooks or module_state._global_forward_pre_hooks:
        raise Rejected("global hooks are outside the supported execution model")
    records = []
    for node in gm.graph.nodes:
        target = str(node.target)
        if node.op == "call_module":
            m = gm.get_submodule(node.target)
            inspect_module(m)
            target = (target, type(m).__module__, type(m).__qualname__, m.extra_repr())
        records.append((node.op, node.name, target, canonical_arg(node.args), canonical_arg(node.kwargs)))
    state = [(n, tuple(t.shape), tuple(t.stride()), str(t.dtype), str(t.device), t._version)
             for n, t in tuple(gm.named_parameters()) + tuple(gm.named_buffers())]
    return digest({"graph": records, "state": state, "torch": torch.__version__,
                   "registry": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})


@dataclass
class Component:
    graph: object
    input_names: tuple
    output_name: str
    input_specs: tuple
    executable: str

    @classmethod
    def extract(cls, model, examples):
        for m in model.modules():
            inspect_module(m)
        try:
            gm = symbolic_trace(model)
        except Exception as exc:
            raise Rejected("FX extraction rejected: " + type(exc).__name__) from exc
        inputs = tuple(n.name for n in gm.graph.nodes if n.op == "placeholder")
        if len(inputs) != len(examples):
            raise Rejected("all placeholders require concrete tensor specifications")
        output = next(n for n in gm.graph.nodes if n.op == "output")
        if len(output.args) != 1 or not isinstance(output.args[0], FxNode):
            raise Rejected("initial component ABI requires one tensor output")
        for n in gm.graph.nodes:
            if n.op not in ("placeholder", "output"):
                summary_for(gm, n)
        return cls(gm, inputs, output.args[0].name, tuple(spec(x) for x in examples), signature(gm))

    def check(self):
        if signature(self.graph) != self.executable:
            raise Rejected("component executable changed before launch")


@dataclass(frozen=True)
class Call:
    name: str
    component: Component
    inputs: tuple


class Pipeline:
    """Compose already checked FX components through explicit tensor edges.

    Connections are application configuration, not handwritten last-read points.
    Prefixing graph nodes lets the same rules cover cross-component view escape
    and downstream calls which have not started when another call finishes.
    """

    def __init__(self, root_specs, calls, outputs):
        self.root_specs, self.calls = dict(root_specs), tuple(calls)
        self.operations, self.call_operations, self.local_names = {}, {}, {}
        values = {r: r for r in root_specs}
        nodes = []
        for call in self.calls:
            if call.name in values or len(call.inputs) != len(call.component.input_names):
                raise Rejected("invalid component connection")
            call.component.check()
            if any(v not in values for v in call.inputs):
                raise Rejected("component input is not yet defined")
            local = dict(zip(call.component.input_names, (values[v] for v in call.inputs)))
            self.call_operations[call.name] = []
            for fx in call.component.graph.graph.nodes:
                if fx.op in ("placeholder", "output"):
                    continue
                name = call.name + "::" + fx.name
                inputs = tuple(local[n.name] for n in fx.all_input_nodes)
                node = Node(name, inputs, summary_for(call.component.graph, fx))
                nodes.append(node)
                self.operations[name] = (call, fx)
                self.call_operations[call.name].append(name)
                local[fx.name] = name
            self.local_names[call.name] = local
            values[call.name] = local[call.component.output_name]
        if any(o not in values for o in outputs):
            raise Rejected("unknown pipeline output")
        self.outputs = tuple(values[o] for o in outputs)
        executable = digest([(c.name, c.inputs, c.component.executable) for c in calls])
        self.plan = compile_plan(tuple(root_specs), nodes, self.outputs, root_specs, executable)

    def start(self, tensors, versions=None, publications=None):
        for call in self.calls:
            call.component.check()
        if set(tensors) != set(self.root_specs):
            raise Rejected("wrong pipeline inputs")
        bindings = {r: bind(t, **(publications or {}).get(r, {})) for r, t in tensors.items()}
        if versions is not None:
            # Caller-supplied expected publication is checked before any operation.
            expected = versions
        else:
            expected = {r: b.version for r, b in bindings.items()}
        lease = Lease(self.plan, bindings, self.plan.executable, expected)
        for call in self.calls:
            for t in list(call.component.graph.parameters()) + list(call.component.graph.buffers()):
                if allocation(t) in lease.sizes:
                    raise Rejected("component state aliases externally borrowed storage")
        self._check_meta(tensors)
        return Execution(self, tensors, lease)

    def _check_meta(self, tensors):
        # No borrowed data or CUDA execution: validate intermediate shape/layout
        # assumptions using meta tensors and copies of module metadata only.
        values, bases = {}, {}
        for root, value in tensors.items():
            key = allocation(value)
            if key not in bases:
                bases[key] = torch.empty(value.untyped_storage().nbytes() // value.element_size(),
                                         dtype=value.dtype, device="meta")
            elif bases[key].dtype != value.dtype:
                raise Rejected("cross-dtype borrowed aliases are outside scope")
            values[root] = bases[key].as_strided(tuple(value.shape), tuple(value.stride()),
                                               value.storage_offset())
        for call in self.calls:
            arguments = [values[n] for n in call.inputs]
            for argument, expected in zip(arguments, call.component.input_specs):
                if replace(spec(argument), device=expected.device) != expected:
                    raise Rejected("component input guard failed in prelaunch meta check")
            memo = {}
            for t in list(call.component.graph.parameters()) + list(call.component.graph.buffers()):
                mt = torch.empty_strided(tuple(t.shape), tuple(t.stride()), dtype=t.dtype, device="meta")
                memo[id(t)] = nn.Parameter(mt, requires_grad=False) if isinstance(t, nn.Parameter) else mt
            meta_graph = copy.deepcopy(call.component.graph, memo)
            try:
                with torch.inference_mode():
                    values[call.name] = meta_graph(*arguments)
            except Exception as exc:
                raise Rejected("prelaunch metadata execution failed: " + type(exc).__name__) from exc


class Ready:
    def query(self):
        return True

    def synchronize(self):
        pass


class Execution:
    def __init__(self, pipeline, tensors, lease):
        self.pipeline, self.lease = pipeline, lease
        self.values = dict(tensors)
        self.device = next(iter(tensors.values())).device
        if any(t.device != self.device for t in tensors.values()):
            raise Rejected("single-device pipeline only")
        self.ready = {}
        if self.device.type == "cuda":
            for root in tensors:
                event = torch.cuda.Event()
                event.record(torch.cuda.current_stream(self.device))
                self.ready[root] = event
        self.facts = dict(pipeline.plan.facts)
        self.executed = []

    def step(self, name, stream=None):
        if name not in self.pipeline.operations:
            raise Rejected("unregistered operation")
        call, node = self.pipeline.operations[name]
        local = self.pipeline.local_names[call.name]
        args = map_arg(node.args, lambda n: self.values[local[n.name]])
        kwargs = map_arg(node.kwargs, lambda n: self.values[local[n.name]])
        self.lease.begin(name)
        try:
            if self.device.type == "cuda":
                stream = stream or torch.cuda.current_stream(self.device)
                for dep in self.lease.nodes[name].inputs:
                    event = self.ready.get(dep) or self.lease.output_events.get(dep)
                    if event is not None:
                        stream.wait_event(event)
                with torch.cuda.stream(stream), torch.inference_mode():
                    result = self._invoke(call.component.graph, node, args, kwargs)
                    event = torch.cuda.Event()
                    event.record(stream)
            else:
                with torch.inference_mode():
                    result = self._invoke(call.component.graph, node, args, kwargs)
                event = Ready()
            if isinstance(result, torch.Tensor):
                actual = {r for r, b in self.lease.bindings.items() if allocation(result) == b.allocation}
                predicted = self.facts[name].borrows
                # A physical alias group may have several logical root names.
                allowed_allocations = {self.lease.bindings[r].allocation for r in predicted}
                if any(self.lease.bindings[r].allocation not in allowed_allocations for r in actual):
                    raise Rejected("backend violated declared storage summary")
            self.values[name] = result
            self.lease.submitted(name, event)
            self.executed.append(name)
        except BaseException:
            self.lease.abort()
            # No implicit release on error. Unwitnessed started work stays owned.
            raise

    @staticmethod
    def _invoke(gm, node, args, kwargs):
        if node.op == "get_attr":
            value = gm
            for atom in node.target.split("."):
                value = getattr(value, atom)
            return value
        if node.op == "call_module":
            return gm.get_submodule(node.target)(*args, **kwargs)
        if node.op == "call_function":
            return node.target(*args, **kwargs)
        if node.op == "call_method":
            return getattr(args[0], node.target)(*args[1:], **kwargs)
        raise Rejected("unsupported operation")

    def run_component(self, name, stream=None):
        if name not in self.pipeline.call_operations:
            raise Rejected("unknown component")
        for operation in self.pipeline.call_operations[name]:
            self.step(operation, stream)

    def wait_submitted(self):
        for event in self.lease.output_events.values():
            event.synchronize()

    def outputs(self):
        if not self.lease.can_publish():
            raise Rejected("outputs incomplete")
        return tuple(self.values[name] for name in self.pipeline.outputs)
