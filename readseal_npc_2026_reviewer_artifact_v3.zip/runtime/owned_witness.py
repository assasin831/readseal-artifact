"""Owned fixed code with deduplicated monotone output-completion checks."""
import hashlib
import json
from pathlib import Path

import torch
from core import Rejected, digest
from owned_backend import OwnedExecution
from owned_prepared import PreparedProgram
from torch_backend import allocation, bind, spec
import witness_lease
from witness_lease import WitnessLease


class WitnessProgram(PreparedProgram):
    __slots__ = ('_witness_artifact', '_witness_identity')

    def __init__(self, exported, example, late_read=False):
        super().__init__(exported, example, late_read)
        artifact = super().artifact
        artifact.update(schema='borrowplan-owned-witness-artifact-v6',
            witness_backend_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            witness_runtime_sha256=hashlib.sha256(Path(witness_lease.__file__).read_bytes()).hexdigest(),
            completion_contract='private single-record monotone CUDA events; no external re-recording')
        object.__setattr__(self, '_witness_artifact', json.dumps(artifact, sort_keys=True))
        object.__setattr__(self, '_witness_identity', digest(artifact))

    @property
    def artifact(self):
        return json.loads(self._witness_artifact)

    @property
    def executable(self):
        return self._witness_identity

    def start(self, x, publication=None, ready=None):
        c = self._capsule
        if not x.is_cuda or spec(x) != c.expected:
            raise Rejected('fixed ordinary CUDA input required')
        self.guard()
        if self._certificate.plan is not c.plan:
            raise Rejected('certificate is not for the admitted executable')
        if any(allocation(x) == token[5] for token in c.state_tokens):
            raise Rejected('input aliases owned model state')
        b = bind(x, **(publication or {}))
        lease = WitnessLease(self._certificate, {c.root: b}, c.child_executable, {c.root: b.version})
        if ready is None:
            ready = torch.cuda.Event()
            ready.record(torch.cuda.current_stream(x.device))
        elif not isinstance(ready, torch.cuda.Event):
            raise Rejected('the adapter requires a trusted CUDA ready event')
        return OwnedExecution(self, lease, x, ready)
