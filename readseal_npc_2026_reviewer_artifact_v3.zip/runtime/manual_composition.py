"""Complete explicit A/C join; no automatic plan or ReadSeal lease is used."""
import torch
from manual_static import ManualProgram, ManualRejected
from native_loader import FrozenNative
from common import ROOT, Join, now
from study_common import MODELS


class ManualComposition:
    def __init__(self, example, late, full):
        self.child = ManualProgram(MODELS['transfusion'][0], example, 'transfusion', late, full)
        self.native = FrozenNative(ROOT / 'results/borrowplan_v2_native_composition_attempt1')
        self.full = full
        self.artifact = dict(schema='readseal-independent-manual-abc-v8', full=full,
            child=self.child.artifact, native=self.native.receipt,
            complete_enrollment=['A', 'C'], manual_join=True,
            automatic_plan_consumed=False, checked_child_consumed=False)

    def start(self, x, publication, ready):
        return ManualInvocation(self, x, dict(publication), ready)


class ManualInvocation:
    def __init__(self, program, x, publication, ready):
        self.program, self.x, self.publication, self.ready = program, x, publication, ready
        self.pending = {'A', 'C'}
        self.events, self.stage = [], 0
        self.published = False
        self.trace = dict(enrolled_ns=now())

    def submit(self, stage, stream):
        if stage != self.stage or self.published or stage > (0 if self.program.full else 1):
            raise ManualRejected('invalid manual composition stage')
        if stage == 0:
            self.native = self.program.native.launch(self.x, self.ready)
            self.pending.remove('A')
            self.trace['a_submitted_ns'] = now()
            self.child = self.program.child.start(self.x.view_as(self.x), self.publication, self.ready)
            self.child.submit(0, stream)
            self.pending.remove('C')
            self.trace['c_prefix_submitted_ns'] = now()
            native_event = self.native.output_done if self.program.full else self.native.read_done
            self.events.append(Join([native_event, self.child.events[0]]))
            self.x = None
        else:
            self.child.submit(1, stream)
            self.events.append(Join([self.native.output_done, self.child.events[-1]]))
        self.stage += 1
        return self.events[-1]

    def can_release(self):
        return not self.pending and bool(self.events) and self.events[0].query() and self.child.can_release()

    def publish(self):
        if self.published or self.pending or not self.events[-1].query():
            raise ManualRejected('incomplete or duplicate manual composition output')
        values, identity = self.child.publish()
        if identity != self.publication:
            raise ManualRejected('manual child publication differs')
        self.published = True
        return (self.native.output,) + tuple(values), dict(identity)
