"""Differential CPU schedules and negative controls for grouped transitions."""
from dataclasses import asdict, replace
import itertools
import unittest
from core import Binding, Node, Rejected, Summary, TensorSpec, compile_plan, digest
from prepared_lease import prepare
from witness_lease import WitnessLease
from batch_lease import BatchLease, prepare_groups


class Event:
    def __init__(self): self.done=False
    def query(self): return self.done


class Tests(unittest.TestCase):
    def make(self,late=False):
        spec=TensorSpec((2,3),(3,1),'float32','cpu')
        s=Summary((0,),implementation='reviewed-functional')
        nodes=(Node('a',('x',),s),Node('b',('a',),s),Node('c',('x' if late else 'b',),s))
        p=compile_plan(('x',),nodes,('c',),{'x':spec},'exe')
        b=Binding('pool',24,1,1,2,digest(asdict(spec)),spec)
        cert=prepare(p); groups=(('a',),('b','c'))
        args=(cert,{'x':b},'exe',{'x':b.version})
        return WitnessLease(*args),BatchLease(*args,prepare_groups(p,groups))

    def compare(self,a,b):
        self.assertEqual(a.states,b.states)
        self.assertEqual(a.can_release('pool'),b.can_release('pool'))
        self.assertEqual(a.can_publish(),b.can_publish())

    def test_all_group_completion_and_abort_schedules(self):
        for late,first_done,last_done,abort in itertools.product((False,True),repeat=4):
            a,b=self.make(late); es=[Event(),Event()]
            self.compare(a,b)
            for index,group in enumerate(b.grouping.groups):
                b.begin_group(index)
                for n in group:
                    a.begin(n); a.submitted(n,es[index])
                b.submitted_group(index,es[index])
                es[index].done=(first_done if index==0 else last_done)
                self.compare(a,b)
            if abort:
                a.abort(); b.abort(); self.compare(a,b)
            es[0].done=es[1].done=True
            self.compare(a,b)
            if not abort:
                self.assertEqual(a.publish_identity(),b.publish_identity())
                self.compare(a,b)

    def test_pending_cancel(self):
        a,b=self.make(True); a.abort(); b.abort(); self.compare(a,b)
        with self.assertRaises(Rejected): b.begin_group(0)

    def test_begun_without_witness_retains_source(self):
        _,b=self.make(); b.begin_group(0); b.abort()
        self.assertFalse(b.can_release('pool'))
        e=Event(); b.submitted_group(0,e)
        self.assertFalse(b.can_release('pool')); e.done=True
        self.assertTrue(b.can_release('pool')); self.assertFalse(b.can_publish())

    def test_invalid_grouping(self):
        _,b=self.make()
        for groups in ((('a','b'),), (('b','a'),('c',)), (('a','a'),('b','c'))):
            with self.assertRaises(Rejected): prepare_groups(b.plan,groups)
        p=replace(b.plan,nodes=(replace(b.plan.nodes[0],summary=replace(b.plan.nodes[0].summary,completion='input_consumed')),)+b.plan.nodes[1:])
        with self.assertRaises(Rejected): prepare_groups(p,b.grouping.groups)

    def test_invalid_transitions(self):
        _,b=self.make()
        for index in (-1,1,True,2):
            with self.assertRaises(Rejected): b.begin_group(index)
        with self.assertRaises(Rejected): b.submitted_group(0,Event())
        b.begin_group(0)
        with self.assertRaises(Rejected): b.begin_group(0)
        with self.assertRaises(Rejected): b.submitted_group(0,object())
        b.submitted_group(0,Event())
        with self.assertRaises(Rejected): b.submitted_group(0,Event())
        with self.assertRaises(Rejected): b.begin_group(0)

    def test_prior_logical_mutation_rejected(self):
        _,b=self.make(); b.begin('a')
        with self.assertRaises(Rejected): b.begin_group(0)


if __name__=='__main__':
    unittest.main(verbosity=2)
