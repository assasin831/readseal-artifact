"""Independent full A/B/C audit plus exact admitted-to-received credit accounting."""
import argparse
import json
from pathlib import Path
import traceback
import validate_abc
from validate_admission_base import audit_cell
from manual_static import sha


def audit(folder):
    validate_abc.audit_cell=audit_cell
    out=validate_abc.cell(folder)
    r=json.loads((folder/'report.json').read_text())
    sink=json.loads((folder/'sink.json').read_text())
    n=r['cell']['consumers']; cap=r['cell']['outstanding_cap']
    events=[]
    for row in r['producer']:
        reason=row['drop_reason']
        assert reason in (None,'producer_late','pool_exhausted','credit_exhausted')
        if reason=='credit_exhausted':
            assert cap and row['outstanding_before']+n>cap and not any(row['enqueued'])
        if 'credit_admit_ns' in row:
            assert row['outstanding_after']==row['outstanding_before']+n
            events.append((row['credit_admit_ns'],n,row['outstanding_before']))
            if 'credit_cancel_ns' in row:
                assert reason=='pool_exhausted'
                events.append((row['credit_cancel_ns'],-n,None))
            for t in row.get('credit_queue_cancel_ns',{}).values():
                events.append((t,-1,None))
    for row in sink:
        assert row['publish_ns']<=row['credit_return_ns']
        events.append((row['credit_return_ns'],-1,None))
    active=peak=0
    for timestamp,delta,before in sorted(events):
        if before is not None:
            assert active==before
        active+=delta
        assert active>=0 and (not cap or active<=cap)
        peak=max(peak,active)
    assert active==r['final_outstanding']==0
    out.update(credit_events=len(events),peak_outstanding=peak,outstanding_cap=cap,
        credit_reconstruction=True,validator_sha256=sha(__file__))
    return out


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--run',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=False)
    out=dict(status='RUNNING')
    try:
        out.update(audit(a.run),status='COMPLETE')
    except BaseException:
        out.update(status='FAILED',traceback=traceback.format_exc()); traceback.print_exc()
    (a.output/'validation.json').write_text(json.dumps(out,indent=2)+'\n')
    (a.output/out['status']).write_text(out['status']+'\n')
    print(json.dumps(out),flush=True)
    raise SystemExit(int(out['status']!='COMPLETE'))
