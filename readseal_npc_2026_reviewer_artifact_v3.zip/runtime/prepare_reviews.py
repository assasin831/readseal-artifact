"""CPU-only construction gate; freeze independent review choices before CUDA."""
import argparse
import json
from pathlib import Path
import traceback
import torch
from core import Rejected
from owned_witness import WitnessProgram
from study_common import MODELS, inputs, sha
from variants import edited_export, review_record, SUPPORTED, UNSUPPORTED
from evolved_manual import EvolvedManual


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    report = dict(status='RUNNING', reviews=[], unsupported=[], cuda_used=False)
    try:
        torch.set_num_threads(1)
        for model, (path, _) in MODELS.items():
            x = inputs(model)[0][0]
            for edit in SUPPORTED:
                review = review_record(path, model, edit)
                snapshot = edited_export(path, model, edit)
                manual = EvolvedManual(snapshot, x, review, model, edit)
                auto = WitnessProgram(snapshot, x)
                readers = sorted(dict(auto.plan.obligations)[auto.root])
                assert readers == review['readers'], (model, edit, readers, review)
                c = auto._capsule
                calls = [n for n in c.groups[0] if n in readers]
                assert calls[-1] == review['boundary'], (model, edit, calls)
                report['reviews'].append(review)
                print('CONSTRUCTION_OK', model, edit, readers, flush=True)
            for edit in UNSUPPORTED:
                try:
                    WitnessProgram(edited_export(path, model, edit), x)
                except Rejected as e:
                    report['unsupported'].append(dict(model=model, edit=edit, reason=str(e)))
                else:
                    raise AssertionError('unsupported graph accepted: '+model+'/'+edit)
        assert len(report['reviews']) == 16 and len(report['unsupported']) == 6
        report.update(status='COMPLETE', source_hashes={str(f):sha(f) for f in Path(__file__).parent.glob('*.py')})
    except BaseException:
        report.update(status='FAILED', traceback=traceback.format_exc())
        traceback.print_exc()
    (a.output/'report.json').write_text(json.dumps(report, indent=2)+'\n')
    (a.output/report['status']).write_text(report['status']+'\n')
    return int(report['status'] != 'COMPLETE')


if __name__ == '__main__':
    raise SystemExit(main())
