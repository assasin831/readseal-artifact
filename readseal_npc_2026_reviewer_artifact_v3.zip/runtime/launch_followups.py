"""Serial additional formal comparisons after the streaming campaign completes."""
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback
import hashlib

ROOT=Path('/www/readseal_ipdps_revision_v6')
SOURCE=Path(__file__).resolve().parent
OUT=ROOT/'results/borrowplan_v7_followups_attempt1'
GPU='GPU-f3b314a8-3058-e0be-694c-76f4227afb7d'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    OUT.mkdir(parents=True,exist_ok=False)
    (OUT/'pid').write_text(str(os.getpid())+'\n')
    report=dict(status='RUNNING',runs=[],sources={str(p):sha(p) for p in SOURCE.iterdir() if p.is_file()})
    try:
        with (ROOT/'borrowplan_gpu0.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            prior=ROOT/'results/borrowplan_v7_streaming_formal_attempt1'
            assert (prior/'COMPLETE').exists() and json.loads((prior/'report.json').read_text())['status']=='COMPLETE'
            report['streaming_campaign_sha256']=sha(prior/'report.json')
            deps=[SOURCE]+[ROOT/n for n in (
                'prototype_borrowplan_v6_resnet_scope_attempt1','prototype_borrowplan_v6_witness_attempt1',
                'prototype_borrowplan_v5_prepared_attempt1','prototype_borrowplan_v5_owned_attempt2',
                'prototype_borrowplan_v4_segmented_attempt1','prototype_borrowplan_v1_attempt2',
                'prototype_borrowplan_v2_composition_attempt2','prototype_borrowplan_v3_attempt1',
                'sdk_trt_10_3_attempt2/packages','experiments')]
            env=dict(os.environ,PYTHONPATH=':'.join(map(str,deps)),CUDA_VISIBLE_DEVICES=GPU,
                PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
                CUDA_CACHE_PATH=str(OUT/'cuda-cache'))
            plan=json.loads((SOURCE/'FOLLOWUP_PLAN.json').read_text())
            report.update(plan=plan,plan_sha256=sha(SOURCE/'FOLLOWUP_PLAN.json'))
            commands=[('local-event-control',[sys.executable,'-B',str(SOURCE/'run_local_event_control.py'),
                                             '--output',str(OUT/'local-event-control')])]
            commands += [(f'cost-r{i:02d}',[sys.executable,'-B',str(SOURCE/'run_manual_cost.py'),
                    '--output',str(OUT/f'cost-r{i:02d}'),'--repeat',str(i)]) for i in range(8)]
            for name,command in commands:
                assert all(sha(p)==h for p,h in report['sources'].items())
                assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid',
                                                     '--format=csv,noheader'],text=True).strip()
                with (OUT/(name+'.log')).open('x') as log:
                    code=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
                assert code==0,name+' failed; no retry'
                r=json.loads((OUT/name/'report.json').read_text())
                assert r['status']=='COMPLETE'
                kind='control' if name=='local-event-control' else 'cost'
                validation=OUT/(name+'-validation')
                command=[sys.executable,'-B',str(SOURCE/'validate_followup.py'),'--kind',kind,
                         '--run',str(OUT/name),'--output',str(validation)]
                with (OUT/(name+'-validation.log')).open('x') as log:
                    code=subprocess.run(command,cwd=ROOT,env=dict(env,CUDA_VISIBLE_DEVICES=''),
                                        stdout=log,stderr=subprocess.STDOUT).returncode
                assert code==0,name+' independent validation failed; no retry'
                report['runs'].append(dict(name=name,report_sha256=sha(OUT/name/'report.json'),
                                          validation_sha256=sha(validation/'validation.json')))
                (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
                print('COMPLETE '+name,flush=True)
            report['status']='COMPLETE'
    except BaseException:
        report.update(status='FAILED',traceback=traceback.format_exc())
        traceback.print_exc()
    (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    (OUT/report['status']).write_text(report['status']+'\n')
    return 0 if report['status']=='COMPLETE' else 1


if __name__=='__main__':
    raise SystemExit(main())
