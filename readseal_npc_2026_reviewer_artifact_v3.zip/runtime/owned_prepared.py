"""Owned stages plus construction-certified admission; original stage executor."""
import hashlib
import json
from pathlib import Path

import torch
from core import Rejected, digest
from owned_backend import OwnedProgram, OwnedExecution
import prepared_lease
from prepared_lease import prepare, PreparedLease
from torch_backend import allocation, bind, spec


class PreparedProgram(OwnedProgram):
    __slots__ = ('_certificate', '_prepared_artifact', '_prepared_identity')

    def __init__(self, exported, example, late_read=False):
        super().__init__(exported, example, late_read)
        certificate = prepare(self.plan)
        artifact = super().artifact
        artifact.update(schema='borrowplan-owned-prepared-artifact-v5',
            prepared_backend_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            prepared_runtime_sha256=hashlib.sha256(Path(prepared_lease.__file__).read_bytes()).hexdigest(),
            prepared_plan_sha256=certificate.plan_sha256,
            admission='static immutable plan validated at construction; original dynamic binding checks and state machine')
        object.__setattr__(self, '_certificate', certificate)
        object.__setattr__(self, '_prepared_artifact', json.dumps(artifact, sort_keys=True))
        object.__setattr__(self, '_prepared_identity', digest(artifact))

    @property
    def artifact(self):
        return json.loads(self._prepared_artifact)

    @property
    def executable(self):
        return self._prepared_identity

    def start(self, x, publication=None, ready=None):
        c = self._capsule
        if not x.is_cuda or spec(x) != c.expected:
            raise Rejected('fixed ordinary CUDA input required')
        self.guard()
        if self._certificate.plan is not c.plan:
            raise Rejected('certificate is not for the admitted executable')
        if any(allocation(x) == token[5] for token in c.state_tokens):
            raise Rejected('input aliases owned model state')
        b = bind(x, **(publication or {}))
        lease = PreparedLease(self._certificate, {c.root: b}, c.child_executable, {c.root: b.version})
        if ready is None:
            ready = torch.cuda.Event()
            ready.record(torch.cuda.current_stream(x.device))
        elif not isinstance(ready, torch.cuda.Event):
            raise Rejected('the adapter requires a trusted CUDA ready event')
        return OwnedExecution(self, lease, x, ready)
