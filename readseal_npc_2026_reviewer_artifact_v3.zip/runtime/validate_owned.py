"""Saved-evidence audit; never imports the owned execution implementation."""
import argparse
import copy
import hashlib
import json
import operator
from pathlib import Path
import random
import traceback

import torch
from core import digest
from validate_segmented_multiprocess import stage_template


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def reference_readers(exported, late):
    graph = copy.deepcopy(exported.graph)
    root = exported.graph_signature.user_inputs[0]
    source = next(n for n in graph.nodes if n.name == root)
    output = next(n for n in graph.nodes if n.op == 'output')
    if late:
        with graph.inserting_before(output):
            clone = graph.call_function(torch.ops.aten.clone.default, (source,))
            graph.call_function(torch.ops.aten.mean.default, (clone,))
    aliases, readers = {root: True}, set()
    for n in graph.nodes:
        if n.op == 'placeholder':
            aliases.setdefault(n.name, False)
        elif n.op == 'call_function':
            incoming = any(aliases[i.name] for i in n.all_input_nodes)
            if incoming:
                readers.add(n.name)
            returns_alias = n.target is operator.getitem or any(r.alias_info is not None for r in n.target._schema.returns)
            aliases[n.name] = incoming and returns_alias
    return readers


def main():
    p = argparse.ArgumentParser()
    for name in ('run', 'output', 'export', 'cases'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    count = 0

    def check(condition, label):
        nonlocal count
        count += 1
        assert condition, label

    result = dict(status='RUNNING', validator_sha256=sha(__file__), report_sha256=sha(a.run / 'report.json'))
    try:
        torch.set_num_threads(1)
        data = json.loads((a.run / 'report.json').read_text())
        check(data['status'] == 'COMPLETE' and (a.run / 'COMPLETE').is_file() and not (a.run / 'FAILED').exists(), 'completion')
        check(data['performance_claim'] is False, 'no formal performance claim')
        check(len(data['cases']) == 6, 'six cases')
        check(data['export_sha256'] == sha(a.export), 'export lineage')
        for path, expected in data['source_sha256'].items():
            check(sha(path) == expected, 'source lineage ' + path)
        check(not data['preflight'], 'initial GPU isolation')
        check(all(p['pid'] == data['pid'] and p['gpu'] == data['gpu_uuid'] for p in data['postflight']), 'final GPU isolation')
        exported = torch.export.load(a.export)
        templates = {late: stage_template(exported, late) for late in (False, True)}
        seen = set()
        tensors = 0
        records = 0
        rng = random.Random(75001)
        for row in data['cases']:
            key = row['source'], row['late']
            check(key not in seen and key[0] in range(3) and type(key[1]) is bool, 'membership')
            seen.add(key)
            check(row['source_sha256'] == sha(a.cases / f'case_{key[0]}.pt'), 'input lineage')
            folder = a.run / f'source-{key[0]}-{"late" if key[1] else "base"}'
            check(sha(folder / 'artifact.json') == row['artifact_sha256'], 'artifact hash')
            artifact = json.loads((folder / 'artifact.json').read_text())
            check(artifact['schema'] == 'borrowplan-owned-segmented-artifact-v5', 'schema')
            check(digest(artifact) == row['executable'], 'actual executable binding')
            expected = templates[key[1]]
            check(set(row['complete_reader_set']) == reference_readers(exported, key[1]), 'exact independently derived reader set')
            check(artifact['groups'] == expected['groups'] and artifact['live'] == expected['live'], 'independent partition')
            for module, reference in zip(artifact['modules'], expected['modules']):
                check(module['nodes'] == reference['nodes'], 'independent generated graph')
                check(module['code'] == reference['code'], 'independent generated code')
            check(len(artifact['modules']) == 2, 'two modules')
            check(sha(folder / 'outputs.pt') == row['output_sha256'], 'output hash')
            saved = torch.load(folder / 'outputs.pt', map_location='cpu')
            check(len(saved['actual']) == len(saved['expected']) == (10 if key[1] else 9), 'output count')
            for actual, reference in zip(saved['actual'], saved['expected']):
                tensors += 1
                check(actual.dtype == reference.dtype and actual.shape == reference.shape, 'tensor metadata')
                check(torch.isfinite(actual).all().item() and torch.isfinite(reference).all().item(), 'finite tensors')
                check(torch.equal(actual, reference), 'exact tensor')
            if data['mode'] == 'correctness':
                check(row['exact'] and row['old_publication_preserved'], 'output and identity predicates')
                check(not row['before_prefix_releasable'] and row['after_prefix_releasable'], 'release predicates')
                check(len(row['receipts']) == 2, 'two witnesses')
                prefix, suffix = row['receipts']
                check(prefix['stage'] == 0 and suffix['stage'] == 1, 'stage order')
                check(prefix['wait_completed_ns'] < row['reuse_done_ns'] < suffix['started_ns'], 'physical reuse order')
                for i, receipt in enumerate((prefix, suffix)):
                    check(receipt['operations'] == artifact['groups'][i], 'complete operation witness')
                    check(receipt['module_sha256'] == artifact['modules'][i]['sha256'], 'module witness binding')
                    check(receipt['started_ns'] <= receipt['submitted_ns'] <= receipt['wait_completed_ns'], 'event order')
                    check(receipt['event_handle'] > 0 and receipt['dynamic_boundary_alias'] is False, 'event and alias')
                check(prefix['stream_handle'] == suffix['stream_handle'], 'single stream')
                check(set(row['complete_reader_set']) <= set(prefix['operations']), 'future reader coverage')
            else:
                check(data['mode'] == 'pilot' and data['recipe'] == dict(warmups=10, randomized_triples=30, seed=75001), 'pilot recipe')
                check(len(row['records']) == 90 and len(row['host_audits']) == 30, 'pilot count')
                for audit in row['host_audits']:
                    check(all(p['pid'] == data['pid'] and p['gpu'] == data['gpu_uuid'] for p in audit), 'pilot isolation')
                for trial in range(30):
                    order = ['direct', 'v5-automatic', 'v5-complete-manual']
                    rng.shuffle(order)
                    for position, method in enumerate(order):
                        record = row['records'][trial * 3 + position]
                        check(record['trial'] == trial and record['position'] == position and record['method'] == method, 'randomized pairing')
                        check(record['exact'] and type(record['wall_ns']) is int and record['wall_ns'] > 0, 'pilot duration and output')
                        records += 1
        check(tensors == 57, 'all 57 tensors')
        if data['mode'] == 'correctness':
            check(len(data['negatives']) == len(set(data['negatives'])) == 54, 'all rejection controls')
        else:
            check(records == 540, '540 exploratory timings')
        result.update(status='COMPLETE', checks=count, tensors=tensors, records=records, mode=data['mode'], performance_claim=False)
        (a.output / 'COMPLETE').write_text('Saved evidence and generated stages independently audited.\n')
    except BaseException as exc:
        result.update(status='FAILED', checks=count, error=str(exc))
        (a.output / 'FAILED').write_text(type(exc).__name__ + '\n')
        (a.output / 'traceback.txt').write_text(traceback.format_exc())
        traceback.print_exc()
    (a.output / 'validation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
    return 0 if result['status'] == 'COMPLETE' else 1


if __name__ == '__main__':
    raise SystemExit(main())
