"""Load the previously validated native artifact without rebuilding it."""
import hashlib
import json
from pathlib import Path

import tensorrt as trt
from core import Rejected, digest
from native_composition import NativeComponent, source_sha


ENGINE_SHA = "e16e10603b9a5508995331576c2f8863ecbfb380041742eb400024789d5fbc97"
REPORT_SHA = "3dee35fc00a238d313c4af9b55f43772f361751225f0ed5a310a94ab29ef5d9d"


class FrozenNative(NativeComponent):
    def __init__(self, directory):
        directory = Path(directory)
        blob, report = (directory / "native.engine").read_bytes(), (directory / "report.json").read_bytes()
        if (trt.__version__ != "10.3.0" or hashlib.sha256(blob).hexdigest() != ENGINE_SHA
                or hashlib.sha256(report).hexdigest() != REPORT_SHA):
            raise Rejected("frozen native lineage mismatch")
        prior = json.loads(report)
        assert prior["status"] == "COMPLETE"
        self.receipt = prior["native"]
        assert self.receipt["engine_sha256"] == ENGINE_SHA
        self.logger = trt.Logger(trt.Logger.WARNING)
        self.runtime = trt.Runtime(self.logger)
        self.engine = self.runtime.deserialize_cuda_engine(blob)
        if self.engine is None:
            raise Rejected("frozen engine deserialize failed")
        assert self.engine.num_io_tensors == 2 and self.engine.num_aux_streams == 0
        for name, shape in (("input", (1, 512, 180, 180)), ("output", (1, 128))):
            assert tuple(self.engine.get_tensor_shape(name)) == shape
            assert self.engine.get_tensor_dtype(name) == trt.float32
            assert self.engine.get_tensor_location(name) == trt.TensorLocation.DEVICE
        self.identity = digest({"receipt": self.receipt, "adapter_sha256": source_sha(),
                                "loader_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
