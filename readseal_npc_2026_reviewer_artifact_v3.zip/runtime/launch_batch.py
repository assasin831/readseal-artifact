"""Wait for the admission campaign, then gate and measure grouped bookkeeping."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT=Path('/www/readseal_ipdps_revision_v6')
GPU='GPU-f3b314a8-3058-e0be-694c-76f4227afb7d'
SOURCE=Path(__file__).resolve().parent


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser(); p.add_argument('--output',type=Path,required=True)
    p.add_argument('--after',type=Path,required=True)
    a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=False)
    (a.output/'pid').write_text(str(os.getpid())+'\n')
    result=dict(status='WAITING',active=None,runs=[],after=str(a.after),
        source_hashes={str(f):sha(f) for f in SOURCE.glob('*.py')},
        cost_plan=dict(process_repetitions=8,models=2,graphs=2,inputs_per_model=3,warmups=20,
                       quartets=50,methods=['auto-early','auto-batched','manual-early','manual-full'],
                       order_seeds=list(range(101051,101059)),timed_invocations=19200))
    def save(): (a.output/'report.json').write_text(json.dumps(result,indent=2)+'\n')
    save()
    try:
        while True:
            before=json.loads((a.after/'report.json').read_text())
            if before['status']=='COMPLETE': break
            assert before['status']=='RUNNING', 'preceding campaign failed; do not launch'
            time.sleep(60)
        result.update(status='RUNNING',after_sha256=sha(a.after/'report.json')); save()
        with (ROOT/'borrowplan_gpu0.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            deps=[SOURCE]+[ROOT/s for s in ('prototype_borrowplan_v7_followups_attempt1',
                'prototype_borrowplan_v7_formal_attempt1','prototype_borrowplan_v6_resnet_scope_attempt1',
                'prototype_borrowplan_v6_witness_attempt1','prototype_borrowplan_v5_prepared_attempt1',
                'prototype_borrowplan_v5_owned_attempt2','prototype_borrowplan_v4_segmented_attempt1',
                'prototype_borrowplan_v1_attempt2','prototype_borrowplan_v2_composition_attempt2',
                'prototype_borrowplan_v3_attempt1','experiments')]
            env=dict(os.environ,PYTHONPATH=':'.join(map(str,deps)),CUDA_VISIBLE_DEVICES=GPU,
                PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
                CUDA_CACHE_PATH=str(a.output/'cuda-cache'))
            def step(name,script,args,gpu):
                assert all(sha(f)==h for f,h in result['source_hashes'].items()), 'source changed'
                if gpu:
                    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader'],text=True).strip(), 'foreign compute; no inference launched'
                result['active']=name; save()
                cmd=[sys.executable,'-B',str(SOURCE/script),*args,'--output',str(a.output/name)]
                with (a.output/(name+'.log')).open('x') as log:
                    code=subprocess.run(cmd,cwd=ROOT,env=env if gpu else dict(env,CUDA_VISIBLE_DEVICES=''),stdout=log,stderr=subprocess.STDOUT).returncode
                assert code==0, name+' failed; preserve without inference retry'
                report=next(p for p in (a.output/name/'report.json',a.output/name/'validation.json') if p.exists())
                result['runs'].append(dict(name=name,report=str(report),report_sha256=sha(report),gpu=gpu))
                print('COMPLETE',name,flush=True); save()
            step('construction','prepare_batch_reviews.py',[],False)
            reviews=str(a.output/'construction/report.json')
            step('gate','run_batch_gate.py',['--reviews',reviews],True)
            step('gate-validation','validate_maintenance.py',['--reviews',reviews,'--run',str(a.output/'gate')],False)
            for rep in range(8):
                name=f'cost-r{rep:02d}'
                step(name,'run_batch_cost.py',['--repeat',str(rep)],True)
                step(name+'-validation','validate_batch_cost.py',['--run',str(a.output/name)],False)
        result.update(status='COMPLETE',active=None)
    except BaseException:
        result.update(status='FAILED',traceback=traceback.format_exc()); traceback.print_exc()
    save(); (a.output/result['status']).write_text(result['status']+'\n')
    return int(result['status']!='COMPLETE')


if __name__=='__main__':
    raise SystemExit(main())
