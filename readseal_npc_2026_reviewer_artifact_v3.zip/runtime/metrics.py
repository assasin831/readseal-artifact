"""Physical-allocation interval union, independent of recipient multiplicity."""
def union_byte_seconds(intervals, begin, end, source_bytes):
    by_slot={}
    for r in intervals:
        if r['end_ns']<r['start_ns']:
            raise ValueError('negative hold interval')
        left,right=max(begin,r['start_ns']),min(end,r['end_ns'])
        if right>left:
            by_slot.setdefault(r['slot'],[]).append((left,right))
    total=0
    for spans in by_slot.values():
        start=stop=None
        for left,right in sorted(spans):
            if stop is None:
                start,stop=left,right
            elif left>stop:
                total+=stop-start
                start,stop=left,right
            else:
                stop=max(stop,right)
        total+=stop-start
    return total*source_bytes/1e9


if __name__=='__main__':
    rows=[dict(slot=0,start_ns=0,end_ns=10),dict(slot=0,start_ns=5,end_ns=15),
          dict(slot=1,start_ns=5,end_ns=15)]
    assert union_byte_seconds(rows,0,20,10**9)==25
    assert union_byte_seconds(rows,7,12,10**9)==10
    assert union_byte_seconds([],0,20,10**9)==0
    print('3 interval-union checks passed')
