"""Native event + delayed alias consumer; correctness only, one frozen GPU."""
import argparse
import copy
from dataclasses import asdict
import json
import os
from pathlib import Path
import subprocess
import traceback

import torch
import tensorrt as trt
import core
import export_backend
import storage_pool
import torch_backend
import run_export_execution

from core import Lease, Rejected
from export_backend import Program
from native_composition import NativeComponent, compose, ChildReadDone, ChildOutputDone, ReferenceBorrowManager
from run_export_execution import GPU, sha, tensor_sha
from storage_pool import Pool
from torch_backend import Ready, bind, allocation


def main():
    p = argparse.ArgumentParser()
    for name in ("export", "cases", "sdk", "output"):
        p.add_argument("--" + name, type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    report = {"status": "RUNNING", "performance_claim": False,
              "scope": "single-process native TensorRT + alias view + exported TransFusion head; not full V6 pool",
              "cases": [], "source_sha256": {f.name: sha(f) for f in Path(__file__).parent.glob("*.py")},
              "dependency_sha256": {Path(m.__file__).name: sha(m.__file__) for m in
                                    (core, export_backend, storage_pool, torch_backend, run_export_execution)}}
    try:
        assert os.environ.get("CUDA_VISIBLE_DEVICES") == GPU
        active = subprocess.check_output(["nvidia-smi", "--query-compute-apps=gpu_uuid,pid", "--format=csv,noheader"], text=True)
        assert not any(line.startswith(GPU) for line in active.splitlines()), "GPU0 not idle"
        report.update(gpu_uuid=GPU, preexisting_compute_processes=active.splitlines(), torch=torch.__version__, tensorrt=trt.__version__)
        sdk_report = json.loads((a.sdk / "report.json").read_text())
        assert sdk_report["status"] == "COMPLETE" and sdk_report["imported_version"] == trt.__version__ == "10.3.0"
        assert sha(a.sdk / "inventory.json") == sdk_report["inventory_sha256"]
        for name, record in json.loads((a.sdk / "inventory.json").read_text()).items():
            assert sha(a.sdk / "packages" / name) == record["sha256"], "SDK file changed"
        report["sdk_inventory_sha256"] = sdk_report["inventory_sha256"]
        torch.set_num_threads(1)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        assert sha(a.export) == "8efaa67aa6884d0c9aec6fff442e9a50b683a290d856abef390db1f034ccabbd"
        report["export_sha256"] = sha(a.export)
        exported = torch.export.load(a.export)
        native = NativeComponent(exported, a.output / "native.engine")
        report["native"] = native.receipt
        (a.output / "native-inspection.json").write_text(native.inspection)
        oracle_report = json.loads((a.cases / "report.json").read_text())
        report["cases_receipt_sha256"] = sha(a.cases / "report.json")
        previous_plan = {}
        for i in range(3):
            source = a.cases / f"case_{i}.pt"
            assert sha(source) == oracle_report["files"][source.name]
            data = torch.load(source, map_location="cpu")
            example = data["input"].clone().cuda()
            ready = torch.cuda.Event()
            ready.record(torch.cuda.current_stream())
            oracle_native = native.launch(example, ready)
            oracle_native.output_done.synchronize()
            expected_a = oracle_native.output.detach().clone()
            for late in (False, True):
                child = Program(exported, example, late_read=late)
                plan = compose(child, example, native)
                assert set(dict(plan.obligations)["source"]) == {"A", "C"}
                assert not dict(plan.escapes)["source"]
                if not late:
                    previous_plan[i] = plan.sha256
                else:
                    assert previous_plan[i] != plan.sha256, "mutated child failed to rebind parent"
                with torch.inference_mode():
                    graph = torch.fx.GraphModule(torch.nn.Module(), copy.deepcopy(child.graph))
                    args = [example if n.name == child.root else child.state[n.name]
                            for n in child.graph.nodes if n.op == "placeholder"]
                    expected_c = tuple(t.detach().clone() for t in graph(*args))
                for policy in ("automatic", "native-complete-manager"):
                    name = f"case_{i}-{'late' if late else 'base'}-{policy}"
                    folder = a.output / name
                    folder.mkdir()
                    print("RUN " + name, flush=True)
                    x = data["input"].clone().cuda()
                    binding = bind(x)
                    ready = torch.cuda.Event()
                    ready.record(torch.cuda.current_stream())
                    lease = (Lease(plan, {"source": binding}, plan.executable, {"source": binding.version})
                             if policy == "automatic" else ReferenceBorrowManager(plan, {"source": binding}))
                    pool = Pool([binding])
                    ticket = pool.enroll(binding.allocation, binding.version)
                    pool.attach(ticket, lease)
                    lease.begin("A")
                    job = native.launch(x, ready)
                    lease.submitted("A", job.read_done, job.output_done)
                    lease.begin("B")
                    view = x.view_as(x)
                    assert allocation(view) == allocation(x)
                    lease.submitted("B", Ready())
                    job.read_done.synchronize()
                    assert job.read_done.query() and lease.states["C"] == "pending"
                    assert not lease.can_release(binding.allocation)
                    try:
                        pool.begin_write(binding.allocation)
                    except Rejected:
                        pass
                    else:
                        raise AssertionError("native input event ignored delayed alias consumer")
                    lease.begin("C")
                    execution = child.start(view, ready=ready)
                    assert execution.lease.bindings[child.root] == binding
                    lease.submitted("C", ChildReadDone(execution, binding.allocation), ChildOutputDone(execution))
                    stream, writer = torch.cuda.Stream(), torch.cuda.Stream()
                    q = set(dict(child.plan.obligations)[child.root])
                    closure = None
                    for operation in child.operations:
                        execution.step(operation, stream)
                        if operation in q:
                            execution.lease.events[operation].synchronize()
                            if lease.can_release(binding.allocation):
                                assert closure is None and not lease.can_publish()
                                pending = [n for n, state in execution.lease.states.items() if state == "pending"]
                                assert pending
                                reservation = pool.begin_write(binding.allocation)
                                with torch.cuda.stream(writer), torch.inference_mode():
                                    x.fill_(17)
                                    written = torch.cuda.Event()
                                    written.record(writer)
                                new_binding = pool.commit_write(binding.allocation, reservation, written)
                                written.synchronize()
                                closure = {"after_child_operation": operation, "pending_private_operations": pending,
                                           "old_version": binding.version, "new_version": new_binding.version,
                                           "native_input_consumed": job.read_done.query(),
                                           "parent_output_publishable": lease.can_publish(), "overwrite_sha256": tensor_sha(x)}
                    assert closure is not None
                    execution.wait()
                    job.output_done.synchronize()
                    actual = (job.output,) + execution.outputs()
                    expected = (expected_a,) + expected_c
                    torch.save({"actual": tuple(t.detach().cpu() for t in actual),
                                "expected": tuple(t.detach().cpu() for t in expected)}, folder / "outputs.pt")
                    differences = [{"index": j, "exact": torch.equal(t, expected[j]),
                                    "actual_sha256": tensor_sha(t), "expected_sha256": tensor_sha(expected[j])}
                                   for j, t in enumerate(actual)]
                    (folder / "comparison.json").write_text(json.dumps(differences, indent=2) + "\n")
                    assert all(d["exact"] for d in differences), "native-composition output mismatch"
                    assert all(bool(torch.isfinite(t).all()) for t in actual)
                    identities = lease.publish_identity()
                    assert all(v["source"].version == binding.version for v in identities.values())
                    record = {"name": name, "policy": policy, "case_sha256": sha(source),
                              "parent_plan_sha256": plan.sha256, "child_plan_sha256": child.plan.sha256,
                              "parent_obligations": dict(plan.obligations), "child_obligations": dict(child.plan.obligations),
                              "delayed_consumer_blocked_reuse": True, "closure": closure,
                              "outputs": differences, "parent_output_identity": {o: asdict(v["source"]) for o, v in identities.items()}}
                    (folder / "parent-plan.json").write_text(json.dumps(asdict(plan), indent=2, default=lambda x: sorted(x)) + "\n")
                    (folder / "child-plan.json").write_text(json.dumps(asdict(child.plan), indent=2, default=lambda x: sorted(x)) + "\n")
                    (folder / "dispatch.json").write_text(json.dumps(execution.receipts, indent=2) + "\n")
                    record["files"] = {f.name: sha(f) for f in folder.iterdir() if f.is_file()}
                    (folder / "record.json").write_text(json.dumps(record, indent=2) + "\n")
                    (folder / "COMPLETE").write_text("Native and child outputs exact after legal source reuse.\n")
                    report["cases"].append(record)
                    print("COMPLETE " + name, flush=True)
        assert len(report["cases"]) == 12
        report.update(status="COMPLETE", expected_cases=12, timing_interpretation="No performance or release-lag estimate",
                      private_overlap_claim=False, full_retention_integration=False)
        (a.output / "COMPLETE").write_text("12 native composition cases complete.\n")
    except BaseException as exc:
        report.update(status="FAILED", error=str(exc))
        (a.output / "FAILED").write_text(type(exc).__name__ + "\n")
        (a.output / "traceback.txt").write_text(traceback.format_exc())
        traceback.print_exc()
    (a.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "cases"}), flush=True)
    return 0 if report["status"] == "COMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
