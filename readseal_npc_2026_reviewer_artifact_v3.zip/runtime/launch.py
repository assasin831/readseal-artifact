"""One isolated, non-retrying launch. Every attempt gets a fresh directory."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback


ROOT = Path("/www/readseal_ipdps_revision_v6")


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--name", required=True)
    p.add_argument("--smoke", action="store_true")
    a = p.parse_args()
    if not a.name.replace("_", "").replace("-", "").isalnum():
        raise ValueError("invalid attempt name")
    output = ROOT / "results" / a.name
    launcher = ROOT / "results" / (a.name + "-launch")
    assert not output.exists()
    launcher.mkdir(exist_ok=False)
    (launcher/"pid").write_text(str(os.getpid())+"\n")
    status = 1
    try:
        with (ROOT/"borrowplan_gpu0.lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            dependencies = [ROOT/"prototype_borrowplan_v1_attempt2", ROOT/"prototype_borrowplan_v2_execution_attempt4",
                            ROOT/"prototype_borrowplan_v2_composition_attempt2", ROOT/"prototype_borrowplan_v2_retention_attempt1",
                            ROOT/"experiments", ROOT/"sdk_trt_10_3_attempt2/packages"]
            sdk = ROOT/"sdk_trt_10_3_attempt2"
            receipt = json.loads((sdk/"report.json").read_text())
            assert receipt["status"] == "COMPLETE" and sha(sdk/"inventory.json") == receipt["inventory_sha256"]
            for name, record in json.loads((sdk/"inventory.json").read_text()).items():
                assert sha(sdk/"packages"/name) == record["sha256"]
            env = dict(os.environ, CUDA_VISIBLE_DEVICES="GPU-f3b314a8-3058-e0be-694c-76f4227afb7d",
                       PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
                       CUDA_CACHE_PATH=str(launcher/"cuda-cache"), PYTHONPATH=":".join(map(str, dependencies)))
            command = [sys.executable, "-B", str(Path(__file__).with_name("run_multiprocess.py")),
                       "--export", str(ROOT/"inputs/transfusion_borrowplan_v2/head_export.pt2"),
                       "--cases", str(ROOT/"inputs/transfusion_borrowplan_v2_oracle"),
                       "--native", str(ROOT/"results/borrowplan_v2_native_composition_attempt1"), "--output", str(output)]
            if a.smoke:
                command.append("--smoke")
            (launcher/"invocation.json").write_text(json.dumps(dict(command=command, gpu=env["CUDA_VISIBLE_DEVICES"],
                sdk_inventory_sha256=receipt["inventory_sha256"],
                source_sha256={p.name: sha(p) for p in Path(__file__).parent.glob("*.py")}), indent=2)+"\n")
            with (launcher/"run.log").open("x") as log:
                status = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
    except BaseException:
        (launcher/"traceback.txt").write_text(traceback.format_exc())
        traceback.print_exc()
    (launcher/"exit_code").write_text(str(status)+"\n")
    (launcher/("COMPLETE" if status == 0 else "FAILED")).write_text("No retry was performed.\n")
    print(json.dumps(dict(status=status, launcher=str(launcher), output=str(output))), flush=True)
    return status


if __name__ == "__main__":
    raise SystemExit(main())
