"""Closed composition of a native TensorRT component and checked ATen child.

TensorRT's documented input-consumed event is trusted, not reconstructed.
Child obligations come from the artifact compiler, not a last-layer hook.
Only fixed, plugin-free, explicitly bound single-input/single-output engines.
"""
from dataclasses import asdict
import hashlib
from pathlib import Path

import numpy as np
import torch
import tensorrt as trt

from core import Lease, Node, Summary, Rejected, compile_plan, digest
from torch_backend import allocation, spec


def source_sha():
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


class NativeComponent:
    def __init__(self, exported, output):
        if trt.__version__ != "10.3.0":
            raise Rejected("unreviewed native SDK")
        weights = {name: t.detach().cpu().contiguous().numpy() for name, t in exported.state_dict.items()
                   if name.endswith("shared_conv.weight") or name.endswith("shared_conv.bias")}
        weight = next(v for k, v in weights.items() if k.endswith("shared_conv.weight"))
        bias = next(v for k, v in weights.items() if k.endswith("shared_conv.bias"))
        assert weight.shape == (128, 512, 3, 3) and bias.shape == (128,) and len(weights) == 2
        logger = trt.Logger(trt.Logger.WARNING)
        builder = trt.Builder(logger)
        network = builder.create_network(1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))
        x = network.add_input("input", trt.float32, (1, 512, 180, 180))
        conv = network.add_convolution_nd(x, 128, (3, 3), weight, bias)
        conv.padding_nd = (1, 1)
        relu = network.add_activation(conv.get_output(0), trt.ActivationType.RELU)
        average = network.add_reduce(relu.get_output(0), trt.ReduceOperation.AVG, (1 << 2) | (1 << 3), False)
        y = average.get_output(0)
        y.name = "output"
        network.mark_output(y)
        config = builder.create_builder_config()
        config.clear_flag(trt.BuilderFlag.TF32)
        config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, 256 << 20)
        config.max_aux_streams = 0
        config.profiling_verbosity = trt.ProfilingVerbosity.DETAILED
        serialized = builder.build_serialized_network(network, config)
        if serialized is None:
            raise Rejected("native engine build failed")
        blob = bytes(serialized)
        output.write_bytes(blob)
        self.logger, self.runtime = logger, trt.Runtime(logger)
        self.engine = self.runtime.deserialize_cuda_engine(blob)
        if self.engine is None:
            raise Rejected("native engine deserialize failed")
        assert self.engine.num_io_tensors == 2 and self.engine.num_aux_streams == 0
        assert tuple(self.engine.get_tensor_shape("input")) == (1, 512, 180, 180)
        assert tuple(self.engine.get_tensor_shape("output")) == (1, 128)
        for name in ("input", "output"):
            assert self.engine.get_tensor_dtype(name) == trt.float32
            assert self.engine.get_tensor_location(name) == trt.TensorLocation.DEVICE
        self.receipt = {"sdk": trt.__version__, "engine_sha256": hashlib.sha256(blob).hexdigest(),
                        "input": [1, 512, 180, 180], "output": [1, 128], "tf32": False,
                        "plugins": False, "max_aux_streams": 0, "workspace_limit_bytes": 256 << 20,
                        "weights": {k: hashlib.sha256(v.tobytes()).hexdigest() for k, v in weights.items()},
                        "scope": "TransFusion shared convolution weights + ReLU + global average; not full TensorRT head",
                        "input_boundary": "IExecutionContext.set_input_consumed_event",
                        "output_boundary": "event recorded after execute_async_v3 on its non-default stream"}
        self.identity = digest({"receipt": self.receipt, "adapter_sha256": source_sha()})
        inspector = self.engine.create_engine_inspector()
        self.inspection = inspector.get_engine_information(trt.LayerInformationFormat.JSON)

    def launch(self, x, ready):
        if (not x.is_cuda or x.device.index != 0 or not x.is_contiguous()
                or tuple(x.shape) != (1, 512, 180, 180) or x.dtype != torch.float32):
            raise Rejected("native input outside fixed engine ABI")
        return NativeInvocation(self, x, ready)


class NativeInvocation:
    def __init__(self, component, x, ready):
        self.component = component
        self.context = component.engine.create_execution_context()
        if self.context is None:
            raise Rejected("native context allocation failed")
        self.stream = torch.cuda.Stream()
        self.output = torch.empty((1, 128), device=x.device, dtype=x.dtype)
        self.read_done, self.output_done = torch.cuda.Event(), torch.cuda.Event()
        # Materialize a CUDA handle once. TensorRT records this event anew during
        # execute_async_v3; it is never exposed to the lease before enqueue.
        self.read_done.record(self.stream)
        self.read_done.synchronize()
        self.stream.wait_event(ready)
        assert allocation(self.output) != allocation(x)
        for name, tensor in (("input", x), ("output", self.output)):
            if not self.context.set_tensor_address(name, tensor.data_ptr()):
                raise Rejected("native binding rejected")
        if not self.context.set_input_consumed_event(self.read_done.cuda_event):
            raise Rejected("native input completion registration failed")
        if not self.context.execute_async_v3(self.stream.cuda_stream):
            # The caller retains the started borrow; no missing-event release.
            raise Rejected("native enqueue failed")
        self.output_done.record(self.stream)
        self.output.record_stream(self.stream)


def compose(child, example, component):
    root = child.root
    read = bool(dict(child.plan.obligations)[root])
    escape = bool(dict(child.plan.escapes)[root])
    c = Summary((0,) if read else (), (0,) if escape else (), completion="input_consumed",
                implementation=digest({"child_plan": child.plan.sha256, "adapter": source_sha()}))
    nodes = (Node("A", ("source",), Summary((0,), completion="input_consumed", implementation=component.identity)),
             Node("B", ("source",), Summary((), (0,), completion="synchronous", implementation="torch.view_as.same-metadata")),
             Node("C", ("B",), c))
    executable = digest({"native": component.identity, "child": child.executable,
                         "adapter": source_sha(), "nodes": [asdict(n) for n in nodes]})
    return compile_plan(("source",), nodes, ("A", "C"), {"source": spec(example)}, executable)


class ChildReadDone:
    def __init__(self, execution, allocation_id):
        self.execution, self.allocation = execution, allocation_id

    def query(self):
        return self.execution.lease.can_release(self.allocation)


class ChildOutputDone:
    def __init__(self, execution):
        self.execution = execution

    def query(self):
        return self.execution.lease.can_publish()


class ReferenceBorrowManager:
    """Complete hand-managed comparator, given the identical trusted summaries.

    It enrolls every future reader, waits read AND output events appropriately,
    and accounts for returned aliases. This is not an intentionally weak native
    event baseline. It is a local correctness comparator, not full V6 Retention.
    """
    def __init__(self, plan, bindings):
        self.plan, self.bindings = plan, dict(bindings)
        self.states = {n.name: "pending" for n in plan.nodes}
        self.nodes = {n.name: n for n in plan.nodes}
        self.read_events, self.output_events = {}, {}
        self.returned, self.aborted, self.published = set(), False, False
        self.fact_map = dict(plan.facts)

    def begin(self, name):
        if self.aborted or self.states.get(name) != "pending":
            raise Rejected("reference invalid submission")
        if any(self.states[i] != "submitted" for i in self.nodes[name].inputs if i in self.states):
            raise Rejected("reference dependency missing")
        self.states[name] = "started"

    def submitted(self, name, read_done, output_done=None):
        if self.states.get(name) != "started" or not callable(getattr(read_done, "query", None)):
            raise Rejected("reference missing read witness")
        if output_done is None and self.nodes[name].summary.completion == "input_consumed":
            raise Rejected("reference input event cannot stand in for output")
        output_done = output_done or read_done
        if not callable(getattr(output_done, "query", None)):
            raise Rejected("reference missing output witness")
        self.read_events[name], self.output_events[name] = read_done, output_done
        self.states[name] = "submitted"

    def can_release(self, allocation_id):
        roots = [r for r, b in self.bindings.items() if b.allocation == allocation_id]
        if not roots:
            raise Rejected("reference unknown physical allocation")
        for root in roots:
            for reader in dict(self.plan.obligations)[root]:
                if self.states[reader] == "cancelled":
                    continue
                if self.states[reader] != "submitted" or not self.read_events[reader].query():
                    return False
            if not self.aborted and any(o not in self.returned for o in dict(self.plan.escapes)[root]):
                return False
        return True

    def abort(self):
        if self.published:
            raise Rejected("reference output already published")
        self.aborted = True
        for name in self.states:
            if self.states[name] == "pending":
                self.states[name] = "cancelled"

    def can_publish(self):
        return (not self.aborted and not self.published and all(s == "submitted" for s in self.states.values())
                and all(e.query() for e in self.read_events.values()) and all(e.query() for e in self.output_events.values()))

    def return_output_borrow(self, name):
        if not self.can_publish() or name not in self.plan.outputs or name in self.returned:
            raise Rejected("reference premature alias acknowledgement")
        self.returned.add(name)

    def publish_identity(self):
        if not self.can_publish():
            raise Rejected("reference premature publication")
        self.published = True
        return {o: {r: self.bindings[r] for r in sorted(self.fact_map[o].provenance)} for o in self.plan.outputs}
