"""Non-timed complete A/B/C gate; no timing conclusions and no inference retry."""
import argparse
import fcntl
import gc
import json
from pathlib import Path
import traceback

import torch
from common import inventory, sha
from core import Rejected
from manual_static import ManualRejected
from study_common import ROOT, GPU, compute_pids, configure, inputs, cpu_values, tensor_hashes, exact
from run_grouped_admission import factory, METHODS


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    assert a.output.resolve().is_relative_to(ROOT)
    a.output.mkdir(parents=True, exist_ok=False)
    report = dict(status='RUNNING', performance_claim=False, cases=[])
    try:
        pids = compute_pids()
        assert not any(x['gpu'] == GPU for x in pids), 'GPU0 occupied; no inference'
        report.update(other_gpu_compute=pids, gpu_uuid=GPU, sources=inventory())
        configure()
        sources, source_hashes = inputs('transfusion')
        report['input_hashes'] = source_hashes
        with (ROOT/'borrowplan_gpu0.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            for late in (False, True):
                for sid, source in enumerate(sources):
                    folder = a.output/f'late-{int(late)}-s{sid}'
                    folder.mkdir()
                    x = source.cuda()
                    stream = torch.cuda.Stream()
                    reference = factory('transfusion', x, late, 'manual-full')
                    ready = torch.cuda.Event(); ready.record()
                    ex = reference.start(x, dict(epoch=112, sequence=1, generation=2), ready)
                    ex.submit(0, stream).synchronize()
                    protected = cpu_values(ex.publish()[0])
                    assert len(protected) == (11 if late else 10)
                    torch.save(protected, folder/'reference.pt')
                    del reference, ex
                    for method in METHODS:
                        x.copy_(source)
                        torch.cuda.synchronize()
                        program = factory('transfusion', x, late, method)
                        ready = torch.cuda.Event(); ready.record()
                        publication = dict(epoch=112, sequence=100+sid, generation=2*(100+sid))
                        ex = program.start(x, publication, ready)
                        ex.submit(0, stream).synchronize()
                        assert ex.can_release()
                        x.copy_(sources[(sid+1)%3])
                        torch.cuda.synchronize()
                        if method != 'manual-full':
                            ex.submit(1, stream).synchronize()
                        actual, identity = ex.publish()
                        assert identity == publication
                        actual = cpu_values(actual)
                        exact(actual, protected)
                        try:
                            ex.publish()
                        except (Rejected, ManualRejected):
                            pass
                        else:
                            raise AssertionError('duplicate output accepted')
                        output = folder/(method+'.pt')
                        torch.save(actual, output)
                        art = folder/(method+'-artifact.json')
                        art.write_text(json.dumps(program.artifact, indent=2)+'\n')
                        report['cases'].append(dict(late=late, source_id=sid, method=method,
                            output=str(output.relative_to(a.output)), output_sha256=sha(output),
                            reference=str((folder/'reference.pt').relative_to(a.output)),
                            reference_sha256=sha(folder/'reference.pt'),
                            artifact=str(art.relative_to(a.output)), artifact_sha256=sha(art),
                            output_hashes=tensor_hashes(actual), publication=identity,
                            exact=True, ordered_overwrite=True, duplicate_publication_rejected=True,
                            complete_native_and_model_outputs=True))
                        print('PASS',late,sid,method,flush=True)
                        del program, ex, actual
                    del x, protected
                    gc.collect(); torch.cuda.empty_cache()
            assert len(report['cases']) == 24
        report.update(status='COMPLETE', sources=inventory())
    except BaseException:
        report.update(status='FAILED', traceback=traceback.format_exc())
        traceback.print_exc()
    (a.output/'report.json').write_text(json.dumps(report, indent=2)+'\n')
    (a.output/report['status']).write_text(report['status']+'\n')
    return int(report['status'] != 'COMPLETE')


if __name__ == '__main__':
    raise SystemExit(main())
