"""Independent structural/receipt audit; no imports from the analyzer/runtime."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate(result, source, output):
    output.mkdir(parents=True, exist_ok=False)
    checks = 0
    def check(ok, message):
        nonlocal checks
        checks += 1
        if not ok:
            raise AssertionError(message)
    try:
        r = json.loads((result / "report.json").read_text())
        check((result / "COMPLETE").is_file() and not (result / "FAILED").exists(), "result markers")
        check(r["status"] == "COMPLETE_CORRECTNESS_SMOKE", "scope status")
        check(r["core_tests"] == 26, "core regressions")
        check(r["case_count"] == 12 == len(r["cases"]), "scenario count")
        cases = {c["name"]: c for c in r["cases"]}
        check(len(cases) == len(r["cases"]) and all(c["status"] == "PASS" for c in cases.values()), "all scenarios")
        check(not r["v6_modified"] and not r["same_semantics_performance_complete"], "no performance claim")
        for filename, expected in r["sources"].items():
            check(Path(filename).name == filename, "source path confinement")
            check(sha(source / filename) == expected, "source hash: " + filename)
        for filename in ("resnet-plan.json", "composition-plan.json"):
            plan = json.loads((result / filename).read_text())
            nodes = {n["name"]: n for n in plan["nodes"]}
            check(len(nodes) == len(plan["nodes"]), "unique graph nodes")
            declared = dict(plan["obligations"])
            roots = set(declared)
            memo = {}
            def borrowed_roots(value, active=frozenset()):
                if value in roots:
                    return {value}
                if value in active:
                    raise AssertionError("cycle in graph")
                if value not in memo:
                    n = nodes[value]
                    memo[value] = set().union(*(borrowed_roots(n["inputs"][i], active | {value})
                                              for i in n["summary"]["aliases"]))
                return memo[value]
            actual = {root: set() for root in roots}
            seen = set(roots)
            for n in plan["nodes"]:
                check(all(v in seen for v in n["inputs"]), "topological graph")
                s = n["summary"]
                check(s["completion"] in ("operation_complete", "input_consumed", "synchronous"),
                      "trusted completion kind")
                check(bool(s["implementation"]), "named implementation")
                for i in s["reads"]:
                    for root in borrowed_roots(n["inputs"][i]):
                        actual[root].add(n["name"])
                for i in s["writes"]:
                    check(not borrowed_roots(n["inputs"][i]), "borrowed mutation prohibited")
                seen.add(n["name"])
            for root in roots:
                check(actual[root] == set(declared[root]), "independent backwards-reader coverage")
            if filename == "resnet-plan.json":
                check(len(actual["x"]) == 2, "conv + residual add")
                check(actual["x"] == set(cases["resnet_tail_auto_boundary"]["reader_nodes"]), "receipt matches graph")
            else:
                check(any(n.startswith("C::") for n in actual["x"]), "delayed downstream enrolled")
                check(cases["cross_component_delayed_view_reader"]["future_reader_blocked"], "future reader held")
        check(cases["late_branch_regenerates_usable_plan"]["plan_changed"], "usable regenerated plan")
        check(len(cases["late_branch_regenerates_usable_plan"]["reader_nodes"]) == 3, "late branch obligation")
        for name, c in cases.items():
            if name.endswith("prelaunch"):
                check(c["before_submission"] and bool(c["rejection"]), "prelaunch rejection receipt")
        if r["device"] == "cpu":
            check(not r["cuda_initialized"], "CPU smoke never initialized CUDA")
        else:
            check(r["gpu_uuid"] == "GPU-f3b314a8-3058-e0be-694c-76f4227afb7d", "authorized GPU")
            check(r["inputs"]["checkpoint_sha256"] ==
                  "f37072fd47e89c5e827621c5baffa7500819f7896bbacec160b1a16c560e07ec", "pretrained checkpoint")
            check(cases["cross_component_delayed_view_reader"]["actual_cuda_streams"] == 2, "real cross-stream execution")
        receipt = {"status": "COMPLETE_STRUCTURAL_RECEIPT_VALIDATION", "checks": checks,
                   "limitations": "independent graph/receipt/hash audit, not independent re-execution or a universal safety proof",
                   "report_sha256": sha(result / "report.json"), "validator_sha256": sha(Path(__file__)),
                   "files": {p.name: sha(p) for p in result.iterdir() if p.is_file()}}
        (output / "validation.json").write_text(json.dumps(receipt, indent=2, sort_keys=True))
        (output / "COMPLETE").write_text("structural and receipt audit\n")
        print(json.dumps(receipt), flush=True)
    except BaseException as exc:
        (output / "FAILED.json").write_text(json.dumps({"checks": checks, "error": str(exc)}))
        raise


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--result", type=Path, required=True)
    p.add_argument("--source", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    validate(a.result, a.source, a.output)
