"""Deduplicate monotone, single-record completion witnesses of an owned stage.

No event may be re-recorded after registration. Backend-created CUDA events
are private to the invocation. External mutation/re-recording is unsupported.
The complete logical reader set and original release state machine remain.
"""
from prepared_lease import PreparedLease


class WitnessLease(PreparedLease):
    def __init__(self, certificate, bindings, executable, expected_versions):
        super().__init__(certificate, bindings, executable, expected_versions)
        self._output_completion_observed = False

    def can_publish(self):
        with self.lock:
            if self.aborted or self.published:
                return False
            if self._output_completion_observed:
                return True
            if any(state != 'submitted' for state in self.states.values()):
                return False
            seen = set()
            for witnesses in (self.events, self.output_events):
                for event in witnesses.values():
                    identity = id(event)
                    if identity not in seen:
                        seen.add(identity)
                        if not event.query():
                            return False
            self._output_completion_observed = True
            return True
