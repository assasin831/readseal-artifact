"""The generated A/B/C plan on the same native adapter and owned child as V8."""
from core import Lease
from native_loader import FrozenNative
from native_composition import compose, ChildReadDone, ChildOutputDone
from torch_backend import bind, Ready, allocation
from study_common import make_program
from common import ROOT, Join, now


class AutoComposition:
    def __init__(self, example, late):
        self.child = make_program('transfusion', example, late, 'auto-early')
        self.native = FrozenNative(ROOT / 'results/borrowplan_v2_native_composition_attempt1')
        self.plan = compose(self.child, example, self.native)
        self.artifact = dict(schema='readseal-generated-abc-v8', child=self.child.artifact,
            native=self.native.receipt, plan_sha256=self.plan.sha256,
            obligations=dict(self.plan.obligations), escapes=dict(self.plan.escapes),
            executable=self.plan.executable)

    def start(self, x, publication, ready):
        return AutoInvocation(self, x, dict(publication), ready)


class AutoInvocation:
    def __init__(self, program, x, publication, ready):
        self.program, self.x, self.publication, self.ready = program, x, publication, ready
        b = bind(x, **publication)
        self.lease = Lease(program.plan, {'source': b}, program.plan.executable, {'source': b.version})
        self.events, self.stage = [], 0
        self.trace = dict(enrolled_ns=now())

    def submit(self, stage, stream):
        assert stage == self.stage and stage in (0, 1)
        if stage == 0:
            self.lease.begin('A')
            self.native = self.program.native.launch(self.x, self.ready)
            self.lease.submitted('A', self.native.read_done, self.native.output_done)
            self.trace['a_submitted_ns'] = now()
            self.lease.begin('B')
            view = self.x.view_as(self.x)
            self.lease.submitted('B', Ready())
            assert self.lease.states['C'] == 'pending'
            self.lease.begin('C')
            self.child = self.program.child.start(view, self.publication, self.ready)
            self.lease.submitted('C', ChildReadDone(self.child, allocation(view)), ChildOutputDone(self.child))
            self.child.submit(0, stream)
            self.trace['c_prefix_submitted_ns'] = now()
            self.events.append(Join([self.native.read_done, self.child.events[0]]))
            self.x = None
        else:
            self.child.submit(1, stream)
            self.events.append(Join([self.native.output_done, self.child.events[-1]]))
        self.stage += 1
        return self.events[-1]

    def can_release(self):
        return self.lease.can_release(self.lease.bindings['source'].allocation)

    def publish(self):
        values = self.child.outputs()
        identities = self.lease.publish_identity()
        versions = {b.version for item in identities.values() for b in item.values()}
        assert versions == {(self.publication['epoch'], self.publication['sequence'], self.publication['generation'])}
        return (self.native.output,) + tuple(values), dict(self.publication)
