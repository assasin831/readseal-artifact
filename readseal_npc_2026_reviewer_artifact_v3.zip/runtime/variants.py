"""Declared dependency edits to pinned exported graphs; no boundary inference."""
import copy
import hashlib
import json
from types import SimpleNamespace

import torch
from manual_static import graph_records, EXPORTS, BASE_BOUNDARY, sha

SUPPORTED = ('base', 'alias_chain', 'early_read', 'middle_read', 'late_read',
             'late_alias_read', 'remove_late_read', 'private_probe')
UNSUPPORTED = ('borrowed_output', 'source_mutation', 'opaque_callback')


def opaque_callback(x):
    return x.clone()


def structural_hash(graph):
    return hashlib.sha256(json.dumps(graph_records(graph), sort_keys=True,
                         separators=(',', ':')).encode()).hexdigest()


def edited_export(path, model, edit):
    assert sha(path) == EXPORTS[model]
    assert edit in SUPPORTED + UNSUPPORTED
    original = torch.export.load(path)
    graph = copy.deepcopy(original.graph)
    sig = copy.deepcopy(original.graph_signature)
    root = next(n for n in graph.nodes if n.name == sig.user_inputs[0])
    calls = [n for n in graph.nodes if n.op == 'call_function']
    output = next(n for n in graph.nodes if n.op == 'output')
    values = list(output.args[0])
    if edit == 'alias_chain':
        old_users = list(root.users)
        with graph.inserting_before(calls[0]):
            a = graph.create_node('call_function', torch.ops.aten.alias.default, (root,), {}, name='evo_alias_0')
            b = graph.create_node('call_function', torch.ops.aten.alias.default, (a,), {}, name='evo_alias_1')
        for user in old_users:
            user.replace_input_with(root, b)
    elif edit in ('early_read', 'middle_read', 'late_read', 'late_alias_read', 'private_probe'):
        if edit == 'early_read':
            index = next(i for i, n in enumerate(calls) if n.name == BASE_BOUNDARY[model])
            before = calls[index + 1]
        elif edit == 'middle_read':
            before = calls[len(calls) // 2]
        else:
            before = output
        with graph.inserting_before(before):
            source = values[0] if edit == 'private_probe' else root
            if edit == 'late_alias_read':
                source = graph.create_node('call_function', torch.ops.aten.alias.default, (source,), {}, name='evo_alias_0')
                source = graph.create_node('call_function', torch.ops.aten.alias.default, (source,), {}, name='evo_alias_1')
            read = graph.create_node('call_function', torch.ops.aten.clone.default, (source,), {}, name='evo_read')
            stat = graph.create_node('call_function', torch.ops.aten.mean.default, (read,), {}, name='evo_stat')
        values.append(stat)
    elif edit == 'borrowed_output':
        values.append(root)
    elif edit == 'source_mutation':
        with graph.inserting_before(output):
            changed = graph.create_node('call_function', torch.ops.aten.add_.Tensor, (root, root), {}, name='evo_mutation')
        values.append(changed)
    elif edit == 'opaque_callback':
        with graph.inserting_before(output):
            changed = graph.create_node('call_function', opaque_callback, (root,), {}, name='evo_opaque')
        values.append(changed)
    output.args = (tuple(values),)
    sig.user_outputs = [n.name for n in values]
    graph.lint()
    snapshot = SimpleNamespace(graph=graph, graph_signature=sig, state_dict=original.state_dict)
    return snapshot


def reviewed_boundary(model, edit):
    """Explicit independent review choices, never read an automatic artifact."""
    assert edit in SUPPORTED
    return 'evo_read' if edit in ('early_read', 'middle_read', 'late_read', 'late_alias_read') else BASE_BOUNDARY[model]


def reviewed_readers(model, edit):
    assert edit in SUPPORTED
    base = ['convolution'] if model == 'transfusion' else ['convolution', 'add']
    if edit in ('alias_chain', 'late_alias_read'):
        base += ['evo_alias_0', 'evo_alias_1']
    if edit in ('early_read', 'middle_read', 'late_read', 'late_alias_read'):
        base += ['evo_read']
    return sorted(base)


def review_record(path, model, edit):
    snapshot = edited_export(path, model, edit)
    return dict(model=model, edit=edit, export_sha256=EXPORTS[model],
                graph_sha256=structural_hash(snapshot.graph), boundary=reviewed_boundary(model, edit),
                readers=reviewed_readers(model, edit), review_kind='explicit frozen schema/name review')
