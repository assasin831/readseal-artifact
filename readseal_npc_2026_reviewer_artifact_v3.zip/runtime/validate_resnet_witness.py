"""Independent exported-schema, generated-code, event and raw-output audit."""
import argparse
import hashlib
import json
from pathlib import Path
import traceback

import torch
from validate_segmented_multiprocess import stage_template, digest
from validate_witness import reference_readers
import validate_segmented_multiprocess
import validate_witness


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def tensor_sha(t):
    return hashlib.sha256(t.contiguous().numpy().tobytes()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--run', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    result = dict(status='RUNNING', validator_sha256=sha(__file__), checks=0,
                  helpers={str(Path(m.__file__).resolve()): sha(m.__file__) for m in (validate_segmented_multiprocess, validate_witness)})
    def check(condition, label):
        result['checks'] += 1
        assert condition, label
    try:
        torch.set_num_threads(1)
        report = json.loads((a.run / 'report.json').read_text())
        check(report['status'] == 'COMPLETE' and (a.run / 'COMPLETE').exists() and not (a.run / 'FAILED').exists(), 'complete run')
        check(report['schema'] == 'borrowplan-resnet-witness-conformance-v6' and not report['performance_claim'], 'scope')
        check(not report['preflight'] and all(p['pid'] == report['pid'] and p['gpu'] == report['gpu_uuid'] for p in report['postflight']), 'isolation')
        for path, expected in report['source_sha256'].items():
            check(sha(path) == expected, 'frozen source')
        base = Path(report['export_run'])
        probe = json.loads((base / 'report.json').read_text())
        check(sha(base / 'report.json') == report['export_report_sha256'], 'CPU export lineage')
        for name, expected in probe['files'].items():
            check(sha(base / name) == expected, 'export artifact')
        for path, expected in probe['inputs'].items():
            check(sha(path) == expected, 'real input/checkpoint lineage')
        check(len(probe['cases']) == 3 and all(c['exact'] for c in probe['cases']), 'CPU eager-export agreement')
        exported = torch.export.load(base / 'resnet_tail.pt2')
        templates = {late: stage_template(exported, late) for late in (False, True)}
        members = {(sid, late, schedule) for sid in range(3) for late in (False, True) for schedule in ('synchronous', 'eager-private')}
        seen, tensors = set(), 0
        for row in report['cases']:
            key = row['source'], row['late'], row['schedule']
            check(key in members and key not in seen, 'exact membership')
            seen.add(key)
            sid, late, schedule = key
            folder = a.run / row['key']
            check(sha(base / f'case_{sid}.pt') == row['source_sha256'], 'source file')
            original = torch.load(base / f'case_{sid}.pt', map_location='cpu')['input']
            check(tensor_sha(original) == row['before_bytes_sha256'], 'actual old input bytes')
            check(tensor_sha(torch.full_like(original, 123)) == row['after_bytes_sha256'] != row['before_bytes_sha256'], 'actual changed input bytes')
            check(row['reused_same_allocation'] and row['old_publication_preserved'] and row['exact'], 'reuse and publication assertions')
            check(sha(folder / 'artifact.json') == row['artifact_sha256'], 'owned artifact hash')
            artifact = json.loads((folder / 'artifact.json').read_text())
            check(artifact['schema'] == 'borrowplan-owned-witness-artifact-v6' and digest(artifact) == row['executable'], 'owned execution identity')
            check(artifact['prepared_plan_sha256'] == artifact['child_plan_sha256'], 'construction certificate')
            for file, field in (('owned_backend.py','backend_sha256'),('owned_prepared.py','prepared_backend_sha256'),
                                ('prepared_lease.py','prepared_runtime_sha256'),('owned_witness.py','witness_backend_sha256'),
                                ('witness_lease.py','witness_runtime_sha256')):
                check(artifact[field] == next(h for p,h in report['source_sha256'].items() if p.endswith('/'+file)), 'executor source identity')
            readers = reference_readers(exported, late)
            check(set(row['complete_reader_set']) == readers and len(readers) == (3 if late else 2), 'all independently derived future readers')
            t = templates[late]
            check(artifact['groups'] == t['groups'] and artifact['live'] == t['live'], 'independent stage boundary')
            check(len(artifact['modules']) == 2 and len(row['receipts']) == 2, 'two stages')
            for i, (module, expected, event) in enumerate(zip(artifact['modules'], t['modules'], row['receipts'])):
                check(module['nodes'] == expected['nodes'] and module['code'] == expected['code'], 'actual generated code')
                check(event['stage'] == i and event['operations'] == t['groups'][i] and event['module_sha256'] == module['sha256'], 'complete operation witness')
                check(event['started_ns'] <= event['submitted_ns'] <= event['wait_completed_ns'], 'completion order')
                check(event['event_handle'] > 0 and event['dynamic_boundary_alias'] is False, 'real completion and private boundary')
            first, second = row['receipts']
            check(first['event_handle'] != second['event_handle'] and first['stream_handle'] == second['stream_handle'], 'fresh per-stage single-stream events')
            check(first['wait_completed_ns'] < row['reuse_done_ns'], 'reuse only after read completion')
            if schedule == 'synchronous':
                check(row['reuse_done_ns'] < second['started_ns'] and row['output_incomplete_at_release'], 'physical overwrite before suffix')
            else:
                check(first['submitted_ns'] <= second['started_ns'] <= second['submitted_ns'] <= first['wait_completed_ns'], 'eager-private submission order')
                check(type(row['output_incomplete_at_release']) is bool, 'overlap observed, not assumed')
            check(sha(folder / 'outputs.pt') == row['output_sha256'], 'saved outputs')
            outputs = torch.load(folder / 'outputs.pt', map_location='cpu')
            check(len(outputs['actual']) == len(outputs['expected']) == (2 if late else 1), 'all outputs')
            for actual, expected in zip(outputs['actual'], outputs['expected']):
                check(torch.equal(actual,expected) and torch.isfinite(actual).all().item(), 'bit-exact finite protected output')
                tensors += 1
        check(seen == members and tensors == 18, 'twelve cases and all eighteen tensors')
        check(len(report['negatives']) == len(set(report['negatives'])) == 108, 'all prelaunch/transition rejection controls')
        result.update(status='COMPLETE', cases=12, tensors=tensors, rejection_controls=108,
                      report_sha256=sha(a.run/'report.json'), performance_claim=False)
        (a.output/'COMPLETE').write_text('Independent second-model saved-evidence audit complete.\n')
    except BaseException as exc:
        result.update(status='FAILED', error=str(exc))
        (a.output/'FAILED').write_text(type(exc).__name__+'\n')
        (a.output/'traceback.txt').write_text(traceback.format_exc())
    (a.output/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
    return 0 if result['status']=='COMPLETE' else 1


if __name__=='__main__':
    raise SystemExit(main())
