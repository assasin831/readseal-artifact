"""Fresh exact-output/reuse gate or an explicitly exploratory paired cost pilot."""
import argparse
import copy
import json
import os
from pathlib import Path
import random
import time
import traceback

import torch
import core
import export_backend
import owned_backend
import owned_prepared
import prepared_lease
import owned_witness
import witness_lease
import segmented_backend
import torch_backend
from core import Lease, Node, Rejected, Summary, compile_plan, digest
from export_backend import Program
from measure_execution_cost import active_compute, exact, sha, GPU
from native_composition import ChildReadDone, ChildOutputDone, ReferenceBorrowManager
from owned_witness import WitnessProgram as OwnedProgram
from torch_backend import allocation, bind, spec


def main():
    p = argparse.ArgumentParser()
    for key in ('export', 'cases', 'output'):
        p.add_argument('--' + key, type=Path, required=True)
    p.add_argument('--mode', choices=('correctness', 'overlap', 'pilot'), required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    report = dict(status='RUNNING', mode=a.mode, performance_claim=False, cases=[], pid=os.getpid(),
        scope='Owned functional head only; pilot is exploratory, not formal pipeline performance',
        source_sha256={str(Path(m.__file__).resolve()): sha(m.__file__) for m in
                       (core, export_backend, owned_backend, owned_prepared, prepared_lease, owned_witness, witness_lease, segmented_backend, torch_backend)},
        runner_sha256=sha(__file__), export_sha256=sha(a.export), gpu_uuid=GPU, negatives=[])
    try:
        assert os.environ['CUDA_VISIBLE_DEVICES'] == GPU
        report['preflight'] = active_compute()
        assert not report['preflight'], 'GPUs not idle; no launch'
        assert report['export_sha256'] == '8efaa67aa6884d0c9aec6fff442e9a50b683a290d856abef390db1f034ccabbd'
        torch.set_num_threads(1)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        exported = torch.export.load(a.export)
        oracle = json.loads((a.cases / 'report.json').read_text())
        rng = random.Random(76011)
        report['plan_sha256'] = sha(Path(__file__).with_name('PILOT_PLAN.md'))
        report['recipe'] = dict(warmups=10, randomized_quartets=30, seed=76011) if a.mode == 'pilot' else {}

        def rejects(label, fn):
            try:
                fn()
            except Rejected:
                report['negatives'].append(label)
            else:
                raise AssertionError(label + ' was accepted')

        for sid in range(3):
            path = a.cases / f'case_{sid}.pt'
            assert sha(path) == oracle['files'][path.name]
            original = torch.load(path, map_location='cpu')['input'].cuda()
            for late in (False, True):
                x = original.clone()
                reference = Program(exported, x, late_read=late)
                graph = torch.fx.GraphModule(torch.nn.Module(), copy.deepcopy(reference.graph))
                args = tuple(x if n.name == reference.root else reference.state[n.name]
                             for n in reference.graph.nodes if n.op == 'placeholder')
                with torch.inference_mode():
                    expected = tuple(t.detach().clone() for t in graph(*args))
                torch.cuda.synchronize()
                start = time.perf_counter_ns()
                program = OwnedProgram(exported, x, late_read=late)
                torch.cuda.synchronize()
                construction_ns = time.perf_counter_ns() - start
                outer_plan = compile_plan(('source',),
                    (Node('C', ('source',), Summary((0,), completion='input_consumed', implementation=program.executable)),),
                    ('C',), {'source': spec(x)}, digest({'owned': program.executable, 'scope': 'single-head-cost'}))
                stream = torch.cuda.Stream()
                name = f'source-{sid}-{"late" if late else "base"}'
                folder = a.output / name
                folder.mkdir()
                (folder / 'artifact.json').write_text(json.dumps(program.artifact, indent=2) + '\n')
                row = dict(source=sid, late=late, source_sha256=sha(path), executable=program.executable,
                    construction_ns=construction_ns, artifact_sha256=sha(folder / 'artifact.json'),
                    complete_reader_set=list(dict(program.plan.obligations)[program.root]))
                if a.mode in ('correctness', 'overlap'):
                    rejects(name + '-shape', lambda: program.start(x.flatten()))
                    rejects(name + '-invalid-generation', lambda: program.start(x, {'generation': 3}))
                    rejects(name + '-invalid-sequence', lambda: program.start(x, {'sequence': 0}))
                    aborted = program.start(x)
                    aborted.ready.synchronize()
                    aborted.lease.abort()
                    rejects(name + '-aborted-submit', lambda: aborted.submit(0, stream))
                    binding = dict(epoch=2**40 + sid, sequence=2 + sid, generation=4)
                    execution = program.start(x, binding)
                    source_allocation = allocation(x)
                    assert not execution.lease.can_release(source_allocation)
                    rejects(name + '-suffix-first', lambda: execution.submit(1, stream))
                    rejects(name + '-premature-output', execution.outputs)
                    rejects(name + '-premature-publication', execution.lease.publish_identity)
                    execution.submit(0, stream)
                    rejects(name + '-repeated-prefix', lambda: execution.submit(0, stream))
                    other = torch.cuda.Stream()
                    rejects(name + '-foreign-stream', lambda: execution.submit(1, other))
                    if a.mode == 'overlap':
                        execution.submit(1, stream)
                    execution.wait_stage(0)
                    assert execution.lease.can_release(source_allocation)
                    output_incomplete_at_release = not execution.lease.can_publish()
                    if a.mode == 'correctness':
                        assert output_incomplete_at_release
                    with torch.inference_mode():
                        x.fill_(123.0)
                    torch.cuda.synchronize()
                    reuse_done = time.monotonic_ns()
                    assert allocation(x) == source_allocation and not torch.equal(x, original)
                    if a.mode == 'correctness':
                        execution.submit(1, stream)
                    execution.wait()
                    actual = execution.outputs()
                    exact(actual, expected)
                    published = execution.lease.publish_identity()
                    assert all(b.version == (binding['epoch'], binding['sequence'], binding['generation'])
                               for out in published.values() for b in out.values())
                    row.update(receipts=execution.receipts, reuse_done_ns=reuse_done, source_allocation=source_allocation,
                               before_prefix_releasable=False, after_prefix_releasable=True,
                               old_publication_preserved=True, exact=True, publication=binding,
                               output_incomplete_at_release=output_incomplete_at_release)
                else:
                    methods = ('direct', 'witness-sync', 'witness-overlap', 'manual-overlap')

                    def execute(method):
                        with torch.cuda.stream(stream), torch.inference_mode():
                            if method == 'direct':
                                return tuple(graph(*args))
                            b = bind(x)
                            outer = (Lease(outer_plan, {'source': b}, outer_plan.executable, {'source': b.version})
                                     if method != 'manual-overlap' else ReferenceBorrowManager(outer_plan, {'source': b}))
                            outer.begin('C')
                            ex = program.start(x)
                            outer.submitted('C', ChildReadDone(ex, b.allocation), ChildOutputDone(ex))
                            ex.submit(0, stream)
                            if method != 'witness-sync':
                                ex.submit(1, stream)
                            ex.wait_stage(0)
                            assert outer.can_release(b.allocation)
                            if method == 'witness-sync':
                                assert not outer.can_publish()
                                ex.submit(1, stream)
                            ex.wait()
                            output = ex.outputs()
                            assert outer.publish_identity()['C']['source'] == b
                            return output

                    for _ in range(10):
                        for method in methods:
                            actual = execute(method)
                            torch.cuda.synchronize()
                            exact(actual, expected)
                    row['records'] = []
                    row['host_audits'] = []
                    for trial in range(30):
                        processes = active_compute()
                        assert all(p['pid'] == os.getpid() and p['gpu'] == GPU for p in processes)
                        row['host_audits'].append(processes)
                        order = list(methods)
                        rng.shuffle(order)
                        for position, method in enumerate(order):
                            torch.cuda.synchronize()
                            start = time.perf_counter_ns()
                            actual = execute(method)
                            torch.cuda.synchronize()
                            duration = time.perf_counter_ns() - start
                            exact(actual, expected)
                            row['records'].append(dict(trial=trial, position=position, method=method,
                                                       wall_ns=duration, exact=True))
                torch.save(dict(actual=tuple(t.detach().cpu() for t in actual),
                                expected=tuple(t.detach().cpu() for t in expected)), folder / 'outputs.pt')
                row['output_sha256'] = sha(folder / 'outputs.pt')
                report['cases'].append(row)
                print('COMPLETE ' + name, flush=True)
        report['postflight'] = active_compute()
        assert all(p['pid'] == os.getpid() and p['gpu'] == GPU for p in report['postflight'])
        report['status'] = 'COMPLETE'
        (a.output / 'COMPLETE').write_text('All six owned-executable cases complete in stated mode.\n')
    except BaseException as exc:
        report.update(status='FAILED', error=str(exc))
        (a.output / 'FAILED').write_text(type(exc).__name__ + '\n')
        (a.output / 'traceback.txt').write_text(traceback.format_exc())
        traceback.print_exc()
    (a.output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(status=report['status'], cases=len(report['cases']), negatives=len(report['negatives']))))
    return 0 if report['status'] == 'COMPLETE' else 1


if __name__ == '__main__':
    raise SystemExit(main())
