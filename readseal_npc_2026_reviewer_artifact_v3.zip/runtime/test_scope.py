"""One additional functional schema, not a model-specific reader rule."""
import argparse
import ast
import hashlib
import json
from pathlib import Path

import torch
import export_backend
from core import Rejected
from owned_witness import WitnessProgram


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--original-backend', type=Path, required=True)
    p.add_argument('--export-run', type=Path, required=True)
    a = p.parse_args()
    torch.set_num_threads(1)
    old = ast.parse(a.original_backend.read_text())
    new = ast.parse(Path(export_backend.__file__).read_text())
    def allowed(tree):
        return next(n for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'ALLOWED' for t in n.targets))
    x, y = allowed(old), allowed(new)
    original = set(x.value.args[0].func.value.value.split())
    revised = set(y.value.args[0].func.value.value.split())
    assert revised == original | {'mean.dim'} and 'mean.dim' not in original
    new.body[new.body.index(y)] = x
    assert ast.dump(old, include_attributes=False) == ast.dump(new, include_attributes=False)
    op = torch.ops.aten.mean.dim
    assert str(op._schema) == 'aten::mean.dim(Tensor self, int[1]? dim, bool keepdim=False, *, ScalarType? dtype=None) -> Tensor'
    assert not any(a.alias_info and a.alias_info.is_write for a in op._schema.arguments)
    assert not any(r.alias_info for r in op._schema.returns)
    checks = 4
    for shape in ((1, 64, 7, 7), (2, 3, 4, 5)):
        x = torch.arange(torch.tensor(shape).prod().item(), dtype=torch.float32).reshape(shape)
        before = x.clone()
        for dims in ((2, 3), (1,), (-1,)):
            for keep in (False, True):
                actual = op(x, dims, keep)
                assert torch.equal(actual, x.mean(dim=dims, keepdim=keep))
                assert actual.untyped_storage().data_ptr() != x.untyped_storage().data_ptr()
                assert torch.equal(x, before)
                checks += 3
    export = torch.export.load(a.export_run / 'resnet_tail.pt2')
    x = torch.load(a.export_run / 'case_0.pt', map_location='cpu')['input']
    programs = [WitnessProgram(export, x, late_read=late) for late in (False, True)]
    reader_sets = []
    for program in programs:
        readers = set(dict(program.plan.obligations)[program.root])
        assert readers <= set(program.artifact['groups'][0])
        assert not readers.intersection(program.artifact['groups'][1])
        assert not any(dict(program.plan.facts)[name].borrows for name in program.artifact['live'])
        reader_sets.append(readers)
        checks += 3
    assert len(reader_sets[0]) == 2 and len(reader_sets[1]) == 3
    assert reader_sets[0] < reader_sets[1]
    for target in (torch.ops.aten.sin.default, torch.ops.aten.add_.Tensor, torch.ops.aten.mean.out):
        graph = torch.fx.Graph()
        n = graph.call_function(target, (graph.placeholder('x'),))
        try:
            export_backend.summary(n)
        except Rejected:
            checks += 1
        else:
            raise AssertionError('unsupported or mutating variant admitted')
    print(json.dumps(dict(status='COMPLETE', checks=checks + 2, cpu_only=True,
                         added_operator='aten.mean.dim', reader_sets=[sorted(s) for s in reader_sets],
                         backend_sha256=hashlib.sha256(Path(export_backend.__file__).read_bytes()).hexdigest())))


if __name__ == '__main__':
    main()
