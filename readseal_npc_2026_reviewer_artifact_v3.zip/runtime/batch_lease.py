"""Batch fixed logical transitions without dropping readers or completion checks."""
from dataclasses import dataclass
from core import Rejected
from witness_lease import WitnessLease

_SEAL=object()


@dataclass(frozen=True)
class Grouping:
    plan: object
    groups: tuple
    external: tuple
    seal: object


def prepare_groups(plan,groups):
    groups=tuple(tuple(g) for g in groups)
    names={n.name:n for n in plan.nodes}
    flat=tuple(n for g in groups for n in g)
    if not groups or len(flat)!=len(set(flat)) or set(flat)!=set(names):
        raise Rejected('grouping must cover every logical node exactly once')
    seen=set(); external=[]
    for g in groups:
        prior=set(seen); deps=set()
        for name in g:
            n=names[name]
            if n.summary.completion!='operation_complete':
                raise Rejected('batching requires owned operation-complete witnesses')
            node_deps=set(n.inputs)&set(names)
            if not node_deps<=seen:
                raise Rejected('grouping violates dependency order')
            deps |= node_deps & prior
            seen.add(name)
        external.append(tuple(sorted(deps)))
    return Grouping(plan,groups,tuple(external),_SEAL)


class BatchLease(WitnessLease):
    def __init__(self,certificate,bindings,executable,expected_versions,grouping):
        super().__init__(certificate,bindings,executable,expected_versions)
        if type(grouping) is not Grouping or grouping.seal is not _SEAL or grouping.plan is not self.plan:
            raise Rejected('grouping not bound to the admitted immutable plan')
        self.grouping=grouping
        self.next_group=0
        self.active_group=None

    def begin_group(self,index):
        with self.lock:
            if (type(index) is not int or self.aborted or self.published or self.active_group is not None
                    or index!=self.next_group or not 0<=index<len(self.grouping.groups)):
                raise Rejected('invalid group submission')
            group=self.grouping.groups[index]
            if any(self.states[n]!='pending' for n in group):
                raise Rejected('logical node was already begun or cancelled')
            if any(self.states[n]!='submitted' for n in self.grouping.external[index]):
                raise Rejected('external dependency not submitted')
            self.states.update(dict.fromkeys(group,'started'))
            self.active_group=index

    def submitted_group(self,index,event):
        with self.lock:
            if (type(index) is not int or index!=self.active_group
                    or not callable(getattr(event,'query',None))):
                raise Rejected('invalid group completion witness')
            group=self.grouping.groups[index]
            if any(self.states[n]!='started' for n in group):
                raise Rejected('logical node not begun')
            self.events.update(dict.fromkeys(group,event))
            self.output_events.update(dict.fromkeys(group,event))
            self.states.update(dict.fromkeys(group,'submitted'))
            self.active_group=None
            self.next_group+=1
