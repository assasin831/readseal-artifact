import queue
import unittest

from coordination import FullOperation, Inbox, await_control, matrix


class CoordinationTests(unittest.TestCase):
    def test_exact_matrix(self):
        cells = matrix()
        self.assertEqual(len(cells), 162)
        self.assertEqual(len({c["id"] for c in cells}), 162)
        self.assertEqual(sum(c["consumers"] for c in cells), 378)
        for n in (1, 2, 4):
            for r in (1, 2, 4):
                self.assertEqual(sum(c["consumers"] == n and c["ring"] == r for c in cells), 18)

    def test_smoke_is_explicit_subset(self):
        smoke = matrix(True)
        self.assertEqual(len(smoke), 6)
        self.assertTrue(all(c in matrix() for c in smoke))

    def test_conservative_release_needs_both_boundaries(self):
        class Proof:
            bindings = {"source": "bound"}
            reads = outputs = False
            def can_release(self, allocation):
                return allocation == "slot" and self.reads
            def can_publish(self):
                return self.outputs
        proof = Proof()
        wrapper = FullOperation(proof)
        for reads in (False, True):
            for outputs in (False, True):
                proof.reads, proof.outputs = reads, outputs
                self.assertEqual(wrapper.can_release("slot"), reads and outputs)
                self.assertFalse(wrapper.can_release("other"))
        self.assertIs(wrapper.bindings, proof.bindings)

    def test_inbox_preserves_out_of_order_events(self):
        q = queue.Queue()
        q.put(dict(kind="done", consumer=1, cell="a"))
        q.put(dict(kind="closed", consumer=0, cell="a"))
        inbox = Inbox(q)
        self.assertEqual(inbox.take("closed", 0, "a")["consumer"], 0)
        self.assertEqual(inbox.take("done", 1, "a")["consumer"], 1)
        self.assertFalse(inbox.pending)

    def test_worker_error_never_waits_for_success(self):
        q = queue.Queue()
        q.put(dict(kind="error", consumer=1, traceback="worker failed"))
        with self.assertRaisesRegex(RuntimeError, "worker failed"):
            Inbox(q).take("done", 0)

    def test_control_rejects_wrong_cell_or_phase(self):
        for row in (dict(cell="wrong", phase="child"), dict(cell="right", phase="private")):
            q = queue.Queue()
            q.put(row)
            with self.assertRaisesRegex(RuntimeError, "unexpected control"):
                await_control(q, "right", "child")


if __name__ == "__main__":
    unittest.main()
