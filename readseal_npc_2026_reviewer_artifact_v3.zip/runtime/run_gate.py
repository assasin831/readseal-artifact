"""Both native A and checked C outputs after actual source overwrite."""
import argparse
import json
from pathlib import Path
import traceback
import torch
from study_common import configure, compute_pids, inputs, cpu_values, exact
from run_abc import factory
from common import inventory, save, sha, now


def main():
    p = argparse.ArgumentParser(); p.add_argument('--output', type=Path, required=True)
    a = p.parse_args(); a.output.mkdir(parents=True, exist_ok=False)
    result = dict(status='RUNNING', cases=[])
    try:
        assert not compute_pids(); configure()
        xs, hashes = inputs('transfusion')
        sources = [x.cuda() for x in xs]
        stream = torch.cuda.Stream()
        for late in (False, True):
            programs = {m: factory('transfusion', sources[0], late, m) for m in ('auto-early', 'manual-early', 'manual-full')}
            for sid, source in enumerate(sources):
                pub = dict(epoch=987654, sequence=sid+1, generation=2*(sid+1))
                ready = torch.cuda.Event(); ready.record()
                reference = programs['manual-full'].start(source, pub, ready)
                reference.submit(0, stream).synchronize()
                expected, _ = reference.publish()
                expected = cpu_values(expected)
                for method, program in programs.items():
                    x = source.clone(); torch.cuda.synchronize()
                    ready = torch.cuda.Event(); ready.record()
                    ex = program.start(x, pub, ready)
                    admitted = now()
                    ex.submit(0, stream).synchronize()
                    returned = now()
                    assert ex.can_release()
                    with torch.inference_mode():
                        x.copy_(sources[(sid+1) % 3])
                    torch.cuda.synchronize()
                    overwritten = now()
                    if method != 'manual-full':
                        ex.submit(1, stream).synchronize()
                    values, identity = ex.publish()
                    values = cpu_values(values)
                    exact(values, expected)
                    assert identity == pub and len(values) == (11 if late else 10)
                    key = f'{method}-s{sid}-late{int(late)}'
                    torch.save(dict(actual=values, expected=expected), a.output / (key + '.pt'))
                    result['cases'].append(dict(key=key, method=method, late=late, source=sid,
                        admitted_ns=admitted, return_ns=returned, overwrite_done_ns=overwritten,
                        published_ns=now(), identity=identity, outputs=len(values),
                        sha256=sha(a.output / (key+'.pt')), artifact=program.artifact))
                    print('COMPLETE ' + key, flush=True)
        result.update(status='COMPLETE', input_hashes=hashes, sources=inventory(), gate_cases=18)
    except BaseException:
        result.update(status='FAILED', traceback=traceback.format_exc())
        traceback.print_exc()
    save(a.output, result); (a.output / result['status']).write_text(result['status']+'\n')
    return 0 if result['status'] == 'COMPLETE' else 1


if __name__ == '__main__':
    raise SystemExit(main())
