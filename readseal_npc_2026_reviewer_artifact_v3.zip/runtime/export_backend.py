"""Execute the checked, functional ATen artifact, never the original callback.

Pinned PyTorch 2.1.2, fixed dense tensor input, single device. Schema-declared
aliases are conservative; all operand dependencies count as reads, including
metadata operations. Tuple results carry union alias facts through getitem.
"""
import copy
from dataclasses import asdict
import hashlib
import operator
from pathlib import Path

import torch
from torch.fx.node import map_arg
from torch.utils._pytree import tree_flatten

from core import Lease, Node, Summary, Rejected, compile_plan, digest
from torch_backend import bind, spec, allocation, Ready, canonical_arg


# Functional, deterministic operators used by the fixed inference artifact.
# No custom namespaces, out variants, writes, opaque callbacks, or hidden streams.
ALLOWED = frozenset("""
_assert_async.msg _native_batch_norm_legit_no_training.default _softmax.default
_to_copy.default add.Tensor addmm.default alias.default all.default arange.start_step
bitwise_and.Tensor bmm.default cat.default clone.default convolution.default
copy.default div.Tensor eq.Tensor expand.default floor_divide.default full_like.default
gather.default ge.Scalar lt.Scalar max_pool2d_with_indices.default mm.default mul.Tensor
native_layer_norm.default permute.default relu.default remainder.Scalar repeat.default
select.int select_scatter.default sigmoid.default slice.Tensor slice_scatter.default
sort.default split.Tensor unsqueeze.default view.default mean.default mean.dim
""".split())


def summary(node):
    inputs = tuple(range(len(node.all_input_nodes)))
    if node.target is operator.getitem:
        if len(node.args) != 2 or type(node.args[1]) is not int or node.kwargs:
            raise Rejected("only fixed tuple/list getitem is allowed")
        return Summary(inputs, inputs, implementation="tuple-getitem-conservative")
    target = node.target
    if not isinstance(target, torch._ops.OpOverload) or str(target) not in {"aten." + n for n in ALLOWED}:
        raise Rejected("unregistered ATen operator: " + str(target))
    schema = target._schema
    if any(a.alias_info is not None and a.alias_info.is_write for a in schema.arguments):
        raise Rejected("mutation is outside the functional executable scope")
    aliases = inputs if any(r.alias_info is not None for r in schema.returns) else ()
    return Summary(inputs, aliases, implementation=str(schema))


def canonical(value):
    if isinstance(value, (torch.layout, torch.memory_format)):
        return str(value)
    if isinstance(value, (tuple, list)):
        return [canonical(v) for v in value]
    if isinstance(value, dict):
        return {k: canonical(v) for k, v in value.items()}
    return canonical_arg(value)


def fingerprint(graph, state):
    return digest({"graph": [(n.op, n.name, str(n.target), canonical(n.args), canonical(n.kwargs))
                             for n in graph.nodes],
                   "state": [(name, tuple(t.shape), tuple(t.stride()), str(t.dtype), str(t.device),
                              allocation(t), t._version) for name, t in sorted(state.items())],
                   "torch": torch.__version__,
                   "backend": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})


class Program:
    def __init__(self, exported, example, late_read=False):
        if torch.__version__ != "2.1.2+cu121":
            raise Rejected("unreviewed PyTorch operator implementation version")
        sig = exported.graph_signature
        if len(sig.user_inputs) != 1 or sig.buffers_to_mutate or sig.assertion_dep_token is not None:
            raise Rejected("one tensor input, explicit outputs, no mutable state required")
        self.graph = copy.deepcopy(exported.graph)
        self.root = sig.user_inputs[0]
        self.expected = spec(example)
        root_node = next(n for n in self.graph.nodes if n.name == self.root)
        reference = root_node.meta["val"]
        if (tuple(reference.shape), tuple(reference.stride()), reference.dtype, reference.storage_offset()) != (
                tuple(example.shape), tuple(example.stride()), example.dtype, example.storage_offset()):
            raise Rejected("input differs from export's fixed metadata")
        self.state = {}
        names = dict(sig.inputs_to_parameters, **sig.inputs_to_buffers)
        for n, key in names.items():
            self.state[n] = exported.state_dict[key].detach().to(example.device)
        self.device_retargets = []
        for n in self.graph.nodes:
            if n.op == "call_function" and n.kwargs.get("device") is not None:
                if str(n.target) not in ("aten.arange.start_step", "aten._to_copy.default"):
                    raise Rejected("unreviewed device-specific factory")
                if torch.device(n.kwargs["device"]).type != "cpu":
                    raise Rejected("expected the CPU export artifact")
                self.device_retargets.append(n.name)
                n.kwargs = dict(n.kwargs, device=example.device)
        output = next(n for n in self.graph.nodes if n.op == "output")
        if tuple(n.name for n in output.args[0]) != tuple(sig.user_outputs):
            raise Rejected("export output signature mismatch")
        if late_read:
            with self.graph.inserting_before(output):
                clone = self.graph.call_function(torch.ops.aten.clone.default, (root_node,))
                mean = self.graph.call_function(torch.ops.aten.mean.default, (clone,))
            output.args = (tuple(output.args[0]) + (mean,),)
        self.graph.lint()
        self.output_names = tuple(n.name for n in output.args[0])
        nodes = []
        self.operations = {}
        for n in self.graph.nodes:
            if n.name == self.root or n.op == "output":
                continue
            if n.op == "placeholder":
                if n.name not in self.state:
                    raise Rejected("unbound placeholder")
                s = Summary((), implementation="frozen-lifted-state")
            elif n.op == "call_function":
                s = summary(n)
            else:
                raise Rejected("nonfunctional graph node")
            nodes.append(Node(n.name, tuple(i.name for i in n.all_input_nodes), s))
            self.operations[n.name] = n
        self.executable = fingerprint(self.graph, self.state)
        self.plan = compile_plan((self.root,), nodes, tuple(dict.fromkeys(self.output_names)),
                                 {self.root: self.expected}, self.executable)

    def start(self, x, publication=None, ready=None):
        if fingerprint(self.graph, self.state) != self.executable or spec(x) != self.expected:
            raise Rejected("executable or metadata changed before launch")
        if any(allocation(x) == allocation(t) for t in self.state.values()):
            raise Rejected("state aliases producer allocation")
        b = bind(x, **(publication or {}))
        lease = Lease(self.plan, {self.root: b}, self.executable, {self.root: b.version})
        return Execution(self, x, lease, ready)


class Execution:
    def __init__(self, program, x, lease, ready):
        self.program, self.lease, self.device = program, lease, x.device
        self.values = {program.root: x}
        self.root_ready = ready
        if x.is_cuda and ready is None:
            self.root_ready = torch.cuda.Event()
            self.root_ready.record(torch.cuda.current_stream(x.device))
        self.receipts = []
        self.facts = dict(program.plan.facts)

    def step(self, name, stream=None):
        n = self.program.operations[name]
        self.lease.begin(name)
        try:
            if n.op == "placeholder":
                result, event = self.program.state[name], Ready()
            else:
                args = map_arg(n.args, lambda i: self.values[i.name])
                kwargs = map_arg(n.kwargs, lambda i: self.values[i.name])
                if self.device.type == "cuda":
                    stream = stream or torch.cuda.current_stream(self.device)
                    for dep in n.all_input_nodes:
                        e = self.root_ready if dep.name == self.program.root else self.lease.output_events[dep.name]
                        if isinstance(e, torch.cuda.Event):
                            stream.wait_event(e)
                    with torch.cuda.stream(stream), torch.inference_mode():
                        result = n.target(*args, **kwargs)
                        event = torch.cuda.Event()
                        event.record(stream)
                else:
                    with torch.inference_mode():
                        result = n.target(*args, **kwargs)
                    event = Ready()
            leaves, _ = tree_flatten(result)
            actual = any(isinstance(t, torch.Tensor) and allocation(t) == self.lease.bindings[self.program.root].allocation
                         for t in leaves)
            if actual and self.program.root not in self.facts[name].borrows:
                raise Rejected("observed storage alias violates schema summary")
            self.values[name] = result
            self.lease.submitted(name, event)
            self.receipts.append({"node": name, "operator": str(n.target), "source_alias": actual,
                                  "tensor_shapes": [list(t.shape) for t in leaves if isinstance(t, torch.Tensor)]})
        except BaseException:
            self.lease.abort()
            raise

    def wait(self):
        for event in self.lease.output_events.values():
            event.synchronize()

    def outputs(self):
        if not self.lease.can_publish():
            raise Rejected("output not complete")
        return tuple(self.values[n] for n in self.program.output_names)
