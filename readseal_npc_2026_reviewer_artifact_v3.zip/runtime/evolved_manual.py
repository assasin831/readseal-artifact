"""Complete manual executor for reviewed snapshots, preserving V8 safeguards."""
import copy
import hashlib
import marshal

import torch
from manual_static import (ManualProgram, ManualRejected, manual_partition,
                           own_function, state_token, tensor_meta, graph_records)
from variants import structural_hash, SUPPORTED


class EvolvedManual(ManualProgram):
    def __init__(self, snapshot, example, review, model, edit, full=False):
        if edit not in SUPPORTED or review['model'] != model or review['edit'] != edit:
            raise ManualRejected('snapshot has no matching manual review')
        if structural_hash(snapshot.graph) != review['graph_sha256']:
            raise ManualRejected('changed graph needs a new manual binding and boundary review')
        self.graph = copy.deepcopy(snapshot.graph)
        sig = snapshot.graph_signature
        self.root = sig.user_inputs[0]
        for n in self.graph.nodes:
            if n.op == 'call_function' and n.kwargs.get('device') is not None:
                if str(n.target) not in ('aten.arange.start_step', 'aten._to_copy.default'):
                    raise ManualRejected('unreviewed device retarget')
                n.kwargs = dict(n.kwargs, device=example.device)
        names = dict(sig.inputs_to_parameters, **sig.inputs_to_buffers)
        self.state = {n: snapshot.state_dict[k].detach().to(example.device).clone() for n, k in names.items()}
        ref = next(n for n in self.graph.nodes if n.name == self.root).meta['val']
        if (tuple(ref.shape), tuple(ref.stride()), ref.dtype) != (tuple(example.shape), tuple(example.stride()), example.dtype):
            raise ManualRejected('input metadata not reviewed')
        self.expected, self.full, self.boundary = tensor_meta(example), full, review['boundary']
        graphs, carry = ((self.graph,), ()) if full else manual_partition(self.graph, self.boundary)
        self.functions = tuple(own_function(g) for g in graphs)
        self.state_tokens = tuple((n, state_token(t)) for n, t in self.state.items())
        self.arguments = tuple(n.name for n in self.graph.nodes if n.op == 'placeholder')
        self.artifact = dict(schema='reviewed-evolved-manual-v10', model=model, edit=edit, full=full,
            review=review, boundary=self.boundary, carry=carry, graph=graph_records(self.graph),
            stages=[graph_records(g) for g in graphs], code=[f[3] for f in self.functions],
            code_sha256=[hashlib.sha256(marshal.dumps(f[1])).hexdigest() for f in self.functions],
            no_readseal_analysis_or_executor=True, original_manual_guards_preserved=True)
