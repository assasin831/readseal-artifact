"""Four-way complete-pipeline comparison with unchanged V10 admission semantics."""
import argparse
import json
from pathlib import Path

import admission_streaming as base
import run_abc as abc
from auto_composition import AutoComposition
from manual_composition import ManualComposition
from grouped_composition import GroupedComposition
from study_common import compute_pids, configure
from common import inventory


METHODS = ('auto-early', 'auto-batched', 'manual-early', 'manual-full')


def factory(model, example, late, method):
    assert model == 'transfusion' and method in METHODS
    if method == 'auto-batched':
        return GroupedComposition(example, late)
    if method == 'auto-early':
        return AutoComposition(example, late)
    return ManualComposition(example, late, full=method == 'manual-full')


def consumer(*args):
    # Spawn imports this wrapper afresh. Install its factory inside the child,
    # not just the parent; keep the original producer/sink/consumer unchanged.
    abc.factory = factory
    return abc.consumer(*args)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--cell', required=True)
    p.add_argument('--method', choices=METHODS, required=True)
    a = p.parse_args()
    assert not compute_pids(), 'foreign compute; no inference launched'
    configure()
    base.make_program, base.consumer, base.source_inventory = factory, consumer, inventory
    print(json.dumps(base.measure_cell(a.output, json.loads(a.cell), a.method)), flush=True)


if __name__ == '__main__':
    main()
