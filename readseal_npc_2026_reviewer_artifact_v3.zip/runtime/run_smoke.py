"""Fresh-output correctness experiment. Deliberately not a timing benchmark."""
import argparse
from dataclasses import asdict
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import subprocess
import time
import unittest

import torch
from torch import nn
from torchvision.models import resnet18

from core import Rejected
from test_core import CoreTests
from torch_backend import Call, Component, Pipeline, allocation, spec


HERE = Path(__file__).resolve().parent
GPU = "GPU-f3b314a8-3058-e0be-694c-76f4227afb7d"


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


class Tail(nn.Module):
    def __init__(self, model):
        super().__init__()
        self.layer1, self.layer2 = model.layer1, model.layer2
        self.layer3, self.layer4 = model.layer3, model.layer4
        self.avgpool, self.fc = model.avgpool, model.fc

    def forward(self, x):
        x = self.layer4(self.layer3(self.layer2(self.layer1(x))))
        return self.fc(torch.flatten(self.avgpool(x), 1))


class LaterBranch(nn.Module):
    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, x):
        y = self.model(x)
        return y + x.clone().mean()


class View(nn.Module):
    def forward(self, x):
        return x.transpose(2, 3)


class Fresh(nn.Module):
    def forward(self, x):
        return x.clone()


class SumPair(nn.Module):
    def forward(self, x, y):
        return x + y


class Unknown(nn.Module):
    def forward(self, x):
        return torch.sin(x)


class BadBorrow(nn.Module):
    def __init__(self):
        super().__init__()
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.relu(x)


def run(a):
    out = a.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    report = {"status": "RUNNING", "scope": "finite FX correctness smoke; NOT performance evidence",
              "device": a.device, "cases": [], "started_ns": time.time_ns(),
              "sources": {p.name: sha(p) for p in HERE.glob("*.py")},
              "environment": {"torch": torch.__version__, "python": platform.python_version()},
              "transfusion_complete": False, "native_tensorrt_complete": False,
              "same_semantics_performance_complete": False, "v6_modified": False}
    def save(name, value):
        (out / name).write_text(json.dumps(value, indent=2, sort_keys=True), encoding="utf-8")
    def check(condition, message):
        if not condition:
            raise AssertionError(message)
    def record(name, **data):
        report["cases"].append({"name": name, "status": "PASS", **data})
        print(json.dumps({"case": name, "status": "PASS"}), flush=True)
    def expected_reject(fn, label):
        try:
            fn()
        except Rejected as e:
            record(label, rejection=str(e), before_submission=True)
        else:
            raise AssertionError("expected prelaunch rejection: " + label)
    try:
        if a.device.startswith("cuda"):
            check(os.environ.get("CUDA_VISIBLE_DEVICES") == GPU, "GPU UUID isolation required")
            rows = subprocess.check_output(["nvidia-smi", "--query-compute-apps=gpu_uuid,pid",
                                            "--format=csv,noheader"], text=True)
            check(not any(row.split(",")[0].strip() == GPU for row in rows.splitlines()),
                  "GPU0 has an existing compute process; do not launch")
            report["gpu_uuid"] = GPU
            report["other_gpu_compute_present"] = bool(rows.strip())
        torch.set_num_threads(1)
        torch.manual_seed(20260908)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        log = io.StringIO()
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromTestCase(CoreTests))
        (out / "core-tests.txt").write_text(log.getvalue(), encoding="utf-8")
        check(result.wasSuccessful(), "core tests failed")
        report["core_tests"] = result.testsRun

        model = resnet18(weights=None).eval()
        if a.references:
            checkpoint = a.references / "resnet18-f37072fd.pth"
            check(sha(checkpoint) == "f37072fd47e89c5e827621c5baffa7500819f7896bbacec160b1a16c560e07ec",
                  "checkpoint hash mismatch")
            model.load_state_dict(torch.load(checkpoint, map_location="cpu", weights_only=True))
            manifest = json.loads((a.references / "manifest.json").read_text())
            bank_path = a.references / "feature_bank.pt"
            check(sha(bank_path) == manifest["bank_file_sha256"], "feature bank hash mismatch")
            bank = torch.load(bank_path, map_location="cpu", weights_only=True)
            x = bank[:1].clone().to(a.device)
            report["inputs"] = {"checkpoint_sha256": sha(checkpoint), "bank_sha256": sha(bank_path),
                                "source": "existing real camera stem activation bank", "bank_row": 0}
            del bank
        else:
            x = torch.randn(1, 64, 8, 8, device=a.device)
            report["inputs"] = {"source": "synthetic structural smoke", "seed": 20260908}
        model.to(a.device)
        tail = Tail(model).eval()
        artifact = Component.extract(tail, (x,))
        pipeline = Pipeline({"x": spec(x)}, (Call("tail", artifact, ("x",)),), ("tail",))
        save("resnet-plan.json", {"sha256": pipeline.plan.sha256,
                                 "nodes": [asdict(n) for n in pipeline.plan.nodes],
                                 "obligations": pipeline.plan.obligations})
        with torch.inference_mode():
            expected = tail(x.clone())
        exe = pipeline.start({"x": x})
        released_at = None
        for node in pipeline.plan.nodes:
            exe.step(node.name)
            exe.wait_submitted()
            if released_at is None and exe.lease.can_release(allocation(x)):
                released_at = node.name
        actual = exe.outputs()[0]
        check(torch.equal(actual, expected), "frozen graph output differs from eager reference")
        readers = dict(pipeline.plan.obligations)["x"]
        check(len(readers) == 2, "ResNet source should have convolution and residual-add readers")
        check(released_at.endswith("add"), "automatic closure must include first residual addition")
        check(exe.lease.publish_identity()[pipeline.outputs[0]]["x"].sequence == 2, "provenance lost")
        record("resnet_tail_auto_boundary", reader_nodes=readers, released_at=released_at,
               node_count=len(pipeline.plan.nodes), exact_eager_output=True)

        # A supported structural change must generate a usable new plan, not just
        # reject the old plan or hard-code a model-specific hook.
        later = LaterBranch(tail).eval()
        late_artifact = Component.extract(later, (x,))
        late_pipeline = Pipeline({"x": spec(x)}, (Call("late", late_artifact, ("x",)),), ("late",))
        late_exe = late_pipeline.start({"x": x})
        with torch.inference_mode():
            late_expected = later(x.clone())
        late_exe.run_component("late")
        late_exe.wait_submitted()
        check(torch.equal(late_exe.outputs()[0], late_expected), "late-branch regenerated plan unusable")
        late_readers = dict(late_pipeline.plan.obligations)["x"]
        check(len(late_readers) == 3 and any(n.endswith("clone") for n in late_readers), "late read omitted")
        record("late_branch_regenerates_usable_plan", reader_nodes=late_readers,
               plan_changed=late_pipeline.plan.sha256 != pipeline.plan.sha256)

        view = Component.extract(View().eval(), (x,))
        fresh = Component.extract(Fresh().eval(), (x,))
        view_example = x.transpose(2, 3)
        downstream = Component.extract(model.layer1[0], (view_example,))
        composed = Pipeline({"x": spec(x)}, (Call("A", fresh, ("x",)), Call("B", view, ("x",)),
                            Call("C", downstream, ("B",))), ("A", "C"))
        streams = [torch.cuda.Stream() for _ in range(2)] if a.device.startswith("cuda") else [None, None]
        run_comp = composed.start({"x": x})
        with torch.inference_mode():
            expected_c = model.layer1[0](view_example.clone())
            expected_a = x.clone()
        run_comp.run_component("A", streams[0])
        run_comp.run_component("B", streams[0])
        run_comp.wait_submitted()
        check(not run_comp.lease.can_release(allocation(x)), "unstarted C borrow was lost")
        run_comp.run_component("C", streams[1])
        run_comp.wait_submitted()
        check(run_comp.lease.can_release(allocation(x)), "completed C borrow did not close")
        # The producer reuses the same physical storage only after every enrolled
        # shared read completes. Outputs must remain independent of this overwrite.
        with torch.inference_mode():
            backup = x.clone()
            x.fill_(17.0)
        y_a, y_c = run_comp.outputs()
        check(torch.equal(y_a, expected_a) and torch.equal(y_c, expected_c), "source reuse changed private output")
        with torch.inference_mode():
            x.copy_(backup)
        identity = run_comp.lease.publish_identity()
        check(all("x" in item for item in identity.values()), "cross-component provenance missing")
        save("composition-plan.json", {"sha256": composed.plan.sha256,
                                      "obligations": composed.plan.obligations,
                                      "nodes": [asdict(n) for n in composed.plan.nodes]})
        record("cross_component_delayed_view_reader", actual_cuda_streams=len(streams) if streams[0] else 0,
               future_reader_blocked=True, reused_source_exact_outputs=True,
               scope="PyTorch components; native TensorRT engine not installed")

        pair = Component.extract(SumPair().eval(), (x, x))
        pair_pipeline = Pipeline({"x": spec(x), "y": spec(x)}, (Call("sum", pair, ("x", "y")),), ("sum",))
        pair_exe = pair_pipeline.start({"x": x, "y": x})
        check(len(pair_exe.lease.sizes) == 1, "physical allocation counted twice")
        pair_exe.run_component("sum")
        pair_exe.wait_submitted()
        with torch.inference_mode():
            check(torch.equal(pair_exe.outputs()[0], x + x), "two-input alias output mismatch")
        record("actual_two_input_alias_merge", physical_allocations=1, logical_inputs=2)

        view_only = Pipeline({"x": spec(x)}, (Call("view", view, ("x",)),), ("view",))
        v = view_only.start({"x": x})
        v.run_component("view")
        v.wait_submitted()
        check(not v.lease.can_release(allocation(x)), "terminal borrowed view escaped untracked")
        v.lease.return_output_borrow(view_only.outputs[0])
        check(v.lease.can_release(allocation(x)), "sink acknowledgement did not settle view borrow")
        record("terminal_view_requires_sink_ack")

        expected_reject(lambda: Component.extract(Unknown().eval(), (x,)), "unknown_operator_prelaunch")
        bad = Component.extract(BadBorrow().eval(), (x,))
        expected_reject(lambda: Pipeline({"x": spec(x)}, (Call("bad", bad, ("x",)),), ("bad",)),
                        "borrowed_mutation_prelaunch")
        expected_reject(lambda: pipeline.start({"x": x[:, :, :1, :]}), "shape_guard_prelaunch")
        expected_reject(lambda: pipeline.start({"x": x}, versions={"x": (1, 4, 2)}),
                        "publication_guard_prelaunch")
        expected_reject(lambda: pipeline.start({"x": x}, publications={"x": {"generation": 3}}),
                        "writer_active_generation_prelaunch")
        odd_sequence = pipeline.start({"x": x}, publications={"x": {"sequence": 3}})
        check(odd_sequence.lease.bindings["x"].sequence == 3, "legal odd sequence rejected")
        odd_sequence.lease.abort()
        record("legal_odd_sequence_admitted_without_launch")
        modified = Component.extract(Fresh().eval(), (x,))
        changed_pipeline = Pipeline({"x": spec(x)}, (Call("fresh", modified, ("x",)),), ("fresh",))
        node = next(n for n in modified.graph.graph.nodes if n.op == "call_method")
        node.target = "sin"
        expected_reject(lambda: changed_pipeline.start({"x": x}), "changed_executable_prelaunch")

        report["status"] = "COMPLETE_CORRECTNESS_SMOKE"
        report["finished_ns"] = time.time_ns()
        report["case_count"] = len(report["cases"])
        report["cuda_initialized"] = torch.cuda.is_initialized()
        save("report.json", report)
        (out / "COMPLETE").write_text("correctness smoke only\n")
        print(json.dumps({"status": report["status"], "cases": len(report["cases"]),
                          "core_tests": result.testsRun}), flush=True)
    except BaseException as exc:
        report.update(status="FAILED", error_type=type(exc).__name__, error=str(exc))
        save("report.json", report)
        (out / "FAILED").write_text(type(exc).__name__ + ": " + str(exc) + "\n")
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda:0"), default="cpu")
    parser.add_argument("--references", type=Path)
    run(parser.parse_args())
