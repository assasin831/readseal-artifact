"""CPU-only reconstruction of complete-manual cost and ordered local controls."""
import argparse
import ast
import itertools
import json
from pathlib import Path
import random
import traceback
import numpy as np
import torch
from manual_static import sha, EXPORTS

GPU='GPU-f3b314a8-3058-e0be-694c-76f4227afb7d'
METHODS=['auto-early','auto-batched','manual-early','manual-full']


def equal(a,b):
    assert len(a)==len(b)
    for x,y in zip(a,b):
        assert x.shape==y.shape and x.dtype==y.dtype
        assert torch.isfinite(x).all().item() and torch.equal(x,y)


def hashes(items):
    assert items
    for p,h in items.items():
        assert sha(p)==h, 'changed source/input '+p


def cost(run, report):
    assert report['status']=='COMPLETE' and (run/'COMPLETE').exists()
    assert report['gpu_uuid']==GPU and 0<=report['repeat']<8
    assert (report['warmups'],report['quartets'],report['seed'])==(20,50,101051+report['repeat'])
    hashes(report['sources'])
    manual_path=next(p for p in report['sources'] if Path(p).name=='manual_static.py')
    imports=[]
    for n in ast.walk(ast.parse(Path(manual_path).read_text())):
        if isinstance(n,ast.Import): imports += [a.name for a in n.names]
        if isinstance(n,ast.ImportFrom): imports += [n.module]
    assert set(imports)<= {'copy','hashlib','json','marshal','types','torch','torch.fx.node','torch.utils._pytree'}
    population=list(itertools.product(('transfusion','resnet'),(False,True),range(3)))
    assert [(c['model'],c['late'],c['source']) for c in report['cases']]==population
    rng=random.Random(report['seed'])
    values={}
    for c in report['cases']:
        folder=run/c['key']
        hashes(c['input_hashes'])
        assert sha(folder/'outputs.pt')==c['output_sha256']
        saved=torch.load(folder/'outputs.pt',map_location='cpu')
        equal(saved['actual'],saved['expected'])
        arity=(10 if c['late'] else 9) if c['model']=='transfusion' else (2 if c['late'] else 1)
        assert len(saved['actual'])==arity
        artifacts={}
        for m,h in c['artifacts'].items():
            assert sha(folder/(m+'.json'))==h
            artifacts[m]=json.loads((folder/(m+'.json')).read_text())
        assert set(artifacts)==set(METHODS)
        ae,ab,me,mf=[artifacts[m] for m in METHODS]
        assert ae['graph']==ab['graph'] and ae['groups']==ab['groups'] and ae['live']==ab['live']
        assert ab['schema']=='borrowplan-batched-witness-v10'
        assert 'unchanged state, function, stream, alias' in ab['guard_schedule']
        assert ae['graph']==me['graph']==mf['graph']
        for m in (me,mf):
            assert m['export_sha256']==EXPORTS[c['model']]
            assert m['manual_source_sha256']==sha(manual_path)
            assert m['no_readseal_analysis_or_executor'] is True
            assert (m['model'],m['late'])==(c['model'],c['late'])
        assert me['full'] is False and mf['full'] is True
        assert len(me['stages'])==2 and len(mf['stages'])==1
        assert mf['stages'][0]==mf['graph']
        operations=[n for n in me['graph'] if n[0]=='call_function']
        assert [n for g in me['stages'] for n in g if n[0]=='call_function']==operations
        prefix=[n for n in me['stages'][0] if n[0]=='call_function']
        assert prefix[-1][1]==me['boundary']
        assert len(c['records'])==200
        times=np.empty((50,4))
        for trial in range(50):
            order=METHODS.copy(); rng.shuffle(order)
            chunk=c['records'][trial*4:trial*4+4]
            assert [r['method'] for r in chunk]==order
            for pos,r in enumerate(chunk):
                assert (r['trial'],r['position'],r['exact'])==(trial,pos,True)
                assert type(r['wall_ns']) is int and r['wall_ns']>0
                times[trial,METHODS.index(r['method'])]=r['wall_ns']/1e6
        assert c['compute'] and all(p['gpu']==GPU and p['pid']==report['pid'] for p in c['compute'])
        assert np.isfinite(times).all()
        values[c['key']]=times.tolist()
    return dict(cases=12,timed_invocations=2400,values_ms=values,repeat=report['repeat'],
                report_sha256=sha(run/'report.json'))



if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--run',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=False)
    out=dict(status='RUNNING',validator_sha256=sha(__file__))
    try:
        report=json.loads((a.run/'report.json').read_text())
        out.update(cost(a.run,report),status='COMPLETE')
        altered=json.loads(json.dumps(report))
        altered['cases'][0]['records'][0]['wall_ns']=-1
        try:
            cost(a.run,altered)
        except AssertionError:
            out['negative_duration_rejected']=True
        else:
            raise AssertionError('invalid timing accepted')
    except BaseException:
        out.update(status='FAILED',traceback=traceback.format_exc()); traceback.print_exc()
    (a.output/'validation.json').write_text(json.dumps(out,indent=2)+'\n')
    (a.output/out['status']).write_text(out['status']+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='values_ms'}),flush=True)
    raise SystemExit(int(out['status']!='COMPLETE'))

