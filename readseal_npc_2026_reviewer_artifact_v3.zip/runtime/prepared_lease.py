"""Construction certificate for immutable plans; inherit the original state machine.

The certificate is runtime-owned, not a security boundary against hostile
Python reflection. All invocation binding checks remain the original checks.
"""
from dataclasses import asdict, dataclass, fields, is_dataclass
from threading import RLock

from core import Lease, Rejected, compile_plan, digest

_SEAL = object()


def immutable(value):
    if type(value) in (str, int, float, bool, type(None)):
        return True
    if type(value) in (tuple, frozenset):
        return all(immutable(v) for v in value)
    if is_dataclass(value) and value.__dataclass_params__.frozen:
        return all(immutable(getattr(value, f.name)) for f in fields(value))
    return False


@dataclass(frozen=True)
class _Prepared:
    plan: object
    contracts: tuple
    plan_sha256: str
    seal: object


def prepare(plan):
    if not immutable(plan):
        raise Rejected('construction certificate requires a recursively immutable plan')
    regenerated = compile_plan(plan.roots, plan.nodes, plan.outputs, dict(plan.specs), plan.executable)
    if regenerated != plan:
        raise Rejected('invalid derived plan')
    return _Prepared(plan, tuple((root, digest(asdict(spec))) for root, spec in plan.specs), plan.sha256, _SEAL)


class PreparedLease(Lease):
    def __init__(self, certificate, bindings, executable, expected_versions):
        if type(certificate) is not _Prepared or certificate.seal is not _SEAL:
            raise Rejected('unadmitted construction certificate')
        plan = certificate.plan
        if executable != plan.executable:
            raise Rejected('plan or executable mismatch before launch')
        if set(bindings) != set(plan.roots) or set(expected_versions) != set(plan.roots):
            raise Rejected('incomplete group binding')
        sizes, versions = {}, {}
        contracts = dict(certificate.contracts)
        for root, spec in plan.specs:
            b = bindings[root]
            if b.spec != spec or b.version != tuple(expected_versions[root]):
                raise Rejected('specification or publication changed before launch')
            if not b.allocation or b.contract != contracts[root] or b.allocation_bytes <= 0:
                raise Rejected('invalid allocation identity')
            if any(type(v) is not int or v < 0 or v >= 2 ** 64 for v in b.version):
                raise Rejected('invalid version field')
            if b.sequence <= 0 or b.generation <= 0 or b.generation % 2:
                raise Rejected('invalid publication or writer-active generation')
            if b.allocation in versions and versions[b.allocation] != b.version:
                raise Rejected('one physical allocation cannot bind two versions')
            if b.allocation in sizes and sizes[b.allocation] != b.allocation_bytes:
                raise Rejected('inconsistent physical allocation size')
            versions[b.allocation], sizes[b.allocation] = b.version, b.allocation_bytes
        self.plan, self.bindings = plan, dict(bindings)
        self.sizes = sizes
        self.states = {n.name: 'pending' for n in plan.nodes}
        self.nodes = {n.name: n for n in plan.nodes}
        self.events, self.output_events = {}, {}
        self.returned = set()
        self.aborted = False
        self.published = False
        self.lock = RLock()
