"""Bounded two-stage lowering of the unchanged functional borrow plan.

Single stream, fixed export and immutable lifted state. No hidden streams,
opaque operators, output borrows, concurrent artifact mutation or callbacks.
All original operation obligations remain enrolled in the original Lease.
Only stage-boundary alias checks are dynamic; interior schema facts are trusted.
"""
import hashlib
import marshal
from pathlib import Path

import torch
from torch.utils._pytree import tree_flatten

from core import Rejected, digest
from export_backend import Program, fingerprint
from torch_backend import allocation


def module_fingerprint(module):
    if (module._forward_hooks or module._forward_pre_hooks or module._backward_hooks
            or list(module.named_children()) or list(module.parameters()) or list(module.buffers())):
        raise Rejected("generated segments must be hook-free functional code")
    return digest({
        "graph": fingerprint(module.graph, {}),
        "forward": hashlib.sha256(marshal.dumps(module.forward.__func__.__code__)).hexdigest(),
    })


def lower(program):
    calls = [n for n in program.graph.nodes if n.op == "call_function"]
    readers = set(dict(program.plan.obligations)[program.root])
    if not readers or not readers.issubset({n.name for n in calls}):
        raise Rejected("expected explicit source-reading call nodes")
    if any(names for _, names in program.plan.escapes):
        raise Rejected("output borrow needs an explicit sink contract")
    last = max(i for i, n in enumerate(calls) if n.name in readers)
    first, rest = calls[:last + 1], calls[last + 1:]
    placeholders = [n for n in program.graph.nodes if n.op == "placeholder"]
    produced = {n.name for n in placeholders + first}
    suffix = {n.name for n in rest}
    output = next(n for n in program.graph.nodes if n.op == "output")
    needed = {d.name for n in rest for d in n.all_input_nodes if d.name not in suffix}
    needed.update(n.name for n in output.all_input_nodes if n.name in produced)
    facts = dict(program.plan.facts)
    if any(facts[name].borrows for name in needed):
        raise Rejected("borrowed storage crosses the proposed read-closure boundary")
    live = [n for n in program.graph.nodes if n.name in needed]
    g1, env = torch.fx.Graph(), {}
    for n in placeholders + first:
        env[n.name] = g1.node_copy(n, lambda d: env[d.name])
    g1.output(tuple(env[n.name] for n in live))
    g2, env = torch.fx.Graph(), {}
    for n in live:
        env[n.name] = g2.placeholder(n.name)
    for n in rest:
        env[n.name] = g2.node_copy(n, lambda d: env[d.name])
    g2.node_copy(output, lambda d: env[d.name])
    g1.lint()
    g2.lint()
    modules = tuple(torch.fx.GraphModule(torch.nn.Module(), g) for g in (g1, g2))
    groups = (tuple(n.name for n in placeholders if n.name != program.root)
              + tuple(n.name for n in first), tuple(n.name for n in rest))
    assert tuple(name for group in groups for name in group) == tuple(program.operations)
    return modules, groups, tuple(n.name for n in live)


class SegmentedProgram:
    def __init__(self, exported, example, late_read=False):
        self.checked = Program(exported, example, late_read=late_read)
        self.modules, self.groups, self.live = lower(self.checked)
        self.module_hashes = tuple(module_fingerprint(m) for m in self.modules)
        self.source_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        self.plan_hash = self.checked.plan.sha256
        self.partition_hash = digest((self.groups, self.live))

    def guard(self):
        p = self.checked
        if (fingerprint(p.graph, p.state) != p.executable
                or p.plan.sha256 != self.plan_hash
                or digest((self.groups, self.live)) != self.partition_hash
                or tuple(module_fingerprint(m) for m in self.modules) != self.module_hashes
                or hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != self.source_hash):
            raise Rejected("artifact changed before stage launch")

    def start(self, x, publication=None, ready=None):
        if not x.is_cuda:
            raise Rejected("this execution adapter requires CUDA")
        self.guard()
        original = self.checked.start(x, publication, ready)
        return SegmentedExecution(self, original, x)


class SegmentedExecution:
    def __init__(self, program, original, x):
        self.program, self.lease = program, original.lease
        self.x, self.ready = x, original.root_ready
        self.stage = 0
        self.events = []
        self.boundary = None
        self.result = None
        self.stream = None
        self.failed = False

    def submit(self, stage, stream):
        if stage != self.stage or stage not in (0, 1) or self.lease.aborted or self.failed:
            raise Rejected("out-of-order or repeated stage")
        if self.stream is not None and self.stream.cuda_stream != stream.cuda_stream:
            raise Rejected("the segmented adapter is single-stream")
        self.program.guard()
        self.stream = stream
        p = self.program.checked
        try:
            with torch.cuda.stream(stream), torch.inference_mode():
                if stage == 0:
                    stream.wait_event(self.ready)
                    args = tuple(self.x if n.name == p.root else p.state[n.name]
                                 for n in p.graph.nodes if n.op == "placeholder")
                else:
                    args = self.boundary
                value = tuple(self.program.modules[stage].forward(*args))
                event = torch.cuda.Event()
                event.record(stream)
            leaves, _ = tree_flatten(value)
            root_alloc = self.lease.bindings[p.root].allocation
            if any(isinstance(t, torch.Tensor) and allocation(t) == root_alloc for t in leaves):
                raise Rejected("stage result aliases the reusable source")
            # One recorded stage event conservatively witnesses every enclosed op.
            # The original Lease still has the full, pre-enrolled operation set.
            for name in self.program.groups[stage]:
                self.lease.begin(name)
                self.lease.submitted(name, event)
            self.events.append(event)
            if stage == 0:
                self.boundary = value
                self.x = None
            else:
                self.result = value
                self.boundary = None
            self.stage += 1
            return event
        except BaseException:
            # Unknown partial enqueue must quarantine, never cancel unseen readers.
            # Leave pending obligations enrolled; caller must not reclaim on error.
            self.failed = True
            raise

    def outputs(self):
        if self.failed or self.stage != 2 or self.result is None or not self.lease.can_publish():
            raise Rejected("output before checked completion")
        return self.result
