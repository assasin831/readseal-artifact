"""Pinned inputs and adapters for new comparisons; no shared manual executor."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

import torch
from manual_static import ManualProgram, sha

ROOT = Path('/www/readseal_ipdps_revision_v6')
GPU = 'GPU-f3b314a8-3058-e0be-694c-76f4227afb7d'
MODELS = {
    'transfusion': (ROOT/'inputs/transfusion_borrowplan_v2/head_export.pt2',
                    ROOT/'inputs/transfusion_borrowplan_v2_oracle'),
    'resnet': (ROOT/'results/borrowplan_v6_resnet_export_probe_attempt2/resnet_tail.pt2',
               ROOT/'results/borrowplan_v6_resnet_export_probe_attempt2'),
}
now = time.monotonic_ns


def compute_pids():
    text = subprocess.check_output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid',
                                    '--format=csv,noheader'], text=True)
    return [dict(gpu=r.split(',')[0].strip(), pid=int(r.split(',')[1]))
            for r in text.splitlines() if r.strip()]


def configure():
    assert os.environ['CUDA_VISIBLE_DEVICES'] == GPU
    torch.set_num_threads(1)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False


def inputs(model):
    export, folder = MODELS[model]
    inventory = json.loads((folder/'report.json').read_text())
    values, hashes = [], {}
    for i in range(3):
        p = folder/f'case_{i}.pt'
        assert sha(p) == inventory['files'][p.name]
        hashes[str(p)] = sha(p)
        values.append(torch.load(p, map_location='cpu')['input'])
    return values, hashes


def make_program(model, example, late, method):
    export = MODELS[model][0]
    if method == 'auto-early':
        from owned_witness import WitnessProgram
        return WitnessProgram(torch.export.load(export), example, late_read=late)
    return ManualProgram(export, example, model, late, full=method == 'manual-full')


def start(program, method, x, publication, ready):
    return program.start(x, publication, ready)


def release_ready(ex, method, ptr):
    if method == 'auto-early':
        return ex.lease.can_release(ex.lease.bindings[ex.program.root].allocation)
    return ex.can_release()


def publish(ex, method):
    if method != 'auto-early':
        return ex.publish()
    values = ex.outputs()
    identities = ex.lease.publish_identity()
    versions = {b.version for row in identities.values() for b in row.values()}
    assert len(versions) == 1
    e, s, g = next(iter(versions))
    return values, dict(epoch=e, sequence=s, generation=g)


def cpu_values(values):
    return tuple(t.detach().cpu().contiguous() for t in values)


def tensor_hashes(values):
    return [hashlib.sha256(t.numpy().tobytes()).hexdigest() for t in cpu_values(values)]


def exact(a, b):
    assert len(a) == len(b)
    for x, y in zip(a, b):
        assert x.shape == y.shape and x.dtype == y.dtype
        assert torch.isfinite(x).all().item() and torch.equal(x, y)


def source_inventory():
    import sys
    paths = set(Path(__file__).parent.glob('*.py'))
    for name in ('core', 'export_backend', 'segmented_backend', 'owned_backend',
                 'owned_prepared', 'owned_witness', 'prepared_lease', 'witness_lease', 'torch_backend'):
        module = sys.modules.get(name)
        if module is not None:
            paths.add(Path(module.__file__).resolve())
    return {str(p): sha(p) for p in sorted(paths)}


def write_report(folder, report):
    (folder/'report.json').write_text(json.dumps(report, indent=2)+'\n')
