"""Persist the original generic runtime suite and grouped differential tests."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import unittest

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=False)
    log=io.StringIO()
    suite=unittest.defaultTestLoader.loadTestsFromNames(['test_core','test_batch_lease'])
    r=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
    status='COMPLETE' if r.wasSuccessful() else 'FAILED'
    report=dict(status=status,tests=r.testsRun,errors=len(r.errors),failures=len(r.failures),
        validator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        log=log.getvalue(),cuda_used=False)
    (a.output/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    (a.output/status).write_text(status+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='log'}))
    raise SystemExit(int(not r.wasSuccessful()))
