"""Actual ordered-overwrite experiments; never bypass the complete manual guard."""
import argparse
import copy
import json
import os
from pathlib import Path
import traceback
import torch
from core import Rejected
from manual_static import ManualRejected
from owned_witness import WitnessProgram
from study_common import *
from variants import edited_export, SUPPORTED, structural_hash
from evolved_manual import EvolvedManual


def event():
    e = torch.cuda.Event()
    e.record()
    return e


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--reviews', type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    report = dict(status='RUNNING', cases=[], stale_reviews=[], negatives=[], gpu_uuid=GPU,
                  performance_claim=False, reviews_sha256=sha(a.reviews), manual_guards_bypassed=False)
    try:
        assert not compute_pids(), 'foreign compute; no inference launched'
        configure()
        frozen = json.loads(a.reviews.read_text())
        assert frozen['status'] == 'COMPLETE' and not frozen['cuda_used']
        reviews = {(r['model'],r['edit']):r for r in frozen['reviews']}
        for model, (path, _) in MODELS.items():
            xs, hashes = inputs(model)
            example = xs[0].cuda()
            for edit in SUPPORTED:
                review = reviews[model, edit]
                snapshot = edited_export(path, model, edit)
                assert structural_hash(snapshot.graph) == review['graph_sha256']
                previous = 'late_read' if edit in ('remove_late_read','private_probe') else 'base'
                old = copy.deepcopy(reviews[model, previous])
                # Retarget only the descriptive edit label; leave the old graph binding intact.
                old['edit'] = edit
                changed = old['graph_sha256'] != review['graph_sha256']
                if changed:
                    try:
                        EvolvedManual(snapshot, example, old, model, edit)
                    except ManualRejected as e:
                        report['stale_reviews'].append(dict(model=model, edit=edit, previous=previous,
                                                           rejected=True, reason=str(e)))
                    else:
                        raise AssertionError('stale manual graph binding accepted')
                programs = {
                    'manual-full': EvolvedManual(snapshot,example,review,model,edit,full=True),
                    'manual-early': EvolvedManual(snapshot,example,review,model,edit),
                    'auto-early': WitnessProgram(snapshot,example),
                }
                auto = programs['auto-early']
                assert sorted(dict(auto.plan.obligations)[auto.root]) == review['readers']
                assert [n for n in auto._capsule.groups[0] if n in review['readers']][-1] == review['boundary']
                for sid, cpu in enumerate(xs):
                    x = cpu.cuda()
                    stream = torch.cuda.Stream()
                    pub = dict(epoch=101010, sequence=sid+1, generation=2*(sid+1))
                    ref = programs['manual-full'].start(x,pub,event())
                    ref.submit(0,stream).synchronize()
                    expected, identity = ref.publish()
                    expected = cpu_values(expected)
                    assert identity == pub
                    for method in ('manual-early','auto-early'):
                        key = f'{model}-{edit}-s{sid}-{method}'
                        folder = a.output/key
                        folder.mkdir()
                        x.copy_(cpu)
                        torch.cuda.synchronize()
                        before = tensor_hashes((x,))[0]
                        program = programs[method]
                        def rejects(name, fn):
                            try:
                                fn()
                            except (ManualRejected,Rejected):
                                report['negatives'].append(key+'-'+name)
                            else:
                                raise AssertionError('invalid operation accepted: '+key+'-'+name)
                        rejects('odd-generation',lambda:program.start(x,dict(pub,generation=3),event()))
                        ex = program.start(x,pub,event())
                        assert not release_ready(ex,method,x.data_ptr())
                        rejects('suffix-first',lambda:ex.submit(1,stream))
                        rejects('early-publish',lambda:publish(ex,method))
                        ex.submit(0,stream).synchronize()
                        read_done = now()
                        assert release_ready(ex,method,x.data_ptr())
                        ptr = x.untyped_storage().data_ptr()
                        with torch.inference_mode():
                            x.copy_(xs[(sid+1)%3])
                        torch.cuda.synchronize()
                        overwritten = now()
                        after = tensor_hashes((x,))[0]
                        assert before != after and ptr == x.untyped_storage().data_ptr()
                        suffix = now()
                        ex.submit(1,stream).synchronize()
                        actual, identity = publish(ex,method)
                        assert identity == pub
                        actual = cpu_values(actual)
                        exact(actual,expected)
                        rejects('duplicate-publish',lambda:publish(ex,method))
                        torch.save(dict(actual=actual,expected=expected),folder/'outputs.pt')
                        (folder/'artifact.json').write_text(json.dumps(program.artifact,indent=2)+'\n')
                        report['cases'].append(dict(key=key,model=model,edit=edit,source=sid,method=method,
                            publication=pub,published_identity=identity,review=review,input_hashes=hashes,
                            read_done_ns=read_done,overwrite_done_ns=overwritten,suffix_start_ns=suffix,
                            before_sha256=before,after_sha256=after,same_allocation=True,exact=True,
                            outputs_sha256=sha(folder/'outputs.pt'),artifact_sha256=sha(folder/'artifact.json')))
                        print('COMPLETE',key,flush=True)
                        del ex, actual
                    del ref, expected, x
                del programs, auto, snapshot
                torch.cuda.empty_cache()
        assert len(report['cases']) == 96 and len(report['negatives']) == 384
        assert len(report['stale_reviews']) == 14
        assert all(p['pid']==os.getpid() and p['gpu']==GPU for p in compute_pids())
        report.update(status='COMPLETE',sources=source_inventory())
        report['sources'].update({str(f):sha(f) for f in Path(__file__).parent.glob('*.py')})
    except BaseException:
        report.update(status='FAILED',traceback=traceback.format_exc())
        traceback.print_exc()
    write_report(a.output,report)
    (a.output/report['status']).write_text(report['status']+'\n')
    return int(report['status'] != 'COMPLETE')


if __name__ == '__main__':
    raise SystemExit(main())
