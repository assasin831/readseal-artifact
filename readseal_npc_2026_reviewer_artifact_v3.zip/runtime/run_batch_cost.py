"""Four-way paired cost: original automatic, grouped automatic and both manual paths."""
import argparse
import gc
import json
import os
from pathlib import Path
import random
import time
import traceback
import torch
import owned_witness
from batch_backend import BatchProgram
from study_common import *


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--repeat',type=int,required=True)
    a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=False)
    report=dict(status='RUNNING',repeat=a.repeat,cases=[],pid=os.getpid(),gpu_uuid=GPU,
                warmups=20,quartets=50,seed=101051+a.repeat,sources=source_inventory())
    try:
        assert 0<=a.repeat<8 and not compute_pids()
        configure()
        rng=random.Random(report['seed'])
        methods=['auto-early','auto-batched','manual-early','manual-full']
        for model in MODELS:
            xs,hashes=inputs(model)
            for late in (False,True):
                for sid,cpu in enumerate(xs):
                    assert all(p['pid']==os.getpid() and p['gpu']==GPU for p in compute_pids())
                    x=cpu.cuda()
                    programs={m:(BatchProgram(torch.export.load(MODELS[model][0]),x,late_read=late) if m=='auto-batched' else make_program(model,x,late,m)) for m in methods}
                    stream=torch.cuda.Stream()
                    ready=torch.cuda.Event()
                    ready.record()
                    ready.synchronize()
                    pub=dict(epoch=987654,sequence=1,generation=2)
                    def execute(method):
                        adapter='auto-early' if method=='auto-batched' else method
                        ex=start(programs[method],adapter,x,pub,ready)
                        ex.submit(0,stream)
                        if method!='manual-full':
                            ex.submit(1,stream)
                        ex.events[0].synchronize()
                        assert release_ready(ex,adapter,x.data_ptr())
                        ex.events[-1].synchronize()
                        ys,identity=publish(ex,adapter)
                        assert identity==pub
                        return ys
                    expected=tuple(t.clone() for t in execute('manual-full'))
                    torch.cuda.synchronize()
                    for _ in range(20):
                        for method in methods:
                            actual=execute(method)
                            exact(actual,expected)
                    records=[]
                    for trial in range(50):
                        order=list(methods)
                        rng.shuffle(order)
                        for position,method in enumerate(order):
                            torch.cuda.synchronize()
                            started=time.perf_counter_ns()
                            actual=execute(method)
                            torch.cuda.synchronize()
                            duration=time.perf_counter_ns()-started
                            exact(actual,expected)
                            records.append(dict(trial=trial,position=position,method=method,wall_ns=duration,exact=True))
                    key=f'{model}-s{sid}-{"late" if late else "base"}'
                    folder=a.output/key
                    folder.mkdir()
                    torch.save(dict(actual=cpu_values(actual),expected=cpu_values(expected)),folder/'outputs.pt')
                    for method in methods:
                        (folder/(method+'.json')).write_text(json.dumps(programs[method].artifact,indent=2)+'\n')
                    report['cases'].append(dict(model=model,source=sid,late=late,key=key,records=records,
                        input_hashes=hashes,output_sha256=sha(folder/'outputs.pt'),
                        artifacts={m:sha(folder/(m+'.json')) for m in methods},compute=compute_pids()))
                    assert all(p['pid']==os.getpid() and p['gpu']==GPU for p in report['cases'][-1]['compute'])
                    print('COMPLETE '+key,flush=True)
                    del programs,expected,actual,x
                    gc.collect()
                    torch.cuda.empty_cache()
        assert len(report['cases'])==12
        report['sources'].update({str(f):sha(f) for f in Path(__file__).parent.glob('*.py')})
        report['status']='COMPLETE'
    except BaseException:
        report.update(status='FAILED',traceback=traceback.format_exc())
        traceback.print_exc()
    write_report(a.output,report)
    (a.output/report['status']).write_text(report['status']+'\n')
    return 0 if report['status']=='COMPLETE' else 1


if __name__=='__main__':
    raise SystemExit(main())


