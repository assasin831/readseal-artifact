from dataclasses import asdict, replace
import itertools
import unittest

from core import Binding, Lease, Node, Rejected, Summary, TensorSpec, byte_time, compile_plan, digest


SPEC = TensorSpec((2, 3), (3, 1), "float32", "cpu")
FRESH = Summary((0,), implementation="trusted-fresh-v1")
VIEW = Summary((), aliases=(0,), completion="synchronous", implementation="trusted-view-v1")


class Event:
    def __init__(self, done=False):
        self.done = done

    def query(self):
        return self.done


def binding(allocation="p", sequence=2, spec=SPEC):
    return Binding(allocation, 24, 1, sequence, 2, digest(asdict(spec)), spec)


def fork_plan():
    return compile_plan(("x",), (Node("a", ("x",), FRESH), Node("b", ("x",), VIEW),
                         Node("c", ("b",), FRESH)), ("a", "c"), {"x": SPEC}, "exe")


def lease(plan=None, bindings=None):
    plan = plan or fork_plan()
    bindings = bindings or {r: binding() for r in plan.roots}
    return Lease(plan, bindings, "exe", {r: b.version for r, b in bindings.items()})


def submit(l, name, done=True):
    e = Event(done)
    l.begin(name)
    l.submitted(name, e)
    return e


class CoreTests(unittest.TestCase):
    def test_provenance_not_storage_lifetime(self):
        p = fork_plan()
        facts = dict(p.facts)
        self.assertEqual(facts["a"].provenance, {"x"})
        self.assertFalse(facts["a"].borrows)
        self.assertEqual(facts["b"].borrows, {"x"})
        self.assertEqual(dict(p.obligations)["x"], ("a", "c"))

    def test_delayed_reader_blocks_even_with_zero_inflight(self):
        l = lease()
        submit(l, "a")
        submit(l, "b")
        self.assertTrue(all(e.query() for e in l.events.values()))
        self.assertFalse(l.can_release("p"))
        e = submit(l, "c", False)
        self.assertFalse(l.can_release("p"))
        e.done = True
        self.assertTrue(l.can_release("p"))

    def test_two_stream_orders(self):
        for order in itertools.permutations(("a", "c")):
            l = lease()
            events = {"a": submit(l, "a", False)}
            submit(l, "b")
            events["c"] = submit(l, "c", False)
            events[order[0]].done = True
            self.assertFalse(l.can_release("p"))
            events[order[1]].done = True
            self.assertTrue(l.can_release("p"))

    def test_storage_release_does_not_erase_provenance(self):
        l = lease()
        for n in ("a", "b", "c"):
            submit(l, n)
        self.assertTrue(l.can_release("p"))
        result = l.publish_identity()
        self.assertEqual(result["c"]["x"].sequence, 2)
        with self.assertRaises(Rejected):
            l.publish_identity()

    def test_input_event_different_from_output_event(self):
        s = replace(FRESH, completion="input_consumed")
        p = compile_plan(("x",), (Node("engine", ("x",), s),), ("engine",), {"x": SPEC}, "exe")
        l = lease(p)
        read, out = Event(True), Event(False)
        l.begin("engine")
        with self.assertRaises(Rejected):
            l.submitted("engine", read)
        l.submitted("engine", read, out)
        self.assertTrue(l.can_release("p"))
        self.assertFalse(l.can_publish())
        out.done = True
        self.assertTrue(l.can_publish())

    def test_terminal_view_keeps_borrow(self):
        p = compile_plan(("x",), (Node("view", ("x",), VIEW),), ("view",), {"x": SPEC}, "exe")
        l = lease(p)
        submit(l, "view")
        self.assertFalse(l.can_release("p"))
        l.return_output_borrow("view")
        self.assertTrue(l.can_release("p"))

    def test_two_inputs_one_allocation_union(self):
        p = compile_plan(("x", "y"), (Node("a", ("x",), FRESH), Node("b", ("y",), FRESH)),
                         ("a", "b"), {"x": SPEC, "y": SPEC}, "exe")
        l = lease(p)
        submit(l, "a")
        self.assertFalse(l.can_release("p"))
        submit(l, "b")
        self.assertTrue(l.can_release("p"))
        self.assertEqual(l.sizes, {"p": 24})

    def test_distinct_allocations_can_close_independently(self):
        p = compile_plan(("x", "y"), (Node("a", ("x",), FRESH), Node("b", ("y",), FRESH)),
                         ("a", "b"), {"x": SPEC, "y": SPEC}, "exe")
        l = lease(p, {"x": binding("p"), "y": binding("q")})
        submit(l, "a")
        self.assertTrue(l.can_release("p"))
        self.assertFalse(l.can_release("q"))

    def test_aliases_cannot_bind_two_versions(self):
        p = compile_plan(("x", "y"), (Node("a", ("x",), FRESH),), ("a",),
                         {"x": SPEC, "y": SPEC}, "exe")
        with self.assertRaisesRegex(Rejected, "two versions"):
            lease(p, {"x": binding(), "y": binding(sequence=4)})

    def test_guard_mismatch_prelaunch(self):
        p = fork_plan()
        for b in (replace(binding(), spec=replace(SPEC, shape=(3, 2))),
                  replace(binding(), contract="wrong"), replace(binding(), generation=3)):
            with self.assertRaises(Rejected):
                lease(p, {"x": b})

    def test_publication_change_prelaunch(self):
        with self.assertRaisesRegex(Rejected, "publication changed"):
            Lease(fork_plan(), {"x": binding()}, "exe", {"x": (1, 4, 2)})

    def test_executable_change_prelaunch(self):
        with self.assertRaises(Rejected):
            Lease(fork_plan(), {"x": binding()}, "changed", {"x": binding().version})

    def test_tampered_plan_rejected(self):
        p = replace(fork_plan(), obligations=(("x", ("a",)),))
        with self.assertRaises(Rejected):
            lease(p)

    def test_unknown_completion_rejected(self):
        with self.assertRaises(Rejected):
            compile_plan(("x",), (Node("a", ("x",), replace(FRESH, completion="unknown")),),
                         ("a",), {"x": SPEC}, "exe")

    def test_mutating_borrow_rejected(self):
        with self.assertRaises(Rejected):
            compile_plan(("x",), (Node("a", ("x",), replace(FRESH, writes=(0,))),),
                         ("a",), {"x": SPEC}, "exe")

    def test_mutating_private_is_not_mutating_source(self):
        p = compile_plan(("x",), (Node("a", ("x",), FRESH),
                         Node("b", ("a",), replace(FRESH, aliases=(0,), writes=(0,)))),
                         ("b",), {"x": SPEC}, "exe")
        self.assertEqual(dict(p.obligations)["x"], ("a",))

    def test_new_provenance_through_private_mutation_rejected(self):
        with self.assertRaises(Rejected):
            compile_plan(("x", "y"), (Node("a", ("x",), FRESH),
                         Node("b", ("a", "y"), Summary((0, 1), (0,), (0,), implementation="add-inplace"))),
                         ("b",), {"x": SPEC, "y": SPEC}, "exe")

    def test_odd_sequence_is_legal_but_odd_generation_is_not(self):
        l = lease(bindings={"x": binding(sequence=3)})
        self.assertEqual(l.bindings["x"].sequence, 3)
        with self.assertRaisesRegex(Rejected, "generation"):
            lease(bindings={"x": replace(binding(), generation=3)})

    def test_graph_cycle_and_unknown_input_rejected(self):
        for nodes in ((Node("a", ("b",), FRESH), Node("b", ("a",), FRESH)),
                      (Node("a", ("missing",), FRESH),)):
            with self.assertRaises(Rejected):
                compile_plan(("x",), nodes, ("a",), {"x": SPEC}, "exe")

    def test_late_registration_impossible(self):
        with self.assertRaises(Rejected):
            lease().begin("new_reader")

    def test_out_of_order_submission_rejected(self):
        with self.assertRaises(Rejected):
            lease().begin("c")

    def test_abort_cancels_pending_not_inflight(self):
        l = lease()
        event = submit(l, "a", False)
        l.abort()
        self.assertFalse(l.can_release("p"))
        event.done = True
        self.assertTrue(l.can_release("p"))
        self.assertFalse(l.can_publish())
        with self.assertRaises(Rejected):
            l.begin("b")

    def test_started_work_without_witness_stays_owned(self):
        l = lease()
        l.begin("a")
        l.abort()
        self.assertFalse(l.can_release("p"))

    def test_no_abort_after_publish(self):
        l = lease()
        for n in ("a", "b", "c"):
            submit(l, n)
        l.publish_identity()
        with self.assertRaises(Rejected):
            l.abort()

    def test_byte_time_counts_physical_allocation_once(self):
        self.assertEqual(byte_time([("p", 10, 0, 3), ("p", 10, 1, 5),
                                    ("q", 20, 2, 4)]), 90)
        with self.assertRaises(Rejected):
            byte_time([("p", 10, 0, 3), ("p", 20, 1, 5)])

    def test_all_completion_subsets_match_independent_enumeration(self):
        # Oracle walks the graph backwards through alias edges, independently of
        # the forward analysis and its cached obligation table.
        p = fork_plan()
        by_name = {n.name: n for n in p.nodes}
        def aliases_root(value):
            if value == "x":
                return True
            node = by_name[value]
            return any(aliases_root(node.inputs[i]) for i in node.summary.aliases)
        readers = {n.name for n in p.nodes if any(aliases_root(n.inputs[i]) for i in n.summary.reads)}
        for bits in itertools.product((False, True), repeat=3):
            l = lease(p)
            events = {name: submit(l, name, bit) for name, bit in zip(("a", "b", "c"), bits)}
            self.assertEqual(l.can_release("p"), all(events[n].query() for n in readers))


if __name__ == "__main__":
    unittest.main(verbosity=2)
