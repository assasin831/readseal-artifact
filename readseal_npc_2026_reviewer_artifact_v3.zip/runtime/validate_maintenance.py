"""CPU-only raw-output and serialized-graph audit, without ReadSeal execution."""
import argparse
import hashlib
import json
from pathlib import Path
import traceback
import torch


def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):
            h.update(b)
    return h.hexdigest()


def references(value):
    if isinstance(value,dict):
        return {value['node']} if set(value)=={'node'} else set().union(*(references(x) for x in value.values()))
    if isinstance(value,list):
        return set().union(*(references(x) for x in value))
    return set()


def audit(run,reviews):
    r=json.loads((run/'report.json').read_text())
    f=json.loads(reviews.read_text())
    assert r['status']==f['status']=='COMPLETE' and (run/'COMPLETE').exists()
    assert sha(reviews)==r['reviews_sha256'] and not r['manual_guards_bypassed']
    expected={(model,edit,sid,method) for model in ('transfusion','resnet')
              for edit in ('base','alias_chain','early_read','middle_read','late_read','late_alias_read','remove_late_read','private_probe')
              for sid in range(3) for method in ('manual-early','auto-early')}
    assert len(r['cases'])==len(expected)==96
    assert {(c['model'],c['edit'],c['source'],c['method']) for c in r['cases']}==expected
    assert len(set(r['negatives']))==384 and len(r['stale_reviews'])==14
    assert all(c['rejected'] and 'new manual binding' in c['reason'] for c in r['stale_reviews'])
    assert len(f['unsupported'])==6
    snapshots={}; tensors=0
    for c in r['cases']:
        folder=run/c['key']; review=c['review']
        assert c['read_done_ns']<=c['overwrite_done_ns']<c['suffix_start_ns']
        assert c['before_sha256']!=c['after_sha256'] and c['same_allocation'] and c['exact']
        assert c['publication']==c['published_identity']
        assert sha(folder/'outputs.pt')==c['outputs_sha256']
        assert sha(folder/'artifact.json')==c['artifact_sha256']
        pair=torch.load(folder/'outputs.pt',map_location='cpu')
        extra=c['edit'] in ('early_read','middle_read','late_read','late_alias_read','private_probe')
        assert len(pair['actual'])==len(pair['expected'])==(9 if c['model']=='transfusion' else 1)+int(extra)
        for x,y in zip(pair['actual'],pair['expected']):
            assert torch.isfinite(x).all() and torch.isfinite(y).all() and torch.equal(x,y)
            tensors+=1
        art=json.loads((folder/'artifact.json').read_text())
        if c['method']=='manual-early':
            assert art['original_manual_guards_preserved'] and art['no_readseal_analysis_or_executor']
            assert art['review']==review and art['boundary']==review['boundary']
            continue
        graph=art['graph']; root=[x[1] for x in graph if x[0]=='placeholder'][-1]
        borrowed={root}; readers=[]; calls=[]
        for op,name,target,args,kwargs in graph:
            if op!='call_function':
                continue
            calls.append(name)
            deps=references(args)|references(kwargs)
            touches=bool(deps & borrowed)
            if touches:
                readers.append(name)
                # All declared dependency edits use only alias.default to carry source storage.
                assert target in ('aten.alias.default','aten.convolution.default','aten.add.Tensor','aten.clone.default')
                if target=='aten.alias.default':
                    borrowed.add(name)
        assert sorted(readers)==review['readers'] and readers[-1]==review['boundary']
        prefix=[n for n in art['groups'][0] if n in calls]
        suffix=[n for n in art['groups'][1] if n in calls]
        assert prefix+suffix==calls and prefix[-1]==review['boundary']
        assert not (set(art['live']) & borrowed)
        snapshots[c['model'],c['edit']]=dict(model=c['model'],edit=c['edit'],readers=readers,
            boundary=review['boundary'],prefix_operations=len(prefix),total_operations=len(calls),
            graph_sha256=review['graph_sha256'])
    for p,h in r['sources'].items():
        assert sha(p)==h
    for c in r['cases']:
        for p,h in c['input_hashes'].items():
            assert sha(p)==h
    return dict(cases=96,exact_output_tensors=tensors,stale_binding_rejections=14,
                runtime_negative_checks=384,unsupported_constructions=6,
                snapshots=list(snapshots.values()),unique_graphs=len({(m,v['graph_sha256']) for (m,e),v in snapshots.items()}),
                developer_time_measured=False,automatic_discovers_external_recipient_changes=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--run',type=Path,required=True)
    p.add_argument('--reviews',type=Path,required=True); p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=False)
    out=dict(status='RUNNING',validator_sha256=sha(__file__))
    try:
        out.update(audit(a.run,a.reviews),status='COMPLETE',report_sha256=sha(a.run/'report.json'))
    except BaseException:
        out.update(status='FAILED',traceback=traceback.format_exc()); traceback.print_exc()
    (a.output/'validation.json').write_text(json.dumps(out,indent=2)+'\n')
    (a.output/out['status']).write_text(out['status']+'\n')
    print(json.dumps(out),flush=True)
    raise SystemExit(int(out['status']!='COMPLETE'))
