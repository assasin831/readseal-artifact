"""An ordered composition-error control, not a record_stream correctness claim."""
import argparse
import json
from pathlib import Path
import traceback
import torch
from core import Lease
from torch_backend import bind,allocation,Ready
from native_loader import FrozenNative
from native_composition import compose,ChildReadDone,ChildOutputDone
from study_common import *


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=False)
    report=dict(status='RUNNING',cases=[],scope='intentionally incorrect local-only composition; ordered CUDA work',
                performance_claim=False,record_stream_contract_violated=False)
    try:
        assert not compute_pids()
        configure()
        component=FrozenNative(ROOT/'results/borrowplan_v2_native_composition_attempt1')
        xs,hashes=inputs('transfusion')
        originals=[x.cuda() for x in xs]
        for late in (False,True):
            auto=make_program('transfusion',originals[0],late,'auto-early')
            full=make_program('transfusion',originals[0],late,'manual-full')
            manual=make_program('transfusion',originals[0],late,'manual-early')
            references=[]
            stream=torch.cuda.Stream()
            for sid,x in enumerate(originals):
                e=torch.cuda.Event(); e.record()
                ref=full.start(x,dict(epoch=17,sequence=sid+1,generation=2*(sid+1)),e)
                ref.submit(0,stream).synchronize()
                value,_=ref.publish()
                references.append(cpu_values(value))
            for sid,original in enumerate(originals):
                x=original.clone()
                ready=torch.cuda.Event(); ready.record()
                pub=dict(epoch=123456,sequence=sid+1,generation=2*(sid+1))
                b=bind(x,**pub)
                plan=compose(auto,x,component)
                lease=Lease(plan,{'source':b},plan.executable,{'source':b.version})
                lease.begin('A')
                native=component.launch(x,ready)
                lease.submitted('A',native.read_done,native.output_done)
                lease.begin('B')
                view=x.view_as(x)
                lease.submitted('B',Ready())
                native.read_done.synchronize()
                a_done=now()
                native.output_done.synchronize()
                view.record_stream(stream)
                assert stream.query() and lease.states['C']=='pending'
                assert not lease.can_release(allocation(x))
                # Deliberately ignore C's enrolled loan. No C read is running:
                # overwrite finishes before C starts, avoiding a device data race.
                pending_state=dict(lease.states)
                with torch.inference_mode():
                    x.copy_(originals[(sid+1)%3])
                torch.cuda.synchronize()
                overwrite=now()
                e=torch.cuda.Event(); e.record()
                started=now()
                wrong=full.start(view,pub,e)
                wrong.submit(0,stream).synchronize()
                bad,identity=wrong.publish()
                bad=cpu_values(bad)
                exact(bad,references[(sid+1)%3])
                assert any(not torch.equal(u,v) for u,v in zip(bad,references[sid]))
                lease.abort()

                # Correct generated composition on a fresh invocation, not a
                # retry of the intentional bad-policy result.
                x=original.clone()
                ready=torch.cuda.Event(); ready.record()
                b=bind(x,**pub)
                plan=compose(auto,x,component)
                lease=Lease(plan,{'source':b},plan.executable,{'source':b.version})
                lease.begin('A')
                native=component.launch(x,ready)
                lease.submitted('A',native.read_done,native.output_done)
                lease.begin('B')
                view=x.view_as(x)
                lease.submitted('B',Ready())
                native.read_done.synchronize()
                assert not lease.can_release(allocation(x))
                lease.begin('C')
                ex=auto.start(view,pub,ready)
                lease.submitted('C',ChildReadDone(ex,allocation(x)),ChildOutputDone(ex))
                ex.submit(0,stream)
                ex.events[0].synchronize()
                assert lease.can_release(allocation(x))
                with torch.inference_mode():
                    x.fill_(123)
                torch.cuda.synchronize()
                ex.submit(1,stream)
                ex.wait()
                native.output_done.synchronize()
                good=cpu_values(ex.outputs())
                exact(good,references[sid])
                identities=lease.publish_identity()
                assert all(v.version==(pub['epoch'],pub['sequence'],pub['generation']) for r in identities.values() for v in r.values())

                # A complete independently managed composition: C is enrolled
                # as pending before A runs; no ReadSeal lease or child is used.
                x=original.clone()
                ready=torch.cuda.Event(); ready.record()
                held={'A':None,'C':None}
                native=component.launch(x,ready)
                held['A']=native.read_done
                native.read_done.synchronize()
                def manual_returnable():
                    return all(e is not None and e.query() for e in held.values())
                assert not manual_returnable()
                mx=manual.start(x.view_as(x),pub,ready)
                held['C']=mx.submit(0,stream)
                held['C'].synchronize()
                assert manual_returnable()
                with torch.inference_mode():
                    x.fill_(123)
                torch.cuda.synchronize()
                mx.submit(1,stream).synchronize()
                native.output_done.synchronize()
                manual_values,manual_identity=mx.publish()
                manual_values=cpu_values(manual_values)
                exact(manual_values,references[sid])
                assert manual_identity==pub
                key=f's{sid}-{"late" if late else "base"}'
                torch.save(dict(local_only=bad,generated=good,manual=manual_values,
                    requested=references[sid],replacement=references[(sid+1)%3]),a.output/(key+'.pt'))
                report['cases'].append(dict(key=key,source=sid,late=late,requested_publication=pub,
                    local_only_published_identity=identity,pending_state=pending_state,
                    obligations=dict(plan.obligations),a_read_done_ns=a_done,overwrite_done_ns=overwrite,
                    c_start_ns=started,local_only_wrong=True,generated_exact=True,manual_exact=True,
                    outputs_sha256=sha(a.output/(key+'.pt'))))
                print('COMPLETE '+key,flush=True)
        report.update(status='COMPLETE',sources=source_inventory(),native=component.receipt,
                      input_hashes=hashes,incorrect_policy_cases=6,correct_generated_cases=6,correct_manual_cases=6,
                      native_sources={str(ROOT/p):sha(ROOT/p) for p in (
                          'prototype_borrowplan_v3_attempt1/native_loader.py',
                          'prototype_borrowplan_v2_composition_attempt2/native_composition.py',
                          'results/borrowplan_v2_native_composition_attempt1/native.engine',
                          'results/borrowplan_v2_native_composition_attempt1/report.json')})
    except BaseException:
        report.update(status='FAILED',traceback=traceback.format_exc())
        traceback.print_exc()
    write_report(a.output,report)
    (a.output/report['status']).write_text(report['status']+'\n')
    return 0 if report['status']=='COMPLETE' else 1


if __name__=='__main__':
    raise SystemExit(main())
