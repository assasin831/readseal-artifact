"""Twelve second-model CUDA conformance cases; no timing inference."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import time
import traceback

import torch
import core
import export_backend
import owned_backend
import owned_prepared
import prepared_lease
import owned_witness
import witness_lease
import segmented_backend
import torch_backend
import measure_execution_cost
from core import Rejected
from export_backend import Program
from owned_witness import WitnessProgram
from measure_execution_cost import active_compute, exact, sha, GPU
from torch_backend import allocation


def tensor_sha(t):
    return hashlib.sha256(t.detach().contiguous().cpu().numpy().tobytes()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--export-run', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    report = dict(status='RUNNING', schema='borrowplan-resnet-witness-conformance-v6',
                  performance_claim=False, cases=[], negatives=[], pid=os.getpid(), gpu_uuid=GPU,
                  runner_sha256=sha(__file__), source_sha256={str(Path(m.__file__).resolve()): sha(m.__file__) for m in
                  (core, export_backend, owned_backend, owned_prepared, prepared_lease, owned_witness,
                   witness_lease, segmented_backend, torch_backend, measure_execution_cost)},
                  export_run=str(a.export_run), export_report_sha256=sha(a.export_run / 'report.json'))
    try:
        assert os.environ['CUDA_VISIBLE_DEVICES'] == GPU
        report['preflight'] = active_compute()
        assert not report['preflight'], 'GPUs occupied; no launch'
        probe = json.loads((a.export_run / 'report.json').read_text())
        assert probe['status'] == 'COMPLETE' and (a.export_run / 'COMPLETE').exists()
        for name, expected in probe['files'].items():
            assert sha(a.export_run / name) == expected
        assert probe['unsupported'] == {'aten.mean.dim': 'unregistered ATen operator: aten.mean.dim'}
        torch.set_num_threads(1)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        exported = torch.export.load(a.export_run / 'resnet_tail.pt2')

        def reject(name, fn):
            try:
                fn()
            except Rejected:
                report['negatives'].append(name)
            else:
                raise AssertionError('illegal transition accepted: ' + name)

        for sid in range(3):
            original = torch.load(a.export_run / f'case_{sid}.pt', map_location='cpu')['input'].cuda()
            for late in (False, True):
                for schedule in ('synchronous', 'eager-private'):
                    assert all(p['pid'] == os.getpid() and p['gpu'] == GPU for p in active_compute())
                    x = original.clone()
                    reference = Program(exported, x, late_read=late)
                    graph = torch.fx.GraphModule(torch.nn.Module(), copy.deepcopy(reference.graph))
                    args = tuple(x if n.name == reference.root else reference.state[n.name]
                                 for n in reference.graph.nodes if n.op == 'placeholder')
                    with torch.inference_mode():
                        expected = tuple(t.detach().clone() for t in graph(*args))
                    torch.cuda.synchronize()
                    program = WitnessProgram(exported, x, late_read=late)
                    stream = torch.cuda.Stream()
                    key = f's{sid}-{"late" if late else "base"}-{schedule}'
                    folder = a.output / key
                    folder.mkdir()
                    (folder / 'artifact.json').write_text(json.dumps(program.artifact, indent=2) + '\n')
                    reject(key + '-shape', lambda: program.start(x.flatten()))
                    reject(key + '-generation', lambda: program.start(x, {'generation': 3}))
                    reject(key + '-sequence', lambda: program.start(x, {'sequence': 0}))
                    abandoned = program.start(x)
                    abandoned.ready.synchronize()
                    abandoned.lease.abort()
                    reject(key + '-aborted', lambda: abandoned.submit(0, stream))
                    publication = dict(epoch=2**40 + sid, sequence=2 + sid, generation=4)
                    ex = program.start(x, publication)
                    source = allocation(x)
                    before_sha = tensor_sha(x)
                    assert not ex.lease.can_release(source)
                    reject(key + '-suffix-first', lambda: ex.submit(1, stream))
                    reject(key + '-early-output', ex.outputs)
                    reject(key + '-early-publish', ex.lease.publish_identity)
                    ex.submit(0, stream)
                    reject(key + '-repeat-prefix', lambda: ex.submit(0, stream))
                    foreign = torch.cuda.Stream()
                    reject(key + '-stream', lambda: ex.submit(1, foreign))
                    if schedule == 'eager-private':
                        ex.submit(1, stream)
                    ex.wait_stage(0)
                    assert ex.lease.can_release(source)
                    incomplete = not ex.lease.can_publish()
                    if schedule == 'synchronous':
                        assert incomplete
                    with torch.inference_mode():
                        x.fill_(123)
                    torch.cuda.synchronize()
                    reuse_done_ns = time.monotonic_ns()
                    assert allocation(x) == source and not torch.equal(x, original)
                    if schedule == 'synchronous':
                        ex.submit(1, stream)
                    ex.wait()
                    actual = ex.outputs()
                    exact(actual, expected)
                    identities = ex.lease.publish_identity()
                    assert all(b.version == (publication['epoch'], publication['sequence'], publication['generation'])
                               for row in identities.values() for b in row.values())
                    torch.save(dict(actual=tuple(t.detach().cpu() for t in actual),
                                    expected=tuple(t.detach().cpu() for t in expected)), folder / 'outputs.pt')
                    report['cases'].append(dict(key=key, source=sid, late=late, schedule=schedule,
                        source_sha256=sha(a.export_run / f'case_{sid}.pt'), artifact_sha256=sha(folder / 'artifact.json'),
                        before_bytes_sha256=before_sha, after_bytes_sha256=tensor_sha(x),
                        executable=program.executable, complete_reader_set=list(dict(program.plan.obligations)[program.root]),
                        receipts=ex.receipts, reused_same_allocation=True, reuse_done_ns=reuse_done_ns,
                        output_incomplete_at_release=incomplete, old_publication_preserved=True,
                        exact=True, publication=publication, output_sha256=sha(folder / 'outputs.pt')))
                    print('COMPLETE ' + key, flush=True)
        assert len(report['cases']) == 12 and len(report['negatives']) == 108
        report['postflight'] = active_compute()
        assert all(p['pid'] == os.getpid() and p['gpu'] == GPU for p in report['postflight'])
        report['status'] = 'COMPLETE'
        (a.output / 'COMPLETE').write_text('Second-model generated-plan conformance, not performance.\n')
    except BaseException as exc:
        report.update(status='FAILED', error=str(exc))
        (a.output / 'FAILED').write_text(type(exc).__name__ + '\n')
        (a.output / 'traceback.txt').write_text(traceback.format_exc())
    (a.output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(status=report['status'], cases=len(report['cases']))))
    return 0 if report['status'] == 'COMPLETE' else 1


if __name__ == '__main__':
    raise SystemExit(main())
