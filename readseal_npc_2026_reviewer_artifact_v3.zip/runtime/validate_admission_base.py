"""Reconstruct arrival accounting, source/output identity, reuse and byte-time."""
import argparse
import hashlib
import json
from pathlib import Path
import traceback
import numpy as np
import torch
from manual_static import sha


def audit_cell(folder):
    r=json.loads((folder/'report.json').read_text())
    assert r['status']=='COMPLETE' and (folder/'COMPLETE').exists()
    c=r['cell']
    n=c['consumers']
    begin,end=r['cohort_start_ns'],r['cohort_end_ns']
    arrivals=r['producer']
    sink=json.loads((folder/'sink.json').read_text())
    consumers=[x for i in range(n) for x in json.loads((folder/f'consumer-{i}.json').read_text())['rows']]
    for i in range(n):
        worker=json.loads((folder/f'consumer-{i}.json').read_text())
        if 'sources' in worker:
            for p,h in worker['sources'].items():
                assert sha(p)==h
            assert sha(folder/f'consumer-{i}-artifact.json')==worker['artifact_sha256']
    refs=[]
    for i in range(3):
        ts=torch.load(folder/f'reference-{i}.pt',map_location='cpu')
        refs.append([hashlib.sha256(t.contiguous().numpy().tobytes()).hexdigest() for t in ts])
    assert len({tuple(h) for h in refs})==3
    for i,h in enumerate(refs):
        assert h==r['references'][i]['hashes']
    assert len({x['tick'] for x in arrivals})==len(arrivals)
    for tick,x in enumerate(arrivals):
        assert x['tick']==tick
        assert x['scheduled_ns']==r['origin_ns']+round(tick*1e9/c['rate_hz'])
        assert x['cohort']==(begin<=x['scheduled_ns']<end)
    by_tick={x['tick']:x for x in arrivals}
    received={(x['tick'],x['consumer']):x for x in consumers}
    outputs={(x['tick'],x['consumer']):x for x in sink}
    expected={(x['tick'],i) for x in arrivals for i,yes in enumerate(x['enqueued']) if yes}
    assert len(consumers)==len(received) and len(sink)==len(outputs)
    assert set(received)==set(outputs)==expected
    for key,out in outputs.items():
        x=received[key]
        producer=by_tick[x['tick']]
        for field in ('sequence','slot','source_id','scheduled_ns','identity','cohort'):
            assert out[field]==x[field]
        assert x['sequence']==producer['sequence'] and x['slot']==producer['slot']
        assert x['observed_sequence']==x['sequence'] and x['observed_source']==producer['source_id']==x['source_id']
        assert x['identity']==dict(epoch=987654,sequence=x['sequence'],generation=x['sequence']*2)
        assert out['actual_hashes']==refs[x['source_id']]
        assert out['matching_reference_sources']==[x['source_id']]
        assert producer['write_done_ns']<=producer['commit_begin_ns']<=x['received_ns']
        assert x['received_ns']<=x['admission_ns']<=x['read_done_ns']<=x['release_begin_ns']<=x['release_end_ns']
        assert x['release_end_ns']<=x['output_done_ns']<=x['sink_enqueue_ns']<=out['publish_ns']
        assert out['deadline_met']==(out['publish_ns']-producer['scheduled_ns']<=round(c['deadline_ms']*1e6))
        assert out['verified_timely']==out['deadline_met']
        assert out['output_equal'] and out['provenance_verified'] and out['finite'] and out['published']
    # The writer is allowed after actual loan return, whose exact instant lies
    # within [release_begin, release_end]. Require completion before reuse;
    # do not infer GPU-kernel overlap from a host observation timestamp.
    writes=[x for x in arrivals if 'sequence' in x]
    previous={}
    reuses=0
    reused_before_handoff=0
    intervals=[]
    for x in writes:
        slot=x['slot']
        if slot in previous:
            prior=previous[slot]
            for cid,yes in enumerate(prior['enqueued']):
                if yes:
                    old=received[(prior['tick'],cid)]
                    assert old['read_done_ns']<=x['write_start_ns']
                    reuses+=1
                    reused_before_handoff+=x['write_start_ns']<outputs[(prior['tick'],cid)]['publish_ns']
        previous[slot]=x
        finish=max(received[(x['tick'],i)]['release_end_ns'] if yes else x['cancel_returns_ns'][str(i)]
                   for i,yes in enumerate(x['enqueued']))
        intervals.append(dict(slot=slot,sequence=x['sequence'],start_ns=x['commit_begin_ns'],end_ns=finish))
    assert intervals==r['intervals']
    # Independently integrate union by endpoint sweep, not the runner's merge.
    total=0
    for slot in range(c['ring']):
        events=[]
        for x in intervals:
            a,b=max(begin,x['start_ns']),min(end,x['end_ns'])
            if x['slot']==slot and b>a:
                events.extend(((a,1),(b,-1)))
        active=0
        last=begin
        for t,d in sorted(events):
            if active:
                total+=t-last
            active+=d
            assert active>=0
            last=t
        assert active==0
    bs=total*r['source_bytes']/1e9
    assert abs(bs-r['protected_byte_seconds'])<1e-4
    assert 0<=bs<=r['pool_bytes']*c['measure_seconds']+1e-4
    cohort=[x for x in arrivals if x['cohort']]
    published=[x for x in sink if x['cohort']]
    timely=sum(x['deadline_met'] for x in published)
    producer_late=sum(x['drop_reason']=='producer_late' for x in cohort)*n
    exhausted=sum(x['drop_reason']=='pool_exhausted' for x in cohort)*n
    queue_loss=sum(sum(not yes for yes in x['enqueued']) for x in cohort if x['drop_reason'] is None)
    credit_loss=sum(x['drop_reason']=='credit_exhausted' for x in cohort)*n
    assert len(cohort)*n==producer_late+exhausted+credit_loss+queue_loss+len(published)
    assert r['arrivals']==len(cohort)*n and r['publications']==len(published) and r['timely']==timely
    assert r['goodput_hz']==timely/c['measure_seconds']
    assert r['pool_final']['counters']['grants']==r['pool_final']['counters']['releases']
    for path,h in r['sources'].items():
        assert sha(path)==h
    for p in folder.glob('sample-*.npz'):
        cid,sid=(int(v[1:]) for v in p.stem.split('-')[1:])
        with np.load(p,allow_pickle=False) as z:
            hashes=[hashlib.sha256(z[f'output_{i}'].tobytes()).hexdigest() for i in range(len(z.files))]
            assert hashes==refs[sid]
    for sample in r['memory_samples']:
        assert all(p['gpu']==r['gpu_uuid'] and p['pid'] in r['worker_pids'] for p in sample['compute'])
    return dict(method=r['method'],arrivals=r['arrivals'],publications=len(published),timely=timely,
        goodput_hz=r['goodput_hz'],correct_late=len(published)-timely,producer_late=producer_late,
        pool_exhausted=exhausted,credit_exhausted=credit_loss,queue_loss=queue_loss,protected_byte_seconds=bs,
        mean_protected_mib=bs/c['measure_seconds']/2**20,device_peak_mib=r['device_peak_bytes']/2**20,
        actual_reuse_recipient_checks=reuses,reuse_before_output_handoff=reused_before_handoff,
        run_sha256=sha(folder/'report.json'),sink_sha256=sha(folder/'sink.json'))


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--run',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=False)
    result=dict(status='RUNNING',validator_sha256=sha(__file__),cases=[],formal=False)
    try:
        top=json.loads((a.run/'report.json').read_text())
        assert top['status']=='COMPLETE' and len(top['cases'])==3
        for method in ('auto-early','manual-early','manual-full'):
            result['cases'].append(audit_cell(a.run/method))
        result.update(status='COMPLETE',interpretation='pilot only; no general benefit or equivalence claim')
    except BaseException:
        result.update(status='FAILED',traceback=traceback.format_exc())
    (a.output/'report.json').write_text(json.dumps(result,indent=2)+'\n')
    (a.output/result['status']).write_text(result['status']+'\n')
    print(json.dumps(result))
    return 0 if result['status']=='COMPLETE' else 1


if __name__=='__main__':
    raise SystemExit(main())


