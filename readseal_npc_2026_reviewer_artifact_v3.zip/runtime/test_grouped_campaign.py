"""CPU tests of dispatch and frozen scheduling, without constructing a model."""
import json
from pathlib import Path
import unittest
from unittest.mock import patch

import launch_grouped_formal as launch
import run_grouped_admission as run


class CampaignTests(unittest.TestCase):
    def test_complete_schedule(self):
        plan = json.loads((Path(__file__).parent/'grouped_formal_plan.json').read_text())
        rows = launch.schedule(plan)
        self.assertEqual(rows, launch.schedule(plan))
        for repeat in range(6):
            for condition in plan['conditions']:
                selected = [r for r in rows if r['repeat'] == repeat and r['condition'] == condition]
                self.assertEqual({r['method'] for r in selected}, set(run.METHODS))
                self.assertEqual(len(selected), 4)
                self.assertTrue(all(r['cell'] == dict(plan['common'], **condition) for r in selected))

    def test_grouped_dispatch(self):
        with patch.object(run, 'GroupedComposition') as grouped, patch.object(run, 'AutoComposition') as original:
            self.assertIs(run.factory('transfusion', 'input', False, 'auto-batched'), grouped.return_value)
            grouped.assert_called_once_with('input', False)
            original.assert_not_called()

    def test_manual_full_dispatch(self):
        with patch.object(run, 'ManualComposition') as manual:
            run.factory('transfusion', 'input', True, 'manual-full')
            manual.assert_called_once_with('input', True, full=True)

    def test_spawn_wrapper_installs_child_factory(self):
        with patch.object(run.abc, 'factory', None), patch.object(run.abc, 'consumer') as consumer:
            run.consumer('sentinel')
            self.assertIs(run.abc.factory, run.factory)
            consumer.assert_called_once_with('sentinel')

    def test_unknown_method_rejected(self):
        with self.assertRaises(AssertionError):
            run.factory('transfusion', 'input', False, 'unknown')


if __name__ == '__main__':
    unittest.main()
