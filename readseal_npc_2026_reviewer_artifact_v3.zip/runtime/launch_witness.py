"""Fresh serial gates for V5; no retries or overwrites."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback

ROOT = Path('/www/readseal_ipdps_revision_v6')
SOURCE = ROOT / 'prototype_borrowplan_v6_witness_attempt1'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--stage', choices=('cpu', 'correctness', 'overlap', 'pilot'), required=True)
    a = p.parse_args()
    output = ROOT / ('results/borrowplan_v6_witness_' + a.stage + '_attempt1-launch')
    assert not output.exists()
    with (ROOT / 'borrowplan_gpu0.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        output.mkdir()
        (output / 'pid').write_text(str(os.getpid()) + '\n')
        report = dict(status='RUNNING', stage=a.stage,
                      sources={str(p): sha(p) for p in SOURCE.iterdir() if p.is_file()})
        try:
            base_validation = ROOT / 'results/borrowplan_v5_prepared_correctness_attempt1-validation/validation.json'
            base = json.loads(base_validation.read_text())
            base_report = ROOT / 'results/borrowplan_v5_prepared_correctness_attempt1/report.json'
            assert base['status'] == 'COMPLETE' and base['report_sha256'] == sha(base_report)
            for path, expected in json.loads(base_report.read_text())['source_sha256'].items():
                assert sha(path) == expected
            report['prepared_base_validation_sha256'] = sha(base_validation)
            previous = {'correctness': 'cpu', 'overlap': 'correctness', 'pilot': 'overlap'}
            if a.stage in previous:
                prior = ROOT / ('results/borrowplan_v6_witness_' + previous[a.stage] + '_attempt1-launch/report.json')
                data = json.loads(prior.read_text())
                assert data['status'] == 'COMPLETE'
                for name, expected in data['sources'].items():
                    assert sha(name) == expected
                report['previous_gate_sha256'] = sha(prior)
            if a.stage in ('overlap', 'pilot'):
                validation = ROOT / ('results/borrowplan_v6_witness_' + previous[a.stage] + '_attempt1-validation/validation.json')
                assert json.loads(validation.read_text())['status'] == 'COMPLETE'
                report['correctness_validation_sha256'] = sha(validation)
            dependencies = [ROOT / name for name in ('prototype_borrowplan_v6_witness_attempt1', 'prototype_borrowplan_v5_prepared_attempt1', 'prototype_borrowplan_v5_owned_attempt2',
                'prototype_borrowplan_v4_segmented_attempt1', 'prototype_borrowplan_v4_multiprocess_attempt1',
                'prototype_borrowplan_v3_cost_attempt2', 'prototype_borrowplan_v1_attempt2',
                'prototype_borrowplan_v2_execution_attempt4', 'prototype_borrowplan_v2_composition_attempt2',
                'sdk_trt_10_3_attempt2/packages')]
            env = dict(os.environ, PYTHONPATH=':'.join(map(str, dependencies)),
                CUDA_VISIBLE_DEVICES='' if a.stage == 'cpu' else 'GPU-f3b314a8-3058-e0be-694c-76f4227afb7d',
                OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
                PYTHONDONTWRITEBYTECODE='1', CUDA_CACHE_PATH=str(output / 'cuda-cache'))
            command = [sys.executable, '-B', str(SOURCE / ('test_witness_cpu.py' if a.stage == 'cpu' else 'run_witness.py')),
                '--export', str(ROOT / 'inputs/transfusion_borrowplan_v2/head_export.pt2'),
                '--cases', str(ROOT / 'inputs/transfusion_borrowplan_v2_oracle')]
            if a.stage != 'cpu':
                command += ['--mode', a.stage, '--output', str(ROOT / ('results/borrowplan_v6_witness_' + a.stage + '_attempt1'))]
            with (output / 'run.log').open('x') as log:
                code = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
            report['exit_code'] = code
            assert code == 0, 'gate failed; preserved without retry'
            report['log_sha256'] = sha(output / 'run.log')
            report['status'] = 'COMPLETE'
            (output / 'COMPLETE').write_text('Gate complete in declared mode.\n')
        except BaseException as exc:
            report.update(status='FAILED', error=str(exc))
            (output / 'FAILED').write_text(type(exc).__name__ + '\n')
            (output / 'traceback.txt').write_text(traceback.format_exc())
        (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report))
        return 0 if report['status'] == 'COMPLETE' else 1


if __name__ == '__main__':
    raise SystemExit(main())
