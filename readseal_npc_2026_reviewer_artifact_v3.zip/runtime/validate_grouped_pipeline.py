"""CPU-only tensor, composition, receipt and credit audits for four paths."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import traceback

import torch
from common import sha
from validate_admission_base import audit_cell
import validate_admission
import validate_abc


METHODS = ('auto-early', 'auto-batched', 'manual-early', 'manual-full')


def check_artifact(art, method):
    assert art['native']['engine_sha256'] == 'e16e10603b9a5508995331576c2f8863ecbfb380041742eb400024789d5fbc97'
    assert art['native']['sdk'] == '10.3.0'
    if method.startswith('auto'):
        assert set(art['obligations']['source']) == {'A', 'C'}
        if method == 'auto-batched':
            assert art['schema'] == 'readseal-grouped-abc-v11'
            assert art['grouping_only'] and not art['guard_elision']
            child = art['child']
            assert child['schema'] == 'borrowplan-batched-witness-v10'
            assert child['guard_schedule'] == 'admission and both submissions; unchanged state, function, stream, alias checks'
            root = Path('/www/readseal_ipdps_revision_v6/prototype_borrowplan_v10_batch_attempt1')
            assert child['batch_backend_sha256'] == sha(root/'batch_backend.py')
            assert child['batch_lease_sha256'] == sha(root/'batch_lease.py')
    else:
        assert art['complete_enrollment'] == ['A', 'C']
        assert not art['automatic_plan_consumed'] and not art['checked_child_consumed']
        assert art['full'] == (method == 'manual-full')
        assert art['child']['no_readseal_analysis_or_executor']


def gate(folder):
    r = json.loads((folder/'report.json').read_text())
    assert r['status'] == 'COMPLETE' and (folder/'COMPLETE').is_file()
    assert not (folder/'FAILED').exists() and not r['performance_claim']
    assert r['gpu_uuid'] == 'GPU-f3b314a8-3058-e0be-694c-76f4227afb7d'
    keys = [(x['late'], x['source_id'], x['method']) for x in r['cases']]
    assert len(keys) == 24 and set(keys) == set(itertools.product((False, True), range(3), METHODS))
    tensors, refs = 0, set()
    for row in r['cases']:
        for field in ('output', 'reference', 'artifact'):
            path = (folder/row[field]).resolve()
            assert path.is_relative_to(folder.resolve()) and sha(path) == row[field+'_sha256']
        actual = torch.load(folder/row['output'], map_location='cpu', weights_only=True)
        reference = torch.load(folder/row['reference'], map_location='cpu', weights_only=True)
        assert len(actual) == len(reference) == len(row['output_hashes']) == (11 if row['late'] else 10)
        assert actual[0].shape == (1, 128)
        for x, y, digest in zip(actual, reference, row['output_hashes']):
            assert x.shape == y.shape and x.dtype == y.dtype
            assert bool(torch.isfinite(x).all() and torch.isfinite(y).all()) and torch.equal(x, y)
            assert hashlib.sha256(x.contiguous().numpy().tobytes()).hexdigest() == digest
            tensors += 1
        check_artifact(json.loads((folder/row['artifact']).read_text()), row['method'])
        assert row['exact'] and row['ordered_overwrite'] and row['duplicate_publication_rejected']
        assert row['complete_native_and_model_outputs']
        assert row['publication'] == dict(epoch=112, sequence=100+row['source_id'], generation=2*(100+row['source_id']))
        refs.add(row['reference'])
    assert len(refs) == 6
    for path, digest in {**r['sources'], **r['input_hashes']}.items():
        assert sha(path) == digest
    return dict(cases=24, exact_output_tensors=tensors, references=6,
                complete_native_and_child_outputs=True, performance_claim=False)


def cell(folder):
    out = audit_cell(folder)
    r = json.loads((folder/'report.json').read_text())
    assert r['method'] in METHODS
    for i in range(r['cell']['consumers']):
        check_artifact(json.loads((folder/f'consumer-{i}-artifact.json').read_text()), r['method'])
        worker = json.loads((folder/f'consumer-{i}.json').read_text())
        for row in worker['rows']:
            trace = row['composition']
            assert row['admission_ns'] <= trace['enrolled_ns'] <= trace['a_submitted_ns'] <= trace['c_prefix_submitted_ns'] <= row['read_done_ns']
            assert row['native_shape'] == [1, 128] and row['complete_ab_outputs']
    for ref in r['references']:
        assert len(ref['hashes']) == (11 if r['cell']['late'] else 10)
    out.update(complete_native_and_child_outputs=True, gpu_uuid=r['gpu_uuid'])
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--run', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--kind', choices=('gate', 'cell'), required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    result = dict(status='RUNNING', cuda_used=False, inference_executed=False)
    try:
        if a.kind == 'gate':
            result.update(gate(a.run))
        else:
            # Reuse receipt-credit reconstruction without relabeling a grouped
            # result as an original automatic or manual result.
            validate_abc.cell = cell
            result.update(validate_admission.audit(a.run))
        result.update(status='COMPLETE', report_sha256=sha(a.run/'report.json'),
                      validator_sha256=sha(__file__))
    except BaseException:
        result.update(status='FAILED', traceback=traceback.format_exc())
        traceback.print_exc()
    (a.output/'validation.json').write_text(json.dumps(result, indent=2)+'\n')
    (a.output/result['status']).write_text(result['status']+'\n')
    print(json.dumps(result), flush=True)
    return int(result['status'] != 'COMPLETE')


if __name__ == '__main__':
    raise SystemExit(main())
