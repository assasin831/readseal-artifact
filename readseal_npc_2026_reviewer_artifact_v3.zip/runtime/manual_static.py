"""Independent fixed-export manual lifetime implementation, not ReadSeal code.

The integrator reviews and pins the explicit boundary for each export/variant.
FX construction below only carries live Python values across that fixed point;
it performs no source alias analysis and imports no ReadSeal module.
"""
import copy
import hashlib
import json
import marshal
import types

import torch
from torch.fx.node import map_arg
from torch.utils._pytree import tree_flatten


class ManualRejected(RuntimeError):
    pass


EXPORTS = {
    'transfusion': '8efaa67aa6884d0c9aec6fff442e9a50b683a290d856abef390db1f034ccabbd',
    'resnet': '8c633d290c2cd33c52f80b45ff1c01db962771db5faec53ab5417522f2222bff',
}
# Reviewed against the fixed source graph, not copied from an automatic plan.
BASE_BOUNDARY = {'transfusion': 'convolution', 'resnet': 'add'}


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def canon(x):
    if isinstance(x, torch.fx.Node):
        return {'node': x.name}
    if isinstance(x, (list, tuple)):
        return [canon(v) for v in x]
    if isinstance(x, dict):
        return {str(k): canon(v) for k, v in x.items()}
    if isinstance(x, (str, int, float, bool)) or x is None:
        return x
    return str(x)


def graph_records(g):
    return [(n.op, n.name, str(n.target), canon(n.args), canon(n.kwargs)) for n in g.nodes]


def tensor_meta(t):
    return (tuple(t.shape), tuple(t.stride()), t.storage_offset(), str(t.dtype), str(t.device))


def state_token(t):
    return tensor_meta(t) + (t.untyped_storage().data_ptr(), t._version, t.requires_grad)


def fixed_graph(exported, device, late):
    sig = exported.graph_signature
    if len(sig.user_inputs) != 1 or sig.buffers_to_mutate:
        raise ManualRejected('fixed single-input read-only inference only')
    g = copy.deepcopy(exported.graph)
    root = next(n for n in g.nodes if n.name == sig.user_inputs[0])
    for n in g.nodes:
        if n.op == 'call_function' and n.kwargs.get('device') is not None:
            if str(n.target) not in ('aten.arange.start_step', 'aten._to_copy.default'):
                raise ManualRejected('unreviewed device retarget')
            n.kwargs = dict(n.kwargs, device=device)
    output = next(n for n in g.nodes if n.op == 'output')
    boundary = None
    if late:
        with g.inserting_before(output):
            clone = g.call_function(torch.ops.aten.clone.default, (root,))
            mean = g.call_function(torch.ops.aten.mean.default, (clone,))
        output.args = (tuple(output.args[0]) + (mean,),)
        boundary = clone.name
    g.lint()
    names = dict(sig.inputs_to_parameters, **sig.inputs_to_buffers)
    state = {n: exported.state_dict[k].detach().to(device).clone() for n, k in names.items()}
    return g, root.name, state, boundary


def manual_partition(graph, stop):
    nodes = list(graph.nodes)
    calls = [n for n in nodes if n.op == 'call_function']
    positions = [i for i, n in enumerate(calls) if n.name == stop]
    if len(positions) != 1:
        raise ManualRejected('manual boundary is absent or ambiguous')
    left, right = calls[:positions[0]+1], calls[positions[0]+1:]
    placeholders = [n for n in nodes if n.op == 'placeholder']
    output = next(n for n in nodes if n.op == 'output')
    produced_right = set(right)
    required = {d for n in right + [output] for d in n.all_input_nodes if d not in produced_right}
    carry = [n for n in nodes if n in required]
    first, second = torch.fx.Graph(), torch.fx.Graph()
    env = {}
    for n in placeholders + left:
        env[n] = first.node_copy(n, lambda d: env[d])
    first.output(tuple(env[n] for n in carry))
    env = {n: second.placeholder(n.name) for n in carry}
    for n in right + [output]:
        env[n] = second.node_copy(n, lambda d: env[d])
    first.lint()
    second.lint()
    return (first, second), tuple(n.name for n in carry)


def own_function(graph):
    module = torch.fx.GraphModule(torch.nn.Module(), graph)
    original = module.forward.__func__
    code = original.__code__
    if code.co_freevars or original.__defaults__ or original.__kwdefaults__:
        raise ManualRejected('unreviewed function closure')
    namespace = dict(original.__globals__)
    fn = types.FunctionType(code, namespace)
    return fn, code, tuple(namespace.items()), module.code


class ManualProgram:
    def __init__(self, path, example, model, late=False, full=False):
        if sha(path) != EXPORTS[model] or torch.__version__ != '2.1.2+cu121':
            raise ManualRejected('a changed export needs a new manual review')
        exported = torch.export.load(path)
        self.graph, self.root, self.state, changed_boundary = fixed_graph(exported, example.device, late)
        root = next(n for n in self.graph.nodes if n.name == self.root)
        ref = root.meta['val']
        if (tuple(ref.shape), tuple(ref.stride()), ref.dtype) != (tuple(example.shape), tuple(example.stride()), example.dtype):
            raise ManualRejected('input metadata not reviewed')
        self.expected = tensor_meta(example)
        self.full = full
        self.boundary = changed_boundary if late else BASE_BOUNDARY[model]
        graphs, carry = ((self.graph,), ()) if full else manual_partition(self.graph, self.boundary)
        self.functions = tuple(own_function(g) for g in graphs)
        self.state_tokens = tuple((n, state_token(t)) for n, t in self.state.items())
        self.arguments = tuple(n.name for n in self.graph.nodes if n.op == 'placeholder')
        self.artifact = dict(schema='readseal-complete-manual-static-v7', model=model, late=late, full=full,
            export_sha256=EXPORTS[model], boundary=self.boundary, carry=carry,
            graph=graph_records(self.graph), stages=[graph_records(g) for g in graphs],
            code=[f[3] for f in self.functions],
            code_sha256=[hashlib.sha256(marshal.dumps(f[1])).hexdigest() for f in self.functions],
            manual_source_sha256=sha(__file__), no_readseal_analysis_or_executor=True)

    def guard(self):
        if tuple((n, state_token(t)) for n, t in self.state.items()) != self.state_tokens:
            raise ManualRejected('owned model state changed')
        for fn, code, namespace, _ in self.functions:
            if (fn.__code__ is not code or fn.__closure__ or fn.__defaults__ or fn.__kwdefaults__
                    or len(fn.__globals__) != len(namespace)
                    or any(fn.__globals__.get(k) is not v for k, v in namespace)):
                raise ManualRejected('owned function changed')

    def start(self, x, publication, ready):
        self.guard()
        if tensor_meta(x) != self.expected or not x.is_cuda or not isinstance(ready, torch.cuda.Event):
            raise ManualRejected('input/ready mismatch')
        if set(publication) != {'epoch', 'sequence', 'generation'}:
            raise ManualRejected('publication fields')
        e, s, g = (publication[k] for k in ('epoch', 'sequence', 'generation'))
        if any(type(v) is not int or not 0 <= v < 2**64 for v in (e, s, g)) or s == 0 or g % 2 or g == 0:
            raise ManualRejected('uncommitted or invalid publication')
        if any(t.untyped_storage().data_ptr() == x.untyped_storage().data_ptr() for t in self.state.values()):
            raise ManualRejected('input aliases model')
        return ManualInvocation(self, x, dict(publication), ready)


class ManualInvocation:
    def __init__(self, program, x, publication, ready):
        self.program, self.x, self.publication, self.ready = program, x, publication, ready
        self.allocation = x.untyped_storage().data_ptr()
        self.events, self.stage = [], 0
        self.stream, self.value = None, None
        self.failed, self.aborted, self.published = False, False, False

    def submit(self, stage, stream):
        p = self.program
        if (type(stage) is not int or stage != self.stage or stage >= len(p.functions)
                or self.failed or self.aborted or self.published):
            raise ManualRejected('invalid submission')
        if self.stream is not None and self.stream.cuda_stream != stream.cuda_stream:
            raise ManualRejected('single stream required')
        p.guard()
        self.stream = stream
        try:
            with torch.cuda.stream(stream), torch.inference_mode():
                if stage == 0:
                    stream.wait_event(self.ready)
                    args = tuple(self.x if n == p.root else p.state[n] for n in p.arguments)
                else:
                    args = self.value
                self.value = tuple(p.functions[stage][0](None, *args))
                event = torch.cuda.Event()
                event.record(stream)
            if any(isinstance(t, torch.Tensor) and t.untyped_storage().data_ptr() == self.allocation
                   for t in tree_flatten(self.value)[0]):
                raise ManualRejected('manual boundary/output still aliases source')
            self.x = None
            self.events.append(event)
            self.stage += 1
            return event
        except BaseException:
            self.failed = True
            raise

    def can_release(self):
        return not self.failed and bool(self.events) and self.events[0].query()

    def publish(self):
        if (self.failed or self.aborted or self.published or self.stage != len(self.program.functions)
                or not all(e.query() for e in self.events)):
            raise ManualRejected('incomplete or duplicate publication')
        self.published = True
        return self.value, dict(self.publication)

    def abort(self):
        self.aborted = True
        if self.stream is not None:
            self.stream.synchronize()
        self.failed = False

