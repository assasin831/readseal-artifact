import unittest

from core import Binding, Lease, Node, Summary, TensorSpec, Rejected, compile_plan, digest
from dataclasses import asdict
from native_composition import ReferenceBorrowManager


class Event:
    def __init__(self, done=False):
        self.done = done

    def query(self):
        return self.done


class ManagerTests(unittest.TestCase):
    def make(self, kind, escaped=False):
        spec = TensorSpec((4,), (1,), "float32", "cuda:0")
        b = Binding("physical-1", 16, 1, 2, 2, digest(asdict(spec)), spec)
        nodes = [Node("A", ("x",), Summary((0,), completion="input_consumed", implementation="native")),
                 Node("B", ("x",), Summary((), (0,), completion="synchronous", implementation="view")),
                 Node("C", ("B",), Summary((0,), completion="input_consumed", implementation="child"))]
        plan = compile_plan(("x",), nodes, ("A", "C", "B") if escaped else ("A", "C"), {"x": spec}, "e")
        manager = (Lease(plan, {"x": b}, "e", {"x": b.version}) if kind == "automatic"
                   else ReferenceBorrowManager(plan, {"x": b}))
        return manager, b

    def test_future_reader(self):
        for kind in ("automatic", "reference"):
            with self.subTest(kind=kind):
                m, b = self.make(kind)
                m.begin("A")
                m.submitted("A", Event(True), Event(True))
                m.begin("B")
                m.submitted("B", Event(True))
                self.assertFalse(m.can_release(b.allocation))
                m.begin("C")
                read, output = Event(), Event()
                m.submitted("C", read, output)
                self.assertFalse(m.can_release(b.allocation))
                read.done = True
                self.assertTrue(m.can_release(b.allocation))
                self.assertFalse(m.can_publish())
                output.done = True
                self.assertTrue(m.can_publish())

    def test_missing_output_event(self):
        for kind in ("automatic", "reference"):
            with self.subTest(kind=kind):
                m, b = self.make(kind)
                m.begin("A")
                with self.assertRaises(Rejected):
                    m.submitted("A", Event(True))
                self.assertFalse(m.can_release(b.allocation))

    def test_abort_unknown_started_holds(self):
        for kind in ("automatic", "reference"):
            with self.subTest(kind=kind):
                m, b = self.make(kind)
                m.begin("A")
                m.abort()
                self.assertFalse(m.can_release(b.allocation))
                read, output = Event(), Event()
                m.submitted("A", read, output)
                self.assertFalse(m.can_release(b.allocation))
                read.done = True
                self.assertTrue(m.can_release(b.allocation))
                self.assertFalse(m.can_publish())

    def test_escape_acknowledgement(self):
        for kind in ("automatic", "reference"):
            with self.subTest(kind=kind):
                m, b = self.make(kind, escaped=True)
                for name in ("A", "B", "C"):
                    m.begin(name)
                    m.submitted(name, Event(True), Event(True))
                self.assertFalse(m.can_release(b.allocation))
                m.return_output_borrow("B")
                self.assertTrue(m.can_release(b.allocation))
                with self.assertRaises(Rejected):
                    m.return_output_borrow("B")


if __name__ == "__main__":
    unittest.main()
