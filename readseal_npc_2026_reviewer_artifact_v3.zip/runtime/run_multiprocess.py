"""CUDA IPC + bounded Retention + executable borrow proofs + V6 capture gate.

Barrier-controlled conformance only. These delays are NOT throughput samples.
All recipients are enrolled before queueing, including future alias consumers.
"""
import argparse
import copy
from dataclasses import asdict
import gc
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import traceback
import uuid

import torch
import torch.multiprocessing as mp
import core
import export_backend
import native_composition
import torch_backend
import retention_bridge
import capture_policy_v1
import streaming_retention_v1
from capture_policy_v1 import CaptureCapability, ReadWindowGate
from experiments import bim_cuda_protocol_v1 as wire
from core import Lease
from export_backend import Program
from native_composition import compose, ChildReadDone, ChildOutputDone, ReferenceBorrowManager
from retention_bridge import RetentionBridge
from streaming_retention_v1 import RetentionPool
from torch_backend import Ready, bind, allocation

from coordination import matrix, Inbox, FullOperation, await_control
from native_loader import FrozenNative
import coordination
import native_loader


GPU = "GPU-f3b314a8-3058-e0be-694c-76f4227afb7d"
EXPORT_SHA = "8efaa67aa6884d0c9aec6fff442e9a50b683a290d856abef390db1f034ccabbd"
now = time.monotonic_ns


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def tsha(t):
    return hashlib.sha256(t.detach().contiguous().cpu().numpy().tobytes()).hexdigest()


def write_json(path, value):
    with Path(path).open("x") as f:
        json.dump(value, f, indent=2, default=lambda v: sorted(v))
        f.write("\n")


def configure():
    assert os.environ.get("CUDA_VISIBLE_DEVICES") == GPU and torch.cuda.device_count() == 1
    torch.set_num_threads(1)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False


def declaration(x):
    return {"format_version": 1, "semantic_id": "transfusion/checked-head-input/v3",
            "representation": {"shape": list(x.shape), "stride_bytes": [v * 4 for v in x.stride()],
                               "element_bytes": 4, "reachable_extent_bytes": x.numel() * 4},
            "named_views": {"full": {"start": [0] * 4, "extent": list(x.shape)}}}


def observe(state, slot):
    with state.get_lock():
        return int(state[slot * 2]), int(state[slot * 2 + 1])


def consumer(cid, commands, controls, results, tensor_queue, state, pool, epoch, config):
    active = None
    bridge = RetentionBridge(pool)
    try:
        configure()
        dest = Path(config["output"])
        slots, handles = tensor_queue.get(timeout=600)
        events = [torch.cuda.Event.from_ipc_handle(0, h) for h in handles]
        exported = torch.export.load(config["export"])
        native = FrozenNative(config["native"])
        example = torch.load(Path(config["cases"]) / "case_0.pt", map_location="cpu")["input"].cuda()
        programs = {late: Program(exported, example, late_read=late) for late in (False, True)}
        plans = {late: compose(program, example, native) for late, program in programs.items()}
        assert plans[False].sha256 != plans[True].sha256
        expected = {}
        for sid in config["sources"]:
            example.copy_(torch.load(Path(config["cases"]) / f"case_{sid}.pt", map_location="cpu")["input"])
            ready = torch.cuda.Event()
            ready.record(torch.cuda.current_stream())
            oracle = native.launch(example, ready)
            oracle.output_done.synchronize()
            a = oracle.output.detach().cpu()
            for late, child in programs.items():
                graph = torch.fx.GraphModule(torch.nn.Module(), copy.deepcopy(child.graph))
                args = [example if node.name == child.root else child.state[node.name]
                        for node in child.graph.nodes if node.op == "placeholder"]
                with torch.inference_mode():
                    outputs = tuple(t.detach().cpu() for t in graph(*args))
                expected[sid, late] = (a,) + outputs
        del example, graph, args, outputs, oracle
        torch.cuda.synchronize()
        declared = declaration(slots[0])
        results.put({"kind": "ready", "consumer": cid, "pid": os.getpid(),
                     "slots": len(slots), "ipc_handle_hashes": [hashlib.sha256(h).hexdigest() for h in handles]})
        while True:
            scenario = commands.get(timeout=600)
            if scenario["op"] == "stop":
                break
            assert scenario["op"] == "scenario" and active is None and not bridge.records
            cell = scenario["cell"]
            cell_id = cell["id"]
            folder = dest / cell_id / f"consumer-{cid}"
            folder.mkdir(parents=True, exist_ok=False)
            child, plan = programs[cell["late"]], plans[cell["late"]]
            req = commands.get(timeout=600)
            assert req["op"] == "work"
            slot, seq = req["slot"], req["sequence"]
            x, ready_event = slots[slot], events[slot]
            publication = dict(epoch=epoch[1], sequence=seq, generation=2 * seq)
            binding = bind(x, **publication)
            active = bridge.enroll(slot, seq, cid, binding, ready_event)
            lease = (ReferenceBorrowManager(plan, {"source": binding}) if cell["policy"] == "native-complete-manager"
                     else Lease(plan, {"source": binding}, plan.executable, {"source": binding.version}))
            bridge.attach(active, FullOperation(lease) if cell["policy"] == "full-operation" else lease)
            row = {"cell": cell, "consumer": cid, "pid": os.getpid(), "request": req,
                   "physical_id": req["physical_id"], "local_virtual_allocation": binding.allocation,
                   "wire_epoch": epoch, "binding": asdict(binding), "received_ns": now(),
                   "parent_plan_sha256": plan.sha256, "child_plan_sha256": child.plan.sha256,
                   "parent_obligations": dict(plan.obligations), "child_obligations": dict(child.plan.obligations)}
            results.put({"kind": "received", "consumer": cid, "cell": cell_id})
            jobs = {}

            def release():
                nonlocal active
                assert active is not None
                row["release_begin_ns"] = now()
                bridge.release_checked(active)
                row["release_end_ns"] = now()
                active = None

            def ready():
                assert req["descriptor"]["ready_event_id"] == hashlib.sha256(handles[slot]).hexdigest()
                ready_event.synchronize()
                assert observe(state, slot) == (2 * seq, seq)
                row["source_sha256_before"] = tsha(x)
                assert row["source_sha256_before"] == req["source_sha256"]
                return x

            def compute(borrowed, close_reads):
                await_control(controls, cell_id, "native")
                lease.begin("A")
                jobs["A"] = native.launch(borrowed, ready_event)
                lease.submitted("A", jobs["A"].read_done, jobs["A"].output_done)
                lease.begin("B")
                view = borrowed.view_as(borrowed)
                assert allocation(view) == allocation(borrowed)
                lease.submitted("B", Ready())
                jobs["A"].read_done.synchronize()
                row["native_input_done_ns"] = now()
                assert lease.states["C"] == "pending" and not lease.can_release(binding.allocation)
                results.put({"kind": "native_done", "consumer": cid, "cell": cell_id})
                await_control(controls, cell_id, "child")
                lease.begin("C")
                execution = child.start(view, publication=publication, ready=ready_event)
                jobs["C"] = execution
                assert execution.lease.bindings[child.root] == binding
                lease.submitted("C", ChildReadDone(execution, binding.allocation), ChildOutputDone(execution))
                q = set(dict(child.plan.obligations)[child.root])
                operations = iter(child.operations)
                stream = torch.cuda.Stream()
                for operation in operations:
                    execution.step(operation, stream)
                    if operation in q:
                        execution.lease.events[operation].synchronize()
                        if lease.can_release(binding.allocation):
                            row["closure_operation"] = operation
                            row["pending_private_operations"] = [n for n, s in execution.lease.states.items() if s == "pending"]
                            assert row["pending_private_operations"] and not lease.can_publish()
                            close_reads()
                            row["closed_ns"] = now()
                            if cell["policy"] != "full-operation":
                                release()
                            results.put({"kind": "closed", "consumer": cid, "cell": cell_id})
                            await_control(controls, cell_id, "private")
                            row["private_continue_ns"] = now()
                            break
                else:
                    raise AssertionError("no checked read closure")
                for operation in operations:
                    execution.step(operation, stream)
                execution.wait()
                jobs["A"].output_done.synchronize()
                return (jobs["A"].output,) + execution.outputs()

            def complete(output):
                if output is None:
                    # A failed drain never authorizes a return to the producer.
                    torch.cuda.synchronize()
                    return
                jobs["C"].wait()
                jobs["A"].output_done.synchronize()
                assert lease.can_publish()
                row["output_done_ns"] = now()
                if cell["policy"] == "full-operation":
                    release()

            def check(output):
                raw = tuple(t.detach().cpu() for t in output)
                ref = expected[cell["source"], cell["late"]]
                assert len(raw) == len(ref)
                comparisons = [{"index": i, "exact": torch.equal(a, b), "actual_sha256": tsha(a),
                                "expected_sha256": tsha(b), "shape": list(a.shape), "dtype": str(a.dtype)}
                               for i, (a, b) in enumerate(zip(raw, ref))]
                torch.save({"actual": raw, "expected": ref}, folder / "outputs.pt")
                row["comparisons"] = comparisons
                assert all(r["exact"] for r in comparisons) and all(bool(torch.isfinite(a).all()) for a in raw)

            def publish(_):
                identities = lease.publish_identity()
                assert all(v["source"] == binding for v in identities.values())
                row["output_identity"] = {o: asdict(v["source"]) for o, v in identities.items()}
                row["published_ns"] = now()
                row["observed_state_at_publish"] = observe(state, slot)

            def read_complete():
                assert lease.can_release(binding.allocation)
                row["joined_reads_ns"] = now()

            row["outcome"] = ReadWindowGate(declared, lambda: tuple(epoch), lambda s: observe(state, s), "capture",
                CaptureCapability(True, True, True, True)).consume(
                    req["descriptor"], ready, compute, complete, check, publish,
                    lambda: active is not None and pool.held(slot, seq, cid),
                    read_complete, lambda phase: row.update(capture_check_ns=now()))
            assert row["outcome"] == "Correct" and active is None
            write_json(folder / "parent-plan.json", asdict(plan))
            write_json(folder / "child-plan.json", asdict(child.plan))
            write_json(folder / "dispatch.json", jobs["C"].receipts)
            row["files"] = {p.name: sha(p) for p in folder.iterdir() if p.is_file()}
            write_json(folder / "record.json", row)
            (folder / "COMPLETE").write_text("Checked output publication after complete borrowed reads.\n")
            results.put({"kind": "published", "consumer": cid, "cell": cell_id,
                         "record_sha256": sha(folder / "record.json")})
            await_control(controls, cell_id, "cleanup")
            cancellations = []
            while True:
                queued = commands.get(timeout=600)
                if queued["op"] == "end":
                    break
                assert queued["op"] == "cancel_before_start"
                s, qseq = queued["slot"], queued["sequence"]
                token = bridge.enroll(s, qseq, cid, bind(slots[s], epoch=epoch[1], sequence=qseq, generation=2*qseq), events[s])
                bridge.cancel_queued(token)
                cancellations.append(dict(request=queued, cancelled_ns=now(), gpu_dispatch_count=0))
            assert len(cancellations) == cell["ring"] - 1 and not bridge.records
            write_json(folder / "cancellations.json", cancellations)
            results.put({"kind": "scenario_done", "consumer": cid, "cell": cell_id,
                         "cancel_sha256": sha(folder / "cancellations.json")})
            del jobs, row
        del slots, events
        torch.cuda.synchronize()
        results.put({"kind": "stopped", "consumer": cid})
    except BaseException:
        if active is not None:
            try:
                bridge.quarantine(active)
            except BaseException:
                pass
        results.put({"kind": "error", "consumer": cid, "traceback": traceback.format_exc()})
        raise


def run_group(cells, args, report):
    n, r = cells[0]["consumers"], cells[0]["ring"]
    ctx = mp.get_context("spawn")
    pool, state = RetentionPool(ctx, r, n), ctx.Array("Q", 2 * r, lock=True)
    epoch_value = uuid.uuid4().int
    epoch = [epoch_value >> 64, epoch_value & (2**64 - 1)]
    bank = [torch.load(args.cases / f"case_{s}.pt", map_location="cpu")["input"].cuda() for s in range(3)]
    slots = [torch.empty_like(bank[0]) for _ in range(r)]
    events = [torch.cuda.Event(interprocess=True) for _ in slots]
    for event in events:
        event.record(torch.cuda.current_stream())
        event.synchronize()
    handles = [bytes(event.ipc_handle()) for event in events]
    source_hashes = [tsha(t) for t in bank]
    group_id = f"n{n}-r{r}"
    physical_ids = [f"{args.output.name}/{group_id}/slot-{s}" for s in range(r)]
    queues = [ctx.Queue(maxsize=r + 3) for _ in range(n)]
    controls = [ctx.Queue(maxsize=4) for _ in range(n)]
    tensors = [ctx.Queue(maxsize=1) for _ in range(n)]
    results = ctx.Queue()
    inbox, workers = Inbox(results), []
    config = dict(export=str(args.export), native=str(args.native), cases=str(args.cases), output=str(args.output),
                  sources=sorted({c["source"] for c in cells}))
    group = dict(id=group_id, consumers=n, ring=r, wire_epoch=epoch, physical_ids=physical_ids,
                 physical_slot_bytes=bank[0].numel()*bank[0].element_size(),
                 reference_bank_bytes=sum(t.numel()*t.element_size() for t in bank), cases=[])
    sequence = 0

    def control(cid, cell, phase):
        controls[cid].put({"cell": cell, "phase": phase}, timeout=30)

    def write_slot(slot, seq, sid, recipients):
        with state.get_lock():
            state[2*slot], state[2*slot+1] = 2*seq-1, seq
        slots[slot].copy_(bank[sid])
        events[slot].record(torch.cuda.current_stream())
        events[slot].synchronize()
        with state.get_lock():
            state[2*slot] = 2*seq
        pool.commit(slot, seq, recipients)
        return dict(slot=slot, sequence=seq, source_id=sid, source_sha256=source_hashes[sid],
                    written_ns=now(), physical_id=physical_ids[slot],
                    descriptor=wire.build_descriptor(stream_id="borrowplan-v3", epoch=epoch, declaration=declaration(slots[slot]),
                        members=[dict(slot_index=slot, publication_sequence=seq, generation=2*seq)],
                        requested_views=["full"], ready_event_id=hashlib.sha256(handles[slot]).hexdigest()))

    try:
        for cid in range(n):
            worker = ctx.Process(target=consumer, args=(cid, queues[cid], controls[cid], results, tensors[cid], state, pool, epoch, config))
            worker.start()
            workers.append(worker)
            tensors[cid].put((slots, handles), timeout=30)
        group["workers"] = [inbox.take("ready", cid) for cid in range(n)]
        assert len({w["pid"] for w in group["workers"]}) == n
        for cell in cells:
            print("RUN " + cell["id"], flush=True)
            records = []
            for j in range(r):
                sequence += 1
                slot = pool.reserve(sequence)
                assert slot is not None
                records.append(write_slot(slot, sequence, cell["source"] if j == 0 else (cell["source"]+1)%3, range(n)))
            old = records[0]
            sequence += 1
            overwrite_sequence = sequence
            row = dict(cell=cell, original=old, enqueued=records, before_queue=pool.snapshot(), started_ns=now())
            assert all(mask == (1 << n)-1 for mask in row["before_queue"]["recipients"])
            for cid in range(n):
                queues[cid].put({"op": "scenario", "cell": cell}, timeout=30)
                queues[cid].put(dict(op="work", **old), timeout=30)
                for rec in records[1:]:
                    queues[cid].put(dict(op="cancel_before_start", **rec), timeout=30)
                queues[cid].put({"op": "end"}, timeout=30)
            for cid in range(n):
                inbox.take("received", cid, cell["id"])
            assert pool.reserve(overwrite_sequence) is None
            row["queued_reuse_blocked_ns"] = now()
            for cid in range(n):
                control(cid, cell["id"], "native")
            for cid in range(n):
                inbox.take("native_done", cid, cell["id"])
            assert pool.reserve(overwrite_sequence) is None
            row["native_only_reuse_blocked_ns"] = now()
            row["closures"] = []
            reserved = None
            for cid in range(n):
                control(cid, cell["id"], "child")
                inbox.take("closed", cid, cell["id"])
                reserved = pool.reserve(overwrite_sequence)
                should_release = cid == n-1 and cell["policy"] != "full-operation"
                assert (reserved is not None) == should_release
                row["closures"].append(dict(consumer=cid, observed_ns=now(), reserved=reserved, pool=pool.snapshot()))
            if reserved is not None:
                assert reserved == old["slot"]
                row["overwrite"] = write_slot(reserved, overwrite_sequence, (cell["source"]+1)%3, [])
                row["overwrite"]["actual_sha256"] = tsha(slots[reserved])
                assert row["overwrite"]["actual_sha256"] != old["source_sha256"]
            row["private_continue_sent_ns"] = now()
            for cid in range(n):
                control(cid, cell["id"], "private")
            row["published"] = [inbox.take("published", cid, cell["id"]) for cid in range(n)]
            row["all_published_ns"] = now()
            if reserved is None:
                reserved = pool.reserve(overwrite_sequence)
                assert reserved == old["slot"]
                row["overwrite"] = write_slot(reserved, overwrite_sequence, (cell["source"]+1)%3, [])
                row["overwrite"]["actual_sha256"] = tsha(slots[reserved])
            for cid in range(n):
                control(cid, cell["id"], "cleanup")
            row["done"] = [inbox.take("scenario_done", cid, cell["id"]) for cid in range(n)]
            row["after"] = pool.snapshot()
            assert all(not any(row["after"][k]) for k in ("recipients", "writing", "quarantined"))
            assert row["after"]["counters"]["grants"] == row["after"]["counters"]["releases"]
            write_json(args.output / cell["id"] / "coordinator.json", row)
            (args.output / cell["id"] / "COMPLETE").write_text("All recipients and queue cancellations accounted for.\n")
            group["cases"].append(dict(id=cell["id"], coordinator_sha256=sha(args.output/cell["id"]/"coordinator.json")))
            print("COMPLETE " + cell["id"], flush=True)
        for cid in range(n):
            queues[cid].put({"op": "stop"}, timeout=30)
        for cid, worker in enumerate(workers):
            inbox.take("stopped", cid)
            worker.join(timeout=120)
            assert worker.exitcode == 0
        assert not inbox.pending
        group["status"] = "COMPLETE"
        write_json(args.output / (group_id + ".json"), group)
        report["groups"].append(dict(id=group_id, sha256=sha(args.output/(group_id+".json"))))
    except BaseException:
        snapshot = pool.snapshot()
        for slot, seq in enumerate(snapshot["sequence"]):
            if seq and (snapshot["recipients"][slot] or snapshot["writing"][slot]):
                pool.quarantine(slot, seq)
        write_json(args.output / (group_id + "-failure-pool.json"), pool.snapshot())
        raise
    finally:
        for worker in workers:
            if worker.is_alive():
                worker.terminate()
            worker.join(timeout=30)
        for queue in queues + controls + tensors + [results]:
            queue.cancel_join_thread()
            queue.close()
    del slots, events, bank, workers
    gc.collect()
    torch.cuda.empty_cache()


def main():
    p = argparse.ArgumentParser()
    for name in ("export", "cases", "native", "output"):
        p.add_argument("--"+name, type=Path, required=True)
    p.add_argument("--smoke", action="store_true")
    a = p.parse_args()
    a.output = a.output.resolve()
    a.output.mkdir(parents=True, exist_ok=False)
    report = dict(status="RUNNING", schema="borrowplan-multiprocess-conformance-v3", groups=[],
                  performance_claim=False, native_scope="Frozen shared-convolution component, not full TensorRT head",
                  limitations=["Barrier-controlled correctness, not measured GPU overlap or throughput",
                               "CUDA IPC tensor/event transport and native input-event contract are trusted",
                               "Bounded export scope; arbitrary plugins and opaque kernels unsupported"])
    try:
        active = subprocess.check_output(["nvidia-smi", "--query-compute-apps=gpu_uuid,pid", "--format=csv,noheader"], text=True)
        assert not any(line.startswith(GPU) for line in active.splitlines()), "GPU0 is occupied"
        report.update(gpu_uuid=GPU, preexisting_compute_processes=active.splitlines(), torch=torch.__version__)
        assert sha(a.export) == EXPORT_SHA
        deps = (core, export_backend, native_composition, torch_backend, retention_bridge, capture_policy_v1,
                streaming_retention_v1, wire, coordination, native_loader)
        report["source_sha256"] = {str(Path(m.__file__).resolve()): sha(m.__file__) for m in deps}
        report["source_sha256"][str(Path(__file__).resolve())] = sha(__file__)
        report["input_sha256"] = {str(path): sha(path) for path in
            [a.export, a.native/"native.engine", a.native/"report.json", a.cases/"report.json"] +
            [a.cases/f"case_{sid}.pt" for sid in range(3)]}
        oracle = json.loads((a.cases/"report.json").read_text())
        for sid in range(3):
            assert sha(a.cases/f"case_{sid}.pt") == oracle["files"][f"case_{sid}.pt"]
        assert sha(streaming_retention_v1.__file__) == "d257190795b530912870f7dd5cf9fa48bea7225d850c3ca4a890144decfc15bf"
        cells = matrix(a.smoke)
        write_json(a.output/"frozen_matrix.json", dict(kind="smoke" if a.smoke else "formal-conformance", cells=cells))
        report["matrix_sha256"] = sha(a.output/"frozen_matrix.json")
        configure()
        for n, r in sorted({(c["consumers"], c["ring"]) for c in cells}):
            run_group([c for c in cells if c["consumers"] == n and c["ring"] == r], a, report)
        report.update(status="COMPLETE", cells=len(cells), consumer_computations=sum(c["consumers"] for c in cells))
        (a.output/"COMPLETE").write_text("Multi-process conformance completed; not a performance result.\n")
    except BaseException as exc:
        report.update(status="FAILED", error=str(exc))
        (a.output/"FAILED").write_text(type(exc).__name__+"\n")
        (a.output/"traceback.txt").write_text(traceback.format_exc())
        traceback.print_exc()
    write_json(a.output/"report.json", report)
    return 0 if report["status"] == "COMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
