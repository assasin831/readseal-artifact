"""Finite correctness scenarios and control messages, not a load generator."""
import time


POLICIES = ("automatic", "native-complete-manager", "full-operation")


def matrix(smoke=False):
    dimensions = ((1, 1),) if smoke else tuple((n, r) for n in (1, 2, 4) for r in (1, 2, 4))
    return [dict(id=f"n{n}-r{r}-s{s}-{'late' if late else 'base'}-{policy}",
                 consumers=n, ring=r, source=s, late=late, policy=policy)
            for n, r in dimensions for s in range(1 if smoke else 3)
            for late in (False, True) for policy in POLICIES]


class FullOperation:
    """Same complete proof, with a deliberately conservative release boundary."""
    def __init__(self, lease):
        self.lease, self.bindings = lease, lease.bindings

    def can_release(self, allocation):
        return self.lease.can_release(allocation) and self.lease.can_publish()


class Inbox:
    def __init__(self, queue):
        self.queue, self.pending = queue, []

    def take(self, kind, consumer, cell=None, timeout=600):
        deadline = time.monotonic() + timeout
        while True:
            for i, row in enumerate(self.pending):
                if row["kind"] == "error":
                    raise RuntimeError(row["traceback"])
                if row["kind"] == kind and row["consumer"] == consumer and row.get("cell") == cell:
                    return self.pending.pop(i)
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError(f"missing {kind}/{consumer}/{cell}")
            self.pending.append(self.queue.get(timeout=remaining))


def await_control(queue, cell, phase):
    received = queue.get(timeout=600)
    if received != {"cell": cell, "phase": phase}:
        raise RuntimeError(f"unexpected control transition: {received}, expected {cell}/{phase}")
