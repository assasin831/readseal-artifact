"""Fresh serial GPU0 campaign. No retry of a failed inference or changed cell."""
import fcntl
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import traceback
import argparse
import hashlib

ROOT=Path('/www/readseal_ipdps_revision_v6')
GPU='GPU-f3b314a8-3058-e0be-694c-76f4227afb7d'
SOURCE=Path(__file__).resolve().parent


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser(); p.add_argument('--output',type=Path,required=True)
    p.add_argument('--plan',type=Path,required=True); p.add_argument('--pilot',action='store_true')
    a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=False)
    (a.output/'pid').write_text(str(os.getpid())+'\n')
    result=dict(status='RUNNING',runs=[],pilot=a.pilot)
    try:
        with (ROOT/'borrowplan_gpu0.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            deps=[SOURCE]+[ROOT/s for s in (
                'prototype_borrowplan_v8_abc_attempt1','prototype_borrowplan_v7_followups_attempt1',
                'prototype_borrowplan_v7_formal_attempt1','prototype_borrowplan_v6_resnet_scope_attempt1',
                'prototype_borrowplan_v6_witness_attempt1','prototype_borrowplan_v5_prepared_attempt1',
                'prototype_borrowplan_v5_owned_attempt2','prototype_borrowplan_v4_segmented_attempt1',
                'prototype_borrowplan_v1_attempt2','prototype_borrowplan_v2_composition_attempt2',
                'prototype_borrowplan_v3_attempt1','sdk_trt_10_3_attempt2/packages','experiments')]
            env=dict(os.environ,PYTHONPATH=':'.join(map(str,deps)),CUDA_VISIBLE_DEVICES=GPU,
                PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
                CUDA_CACHE_PATH=str(a.output/'cuda-cache'))
            plan=json.loads(a.plan.read_text())
            result.update(plan=plan,plan_sha256=sha(a.plan),sources={str(f):sha(f) for f in SOURCE.glob('*.py')})
            order=random.Random(plan['order_seed']); commands=[]
            for rep in range(1 if a.pilot else plan['repetitions']):
                conditions=[dict(id='pilot-r2-cap4',ring=2,outstanding_cap=4)] if a.pilot else list(plan['conditions'])
                order.shuffle(conditions)
                for condition in conditions:
                    methods=list(plan['methods']); order.shuffle(methods)
                    cell=dict(plan['common'],**condition)
                    if a.pilot:
                        cell.update(warmup_seconds=0.5,measure_seconds=1)
                    for method in methods:
                        commands.append(dict(name=f'r{rep:02d}-{condition["id"]}-{method}',repeat=rep,
                                             condition=condition,method=method,cell=cell))
            result['schedule']=commands
            for item in commands:
                assert all(sha(f)==h for f,h in result['sources'].items()), 'source changed; do not continue'
                assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader'],text=True).strip(), 'foreign compute; no launch'
                name=item['name']; result['active']=name
                (a.output/'report.json').write_text(json.dumps(result,indent=2)+'\n')
                cmd=[sys.executable,'-B',str(SOURCE/'run_admission.py'),'--output',str(a.output/name),
                     '--cell',json.dumps(item['cell']),'--method',item['method']]
                with (a.output/(name+'.log')).open('x') as log:
                    code=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
                assert code==0, name+' failed; no inference retry'
                validation=a.output/(name+'-validation')
                cmd=[sys.executable,'-B',str(SOURCE/'validate_admission.py'),'--run',str(a.output/name),'--output',str(validation)]
                with (a.output/(name+'-validation.log')).open('x') as log:
                    code=subprocess.run(cmd,cwd=ROOT,env=dict(env,CUDA_VISIBLE_DEVICES=''),stdout=log,stderr=subprocess.STDOUT).returncode
                assert code==0, name+' validation failed; preserve run'
                result['runs'].append(dict(item,report_sha256=sha(a.output/name/'report.json'),
                    validation_sha256=sha(validation/'validation.json')))
                print('COMPLETE',name,flush=True)
            result.update(status='COMPLETE',active=None)
    except BaseException:
        result.update(status='FAILED',traceback=traceback.format_exc()); traceback.print_exc()
    (a.output/'report.json').write_text(json.dumps(result,indent=2)+'\n')
    (a.output/result['status']).write_text(result['status']+'\n')
    return int(result['status']!='COMPLETE')


if __name__=='__main__':
    raise SystemExit(main())
