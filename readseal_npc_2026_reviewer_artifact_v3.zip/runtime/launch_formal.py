"""120 fresh unbarriered runs; validate every run before proceeding, no retry."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import traceback

ROOT=Path('/www/readseal_ipdps_revision_v6')
SOURCE=Path(__file__).resolve().parent
OUT=ROOT/'results/borrowplan_v7_streaming_formal_attempt1'
GPU='GPU-f3b314a8-3058-e0be-694c-76f4227afb7d'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    OUT.mkdir(parents=True,exist_ok=False)
    (OUT/'pid').write_text(str(os.getpid())+'\n')
    report=dict(status='RUNNING',cases=[],sources={str(p):sha(p) for p in SOURCE.iterdir() if p.is_file()})
    try:
        with (ROOT/'borrowplan_gpu0.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            prerequisite=ROOT/'results/borrowplan_v7_streaming_pilot_validation_attempt1'
            gate=ROOT/'results/borrowplan_v7_manual_gate_validation_attempt1'
            for p in (prerequisite,gate):
                assert (p/'COMPLETE').exists() and json.loads((p/'report.json').read_text())['status']=='COMPLETE'
            report['prerequisites']={str(p):sha(p/'report.json') for p in (prerequisite,gate)}
            plan=json.loads((SOURCE/'FORMAL_PLAN.json').read_text())
            report['plan']=plan
            report['plan_sha256']=sha(SOURCE/'FORMAL_PLAN.json')
            deps=[SOURCE]+[ROOT/n for n in (
                'prototype_borrowplan_v6_resnet_scope_attempt1','prototype_borrowplan_v6_witness_attempt1',
                'prototype_borrowplan_v5_prepared_attempt1','prototype_borrowplan_v5_owned_attempt2',
                'prototype_borrowplan_v4_segmented_attempt1','prototype_borrowplan_v1_attempt2',
                'prototype_borrowplan_v2_composition_attempt2','experiments')]
            env=dict(os.environ,PYTHONPATH=':'.join(map(str,deps)),CUDA_VISIBLE_DEVICES=GPU,
                PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
                CUDA_CACHE_PATH=str(OUT/'cuda-cache'))
            sys.path[:0]=list(map(str,deps))
            from validate_streaming import audit_cell
            rng=random.Random(plan['order_seed'])
            schedule=[]
            for repeat in range(plan['run_count']):
                conditions=list(plan['conditions'])
                rng.shuffle(conditions)
                for condition in conditions:
                    methods=list(plan['methods'])
                    rng.shuffle(methods)
                    for method in methods:
                        schedule.append(dict(repeat=repeat,condition=condition,method=method))
            report['schedule']=schedule
            (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
            for index,item in enumerate(schedule):
                assert all(sha(p)==h for p,h in report['sources'].items()),'source drift'
                cell={k:plan[k] for k in ('model','consumers','queue','deadline_ms','warmup_seconds','measure_seconds')}
                cell.update(item['condition'])
                name=f"r{item['repeat']:02d}-{cell['id']}-{item['method']}"
                path=OUT/name
                command=[sys.executable,'-B',str(SOURCE/'run_cell.py'),'--cell',json.dumps(cell),
                         '--method',item['method'],'--output',str(path)]
                with (OUT/(name+'.log')).open('x') as log:
                    code=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
                assert code==0,name+' failed; no retry'
                checked=audit_cell(path)
                checked.update(repeat=item['repeat'],condition=cell['id'],run=name)
                report['cases'].append(checked)
                (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
                print(json.dumps(dict(completed=index+1,total=len(schedule),**checked)),flush=True)
            assert len(report['cases'])==120
            report['status']='COMPLETE'
    except BaseException:
        report.update(status='FAILED',traceback=traceback.format_exc())
        traceback.print_exc()
    (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    (OUT/report['status']).write_text(report['status']+'\n')
    return 0 if report['status']=='COMPLETE' else 1


if __name__=='__main__':
    raise SystemExit(main())
