"""Owned, construction-validated functional segments; not a Python sandbox.

Pinned ATen, fixed metadata, one CUDA stream, no concurrent mutation, tensor
subclasses, custom dispatch modes, opaque callbacks or hidden streams.
Audit dictionaries are snapshots. Caller graph edits require new admission.
"""
import dis
from dataclasses import dataclass
import hashlib
import json
import marshal
from pathlib import Path
import time
import types

import torch
from torch.utils._pytree import tree_flatten

from core import Lease, Rejected, compile_plan, digest
from export_backend import Program, canonical, fingerprint
from segmented_backend import lower, module_fingerprint
from torch_backend import allocation, bind, spec


def records(graph):
    return [(n.op, n.name, str(n.target), canonical(n.args), canonical(n.kwargs)) for n in graph.nodes]


def state_token(t):
    return (tuple(t.shape), tuple(t.stride()), t.storage_offset(), str(t.dtype),
            str(t.device), allocation(t), t._version, t.requires_grad)


@dataclass(frozen=True)
class Function:
    invoke: object
    code: object
    globals_items: tuple
    module_sha256: str


def capture(module):
    original = module.forward.__func__
    code = original.__code__
    if code.co_freevars or original.__closure__ or original.__defaults__ or original.__kwdefaults__:
        raise Rejected('generated functions must have no closures or defaults')
    instructions = list(dis.get_instructions(code))
    if any(i.opname == 'LOAD_FAST' and i.argval == 'self' for i in instructions):
        raise Rejected('generated stages cannot access module state')
    names = {i.argval for i in instructions if i.opname == 'LOAD_GLOBAL'}
    if any(name not in original.__globals__ for name in names):
        raise Rejected('implicit globals are outside the captured code contract')
    namespace = {name: original.__globals__[name] for name in names}
    namespace['__builtins__'] = {}
    function = types.FunctionType(code, namespace, 'forward')
    return Function(function, code, tuple(namespace.items()), module_fingerprint(module))


@dataclass(frozen=True)
class Capsule:
    root: str
    expected: object
    plan: object
    child_executable: str
    executable: str
    state: tuple
    state_tokens: tuple
    placeholder_names: tuple
    groups: tuple
    live: tuple
    functions: tuple
    artifact_json: str


class OwnedProgram:
    __slots__ = ('_capsule',)

    def __setattr__(self, name, value):
        raise Rejected('an owned program cannot be replaced in place; construct a new one')

    def __init__(self, exported, example, late_read=False):
        checked = Program(exported, example, late_read=late_read)
        # No caller-owned weight allocation remains in the executable.
        checked.state = {name: t.detach().clone(memory_format=torch.preserve_format)
                         for name, t in checked.state.items()}
        checked.executable = fingerprint(checked.graph, checked.state)
        checked.plan = compile_plan(checked.plan.roots, checked.plan.nodes, checked.plan.outputs,
                                    dict(checked.plan.specs), checked.executable)
        modules, groups, live = lower(checked)
        functions = tuple(capture(m) for m in modules)
        state = tuple(checked.state.items())
        artifact = dict(schema='borrowplan-owned-segmented-artifact-v5',
            child_executable=checked.executable, child_plan_sha256=checked.plan.sha256,
            backend_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            graph=records(checked.graph), groups=groups, live=live,
            binding_contract='owned captured functions and cloned state; audit objects are detached',
            modules=[dict(nodes=records(m.graph), code=m.code, sha256=f.module_sha256,
                          code_sha256=hashlib.sha256(marshal.dumps(f.code)).hexdigest())
                     for m, f in zip(modules, functions)])
        capsule = Capsule(checked.root, checked.expected, checked.plan, checked.executable, digest(artifact),
            state, tuple(state_token(t) for _, t in state),
            tuple(n.name for n in checked.graph.nodes if n.op == 'placeholder'),
            groups, live, functions, json.dumps(artifact, sort_keys=True))
        object.__setattr__(self, '_capsule', capsule)

    @property
    def root(self):
        return self._capsule.root

    @property
    def plan(self):
        return self._capsule.plan

    @property
    def executable(self):
        return self._capsule.executable

    @property
    def artifact(self):
        return json.loads(self._capsule.artifact_json)

    def guard(self):
        c = self._capsule
        if tuple(state_token(t) for _, t in c.state) != c.state_tokens:
            raise Rejected('owned state changed')
        for f in c.functions:
            if (f.invoke.__code__ is not f.code or f.invoke.__closure__ is not None
                    or f.invoke.__defaults__ is not None or f.invoke.__kwdefaults__ is not None
                    or len(f.invoke.__globals__) != len(f.globals_items)
                    or any(f.invoke.__globals__.get(k) is not v for k, v in f.globals_items)):
                raise Rejected('owned generated function changed')

    def start(self, x, publication=None, ready=None):
        c = self._capsule
        if not x.is_cuda or spec(x) != c.expected:
            raise Rejected('fixed ordinary CUDA input required')
        self.guard()
        if any(allocation(x) == token[5] for token in c.state_tokens):
            raise Rejected('input aliases owned model state')
        b = bind(x, **(publication or {}))
        # Retain the original complete plan regeneration and publication checks.
        lease = Lease(c.plan, {c.root: b}, c.child_executable, {c.root: b.version})
        if ready is None:
            ready = torch.cuda.Event()
            ready.record(torch.cuda.current_stream(x.device))
        elif not isinstance(ready, torch.cuda.Event):
            raise Rejected('the adapter requires a trusted CUDA ready event')
        return OwnedExecution(self, lease, x, ready)


class OwnedExecution:
    def __init__(self, program, lease, x, ready):
        self.program, self.lease, self.x, self.ready = program, lease, x, ready
        self._admitted = program
        self.stage, self.failed, self.stream = 0, False, None
        self.events, self.receipts = [], []
        self.boundary, self.result = None, None

    def submit(self, stage, stream):
        if (type(stage) is not int or stage != self.stage or stage not in (0, 1)
                or self.lease.aborted or self.failed or self.program is not self._admitted):
            raise Rejected('out-of-order or repeated stage')
        if self.stream is not None and stream.cuda_stream != self.stream.cuda_stream:
            raise Rejected('only one CUDA stream is supported')
        if stream.device != torch.device(self.program._capsule.expected.device):
            raise Rejected('stream device differs from the admitted input')
        self.program.guard()
        c = self.program._capsule
        self.stream = stream
        started = time.monotonic_ns()
        try:
            with torch.cuda.stream(stream), torch.inference_mode():
                if stage == 0:
                    stream.wait_event(self.ready)
                    state = dict(c.state)
                    args = tuple(self.x if n == c.root else state[n] for n in c.placeholder_names)
                else:
                    args = self.boundary
                value = tuple(c.functions[stage].invoke(None, *args))
                event = torch.cuda.Event()
                event.record(stream)
            leaves, _ = tree_flatten(value)
            root_allocation = self.lease.bindings[c.root].allocation
            if any(isinstance(t, torch.Tensor) and allocation(t) == root_allocation for t in leaves):
                raise Rejected('stage result aliases the source')
            for name in c.groups[stage]:
                self.lease.begin(name)
                self.lease.submitted(name, event)
            self.events.append(event)
            self.receipts.append(dict(stage=stage, operations=c.groups[stage],
                module_sha256=c.functions[stage].module_sha256,
                started_ns=started, submitted_ns=time.monotonic_ns(), event_handle=int(event.cuda_event),
                stream_handle=int(stream.cuda_stream), dynamic_boundary_alias=False))
            if stage == 0:
                self.boundary, self.x = value, None
            else:
                self.result, self.boundary = value, None
            self.stage += 1
            return event
        except BaseException:
            self.failed = True
            raise

    def wait_stage(self, stage):
        self.events[stage].synchronize()
        self.receipts[stage].setdefault('wait_completed_ns', time.monotonic_ns())

    def wait(self):
        for stage in range(len(self.events)):
            self.wait_stage(stage)

    def outputs(self):
        if self.failed or self.stage != 2 or self.result is None or not self.lease.can_publish():
            raise Rejected('output before checked completion')
        return self.result
