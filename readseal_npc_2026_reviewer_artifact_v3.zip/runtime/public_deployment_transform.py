"""Controlled use of PyTorch 2.1.2's public inference conv/BN folding primitive.

This is a deployment-change case study, not a production incident. Fold only a
single-use conv -> inference BN -> tuple[0] pattern. Keep unsupported patterns
in the graph; never erase a side output or add ReadSeal operator support here.
"""
import copy
import operator
import torch
from torch.fx import GraphModule
from torch.nn.utils.fusion import fuse_conv_bn_weights

SOURCES = [
    'https://github.com/pytorch/pytorch/blob/v2.1.2/torch/nn/utils/fusion.py',
    'https://github.com/pytorch/pytorch/blob/v2.1.2/torch/_inductor/fx_passes/pre_grad.py',
]


def attribute(module, node):
    if node is None:
        return None
    if not isinstance(node, torch.fx.Node) or node.op != 'get_attr':
        raise ValueError('fusion parameter must be a lifted constant attribute')
    value = module
    for part in node.target.split('.'):
        value = getattr(value, part)
    if not isinstance(value, torch.Tensor):
        raise ValueError('non-tensor parameter')
    return value


def fold_export(exported):
    original = exported.module()
    graph = copy.deepcopy(original.graph)
    model = GraphModule(copy.deepcopy(original), graph)
    records, skipped = [], []
    for bn in list(graph.nodes):
        if str(bn.target) != 'aten._native_batch_norm_legit_no_training.default':
            continue
        conv = bn.args[0]
        if (not isinstance(conv, torch.fx.Node) or str(conv.target) != 'aten.convolution.default'
                or len(conv.users) != 1 or conv.args[6] is not False):
            skipped.append(dict(node=bn.name, reason='not a single-use non-transposed convolution'))
            continue
        users = list(bn.users)
        if not users or any(u.target is not operator.getitem or u.args[1] != 0 for u in users):
            skipped.append(dict(node=bn.name, reason='batchnorm auxiliary outputs used'))
            continue
        weight, bias = attribute(model, conv.args[1]), attribute(model, conv.args[2])
        bn_weight, bn_bias, mean, variance = [attribute(model, n) for n in bn.args[1:5]]
        eps = bn.args[6]
        if not isinstance(eps, (float, int)):
            raise ValueError('nonconstant batchnorm epsilon')
        fused_weight, fused_bias = fuse_conv_bn_weights(weight, bias, mean, variance, eps, bn_weight, bn_bias)
        i = len(records)
        wname, bname = f'_deployment_fused_weight_{i}', f'_deployment_fused_bias_{i}'
        model.register_buffer(wname, fused_weight.detach())
        model.register_buffer(bname, fused_bias.detach())
        with graph.inserting_before(conv):
            wnode, bnode = graph.get_attr(wname), graph.get_attr(bname)
        args = list(conv.args)
        args[1:3] = [wnode, bnode]
        conv.args = tuple(args)
        for user in users:
            user.replace_all_uses_with(conv)
            graph.erase_node(user)
        records.append(dict(convolution=conv.name, batchnorm=bn.name, epsilon=float(eps),
                            weight_shape=list(weight.shape), primitive='torch.nn.utils.fusion.fuse_conv_bn_weights'))
        graph.erase_node(bn)
    graph.eliminate_dead_code()
    graph.lint()
    model.recompile()
    return model, dict(folded=records, skipped=skipped, public_sources=SOURCES,
                      scope='controlled application of documented deployment optimization; not human study')
