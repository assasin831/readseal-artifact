"""All eight independent process repetitions, paired two-block resampling."""
import argparse
import json
from pathlib import Path
import traceback
import numpy as np
from manual_static import sha
from validate_followup import cost,control,METHODS


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--run',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=False)
    result=dict(status='RUNNING',analyzer_sha256=sha(__file__),cases=[])
    try:
        top=json.loads((a.run/'report.json').read_text())
        assert top['status']=='COMPLETE' and len(top['runs'])==9
        for r in top['runs']:
            assert sha(a.run/r['name']/'report.json')==r['report_sha256']
            assert sha(a.run/(r['name']+'-validation')/'validation.json')==r['validation_sha256']
        result['control']=control(a.run/'local-event-control',json.loads((a.run/'local-event-control/report.json').read_text()))
        audits=[cost(a.run/f'cost-r{i:02d}',json.loads((a.run/f'cost-r{i:02d}/report.json').read_text())) for i in range(8)]
        assert [x['repeat'] for x in audits]==list(range(8))
        rng=np.random.default_rng(77291)
        process=rng.integers(0,8,size=(20000,8))
        blocks=rng.integers(0,2,size=(20000,8,2))
        for key in audits[0]['values_ms']:
            values=np.array([x['values_ms'][key] for x in audits])
            assert values.shape==(8,50,3)
            # A block summary is a median of 25 paired invocations. Average
            # these summaries within and across the eight process families.
            summaries=np.median(values.reshape(8,2,25,3),axis=2)
            sampled=summaries[process[:,:,None],blocks].mean(axis=(1,2))
            estimates=summaries.mean(axis=(0,1))
            out=dict(key=key,methods={},contrasts={},process_block_medians_ms=summaries.tolist())
            for j,m in enumerate(METHODS):
                out['methods'][m]=dict(mean_block_median_ms=float(estimates[j]),
                    interval=np.percentile(sampled[:,j],[2.5,97.5]).tolist())
            for j,m in enumerate(METHODS[1:],1):
                d=sampled[:,0]-sampled[:,j]
                q=sampled[:,0]/sampled[:,j]
                out['contrasts']['auto_vs_'+m]=dict(extra_ms=float(estimates[0]-estimates[j]),
                    extra_interval=np.percentile(d,[2.5,97.5]).tolist(),ratio=float(estimates[0]/estimates[j]),
                    ratio_interval=np.percentile(q,[2.5,97.5]).tolist())
            result['cases'].append(out)
        result.update(status='COMPLETE',process_repetitions=8,bootstrap_replicates=20000,bootstrap_seed=77291,
            timed_invocations=14400,campaign_sha256=sha(a.run/'report.json'),
            interpretation='pointwise same-session paired hierarchical process/25-triplet-block intervals; no equivalence test')
    except BaseException:
        result.update(status='FAILED',traceback=traceback.format_exc())
    (a.output/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
    (a.output/result['status']).write_text(result['status']+'\n')
    print(json.dumps({k:result[k] for k in ('status','timed_invocations','traceback') if k in result}))
    return 0 if result['status']=='COMPLETE' else 1


if __name__=='__main__':
    raise SystemExit(main())
