"""Independent receipt/data audit; no import of compiler, pool or managers."""
import argparse
import hashlib
import json
import operator
from pathlib import Path
import traceback

import torch


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    for name in ("run", "sources", "export", "cases", "backend", "core", "output"):
        p.add_argument("--" + name, type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    count = 0

    def check(value, message):
        nonlocal count
        count += 1
        if not value:
            raise AssertionError(message)

    def plan_audit(plan):
        roots = plan["roots"]
        provenance = {r: {r} for r in roots}
        aliases = {r: {r} for r in roots}
        obligations = {r: set() for r in roots}
        for n in plan["nodes"]:
            s, ins = n["summary"], n["inputs"]
            check(n["name"] not in provenance and all(i in provenance for i in ins), "topological unique names")
            check(not s["writes"] and s["completion"] in ("synchronous", "input_consumed", "operation_complete"), "supported access summary")
            for index in s["reads"]:
                for root in aliases[ins[index]]:
                    obligations[root].add(n["name"])
            provenance[n["name"]] = set().union(*(provenance[i] for i in ins))
            aliases[n["name"]] = set().union(*(aliases[ins[i]] for i in s["aliases"]))
        facts = dict(plan["facts"])
        for n in provenance:
            check(set(facts[n]["provenance"]) == provenance[n], "numerical provenance")
            check(set(facts[n]["borrows"]) == aliases[n], "physical alias fact")
        for root in roots:
            check(set(dict(plan["obligations"])[root]) == obligations[root], "full future-reader closure")
            check(dict(plan["escapes"])[root] == [o for o in plan["outputs"] if root in aliases[o]], "escaped aliases")
        hashed = dict(plan)
        hashed["facts"] = [(n, sorted(facts[n]["provenance"]), sorted(facts[n]["borrows"])) for n in provenance]
        return digest(hashed)

    result = {"status": "RUNNING", "validator_sha256": sha(__file__),
              "scope": "independent schema/receipt and saved-output audit; not independent CUDA reexecution"}
    try:
        report = json.loads((a.run / "report.json").read_text())
        check(report["status"] == "COMPLETE" and (a.run / "COMPLETE").exists() and not (a.run / "FAILED").exists(), "run completion")
        check(report["performance_claim"] is False and report["private_overlap_claim"] is False
              and report["full_retention_integration"] is False, "scope not overstated")
        check(report["gpu_uuid"] == "GPU-f3b314a8-3058-e0be-694c-76f4227afb7d", "GPU0 binding")
        check(report["tensorrt"] == "10.3.0" and report["native"]["tf32"] is False and report["native"]["plugins"] is False, "native SDK policy")
        check(sha(a.run / "native.engine") == report["native"]["engine_sha256"], "executed native engine")
        check(sha(a.export) == report["export_sha256"] == "8efaa67aa6884d0c9aec6fff442e9a50b683a290d856abef390db1f034ccabbd", "frozen child export")
        check(sha(a.cases / "report.json") == report["cases_receipt_sha256"], "input receipt")
        for name, h in report["source_sha256"].items():
            check(sha(a.sources / name) == h, "native adapter source")
        for name, h in report["dependency_sha256"].items():
            directory = a.core if name in ("core.py", "torch_backend.py") else a.backend
            check(sha(directory / name) == h, "executor and pool dependency hash")
        exported = torch.export.load(a.export)
        root = exported.graph_signature.user_inputs[0]
        original = [n for n in exported.graph.nodes if n.name != root and n.op != "output"]
        names = {f"case_{i}-{m}-{p}" for i in range(3) for m in ("base", "late") for p in ("automatic", "native-complete-manager")}
        check(len(report["cases"]) == 12 and {c["name"] for c in report["cases"]} == names, "complete frozen coverage")
        pairs = {}
        for case in report["cases"]:
            folder = a.run / case["name"]
            check((folder / "COMPLETE").exists() and not (folder / "FAILED").exists(), "case completion")
            source = a.cases / (case["name"].split("-")[0] + ".pt")
            check(sha(source) == case["case_sha256"], "source input hash")
            check(json.loads((folder / "record.json").read_text()) == case, "case index consistency")
            for name, h in case["files"].items():
                check(sha(folder / name) == h, "case artifact checksum")
            parent = json.loads((folder / "parent-plan.json").read_text())
            child = json.loads((folder / "child-plan.json").read_text())
            check(plan_audit(parent) == case["parent_plan_sha256"], "parent canonical hash")
            check(plan_audit(child) == case["child_plan_sha256"], "child canonical hash")
            check([n["name"] for n in parent["nodes"]] == ["A", "B", "C"], "component coverage")
            an, bn, cn = parent["nodes"]
            check(an["inputs"] == ["source"] and an["summary"]["reads"] == [0] and not an["summary"]["aliases"]
                  and an["summary"]["completion"] == "input_consumed", "native component contract")
            check(bn["inputs"] == ["source"] and not bn["summary"]["reads"] and bn["summary"]["aliases"] == [0], "metadata view contract")
            check(cn["inputs"] == ["B"] and cn["summary"]["reads"] == [0] and not cn["summary"]["aliases"]
                  and cn["summary"]["completion"] == "input_consumed", "derived child boundary")
            check(cn["summary"]["implementation"] == digest({"child_plan": case["child_plan_sha256"], "adapter": sha(a.sources / "native_composition.py")}), "child boundary binding")
            check(dict(parent["obligations"]) == case["parent_obligations"] == {"source": ["A", "C"]}, "alias-mediated future obligation")
            late = "-late-" in case["name"]
            check(len(child["nodes"]) == len(original) + (2 if late else 0), "child graph node coverage")
            trace = json.loads((folder / "dispatch.json").read_text())
            check([n["name"] for n in child["nodes"]] == [r["node"] for r in trace], "dispatch order")
            targets = {n.name: n.target for n in original if n.op == "call_function"}
            for expected, node in zip(original, child["nodes"]):
                check(expected.name == node["name"] and [n.name for n in expected.all_input_nodes] == node["inputs"], "actual export dataflow")
            if late:
                targets[child["nodes"][-2]["name"]] = torch.ops.aten.clone.default
                targets[child["nodes"][-1]["name"]] = torch.ops.aten.mean.default
                check(child["nodes"][-2]["inputs"] == [root]
                      and child["nodes"][-1]["inputs"] == [child["nodes"][-2]["name"]], "late-read mutation")
            for node, receipt in zip(child["nodes"], trace):
                s, target = node["summary"], targets.get(node["name"])
                if target is None:
                    check(not node["inputs"] and not s["reads"] and not s["aliases"], "lifted private constant")
                    continue
                check(str(target) == receipt["operator"], "actual ATen identity")
                indices = list(range(len(node["inputs"])))
                check(s["reads"] == indices, "conservative read operands")
                if target is operator.getitem:
                    expected_aliases = indices
                else:
                    check(s["implementation"] == str(target._schema), "bound operator schema")
                    expected_aliases = indices if any(r.alias_info is not None for r in target._schema.returns) else []
                check(s["aliases"] == expected_aliases, "complete declared aliases")
            closure = case["closure"]
            order = [n["name"] for n in child["nodes"]]
            cut = order.index(closure["after_child_operation"])
            q = dict(child["obligations"])[root]
            check(q == case["child_obligations"][root] and all(order.index(n) <= cut for n in q), "no unread child borrow at overwrite")
            check(order[cut + 1:] == closure["pending_private_operations"] and bool(order[cut + 1:]), "private work remains")
            check(case["delayed_consumer_blocked_reuse"] is True and closure["native_input_consumed"] is True
                  and closure["parent_output_publishable"] is False, "native/child completion separation receipts")
            old, new = closure["old_version"], closure["new_version"]
            check(new == [old[0], old[1] + 1, old[2] + 2], "actual pool version transition")
            for identity in case["parent_output_identity"].values():
                check([identity["epoch"], identity["sequence"], identity["generation"]] == old, "publication retains original source")
            data = torch.load(folder / "outputs.pt", map_location="cpu")
            check(len(data["actual"]) == len(data["expected"]) == len(case["outputs"]) == (11 if late else 10), "output coverage")
            for tensor, expected, record in zip(data["actual"], data["expected"], case["outputs"]):
                check(torch.equal(tensor, expected) and bool(torch.isfinite(tensor).all()), "exact raw output")
                h = hashlib.sha256(tensor.contiguous().numpy().tobytes()).hexdigest()
                check(h == record["actual_sha256"] == record["expected_sha256"] and record["exact"] is True, "output hash")
            key = case["name"].split("-" + case["policy"])[0]
            signature = (case["parent_plan_sha256"], case["child_plan_sha256"], [r["actual_sha256"] for r in case["outputs"]])
            if key in pairs:
                check(signature == pairs[key], "automatic and complete manager share plans and outputs")
            else:
                pairs[key] = signature
        check(len(pairs) == 6, "six matched policy pairs")
        result.update(status="COMPLETE", checks=count, cases=12, matched_pairs=6, report_sha256=sha(a.run / "report.json"))
        (a.output / "COMPLETE").write_text("Independent native composition evidence audit complete.\n")
    except BaseException as exc:
        result.update(status="FAILED", checks=count, error=str(exc))
        (a.output / "FAILED").write_text(type(exc).__name__ + "\n")
        (a.output / "traceback.txt").write_text(traceback.format_exc())
    (a.output / "validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)
    return 0 if result["status"] == "COMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
