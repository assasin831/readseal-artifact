"""Deterministic differential tests against unmodified Lease; no torch/GPU."""
from dataclasses import asdict, replace
import json
import random

from core import Binding, Lease, Node, Rejected, Summary, TensorSpec, compile_plan, digest
from prepared_lease import PreparedLease, prepare


class Event:
    def __init__(self):
        self.done = False

    def query(self):
        return self.done


def main():
    rng = random.Random(75017)
    checks = 0
    shape = TensorSpec((2, 3), (3, 1), 'float32', 'cpu')
    binding = Binding('allocation-A', 24, 1, 2, 4, digest(asdict(shape)), shape)
    plans = []
    for escape in (False, True):
        plans.append(compile_plan(('x',), (Node('view', ('x',), Summary((0,), (0,), implementation='view')),
            Node('read', ('view',), Summary((0,), (0,) if escape else (), implementation='read'))),
            ('read',), {'x': shape}, 'fixed-code'))
    two = compile_plan(('x', 'y'), (Node('read', ('x', 'y'), Summary((0, 1), implementation='read')),),
                       ('read',), {'x': shape, 'y': shape}, 'fixed-code')
    plans.append(two)
    fields = ('allocation', 'allocation_bytes', 'epoch', 'sequence', 'generation', 'contract', 'spec')
    values = {'allocation': ('', 'allocation-A', 'allocation-B'), 'allocation_bytes': (-1, 0, 24, 48),
        'epoch': (-1, 0, 1, 2**40, 2**64-1, 2**64, True),
        'sequence': (-1, 0, 1, 2, 2**64-1, 2**64, False),
        'generation': (-1, 0, 1, 2, 4, 2**64-2, 2**64), 'contract': ('', binding.contract, 'wrong'),
        'spec': (shape, replace(shape, shape=(6,)), replace(shape, device='cuda:0'))}

    def outcome(fn):
        try:
            return ('ok', fn())
        except Rejected as exc:
            return ('rejected', str(exc))

    for plan in plans:
        certificate = prepare(plan)
        for _ in range(1000):
            bindings = {r: binding for r in plan.roots}
            root = rng.choice(plan.roots)
            field = rng.choice(fields)
            bindings[root] = replace(binding, **{field: rng.choice(values[field])})
            expected = {r: b.version for r, b in bindings.items()}
            if rng.random() < .1:
                expected[root] = (1, 999, 4)
            executable = 'fixed-code' if rng.random() < .9 else 'changed'
            old = outcome(lambda: Lease(plan, bindings, executable, expected))
            new = outcome(lambda: PreparedLease(certificate, bindings, executable, expected))
            assert old[0] == new[0]
            if old[0] == 'rejected':
                assert old[1] == new[1]
            else:
                for name in ('plan', 'bindings', 'sizes', 'states', 'nodes', 'returned', 'aborted', 'published'):
                    assert getattr(old[1], name) == getattr(new[1], name)
            checks += 1
        for _ in range(100):
            bs = {r: binding for r in plan.roots}
            old = Lease(plan, bs, plan.executable, {r: b.version for r, b in bs.items()})
            new = PreparedLease(certificate, bs, plan.executable, {r: b.version for r, b in bs.items()})
            event = Event()
            for step in range(40):
                action = rng.randrange(8)
                name = rng.choice(tuple(old.nodes))
                if action == 0:
                    event.done = True
                def invoke(lease):
                    if action == 0:
                        return None
                    if action == 1:
                        return lease.begin(name)
                    if action == 2:
                        return lease.submitted(name, event)
                    if action == 3:
                        return lease.abort()
                    if action == 4:
                        return lease.can_release('allocation-A')
                    if action == 5:
                        return lease.can_publish()
                    if action == 6:
                        return lease.publish_identity()
                    return lease.return_output_borrow('read')
                assert outcome(lambda: invoke(old)) == outcome(lambda: invoke(new))
                assert old.states == new.states and old.aborted == new.aborted and old.published == new.published
                checks += 1
        for corrupt in (replace(plan, obligations=()), replace(plan, facts=()), replace(plan, nodes=list(plan.nodes))):
            assert outcome(lambda: prepare(corrupt))[0] == 'rejected'
            checks += 1
    print(json.dumps(dict(status='COMPLETE', checks=checks, binding_cases=3000, transition_steps=12000,
                          inherited_state_machine=True, seed=75017)))


if __name__ == '__main__':
    main()
