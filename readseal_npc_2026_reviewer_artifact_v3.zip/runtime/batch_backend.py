"""Owned V10 grouped execution; all original state/function/stream/alias guards remain."""
import hashlib
import json
from pathlib import Path
import time
import torch
from torch.utils._pytree import tree_flatten
from core import Rejected, digest
from owned_backend import OwnedExecution
from owned_witness import WitnessProgram
from torch_backend import allocation, bind, spec
from batch_lease import BatchLease, prepare_groups
import batch_lease


class BatchProgram(WitnessProgram):
    __slots__=('_grouping','_batch_artifact','_batch_identity')

    def __init__(self,exported,example,late_read=False):
        super().__init__(exported,example,late_read)
        object.__setattr__(self,'_grouping',prepare_groups(self.plan,self._capsule.groups))
        art=super().artifact
        art.update(schema='borrowplan-batched-witness-v10',
            batch_backend_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            batch_lease_sha256=hashlib.sha256(Path(batch_lease.__file__).read_bytes()).hexdigest(),
            batching='one checked group transition per owned stage; all logical nodes retained',
            guard_schedule='admission and both submissions; unchanged state, function, stream, alias checks')
        object.__setattr__(self,'_batch_artifact',json.dumps(art,sort_keys=True))
        object.__setattr__(self,'_batch_identity',digest(art))

    @property
    def artifact(self):
        return json.loads(self._batch_artifact)

    @property
    def executable(self):
        return self._batch_identity

    def guard(self):
        super().guard()
        c=self._capsule
        if self._grouping.plan is not c.plan or self._grouping.groups != c.groups:
            raise Rejected('grouped transitions do not match owned executable')

    def start(self,x,publication=None,ready=None):
        c=self._capsule
        if not x.is_cuda or spec(x)!=c.expected:
            raise Rejected('fixed ordinary CUDA input required')
        self.guard()
        if self._certificate.plan is not c.plan:
            raise Rejected('certificate is not for the admitted executable')
        if any(allocation(x)==token[5] for token in c.state_tokens):
            raise Rejected('input aliases owned model state')
        b=bind(x,**(publication or {}))
        lease=BatchLease(self._certificate,{c.root:b},c.child_executable,{c.root:b.version},self._grouping)
        if ready is None:
            ready=torch.cuda.Event()
            ready.record(torch.cuda.current_stream(x.device))
        elif not isinstance(ready,torch.cuda.Event):
            raise Rejected('the adapter requires a trusted CUDA ready event')
        return BatchExecution(self,lease,x,ready)


class BatchExecution(OwnedExecution):
    def submit(self, stage, stream):
        if (type(stage) is not int or stage != self.stage or stage not in (0, 1)
                or self.lease.aborted or self.failed or self.program is not self._admitted):
            raise Rejected('out-of-order or repeated stage')
        if self.stream is not None and stream.cuda_stream != self.stream.cuda_stream:
            raise Rejected('only one CUDA stream is supported')
        if stream.device != torch.device(self.program._capsule.expected.device):
            raise Rejected('stream device differs from the admitted input')
        self.program.guard()
        c = self.program._capsule
        self.stream = stream
        started = time.monotonic_ns()
        try:
            self.lease.begin_group(stage)
            with torch.cuda.stream(stream), torch.inference_mode():
                if stage == 0:
                    stream.wait_event(self.ready)
                    state = dict(c.state)
                    args = tuple(self.x if n == c.root else state[n] for n in c.placeholder_names)
                else:
                    args = self.boundary
                value = tuple(c.functions[stage].invoke(None, *args))
                event = torch.cuda.Event()
                event.record(stream)
            leaves, _ = tree_flatten(value)
            root_allocation = self.lease.bindings[c.root].allocation
            if any(isinstance(t, torch.Tensor) and allocation(t) == root_allocation for t in leaves):
                raise Rejected('stage result aliases the source')
            self.lease.submitted_group(stage, event)
            self.events.append(event)
            self.receipts.append(dict(stage=stage, operations=c.groups[stage],
                module_sha256=c.functions[stage].module_sha256,
                started_ns=started, submitted_ns=time.monotonic_ns(), event_handle=int(event.cuda_event),
                stream_handle=int(stream.cuda_stream), dynamic_boundary_alias=False))
            if stage == 0:
                self.boundary, self.x = value, None
            else:
                self.result, self.boundary = value, None
            self.stage += 1
            return event
        except BaseException:
            self.failed = True
            raise


