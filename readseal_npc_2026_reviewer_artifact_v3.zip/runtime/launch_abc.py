"""Serial GPU0 campaign; gates and every cell validate before further work."""
import fcntl
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import traceback
from common import ROOT, GPU, sha

SOURCE=Path(__file__).resolve().parent
OUT=ROOT/'results/borrowplan_v8_abc_attempt1'


def main():
    OUT.mkdir(parents=True,exist_ok=False)
    (OUT/'pid').write_text(str(os.getpid())+'\n')
    result=dict(status='RUNNING',runs=[],sources={str(p):sha(p) for p in SOURCE.iterdir() if p.is_file()})
    try:
        with (ROOT/'borrowplan_gpu0.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            deps=[SOURCE]+[ROOT/p for p in (
                'prototype_borrowplan_v7_followups_attempt1',
                'prototype_borrowplan_v7_formal_attempt1',
                'prototype_borrowplan_v6_resnet_scope_attempt1','prototype_borrowplan_v6_witness_attempt1',
                'prototype_borrowplan_v5_prepared_attempt1','prototype_borrowplan_v5_owned_attempt2',
                'prototype_borrowplan_v4_segmented_attempt1','prototype_borrowplan_v1_attempt2',
                'prototype_borrowplan_v2_composition_attempt2','prototype_borrowplan_v3_attempt1',
                'sdk_trt_10_3_attempt2/packages','experiments')]
            env=dict(os.environ,PYTHONPATH=':'.join(map(str,deps)),CUDA_VISIBLE_DEVICES=GPU,
                PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
                CUDA_CACHE_PATH=str(OUT/'cuda-cache'))
            plan=json.loads((SOURCE/'PLAN.json').read_text())
            result.update(plan=plan,plan_sha256=sha(SOURCE/'PLAN.json'))
            commands=[dict(name='gate',kind='gate',command=[sys.executable,'-B',str(SOURCE/'run_gate.py'),'--output',str(OUT/'gate')])]
            pilot={k:plan[k] for k in ('model','queue','deadline_ms','warmup_seconds','measure_seconds')}
            pilot.update(plan['pilot']); pilot['id']='pilot-n2-r1-hz30'
            for m in plan['methods']:
                name='pilot-'+m
                commands.append(dict(name=name,kind='cell',pilot=True,command=[sys.executable,'-B',str(SOURCE/'run_abc.py'),
                    '--output',str(OUT/name),'--cell',json.dumps(pilot),'--method',m]))
            order=random.Random(plan['order_seed'])
            for rep in range(plan['repetitions']):
                conditions=list(plan['conditions']); order.shuffle(conditions)
                for condition in conditions:
                    methods=list(plan['methods']); order.shuffle(methods)
                    cell={k:plan[k] for k in ('model','queue','deadline_ms','warmup_seconds','measure_seconds')}
                    cell.update(condition)
                    for m in methods:
                        name=f'r{rep:02d}-{condition["id"]}-{m}'
                        commands.append(dict(name=name,kind='cell',pilot=False,repeat=rep,condition=condition,method=m,
                            command=[sys.executable,'-B',str(SOURCE/'run_abc.py'),'--output',str(OUT/name),'--cell',json.dumps(cell),'--method',m]))
            result['schedule']=[{k:v for k,v in c.items() if k!='command'} for c in commands]
            for item in commands:
                assert all(sha(p)==h for p,h in result['sources'].items()), 'source changed'
                assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader'],text=True).strip(), 'foreign work'
                name=item['name']; result['active']=name
                (OUT/'report.json').write_text(json.dumps(result,indent=2)+'\n')
                with (OUT/(name+'.log')).open('x') as log:
                    status=subprocess.run(item['command'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
                assert status==0, name+' failed; no retry'
                validation=OUT/(name+'-validation')
                command=[sys.executable,'-B',str(SOURCE/'validate_abc.py'),'--kind',item['kind'],'--run',str(OUT/name),'--output',str(validation)]
                with (OUT/(name+'-validation.log')).open('x') as log:
                    status=subprocess.run(command,cwd=ROOT,env=dict(env,CUDA_VISIBLE_DEVICES=''),stdout=log,stderr=subprocess.STDOUT).returncode
                assert status==0, name+' validation failed; no retry'
                result['runs'].append(dict({k:v for k,v in item.items() if k!='command'},
                    report_sha256=sha(OUT/name/'report.json'),validation_sha256=sha(validation/'validation.json')))
                print('COMPLETE '+name,flush=True)
            result.update(status='COMPLETE',active=None)
    except BaseException:
        result.update(status='FAILED',traceback=traceback.format_exc()); traceback.print_exc()
    (OUT/'report.json').write_text(json.dumps(result,indent=2)+'\n')
    (OUT/result['status']).write_text(result['status']+'\n')
    return 0 if result['status']=='COMPLETE' else 1


if __name__=='__main__':
    raise SystemExit(main())
