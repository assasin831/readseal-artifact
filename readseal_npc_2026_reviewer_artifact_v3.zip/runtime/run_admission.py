"""Full frozen A/B/C consumer with the V10 uniform receipt-based admission cap."""
import argparse
import json
from pathlib import Path
import admission_streaming as base
import run_abc as abc
from study_common import compute_pids, configure
from common import inventory


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--output',type=Path,required=True)
    p.add_argument('--cell',required=True); p.add_argument('--method',required=True)
    a=p.parse_args()
    assert not compute_pids(), 'foreign compute; no inference launched'
    configure()
    base.make_program=abc.factory
    base.consumer=abc.consumer
    base.source_inventory=inventory
    print(json.dumps(base.measure_cell(a.output,json.loads(a.cell),a.method)),flush=True)
