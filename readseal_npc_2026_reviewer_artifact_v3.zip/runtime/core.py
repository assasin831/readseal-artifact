"""Finite, closed-world borrow obligations. No torch dependency or clock guesses."""
from dataclasses import asdict, dataclass
import hashlib
import json
from threading import RLock


class Rejected(ValueError):
    pass


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


@dataclass(frozen=True)
class TensorSpec:
    shape: tuple
    stride: tuple
    dtype: str
    device: str
    offset: int = 0


@dataclass(frozen=True)
class Summary:
    reads: tuple
    aliases: tuple = ()
    writes: tuple = ()
    completion: str = "operation_complete"
    implementation: str = ""


@dataclass(frozen=True)
class Node:
    name: str
    inputs: tuple
    summary: Summary


@dataclass(frozen=True)
class Fact:
    provenance: frozenset
    borrows: frozenset


@dataclass(frozen=True)
class Binding:
    allocation: str
    allocation_bytes: int
    epoch: int
    sequence: int
    generation: int
    contract: str
    spec: TensorSpec

    @property
    def version(self):
        return self.epoch, self.sequence, self.generation


@dataclass(frozen=True)
class Plan:
    roots: tuple
    nodes: tuple
    outputs: tuple
    specs: tuple
    executable: str
    facts: tuple
    obligations: tuple
    escapes: tuple

    @property
    def sha256(self):
        return digest({"roots": self.roots,
                       "nodes": [asdict(n) for n in self.nodes],
                       "outputs": self.outputs,
                       "specs": [(n, asdict(s)) for n, s in self.specs],
                       "executable": self.executable,
                       "facts": [(n, sorted(f.provenance), sorted(f.borrows))
                                 for n, f in self.facts],
                       "obligations": self.obligations, "escapes": self.escapes})


def compile_plan(roots, nodes, outputs, specs, executable):
    roots, nodes, outputs = tuple(roots), tuple(nodes), tuple(outputs)
    if not roots or len(set(roots)) != len(roots) or set(specs) != set(roots):
        raise Rejected("invalid roots/specification")
    if not executable or not outputs or len(set(outputs)) != len(outputs):
        raise Rejected("missing executable or invalid outputs")
    facts = {r: Fact(frozenset([r]), frozenset([r])) for r in roots}
    obligations = {r: set() for r in roots}
    for node in nodes:
        if node.name in facts or any(i not in facts for i in node.inputs):
            raise Rejected("graph must be unique and topologically ordered")
        s = node.summary
        if s.completion not in ("operation_complete", "input_consumed", "synchronous"):
            raise Rejected("untrusted or missing complete-work boundary")
        if not s.implementation or any(type(i) is not int or i < 0 or i >= len(node.inputs)
                                       for i in s.reads + s.aliases + s.writes):
            raise Rejected("invalid access summary")
        ins = [facts[i] for i in node.inputs]
        if any(ins[i].borrows for i in s.writes):
            raise Rejected("write to borrowed storage")
        incoming_provenance = frozenset().union(*(f.provenance for f in ins))
        if any(not incoming_provenance.issubset(ins[i].provenance) for i in s.writes):
            raise Rejected("mutation introducing new provenance through private aliases is unsupported")
        for i in s.reads:
            for root in ins[i].borrows:
                obligations[root].add(node.name)
        provenance = frozenset().union(*(f.provenance for f in ins))
        aliases = frozenset().union(*(ins[i].borrows for i in s.aliases))
        facts[node.name] = Fact(provenance, aliases)
    if any(o not in facts for o in outputs):
        raise Rejected("unknown output")
    escapes = {r: [] for r in roots}
    for output in outputs:
        for root in facts[output].borrows:
            escapes[root].append(output)
    return Plan(roots, nodes, outputs, tuple((r, specs[r]) for r in roots), executable,
                tuple(facts.items()), tuple((r, tuple(sorted(obligations[r]))) for r in roots),
                tuple((r, tuple(escapes[r])) for r in roots))


class Lease:
    """Owns only this invocation's borrow; producer/pool must join other leases.

    Completion objects come from a trusted backend and expose query(). The full
    closed graph is enrolled at construction, including work not yet submitted.
    Missing drain evidence leaves a borrow outstanding; timeout is not release.
    """

    def __init__(self, plan, bindings, executable, expected_versions):
        regenerated = compile_plan(plan.roots, plan.nodes, plan.outputs,
                                   dict(plan.specs), plan.executable)
        if regenerated != plan or executable != plan.executable:
            raise Rejected("plan or executable mismatch before launch")
        if set(bindings) != set(plan.roots) or set(expected_versions) != set(plan.roots):
            raise Rejected("incomplete group binding")
        sizes, versions = {}, {}
        for root, spec in plan.specs:
            b = bindings[root]
            if b.spec != spec or b.version != tuple(expected_versions[root]):
                raise Rejected("specification or publication changed before launch")
            if not b.allocation or b.contract != digest(asdict(spec)) or b.allocation_bytes <= 0:
                raise Rejected("invalid allocation identity")
            if any(type(v) is not int or v < 0 or v >= 2 ** 64 for v in b.version):
                raise Rejected("invalid version field")
            if b.sequence <= 0 or b.generation <= 0 or b.generation % 2:
                raise Rejected("invalid publication or writer-active generation")
            if b.allocation in versions and versions[b.allocation] != b.version:
                raise Rejected("one physical allocation cannot bind two versions")
            if b.allocation in sizes and sizes[b.allocation] != b.allocation_bytes:
                raise Rejected("inconsistent physical allocation size")
            versions[b.allocation], sizes[b.allocation] = b.version, b.allocation_bytes
        self.plan, self.bindings = plan, dict(bindings)
        self.sizes = sizes
        self.states = {n.name: "pending" for n in plan.nodes}
        self.nodes = {n.name: n for n in plan.nodes}
        self.events, self.output_events = {}, {}
        self.returned = set()
        self.aborted = False
        self.published = False
        self.lock = RLock()

    def begin(self, name):
        with self.lock:
            if self.aborted or self.states.get(name) != "pending":
                raise Rejected("unregistered, repeated or cancelled submission")
            if any(self.states[i] != "submitted" for i in self.nodes[name].inputs if i in self.states):
                raise Rejected("dependency not submitted")
            self.states[name] = "started"

    def submitted(self, name, read_done, output_done=None):
        with self.lock:
            if self.states.get(name) != "started" or not callable(getattr(read_done, "query", None)):
                raise Rejected("invalid completion witness")
            if output_done is None:
                if self.nodes[name].summary.completion == "input_consumed":
                    raise Rejected("input completion is not output completion")
                output_done = read_done
            if not callable(getattr(output_done, "query", None)):
                raise Rejected("missing output completion witness")
            self.events[name], self.output_events[name] = read_done, output_done
            self.states[name] = "submitted"

    def _done(self, name):
        return self.states[name] == "cancelled" or (
            self.states[name] == "submitted" and self.events[name].query())

    def can_release(self, allocation):
        with self.lock:
            if allocation not in self.sizes:
                raise Rejected("unknown allocation")
            obligations, escapes = dict(self.plan.obligations), dict(self.plan.escapes)
            for root, binding in self.bindings.items():
                if binding.allocation != allocation:
                    continue
                if any(not self._done(n) for n in obligations[root]):
                    return False
                if any(o not in self.returned for o in escapes[root]) and not self.aborted:
                    return False
            return True

    def return_output_borrow(self, name):
        with self.lock:
            # Sink acknowledgement is itself trusted; no naked tensor may escape.
            if self.aborted or name not in self.plan.outputs or name in self.returned:
                raise Rejected("invalid output-borrow acknowledgement")
            if any(s != "submitted" for s in self.states.values()):
                raise Rejected("output not produced")
            if not all(e.query() for e in self.output_events.values()):
                raise Rejected("output work incomplete")
            self.returned.add(name)

    def abort(self):
        with self.lock:
            if self.published:
                raise Rejected("published output cannot be cancelled by its producer")
            self.aborted = True
            for name, state in self.states.items():
                if state == "pending":
                    self.states[name] = "cancelled"

    def can_publish(self):
        with self.lock:
            return (not self.aborted and not self.published
                    and all(s == "submitted" for s in self.states.values())
                    and all(e.query() for e in self.events.values())
                    and all(e.query() for e in self.output_events.values()))

    def publish_identity(self):
        with self.lock:
            if not self.can_publish():
                raise Rejected("publication before completion or after abort")
            self.published = True
            facts = dict(self.plan.facts)
            return {o: {r: self.bindings[r] for r in sorted(facts[o].provenance)}
                    for o in self.plan.outputs}


def byte_time(intervals):
    """Union overlapping protection intervals per allocation, not per reader."""
    grouped, sizes = {}, {}
    for allocation, size, start, end in intervals:
        if size <= 0 or not (0 <= start <= end) or (
                allocation in sizes and sizes[allocation] != size):
            raise Rejected("invalid protection interval")
        sizes[allocation] = size
        grouped.setdefault(allocation, []).append((start, end))
    total = 0
    for allocation, windows in grouped.items():
        merged = []
        for start, end in sorted(windows):
            if merged and start <= merged[-1][1]:
                merged[-1] = merged[-1][0], max(end, merged[-1][1])
            else:
                merged.append((start, end))
        total += sizes[allocation] * sum(end - start for start, end in merged)
    return total
