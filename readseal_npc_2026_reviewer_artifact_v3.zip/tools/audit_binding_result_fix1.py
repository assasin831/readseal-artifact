"""CPU-only independent audit of the 26-case CUDA binding report and tensors."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser()
    p.add_argument('folder',type=Path)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    import torch
    d=json.loads((a.folder/'report.json').read_text())
    assert d['status']=='COMPLETE' and len(d['cases'])==26
    assert len({(r['model'],r['case']) for r in d['cases']})==26
    checks=0; tensors=0; oracle_hashes={}
    for row in d['cases']:
        assert row['model'] in ('transfusion','resnet')
        if row['accepted']:
            path=a.folder/row['output_file']; assert sha(path)==row['output_sha256']
            v=torch.load(path,map_location='cpu')
            late=int(row['case']=='regenerated-late-read')
            oracle=a.folder.parent/'npc_profile_v2_20260914'/'r0'/f"{row['model']}-late{late}"/'manual-full.pt'
            reference=torch.load(oracle,map_location='cpu')['expected']
            oracle_hashes[str(oracle)]=sha(oracle)
            assert len(v['actual'])==len(v['expected'])==row['exact_tensors']
            assert len(reference)==len(v['actual'])
            for actual,expected,independent in zip(v['actual'],v['expected'],reference):
                assert actual.shape==expected.shape and actual.dtype==expected.dtype
                assert torch.isfinite(actual).all() and torch.equal(actual,expected)
                assert torch.equal(actual,independent)
                tensors+=1;checks+=3
            assert not row['released_before_submission'] and row['released_after_completion'] and row['identity_preserved']
            # Runtime groups also contain lifted model-state placeholders. The
            # paper's operation counts deliberately count call_function only.
            graph=row['artifact']['graph']; calls={g[1] for g in graph if g[0]=='call_function'}
            groups=row['artifact']['groups']
            assert row['prefix_operations']==len(groups[0])
            assert row['total_operations']==sum(map(len,groups))
            counts=(len(set(groups[0])&calls),len(calls))
            assert counts=={
                ('transfusion','matching-base'):(1,287),('transfusion','regenerated-late-read'):(288,289),
                ('resnet','matching-base'):(12,123),('resnet','regenerated-late-read'):(124,125)
            }[row['model'],row['case']]
            checks+=8
        else:
            assert row['child_function_calls_during_rejected_operation']==row['new_submitted_events']==0
            assert row['prior_submitted_events']==int(row['phase']=='suffix-entry')
            assert row['rejection'] and row['cleanup']
            checks+=3
    assert sum(r['accepted'] for r in d['cases'])==4 and tensors>0
    assert all(sha(Path(k))==v for k,v in d['source_hashes'].items())
    assert all(sha(Path(k))==v for k,v in d['input_hashes'].items())
    out=dict(status='COMPLETE',checks=checks,cases=26,positive=4,rejected=22,exact_tensors=tensors,
             analysis_sha256=sha(a.folder/'report.json'),validator_sha256=sha(Path(__file__)),
             independent_oracle_sha256=oracle_hashes,
             cuda_used=False,inference_executed=False,
             scope='Actual report and saved tensor audit; trusted stream/event behavior and native producer pool not re-proved')
    with a.output.open('x') as f:json.dump(out,f,indent=2)
    print(json.dumps(out))


if __name__=='__main__':main()
