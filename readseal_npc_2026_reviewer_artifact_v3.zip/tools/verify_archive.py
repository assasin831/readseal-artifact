"""Verify every file in an extracted reviewer artifact; no code is executed."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root/'MANIFEST.json').read_text())
for name, record in manifest['files'].items():
    path = (root/name).resolve()
    assert path.is_relative_to(root)
    data = path.read_bytes()
    assert len(data) == record['bytes']
    assert hashlib.sha256(data).hexdigest() == record['sha256'], name
print(json.dumps(dict(status='COMPLETE', verified_files=len(manifest['files']))))
