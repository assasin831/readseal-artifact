"""Recompute diagnostic summaries from all 2,560 compact call records."""
import csv
import hashlib
import json
from pathlib import Path
import statistics
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
E=ROOT/'evidence'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    path=E/'profile.json'
    assert sha(path)=='ab6a2b730c184254df24db4395cae06d4610da277e7db5a0b1b938727818435d'
    d=json.loads(path.read_text());c=json.loads((E/'profile_campaign.json').read_text())
    assert d['status']==c['status']=='COMPLETE' and sha(E/'profile_campaign.json')==d['campaign_report_sha256']
    assert d['records_checked']==len(d['rows'])==2560 and d['exact_saved_tensors']==352
    assert not d['cuda_used'] and not d['inference_executed']
    cases=['transfusion-late0','transfusion-late1','resnet-late0','resnet-late1']
    methods=['auto-early','auto-batched','manual-early','manual-full']
    keys={(x['repeat'],x['case'],x['method'],x['trial'],x['profiled']) for x in d['rows']}
    assert keys=={(r,c,m,t,p) for r in range(4) for c in cases for m in methods for t in range(20) for p in (False,True)}
    checks=0
    for s in d['summary']:
        rows=[x for x in d['rows'] if (x['case'],x['method'])==(s['case'],s['method'])]
        normal=[x for x in rows if not x['profiled']];profile=[x for x in rows if x['profiled']]
        def med(records,fn):return [statistics.median(fn(x) for x in records if x['repeat']==i) for i in range(4)]
        w=med(normal,lambda x:x['wall_ms']);pw=med(profile,lambda x:x['wall_ms'])
        assert np.array_equal(w,s['wall_run_medians_ms'])
        assert statistics.mean(w)==s['wall_ms'] and statistics.mean(pw)==s['profiled_wall_ms']
        for phase,v in s['phase_ms'].items():
            assert statistics.mean(med(normal,lambda x:x['phases_ms'][phase]))==v
            checks+=1
        assert sorted({x['guard_calls'] for x in profile})==s['guard_calls']
        assert sorted({x['state_token_calls'] for x in profile})==s['state_token_calls']
        for x in rows:
            assert all(np.isfinite(v) and v>=0 for v in x['phases_ms'].values())
            assert sum(x['phases_ms'].values())<=x['wall_ms']
            checks+=2
        checks+=5
    result=dict(status='COMPLETE',analysis_sha256=sha(path),script_sha256=sha(Path(__file__)),
        checks=checks,records=2560,exact_saved_tensors=352,
        scope='Local reconstruction of phase summaries and call counts; remote independent audit checked exact saved tensors.')
    (E/'profile_validation.json').write_text(json.dumps(result,indent=2)+'\n')
    with (ROOT/'figures/profile_summary.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['case','method','host_phase','mean_of_four_process_medians_ms'])
        for s in d['summary']:
            for k,v in s['phase_ms'].items():w.writerow([s['case'],s['method'],k,v])
    print(json.dumps(result))

if __name__=='__main__':main()
