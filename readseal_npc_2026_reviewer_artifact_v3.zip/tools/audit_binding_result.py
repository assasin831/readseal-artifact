"""CPU-only independent audit of the 26-case CUDA binding report and tensors."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser()
    p.add_argument('folder',type=Path)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    import torch
    d=json.loads((a.folder/'report.json').read_text())
    assert d['status']=='COMPLETE' and len(d['cases'])==26
    assert len({(r['model'],r['case']) for r in d['cases']})==26
    checks=0; tensors=0
    for row in d['cases']:
        assert row['model'] in ('transfusion','resnet')
        if row['accepted']:
            path=a.folder/row['output_file']; assert sha(path)==row['output_sha256']
            v=torch.load(path,map_location='cpu')
            assert len(v['actual'])==len(v['expected'])==row['exact_tensors']
            for actual,expected in zip(v['actual'],v['expected']):
                assert actual.shape==expected.shape and actual.dtype==expected.dtype
                assert torch.isfinite(actual).all() and torch.equal(actual,expected)
                tensors+=1;checks+=2
            assert not row['released_before_submission'] and row['released_after_completion'] and row['identity_preserved']
            assert (row['prefix_operations'],row['total_operations'])=={
                ('transfusion','matching-base'):(1,287),('transfusion','regenerated-late-read'):(288,289),
                ('resnet','matching-base'):(12,123),('resnet','regenerated-late-read'):(124,125)
            }[row['model'],row['case']]
            checks+=5
        else:
            assert row['child_function_calls_during_rejected_operation']==row['new_submitted_events']==0
            assert row['prior_submitted_events']==int(row['phase']=='suffix-entry')
            assert row['rejection'] and row['cleanup']
            checks+=3
    assert sum(r['accepted'] for r in d['cases'])==4 and tensors>0
    assert all(sha(Path(k))==v for k,v in d['source_hashes'].items())
    assert all(sha(Path(k))==v for k,v in d['input_hashes'].items())
    out=dict(status='COMPLETE',checks=checks,cases=26,positive=4,rejected=22,exact_tensors=tensors,
             analysis_sha256=sha(a.folder/'report.json'),validator_sha256=sha(Path(__file__)),
             cuda_used=False,inference_executed=False,
             scope='Actual report and saved tensor audit; trusted stream/event behavior and native producer pool not re-proved')
    with a.output.open('x') as f:json.dump(out,f,indent=2)
    print(json.dumps(out))


if __name__=='__main__':main()
