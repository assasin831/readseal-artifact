"""Independent compact-data reconstruction after the remote raw-data audit."""
import hashlib
import json
from pathlib import Path
import random
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
E = ROOT/'evidence'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    d = json.loads((E/'confirmatory.json').read_text())
    assert sha(E/'confirmatory.json') == '0e27ab345df5a62973c88af6617c66e68f97296c06bb084350a8638e80dda56a'
    p = json.loads((E/'confirmatory_prepared.json').read_text())
    c = json.loads((E/'confirmatory_campaign.json').read_text())
    assert d['status'] == c['status'] == 'COMPLETE'
    assert d['prepared_sha256'] == c['prepared_sha256'] == sha(E/'confirmatory_prepared.json')
    assert sha(E/'confirmatory_campaign.json') == d['campaign_report_sha256']
    plan = d['plan']
    assert plan == p['plan'] == c['plan']
    assert len(c['runs']) == d['independent_run_reaudits'] == 54
    assert d['separate_window_not_pooled'] and not d['inference_executed'] and not d['cuda_used']
    assert plan['repetitions'] == 6 and plan['bootstrap_replicates'] == 20000
    conditions = ['r1-cap0','r1-cap8','r2-cap8']
    methods = ['auto-batched','manual-early','manual-full']
    assert [x['id'] for x in plan['conditions']] == conditions and plan['methods'] == methods
    keys = [(r['repeat'],r['condition'],r['method']) for r in d['rows']]
    assert len(keys) == len(set(keys)) == 54
    assert set(keys) == {(r,c,m) for r in range(6) for c in conditions for m in methods}
    lookup = dict(zip(keys,d['rows']))
    rng = random.Random(plan['order_seed'])
    order = []
    for rep in range(6):
        for co in conditions:
            shuffled = list(methods); rng.shuffle(shuffled)
            order.extend(f'r{rep:02d}-{co}-{m}' for m in shuffled)
    assert order == [x['name'] for x in p['schedule']] == [x['name'] for x in c['runs']]
    draws = np.random.default_rng(plan['bootstrap_seed']).integers(0,6,size=(20000,6))
    checks = 0
    for row in d['rows']:
        assert row['arrivals'] == 1440
        assert row['publications'] == row['timely']+row['correct_late']
        assert row['arrivals'] == sum(row[k] for k in ('publications','producer_late','pool_exhausted','credit_exhausted','queue_loss'))
        assert row['goodput_hz'] == row['timely']/12
        checks += 4
    metrics = ['goodput_hz','mean_protected_mib','device_peak_mib','peak_outstanding']
    for co in d['primary']['conditions']:
        vals = {}
        for m in methods:
            for metric in metrics:
                v = np.array([lookup[r,co['condition'],m][metric] for r in range(6)])
                vals[m,metric] = v
                got = co['methods'][m][metric]
                assert np.array_equal(v,got['runs'])
                assert np.isclose(v.mean(),got['mean'],rtol=0,atol=1e-10)
                assert np.allclose(np.percentile(v[draws].mean(axis=1),[2.5,97.5]),got['interval'],rtol=0,atol=1e-10)
                checks += 3
        for pair,record in co['paired_differences'].items():
            a,b = pair.split('_minus_')
            for metric in metrics:
                v = vals[a,metric]-vals[b,metric]
                assert np.allclose(v,record[metric]['runs'],rtol=0,atol=1e-10)
                assert np.isclose(v.mean(),record[metric]['mean'],rtol=0,atol=1e-10)
                assert np.allclose(np.percentile(v[draws].mean(axis=1),[2.5,97.5]),record[metric]['interval'],rtol=0,atol=1e-10)
                checks += 3
    extra = np.array([lookup[r,'r1-cap8','auto-batched']['goodput_hz']-lookup[r,'r2-cap8','manual-full']['goodput_hz'] for r in range(6)])
    result = dict(status='COMPLETE',analysis_sha256=sha(E/'confirmatory.json'),
        script_sha256=sha(Path(__file__)),checks=checks,runs=54,bootstrap_replicates=20000,
        total_arrivals=d['total_arrivals'],total_publications=d['total_publications'],total_timely=d['total_timely'],
        extra_slot_contrast=dict(label='Grouped R1 K8 minus Full R2 K8; different source capacity',
            mean=float(extra.mean()),interval=np.percentile(extra[draws].mean(axis=1),[2.5,97.5]).tolist()),
        scope='Independent schedule, loss accounting, means and paired intervals from all compact run records; remote audit checked the raw tensors and ledgers.')
    for key,field in [('total_arrivals','arrivals'),('total_publications','publications'),('total_timely','timely')]:
        assert result[key] == sum(x[field] for x in d['rows'])
    (E/'confirmatory_validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__ == '__main__': main()
