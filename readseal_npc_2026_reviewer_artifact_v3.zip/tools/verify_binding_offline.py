"""Portable CPU tensor comparison; requires PyTorch, never launches CUDA."""
import hashlib
import json
from pathlib import Path
import torch

root = Path(__file__).resolve().parents[1]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
report = json.loads((root/'evidence/binding.json').read_text())
proof = json.loads((root/'evidence/binding_validation.json').read_text())
assert sha(root/'evidence/binding.json') == proof['analysis_sha256']
count = 0
for row in report['cases']:
    if not row['accepted']:
        assert row['child_function_calls_during_rejected_operation'] == row['new_submitted_events'] == 0
        assert row['prior_submitted_events'] == int(row['phase'] == 'suffix-entry')
        continue
    path = root/'binding_raw'/row['output_file']
    assert sha(path) == row['output_sha256']
    data = torch.load(path, map_location='cpu', weights_only=True)
    case = row['model']+'-late'+str(int(row['case'] == 'regenerated-late-read'))
    oracle = root/'binding_raw/oracles'/case/'manual-full.pt'
    expected_sha = [v for k, v in proof['independent_oracle_sha256'].items() if '/'+case+'/' in k]
    assert expected_sha == [sha(oracle)]
    reference = torch.load(oracle, map_location='cpu', weights_only=True)['expected']
    assert len(data['actual']) == len(data['expected']) == len(reference) == row['exact_tensors']
    for actual, expected, independent in zip(data['actual'], data['expected'], reference):
        assert torch.isfinite(actual).all()
        assert actual.shape == expected.shape == independent.shape
        assert actual.dtype == expected.dtype == independent.dtype
        assert torch.equal(actual, expected) and torch.equal(actual, independent)
        count += 1
assert count == 22
print(json.dumps(dict(status='COMPLETE', exact_tensors=count, cuda_used=False)))
