"""GPU-free re-bootstrap of both windows and direct-binding evidence checks."""
import hashlib
import json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    checks=[];windows=[]
    def check(ok,label):
        assert ok,label
        checks.append(label)
    for name,nmethods,nruns in [('grouped',4,96),('confirmatory',3,54)]:
        d=json.loads((ROOT/'evidence'/f'{name}.json').read_text())
        plan=d['plan'];rows=d['rows'];p=d['primary']
        check(len(plan['methods'])==nmethods and len(rows)==nruns,name+' matrix')
        check(plan['repetitions']==6 and plan['bootstrap_replicates']==20000,name+' resampling unit')
        keys=[(r['repeat'],r['condition'],r['method']) for r in rows]
        check(len(keys)==len(set(keys)),name+' unique cells')
        lookup=dict(zip(keys,rows));draws=np.random.default_rng(plan['bootstrap_seed']).integers(0,6,(20000,6))
        for c in p['conditions']:
            values={}
            for method in plan['methods']:
                subset=[lookup[(r,c['condition'],method)] for r in range(6)]
                for metric in ('goodput_hz','mean_protected_mib','device_peak_mib','peak_outstanding'):
                    a=np.array([r[metric] for r in subset]);values[method,metric]=a
                    v=c['methods'][method][metric]
                    check(np.allclose(a,v['runs'],atol=1e-9,rtol=0),name+' run values')
                    check(np.isclose(a.mean(),v['mean'],atol=1e-9,rtol=0),name+' mean')
                    check(np.allclose(np.percentile(a[draws].mean(axis=1),[2.5,97.5]),v['interval'],atol=1e-9,rtol=0),name+' interval')
                loss=c['methods'][method]['losses']
                check(loss['producer_late']==0,name+' no omitted producer lateness')
                check(loss['publications']==loss['timely']+loss['correct_late'],name+' receipts accounting')
                check(loss['arrivals']==sum(loss[k] for k in ('timely','correct_late','pool_exhausted','credit_exhausted','queue_loss')),name+' complete top bar')
            for pair,metrics in c['paired_differences'].items():
                a,b=pair.split('_minus_')
                for metric,v in metrics.items():
                    delta=values[a,metric]-values[b,metric]
                    check(np.allclose(delta,v['runs'],atol=1e-9,rtol=0),name+' matched differences')
                    check(np.allclose(np.percentile(delta[draws].mean(axis=1),[2.5,97.5]),v['interval'],atol=1e-9,rtol=0),name+' paired CI')
        windows.append(dict(name=name,methods=nmethods,runs=nruns,repeat_block_size=nmethods,bootstrap_seed=plan['bootstrap_seed']))
    old=json.loads((ROOT/'evidence/grouped.json').read_text())
    c=next(c for c in old['primary']['conditions'] if c['condition']=='r2-cap0')
    a,b=[c['methods'][m]['losses'] for m in ('auto-batched','manual-full')]
    pieces=[(a['publications']-b['publications'])/72,-(a['correct_late']-b['correct_late'])/72]
    check([f'{v:.2f}' for v in pieces]==['-0.17','-47.19'],'two-slot exact decomposition')
    check(f'{sum(pieces):.2f}'=='-47.36','decomposition sum')
    binding=json.loads((ROOT/'evidence/binding.json').read_text())
    proof=json.loads((ROOT/'evidence/binding_validation.json').read_text())
    check(binding['status']==proof['status']=='COMPLETE','binding complete')
    check(proof['analysis_sha256']==sha(ROOT/'evidence/binding.json'),'binding proof hash')
    check(proof['cases']==26 and proof['positive']==4 and proof['rejected']==22 and proof['exact_tensors']==22,'binding counts')
    check(proof['validator_sha256']==sha(ROOT/'tools/audit_binding_result_fix1.py'),'binding validator source')
    for row in binding['cases']:
        if row['accepted']:
            calls={g[1] for g in row['artifact']['graph'] if g[0]=='call_function'}
            groups=row['artifact']['groups']
            check((len(set(groups[0])&calls),len(calls))=={
                ('transfusion','matching-base'):(1,287),('transfusion','regenerated-late-read'):(288,289),
                ('resnet','matching-base'):(12,123),('resnet','regenerated-late-read'):(124,125)
            }[row['model'],row['case']],'bound call_function boundary')
            check(sha(ROOT/'binding_raw'/row['output_file'])==row['output_sha256'],'saved output hash')
        else:
            check(row['new_submitted_events']==row['child_function_calls_during_rejected_operation']==0,'rejection before related submission')
    doc=(ROOT/'sections/evaluation.tex').read_text()
    check('whole difference' not in doc and 'admission is instead equalized' not in doc,'causal overclaim removed')
    check('matched repetition blocks' in doc and 'four methods in (a), three in (b)' in doc,'correct CI caption')
    result=dict(status='COMPLETE',checks=len(checks),windows=windows,bootstrap_replicates=20000,
                two_slot_decomposition=pieces,source_sha256=sha(Path(__file__)),
                input_sha256={p.name:sha(p) for p in (ROOT/'evidence').glob('*.json')},cuda_used=False)
    (ROOT/'qa').mkdir(exist_ok=True)
    (ROOT/'qa/revision_validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='input_sha256'}))


if __name__=='__main__':main()
