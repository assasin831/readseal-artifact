"""Quiescent fault injection into the unchanged Grouped executable, not timing.

No race is introduced. CUDA0 only; a foreign GPU1 job is allowed because no
performance estimate is made. Every rejection records the child calls and the
actual lease transitions, rather than crediting a manual constructor's checks.
"""
import argparse
import fcntl
from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback

ROOT = Path('/www/readseal_ipdps_revision_v6')
sys.path.insert(0, str(ROOT/'prototype_borrowplan_v11_grouped_attempt1'))
from launch_grouped_formal import DEPS, sha
for dep in DEPS:
    sys.path.append(str(dep))
import torch
from batch_backend import BatchProgram
from core import Rejected
from study_common import configure, compute_pids, inputs, MODELS, GPU, exact, cpu_values


def main():
    a = argparse.ArgumentParser()
    a.add_argument('--output', type=Path, required=True)
    args = a.parse_args()
    assert args.output.resolve().is_relative_to(ROOT)
    lock = (ROOT/'borrowplan_gpu0.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not any(p['gpu'] == GPU for p in compute_pids()), 'GPU0 busy; no run'
    args.output.mkdir(parents=True, exist_ok=False)
    result = dict(status='RUNNING', scope='Grouped child binding, real CUDA, not performance or concurrent-mutation safety',
                  gpu_uuid=GPU, pid=os.getpid(), torch=torch.__version__, cases=[], source_hashes={}, input_hashes={},
                  external_pool_scope='An already-held recipient input is assumed. No process-shared pool is simulated or measured.')
    try:
        configure()
        for dep in DEPS:
            if dep.name.startswith('prototype_'):
                result['source_hashes'].update({str(p):sha(p) for p in dep.glob('*.py')})
        result['source_hashes'][str(Path(__file__))] = sha(__file__)
        for model in ('transfusion', 'resnet'):
            xs, hashes = inputs(model)
            result['input_hashes'].update(hashes)
            export = MODELS[model][0]
            result['input_hashes'][str(export)] = sha(export)
            x = xs[0].cuda()
            p = BatchProgram(torch.export.load(export), x, late_read=False)
            edited = BatchProgram(torch.export.load(export), x, late_read=True)
            ready = torch.cuda.Event(); ready.record(); ready.synchronize()
            stream = torch.cuda.Stream()
            pub = dict(epoch=20260914, sequence=17, generation=34)

            def run_positive(label, program):
                c = program._capsule
                # Direct sequential evaluation of the owned graph supplies the
                # reference here; old maintenance evidence supplies the separate
                # exported-graph/ordered-overwrite oracle.
                with torch.inference_mode():
                    states = dict(c.state)
                    args0 = tuple(x if n == c.root else states[n] for n in c.placeholder_names)
                    expected = tuple(c.functions[1].invoke(None, *tuple(c.functions[0].invoke(None, *args0))))
                torch.cuda.synchronize()
                ex = program.start(x, pub, ready)
                before = ex.lease.can_release(ex.lease.bindings[program.root].allocation)
                assert not before
                ex.submit(0, stream); ex.submit(1, stream); ex.wait()
                actual = ex.outputs(); exact(actual, expected)
                assert ex.lease.can_release(ex.lease.bindings[program.root].allocation)
                identity = ex.lease.publish_identity()
                assert {b.version for row in identity.values() for b in row.values()} == {(20260914,17,34)}
                output = args.output/f'{model}-{label}.pt'
                torch.save(dict(actual=cpu_values(actual), expected=cpu_values(expected)), output)
                rec = dict(model=model, case=label, accepted=True, prefix_operations=len(c.groups[0]),
                           total_operations=sum(map(len,c.groups)), plan_sha256=program.plan.sha256,
                           artifact=program.artifact, exact_tensors=len(actual), output_file=output.name,
                           output_sha256=sha(output), released_before_submission=before,
                           released_after_completion=True, identity_preserved=True)
                result['cases'].append(rec)

            run_positive('matching-base', p)
            run_positive('regenerated-late-read', edited)

            def reject(label, phase, setup, action, restore, ex=None):
                torch.cuda.synchronize()
                setup()
                codes = {f.invoke.__code__ for obj in (p, edited) for f in obj._capsule.functions}
                calls = []
                def trace(frame, event, arg):
                    if event == 'call' and frame.f_code in codes:
                        calls.append(frame.f_code.co_name)
                before_events = len(ex.events) if ex else 0
                before_group = ex.lease.next_group if ex else 0
                reason = None
                try:
                    sys.setprofile(trace)
                    try:
                        action()
                    except Rejected as error:
                        reason = str(error)
                    finally:
                        sys.setprofile(None)
                    assert reason is not None, label+' unexpectedly accepted'
                    assert not calls, 'related child code was invoked'
                    if ex:
                        assert len(ex.events) == before_events and ex.lease.next_group == before_group
                        ex.lease.abort()
                        ex.wait()
                        allocation = ex.lease.bindings[p.root].allocation
                        assert ex.lease.can_release(allocation) and not ex.lease.can_publish()
                        cleanup = 'actual lease: pending canceled, started events drained, source releasable, publish forbidden'
                    else:
                        cleanup = 'no invocation returned; no child submitted; caller retains and must return its external hold'
                    result['cases'].append(dict(model=model, case=label, phase=phase, accepted=False,
                        rejection=reason, child_function_calls_during_rejected_operation=len(calls),
                        prior_submitted_events=before_events, new_submitted_events=0, cleanup=cleanup))
                finally:
                    restore()
                    torch.cuda.synchronize()

            nothing = lambda:None
            reject('input-shape', 'admission', nothing, lambda:p.start(x.flatten(), pub, ready), nothing)
            reject('input-stride', 'admission', nothing, lambda:p.start(x.transpose(-1,-2), pub, ready), nothing)
            reject('uncommitted-generation', 'admission', nothing,
                   lambda:p.start(x, dict(pub,generation=35), ready), nothing)
            certificate = p._certificate
            reject('foreign-certificate', 'admission',
                   lambda:object.__setattr__(p,'_certificate',edited._certificate),
                   lambda:p.start(x,pub,ready), lambda:object.__setattr__(p,'_certificate',certificate))
            grouping = p._grouping
            reject('foreign-group-plan', 'admission',
                   lambda:object.__setattr__(p,'_grouping',replace(grouping,plan=edited.plan)),
                   lambda:p.start(x,pub,ready), lambda:object.__setattr__(p,'_grouping',grouping))
            for phase in ('admission','prefix-entry','suffix-entry'):
                ex = None
                if phase != 'admission':
                    ex = p.start(x,pub,ready)
                    if phase == 'suffix-entry':
                        ex.submit(0,stream); ex.wait()
                fn = p._capsule.functions[0 if phase != 'suffix-entry' else 1].invoke
                code = fn.__code__
                action = (lambda:p.start(x,pub,ready)) if ex is None else (lambda:ex.submit(ex.stage,stream))
                reject('changed-code-'+phase, phase,
                       lambda:setattr(fn,'__code__',(lambda self,*args:()).__code__), action,
                       lambda:setattr(fn,'__code__',code), ex)
            fn = p._capsule.functions[0].invoke
            reject('changed-global', 'admission',
                   lambda:fn.__globals__.__setitem__('unexpected_binding_test',object()),
                   lambda:p.start(x,pub,ready), lambda:fn.__globals__.pop('unexpected_binding_test'))
            ex = p.start(x,pub,ready)
            reject('different-admitted-program','prefix-entry',lambda:setattr(ex,'program',edited),
                   lambda:ex.submit(0,stream),lambda:setattr(ex,'program',p),ex)
            # A quiescent owned-state version change invalidates this program.
            # Do not refresh its stored token or continue using it afterwards.
            tensor = p._capsule.state[0][1]
            def mutate_state():
                with torch.no_grad():
                    tensor.add_(0)
            reject('owned-state-version','admission',mutate_state,
                   lambda:p.start(x,pub,ready),nothing)
            del p,edited,x,xs,ex
            torch.cuda.synchronize(); torch.cuda.empty_cache()
            print('COMPLETE',model,flush=True)
        result['status'] = 'COMPLETE'
        assert all(sha(k)==v for k,v in result['source_hashes'].items())
    except BaseException:
        result.update(status='FAILED', traceback=traceback.format_exc())
        traceback.print_exc()
    (args.output/'report.json').write_text(json.dumps(result,indent=2)+'\n')
    (args.output/result['status']).write_text(result['status']+'\n')
    print(json.dumps(dict(status=result['status'],cases=len(result['cases']))))
    return result['status'] != 'COMPLETE'


if __name__ == '__main__':
    raise SystemExit(main())
