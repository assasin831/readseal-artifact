"""Pure CPU, per-run metrics; outputs within a run are not replicates."""
import math
import statistics

T95_DF5 = 2.570581835636305


def interval6(values):
    assert len(values) == 6 and all(math.isfinite(v) for v in values)
    mean, sd = statistics.mean(values), statistics.stdev(values)
    delta = T95_DF5 * sd / math.sqrt(6)
    return dict(n=6, mean=mean, sd=sd, ci95_low=mean-delta, ci95_high=mean+delta)


def quantile(values, q):
    assert values and 0 <= q <= 1
    values = sorted(values)
    i = (len(values)-1)*q
    lo, hi = math.floor(i), math.ceil(i)
    return values[lo] + (i-lo)*(values[hi]-values[lo])


def age(events, begin, end):
    assert end > begin
    fresh, last, area, covered = None, begin, 0, 0
    for receipt, generation in sorted(events):
        assert generation <= receipt
        if receipt <= begin:
            fresh = generation if fresh is None else max(fresh, generation)
            continue
        if receipt >= end:
            break
        if fresh is not None:
            dt = receipt-last
            area += (last-fresh)*dt + dt*dt/2
            covered += dt
        fresh = generation if fresh is None else max(fresh, generation)
        last = receipt
    if fresh is not None:
        dt = end-last
        area += (last-fresh)*dt + dt*dt/2
        covered += dt
    return dict(coverage=covered/(end-begin), mean_ms=area/(end-begin)/1e6 if covered == end-begin else None)


def byte_lifetime(intervals, begin, end):
    """Sum live copies, unlike the union of shared slots; clip to wall window."""
    endpoints = []
    for a, b, size in intervals:
        assert a <= b and size >= 0
        lo, hi = max(a, begin), min(b, end)
        if hi > lo:
            endpoints.extend(((lo, size), (hi, -size)))
    active = peak = area = 0
    last = begin
    for timestamp, delta in sorted(endpoints):
        area += active*(timestamp-last)
        active += delta
        assert active >= 0
        peak = max(peak, active)
        last = timestamp
    assert active == 0
    return dict(mean_mib=area/(end-begin)/2**20, peak_mib=peak/2**20)


def calculate(report, sink):
    begin, end = report["cohort_start_ns"], report["cohort_end_ns"]
    duration = (end-begin)/1e9
    assert duration == report["cell"]["measure_seconds"]
    assert all(all(r[k] for k in ("output_equal", "provenance_verified", "finite", "published")) for r in sink)
    cohort = [r for r in sink if r["cohort"]]
    assert cohort
    latency = [(r["publish_ns"]-r["scheduled_ns"])/1e6 for r in cohort]
    ages = [age([(r["publish_ns"], r["scheduled_ns"]) for r in sink if r["consumer"] == cid], begin, end)
            for cid in range(report["cell"]["consumers"])]
    assert all(a["coverage"] == 1 for a in ages), "incomplete warmup freshness coverage"
    copies = [(r["composition"]["private_allocation_ns"], r["invocation_retired_ns"], r["private_copy_bytes"])
              for r in sink if r["private_copy_bytes"]]
    life = byte_lifetime(copies, begin, end)
    copy_ms = [r["composition"]["copy_device_ms"] for r in cohort if r["private_copy_bytes"]]
    stats = dict(receipt_capacity_hz=sum(begin <= r["publish_ns"] < end for r in sink)/duration,
                 cohort_delivered_hz=len(cohort)/duration,
                 mean_age_ms=statistics.mean(a["mean_ms"] for a in ages),
                 p50_latency_ms=quantile(latency, .5), p99_latency_ms=quantile(latency, .99),
                 device_peak_mib=report["device_peak_bytes"]/2**20,
                 protected_mib=report["protected_byte_seconds"]/duration/2**20,
                 private_copy_mean_mib=life["mean_mib"], private_copy_peak_mib=life["peak_mib"],
                 copy_p50_device_ms=quantile(copy_ms, .5) if copy_ms else 0,
                 copy_p99_device_ms=quantile(copy_ms, .99) if copy_ms else 0,
                 summed_consumer_allocated_peaks_mib=sum(r["stats"]["allocated_peak_bytes"] for r in report["allocator_stats"])/2**20,
                 summed_consumer_reserved_peaks_mib=sum(r["stats"]["reserved_peak_bytes"] for r in report["allocator_stats"])/2**20)
    # Sums of per-process maxima need not occur simultaneously; label them explicitly.
    for deadline in (50, 75, 100, 150):
        stats[f"timely_{deadline}ms_hz"] = sum(ms <= deadline for ms in latency)/duration
    assert abs(stats["timely_100ms_hz"]-report["goodput_hz"]) < 1e-10
    assert all(math.isfinite(v) for v in stats.values())
    return stats
