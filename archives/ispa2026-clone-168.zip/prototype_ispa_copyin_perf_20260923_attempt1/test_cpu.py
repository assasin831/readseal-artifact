import itertools
import math
import unittest
from performance_metrics import interval6, age, byte_lifetime, quantile, calculate
from plan import PLAN, METHODS, schedule


class ProtocolTests(unittest.TestCase):
    def test_exact_matrix(self):
        rows = schedule("formal")
        expected = set(itertools.product(range(6), [c["id"] for c in PLAN["conditions"]], METHODS))
        self.assertEqual({(r["repeat"],r["condition"],r["method"]) for r in rows}, expected)
        self.assertEqual(len(rows), 168)
        self.assertEqual(len({r["name"] for r in rows}), 168)
        self.assertTrue(all(r["cell"]["measure_seconds"] == 30 and r["cell"]["warmup_seconds"] == 10 for r in rows))

    def test_smoke_covers_both_graphs_every_policy(self):
        rows = schedule("smoke")
        self.assertEqual(len(rows), 8)
        self.assertEqual({(r["cell"]["late"], r["method"]) for r in rows}, set(itertools.product((False, True), METHODS)))
        self.assertEqual(rows, schedule("smoke"))

    def test_no_uncontrolled_admission_change(self):
        self.assertTrue(all(r["cell"]["consumers"] == 4 and r["cell"]["ring"] == 1 and
                            r["cell"]["outstanding_cap"] == 0 for r in schedule("formal")))


class MetricTests(unittest.TestCase):
    def test_df5_interval(self):
        got = interval6([1,2,3,4,5,6])
        self.assertAlmostEqual(got["mean"], 3.5)
        self.assertAlmostEqual(got["sd"], math.sqrt(3.5))
        self.assertAlmostEqual(got["ci95_high"], 3.5+2.570581835636305*math.sqrt(3.5/6))

    def test_fixed_values(self):
        self.assertEqual(interval6([7]*6)["ci95_low"], 7)
        with self.assertRaises(AssertionError):
            interval6([1,2,3])

    def test_quantile(self):
        self.assertEqual(quantile([1,2,3,4], .5), 2.5)
        self.assertAlmostEqual(quantile([0,100], .99), 99)

    def test_age_ignores_old_arrival(self):
        # Units are ns; freshness cannot regress at the third receipt.
        self.assertEqual(age([(0,0),(5,4),(6,1)], 0, 10)["mean_ms"], 3/1e6)

    def test_missing_warmup_not_zero_age(self):
        got = age([(5,4)], 0, 10)
        self.assertEqual(got["coverage"], .5)
        self.assertIsNone(got["mean_ms"])

    def test_copy_sum_not_union(self):
        got = byte_lifetime([(0,8,2**20),(4,10,2**20)], 0, 10)
        self.assertEqual(got["peak_mib"], 2)
        self.assertAlmostEqual(got["mean_mib"], 1.4)

    def test_clip_lifetime_and_no_copy(self):
        self.assertEqual(byte_lifetime([(-3,11,2**20)], 0, 10)["mean_mib"], 1)
        self.assertEqual(byte_lifetime([], 0, 10), dict(mean_mib=0, peak_mib=0))

    def test_wall_window_is_not_drained_cohort(self):
        def record(receipt, generation, cohort):
            return dict(publish_ns=receipt*1_000_000, scheduled_ns=generation*1_000_000,
                        cohort=cohort, consumer=0, private_copy_bytes=0,
                        output_equal=True, provenance_verified=True, finite=True, published=True)
        sink = [record(90, 80, False), record(130, 110, True), record(260, 190, True)]
        report = dict(cohort_start_ns=100_000_000, cohort_end_ns=200_000_000,
                      cell=dict(measure_seconds=.1, consumers=1), device_peak_bytes=2**20,
                      protected_byte_seconds=0, goodput_hz=20,
                      allocator_stats=[dict(stats=dict(allocated_peak_bytes=2**20, reserved_peak_bytes=2**21))])
        got = calculate(report, sink)
        self.assertEqual(got["receipt_capacity_hz"], 10)
        self.assertEqual(got["cohort_delivered_hz"], 20)
        self.assertEqual(got["timely_100ms_hz"], 20)
        self.assertEqual(got["timely_50ms_hz"], 10)
        self.assertEqual(got["private_copy_mean_mib"], 0)


if __name__ == "__main__":
    unittest.main()
