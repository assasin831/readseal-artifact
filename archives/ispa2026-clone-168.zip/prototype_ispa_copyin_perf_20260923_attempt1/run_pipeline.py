"""Complete V8 consumer loop with uniformly observed invocation retirement."""
import argparse
import gc
import json
import os
from pathlib import Path
import traceback

import torch
import admission_streaming as base
from copyin_composition import CopyInComposition
from grouped_composition import GroupedComposition
from manual_composition import ManualComposition
from study_common import configure, compute_pids
from common import inventory, now
from plan import METHODS


def factory(model, example, late, method):
    assert model == "transfusion" and method in METHODS
    if method == "copy-in":
        return CopyInComposition(example, late)
    if method == "auto-batched":
        return GroupedComposition(example, late)
    return ManualComposition(example, late, full=method == "manual-full")


def consumer(cid, method, cell, commands, control, sink, tensors, pool, oracle, destination):
    try:
        configure()
        slots, handles = tensors.get(timeout=180)
        events = [torch.cuda.Event.from_ipc_handle(0, h) for h in handles]
        program = factory(cell["model"], slots[0], cell["late"], method)
        stream = torch.cuda.Stream()
        folder = Path(destination)
        (folder / f"consumer-{cid}-artifact.json").write_text(json.dumps(program.artifact, indent=2) + "\n")
        private = slots[0].clone()
        torch.cuda.synchronize()
        for k in range(10):
            ready = torch.cuda.Event()
            ready.record()
            ex = program.start(private, dict(epoch=17, sequence=k+1, generation=2*(k+1)), ready)
            ex.submit(0, stream)
            if method != "manual-full":
                ex.submit(1, stream)
            ex.events[-1].synchronize()
            ex.publish()
        del private, ex
        torch.cuda.synchronize()
        gc.collect()
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
        control.put(dict(kind="ready", consumer=cid, pid=os.getpid()))
        rows = []
        while True:
            req = commands.get(timeout=180)
            if req["op"] == "stop":
                break
            row = dict(req, consumer=cid, received_ns=now())
            slot, seq = req["slot"], req["sequence"]
            assert pool.held(slot, seq, cid)
            row["observed_sequence"], row["observed_source"] = int(oracle[2*slot]), int(oracle[2*slot+1])
            assert (row["observed_sequence"], row["observed_source"]) == (seq, req["source_id"])
            pub = dict(epoch=987654, sequence=seq, generation=2*seq)
            row["admission_ns"] = now()
            ex = program.start(slots[slot], pub, events[slot])
            ex.submit(0, stream)
            if method != "manual-full":
                ex.submit(1, stream)
            ex.events[0].synchronize()
            row["read_done_ns"] = now()
            assert ex.can_release()
            row["release_begin_ns"] = now()
            pool.release(slot, seq, cid)
            row["release_end_ns"] = now()
            ex.events[-1].synchronize()
            row["output_done_ns"] = now()
            actual, identity = ex.publish()
            assert identity == pub and len(actual) == (11 if cell["late"] else 10)
            row.update(identity=identity, composition=dict(ex.trace), native_shape=list(actual[0].shape),
                       complete_ab_outputs=True, private_copy_bytes=ex.trace.get("private_copy_bytes", 0))
            payload = [t.detach().cpu().contiguous().numpy() for t in actual]
            # CPU payload owns the outputs; private GPU input need not survive sink enqueue.
            del ex, actual
            row["invocation_retired_ns"] = now()
            row["sink_enqueue_ns"] = now()
            sink.put(dict(kind="output", row=dict(row), arrays=payload))
            rows.append(row)
            del payload
        torch.cuda.synchronize()
        stats = dict(allocated_peak_bytes=torch.cuda.max_memory_allocated(),
                     reserved_peak_bytes=torch.cuda.max_memory_reserved())
        (folder / f"consumer-{cid}.json").write_text(json.dumps(dict(rows=rows, stats=stats,
            sources=inventory(), artifact_sha256=base.sha(folder / f"consumer-{cid}-artifact.json")), indent=2) + "\n")
        sink.put(dict(kind="consumer_done", consumer=cid))
        control.put(dict(kind="done", consumer=cid, stats=stats))
    except BaseException:
        control.put(dict(kind="error", consumer=cid, traceback=traceback.format_exc()))
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cell", required=True)
    parser.add_argument("--method", choices=METHODS, required=True)
    args = parser.parse_args()
    assert not compute_pids(), "foreign compute; no inference"
    configure()
    base.make_program, base.consumer, base.source_inventory = factory, consumer, inventory
    print(json.dumps(base.measure_cell(args.output, json.loads(args.cell), args.method)), flush=True)


if __name__ == "__main__":
    main()
