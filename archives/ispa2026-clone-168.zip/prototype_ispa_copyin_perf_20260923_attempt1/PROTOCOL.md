# E2 wave 1: copy-in against three complete-pipeline policies

Frozen before new inference, 2026-09-23. No outcome-dependent exclusions,
conditions, early success stopping or failed-inference retries.

## Question and matrix

Does copying the complete shared view to private device memory preserve safe
early return at lower cost, especially when the model reads its source late?
The original three policies run afresh in the same instrumented harness; old
performance records are not used as their control group.

R=1, four identical A/C composed recipients, queue=8, unlimited outstanding
work. Base graph at 10/15/20/25/30/40 publications/s; late-read graph at 30/s.
ReadSeal grouped checks, independent Manual-Early, strongest Full (return after
all GPU work, before CPU sink work), and Copy-in. Six randomized paired blocks:
168 formal runs, plus eight base/late-by-policy smoke cases. Warmup 10 s and
measurement 30 s, smoke 1 s and 3 s. Estimate 2.5-3 hours once quiet, subject
to the actual path duration. A smoke is not a formal repetition.

## Fixed implementation

Reuse the frozen producer, receipt-based credit policy, slot state machine,
native engine, complete manual model, automatic model and sink. The source
ledger and three disjoint exact output references remain independent of the
descriptor/runtime identity. Copy-in uses the previously tensor-validated D2D
gate implementation. It enrolls the copy as the sole original-source read,
returns after that event, and runs the unchanged full manual A/C composition
from private storage. It is not charged automatic alias-analysis overhead.

The consumer loop derives from the frozen V8 complete-output loop. Across all
policies the only common change is to destroy the completed invocation after
CPU output materialization and before sink enqueue. Copy-in records the
logical input-copy lifetime from its allocation observation to invocation
destruction observation. This is NOT actual allocator-reserved memory: report
it separately from PyTorch allocated/reserved peaks and NVML device samples.
No artificial synchronization, per-arrival barrier, delay or GPU resource limit
is added. Private copies are not kept after the invocation is finished.

## Metrics and inference

Primary: exact and provenance-verified source-cohort outputs arriving within
100 ms of scheduled arrival, divided by the 30 s window. Failures/unknown
outputs are distinct from correct-late results and producer/queue rejection.
The deadline is a reporting label; there is no deadline-aware cancellation.

Also report wall-window correct receipts/s, mean freshest-result age per sink
(including last valid warmup state, never regressing on out-of-order receipts),
P50/P99 scheduled-arrival-to-sink latency, 50/75/100/150 ms timely goodput,
source protected byte-time, device/allocator peaks, logical copy byte-time and
peak, and per-invocation CUDA-event D2D elapsed time. The copy event measures
device elapsed time on the actual stream, not an isolated memcpy benchmark.
For four recipients, one source publication offers four bundles, not one.

All statistical units are full runs. Give pointwise t95 intervals with n=6 and
df=5, and paired policy differences within the same randomized repeat. Do not
count outputs as independent repetitions. No multiplicity correction or
equivalence margin is claimed. Report unfavorable comparisons and tails.

## Gating and audit

Require frozen successful capacity and copy-in correctness records and every
source/input hash. Wait initially for no compute on either GPU, acquire the
GPU0 lock, then check again. Preserve GPU1 MIG. The wait is bounded at 24 h;
it is not an inference attempt. During a started campaign, foreign work,
changed hashes, disk below 20 GiB, inference/validation failure or timeout
stops the campaign with exact completed/unstarted counts, without retry.
Only child processes created for a timed-out run may be cleaned up.

Every run independently reconstructs receipts, exact reference/sample tensor
hashes, source/identity, safe reuse, admission credits, copy interval bounds,
artifact lineage and method membership. After all smoke cases pass, formal
runs start. Results are written only to fresh paths. Complete raw data remain
remote; a compact handoff can exclude tensors while retaining manifests.

## Scope not covered by this matrix

R=2/3/4 and K design space, isolated-child copy cost, heterogeneous consumers,
non-GPU gaps, latest-only, jitter, live hazards and embedded hardware remain
separate stages. This matrix is ordinary A100 execution, not edge emulation.
