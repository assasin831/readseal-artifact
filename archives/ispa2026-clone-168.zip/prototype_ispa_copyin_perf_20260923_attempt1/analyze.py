"""Recompute all per-run metrics and whole-repeat intervals after validation."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import traceback
from performance_metrics import calculate, interval6
from plan import PLAN, METHODS, schedule


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def write_csv(path, rows):
    assert rows
    with path.open("x", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def analyze(root, output):
    output.mkdir(parents=True, exist_ok=False)
    result = dict(status="RUNNING", cuda_used=False, inference_executed=False)
    try:
        campaign = read(root / "report.json")
        assert campaign["status"] == "COMPLETE"
        phase = campaign["phase"]
        assert campaign["plan"] == PLAN and campaign["schedule"] == schedule(phase)
        assert len(campaign["runs"]) == PLAN["expected_runs"][phase]
        rows = []
        for item, planned in zip(campaign["runs"], campaign["schedule"]):
            assert all(item[k] == v for k, v in planned.items())
            folder = root / item["name"]
            proof_path = root / (item["name"] + "-validation") / "validation.json"
            proof = read(proof_path)
            assert proof["status"] == "COMPLETE" and not proof["cuda_used"]
            assert sha(proof_path) == item["validation_sha256"]
            assert sha(folder / "report.json") == item["report_sha256"] == proof["report_sha256"]
            assert sha(folder / "sink.json") == item["sink_sha256"] == proof["sink_sha256"]
            report, sink = read(folder / "report.json"), read(folder / "sink.json")
            assert report["cell"] == item["cell"] and report["method"] == item["method"]
            assert report["wrong_outputs"] == report["source_unknown"] == 0
            row = dict(run=item["name"], condition=item["condition"], method=item["method"], repeat=item["repeat"],
                       **calculate(report, sink))
            for key in ("arrivals", "publications", "timely", "correct_late", "producer_late",
                        "pool_exhausted", "credit_exhausted", "queue_loss", "peak_outstanding"):
                row[key] = proof[key]
            rows.append(row)
        write_csv(output / "per_run.csv", rows)
        files = ["per_run.csv"]
        if phase == "formal":
            metrics = [k for k in rows[0] if k not in ("run", "condition", "method", "repeat")]
            summaries, paired = [], []
            for condition in [c["id"] for c in PLAN["conditions"]]:
                groups = {}
                for method in METHODS:
                    group = sorted([r for r in rows if r["condition"] == condition and r["method"] == method], key=lambda r:r["repeat"])
                    assert [r["repeat"] for r in group] == list(range(6))
                    groups[method] = group
                    for metric in metrics:
                        summaries.append(dict(condition=condition, method=method, metric=metric,
                                              **interval6([r[metric] for r in group])))
                for a, b in (("copy-in", "auto-batched"), ("copy-in", "manual-full"),
                             ("auto-batched", "manual-full"), ("auto-batched", "manual-early")):
                    for metric in metrics:
                        paired.append(dict(condition=condition, a_method=a, b_method=b, metric=metric,
                                           **interval6([x[metric]-y[metric] for x,y in zip(groups[a],groups[b])])))
            write_csv(output / "summary_t95.csv", summaries)
            write_csv(output / "paired_t95.csv", paired)
            files.extend(["summary_t95.csv", "paired_t95.csv"])
        result.update(status="COMPLETE", runs=len(rows), phase=phase,
                      campaign_sha256=sha(root / "report.json"), csv_sha256={f:sha(output/f) for f in files},
                      analysis_sha256=sha(__file__), metrics_sha256=sha(Path(__file__).with_name("performance_metrics.py")),
                      uncertainty=PLAN["confidence"], edge_emulation=False)
    except BaseException:
        result.update(status="FAILED", traceback=traceback.format_exc())
        traceback.print_exc()
    (output / "validation.json").write_text(json.dumps(result, indent=2) + "\n")
    (output / result["status"]).write_text(result["status"] + "\n")
    print(json.dumps(result), flush=True)
    return int(result["status"] != "COMPLETE")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    raise SystemExit(analyze(args.root, args.output))
