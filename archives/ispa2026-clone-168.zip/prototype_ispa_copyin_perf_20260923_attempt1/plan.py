"""Fixed E2 rate/late-read matrix; no outcome-based condition selection."""
import random

METHODS = ("auto-batched", "manual-early", "manual-full", "copy-in")
COMMON = dict(model="transfusion", consumers=4, queue=8, ring=1,
              outstanding_cap=0, deadline_ms=100, warmup_seconds=10,
              measure_seconds=30)
CONDITIONS = [dict(id=f"base-r1-hz{hz}", rate_hz=hz, late=False)
              for hz in (10, 15, 20, 25, 30, 40)] + [
                  dict(id="late-r1-hz30", rate_hz=30, late=True)]
PLAN = dict(schema="ispa-copyin-performance-wave1-v1", methods=list(METHODS),
            common=COMMON, conditions=CONDITIONS, repetitions=6,
            order_seeds=dict(smoke=26092311, formal=26092312),
            expected_runs=dict(smoke=8, formal=168), minimum_free_gib=20,
            both_gpus_quiet=True, no_inference_retry=True,
            initial_quiet_wait_seconds=86400, initial_quiet_poll_seconds=60,
            run_timeout_seconds=600, validation_timeout_seconds=600,
            gpu0_only=True, gpu_partitions_unchanged=True,
            primary="correct-timely source-cohort receipts within 100 ms of scheduled arrival",
            secondary=["wall-window correct receipt rate", "mean freshest-result age",
                       "P50/P99 receipt latency", "50/75/100/150ms timely goodput",
                       "device and allocator peaks", "protected source byte-time",
                       "logical private-copy lifetime/peak and D2D event duration"],
            confidence="pointwise t95 df5; paired by whole-run repetition; no multiplicity correction",
            copyin_reference="unchanged complete Manual-Full on original source",
            edge_emulation=False, resource_settings_unchanged=True)


def schedule(phase):
    assert phase in ("smoke", "formal")
    rng = random.Random(PLAN["order_seeds"][phase])
    conditions = [c for c in CONDITIONS if c["id"] in
                  ("base-r1-hz20", "late-r1-hz30")] if phase == "smoke" else CONDITIONS
    rows = []
    for repeat in range(1 if phase == "smoke" else PLAN["repetitions"]):
        order = list(conditions)
        rng.shuffle(order)
        for condition in order:
            methods = list(METHODS)
            rng.shuffle(methods)
            for method in methods:
                cell = dict(COMMON, **condition)
                if phase == "smoke":
                    cell.update(warmup_seconds=1, measure_seconds=3)
                rows.append(dict(name=f"{phase}-r{repeat:02d}-{condition['id']}-{method}",
                                 repeat=repeat, condition=condition["id"], method=method, cell=cell))
    assert len(rows) == PLAN["expected_runs"][phase]
    assert len({r["name"] for r in rows}) == len(rows)
    return rows
