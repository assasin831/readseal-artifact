"""Quiet-host, no-retry E2 controller. Initial waiting executes no CUDA code."""
import argparse
import datetime
import fcntl
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import traceback

ROOT = Path("/www/readseal_ipdps_revision_v6")
HERE = Path(__file__).resolve().parent
BASE = ROOT / "results/ispa_copyin_performance_20260923_attempt1"
COPY = ROOT / "prototype_ispa_copyin_20260923_attempt2"
GATE = ROOT / "results/ispa_copyin_gate_20260923_attempt1"
CAP = ROOT / "results/ispa_capacity_20260923_attempt1"
OLD = ROOT / "prototype_borrowplan_v11_grouped_attempt1"
sys.path.append(str(OLD))
import launch_grouped_formal as prior
from plan import PLAN, schedule

DEPS = [HERE, COPY] + prior.DEPS


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    os.replace(temporary, path)


def duplicates():
    found = []
    for proc in Path("/proc").glob("[0-9]*"):
        pid = int(proc.name)
        if pid in (os.getpid(), os.getppid()):
            continue
        try:
            args = (proc / "cmdline").read_bytes().decode(errors="replace").split("\0")
            scripts = [arg for arg in args if arg.startswith(str(ROOT) + "/") and arg.endswith(".py")
                       and ("campaign" in Path(arg).name or "run_pipeline" in Path(arg).name
                            or "run_grouped" in Path(arg).name or "supervisor" in Path(arg).name)]
            if scripts:
                found.append(dict(pid=pid, scripts=scripts))
        except OSError:
            continue
    return found


def verify_bindings(frozen):
    assert frozen["plan"] == PLAN
    assert frozen["schedules"] == {p:schedule(p) for p in ("smoke", "formal")}
    changed = [p for p,h in frozen["bindings"].items() if prior.sha(p) != h]
    assert not changed, "frozen source/input changed: " + repr(changed)


def prepare():
    assert not duplicates(), "another experiment controller exists"
    cp = GATE / "prepared.json"
    assert prior.sha(cp) == "c6935e83637c8a636a8d10a30e48590ec10103de85051ae395087f3b5deb8364"
    bindings = dict(json.loads(cp.read_text())["bindings"])
    proofs = {
        CAP / "formal/analysis/validation.json": "ff7aa86db81f7586f4d558668e6d96b033477ff747ec66d8843eb2d7858f70a0",
        GATE / "validation/validation.json": "6caed7063f065f366b9138d8d980711f8b63af09b10f92bace5b444bd188728e",
        ROOT / "results/ispa_capacity_copyin_completion_audit_20260923_fix1/validation.json":
            "403c105c2aee05723561f52fc56aae883bca1ea2fc213a76d1ff7269156d96d0",
    }
    for path, digest in proofs.items():
        assert len(digest) == 64 and prior.sha(path) == digest
        assert json.loads(path.read_text())["status"] == "COMPLETE"
        bindings[str(path)] = digest
    for base in (CAP, GATE):
        assert (base / "controller/exit_code").read_text().strip() == "0"
        assert (base / "controller/COMPLETE").exists()
    for path in [cp, *sorted(HERE.glob("*.py")), *sorted(HERE.glob("*.md"))]:
        bindings[str(path)] = prior.sha(path)
    frozen = dict(status="PREPARED", utc=utc(), inference_executed=False, gpu_uuid=prior.GPU,
                  plan=PLAN, schedules={p:schedule(p) for p in ("smoke", "formal")}, bindings=bindings,
                  compute_at_prepare=prior.compute(), free_gib=shutil.disk_usage(ROOT).free/2**30,
                  environment_policy="no clocks, power limits, MPS or MIG changes")
    verify_bindings(frozen)
    BASE.mkdir(parents=True, exist_ok=False)
    save(BASE / "prepared.json", frozen)
    (BASE / "PREPARED").write_text("CPU-only freeze; no new inference.\n")
    print(json.dumps(dict(status="PREPARED", sha256=prior.sha(BASE / "prepared.json"),
                          counts=PLAN["expected_runs"], busy=bool(frozen["compute_at_prepare"]))))


def dispatch():
    frozen = json.loads((BASE / "prepared.json").read_text())
    verify_bindings(frozen)
    assert not duplicates()
    control = BASE / "controller"
    control.mkdir(exist_ok=False)
    with (control / "launcher.log").open("x") as log:
        proc = subprocess.Popen([sys.executable, "-B", "-u", str(Path(__file__)), "run"], cwd=ROOT,
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
            env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"), start_new_session=True, close_fds=True)
    save(control / "dispatch.json", dict(pid=proc.pid, utc=utc(), no_retry=True))
    print(json.dumps(dict(status="QUEUED_FOR_QUIET_HOST", pid=proc.pid, output=str(BASE))))


def invoke(command, env, log_path, timeout):
    with log_path.open("x") as log:
        child = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            return child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            # This process group was created exclusively for this run; never touch foreign work.
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=20)
            raise RuntimeError("owned child timeout; preserved without inference retry")


def run():
    control = BASE / "controller"
    frozen = json.loads((BASE / "prepared.json").read_text())
    status = dict(status="WAITING_FOR_QUIET_HOST", utc_start=utc(), inference_executed=False,
                  active=None, completed=[], phases=[], expected_runs=PLAN["expected_runs"])
    lock = None
    phase_report = None
    folder = None
    rc = 2
    try:
        verify_bindings(frozen)
        assert not duplicates()
        deadline = time.monotonic() + PLAN["initial_quiet_wait_seconds"]
        while True:
            busy = prior.compute()
            free = shutil.disk_usage(ROOT).free/2**30
            status.update(last_check_utc=utc(), compute=busy, free_gib=free)
            save(control / "status.json", status)
            if not busy and free >= PLAN["minimum_free_gib"]:
                candidate = (ROOT / "borrowplan_gpu0.lock").open("a")
                try:
                    fcntl.flock(candidate, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    candidate.close()
                else:
                    time.sleep(5)
                    if not prior.compute():
                        lock = candidate
                        break
                    candidate.close()
            if time.monotonic() >= deadline:
                status["status"] = "STOPPED_BEFORE_INFERENCE"
                raise RuntimeError("initial quiet/disk wait exceeded 24h; zero new inference")
            time.sleep(PLAN["initial_quiet_poll_seconds"])
        verify_bindings(frozen)
        assert not duplicates()
        status["status"] = "RUNNING"
        save(control / "status.json", status)
        for phase in ("smoke", "formal"):
            folder = BASE / phase
            folder.mkdir(exist_ok=False)
            phase_report = dict(status="RUNNING", phase=phase, plan=PLAN, runs=[], schedule=schedule(phase),
                                prepared_sha256=prior.sha(BASE / "prepared.json"))
            env = dict(os.environ, PYTHONPATH=":".join(map(str, DEPS)), CUDA_VISIBLE_DEVICES=prior.GPU,
                       PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
                       OPENBLAS_NUM_THREADS="1", CUDA_CACHE_PATH=str(folder / "cuda-cache"))
            for item in phase_report["schedule"]:
                verify_bindings(frozen)
                busy = prior.compute()
                if busy:
                    status.update(status="PAUSED_BEFORE_INFERENCE", next_unstarted=item["name"], compute=busy)
                    raise RuntimeError("foreign compute before next run; no automatic resume")
                assert shutil.disk_usage(ROOT).free/2**30 >= PLAN["minimum_free_gib"], "disk reserve below 20GiB"
                status.update(active=dict(phase=phase, run=item["name"]), inference_executed=True)
                save(control / "status.json", status)
                save(folder / "report.json", phase_report)
                started = time.monotonic()
                command = [sys.executable, "-B", str(HERE / "run_pipeline.py"), "--output", str(folder/item["name"]),
                           "--cell", json.dumps(item["cell"]), "--method", item["method"]]
                code = invoke(command, env, folder/(item["name"]+".log"), PLAN["run_timeout_seconds"])
                assert code == 0, item["name"] + " inference failed; no retry"
                proof = folder / (item["name"] + "-validation")
                code = invoke([sys.executable, "-B", str(HERE/"validate_pipeline.py"), "--run", str(folder/item["name"]),
                               "--output", str(proof)], dict(env, CUDA_VISIBLE_DEVICES=""),
                              folder/(item["name"]+"-validation.log"), PLAN["validation_timeout_seconds"])
                assert code == 0, item["name"] + " independent validation failed; preserve inference"
                entry = dict(item, seconds=time.monotonic()-started,
                             report_sha256=prior.sha(folder/item["name"]/"report.json"),
                             sink_sha256=prior.sha(folder/item["name"]/"sink.json"),
                             validation_sha256=prior.sha(proof/"validation.json"))
                phase_report["runs"].append(entry)
                status["completed"].append(dict(phase=phase, name=item["name"], seconds=entry["seconds"]))
                status["active"] = None
                save(folder/"report.json", phase_report)
                save(control/"status.json", status)
                print(json.dumps(dict(status="RUN_COMPLETE", phase=phase, run=item["name"],
                                      done=len(phase_report["runs"]), total=len(phase_report["schedule"]))), flush=True)
            phase_report["status"] = "COMPLETE"
            save(folder/"report.json", phase_report)
            (folder/"COMPLETE").write_text("COMPLETE\n")
            code = invoke([sys.executable, "-B", str(HERE/"analyze.py"), "--root", str(folder),
                           "--output", str(folder/"analysis")], dict(env, CUDA_VISIBLE_DEVICES=""),
                          folder/"analysis.log", PLAN["validation_timeout_seconds"])
            assert code == 0, phase + " aggregate analysis failed"
            status["phases"].append(dict(phase=phase, validation_sha256=prior.sha(folder/"analysis/validation.json")))
        status["status"], rc = "COMPLETE", 0
    except BaseException:
        if status["status"] in ("RUNNING", "WAITING_FOR_QUIET_HOST"):
            status["status"] = "FAILED"
        status["reason"] = traceback.format_exc()
        if phase_report is not None:
            phase_report.update(status=status["status"], failure=status["reason"])
            save(folder/"report.json", phase_report)
            (folder/status["status"]).write_text(status["status"]+"\n")
        traceback.print_exc()
    finally:
        if lock is not None:
            lock.close()
    status["utc_end"] = utc()
    save(control/"status.json", status)
    (control/status["status"]).write_text(status["status"]+"\n")
    (control/"exit_code").write_text(str(rc)+"\n")
    return rc


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("prepare", "dispatch", "run"))
    args = parser.parse_args()
    if args.action == "run":
        raise SystemExit(run())
    globals()[args.action]()
