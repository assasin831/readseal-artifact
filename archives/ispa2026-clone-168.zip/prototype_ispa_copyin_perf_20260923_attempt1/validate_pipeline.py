"""CPU-only extension of frozen receipt/credit/tensor auditors for copy-in."""
import argparse
import json
import math
import os
from pathlib import Path
import traceback

from common import sha
from validate_admission_base import audit_cell
import validate_admission
import validate_abc
from validate_grouped_pipeline import check_artifact
from plan import METHODS


def cell(folder):
    out = audit_cell(folder)
    report = json.loads((folder / "report.json").read_text())
    method = report["method"]
    assert method in METHODS
    assert report["gpu_uuid"] == "GPU-f3b314a8-3058-e0be-694c-76f4227afb7d"
    assert report["wrong_outputs"] == report["source_unknown"] == 0
    sink = json.loads((folder / "sink.json").read_text())
    receipts = {(r["tick"], r["consumer"]): r for r in sink}
    copy_rows = 0
    for i in range(report["cell"]["consumers"]):
        art = json.loads((folder / f"consumer-{i}-artifact.json").read_text())
        if method == "copy-in":
            assert art["schema"] == "ispa-copyin-abc-v1"
            assert art["original_source_readers"] == ["D2D-copy"]
            assert art["complete_private_readers"] == ["A", "C"]
            assert art["private_copy_bytes"] == report["source_bytes"]
            assert not art["automatic_source_read_analysis_used"]
            assert art["original_source_release"] == "copy-completion event"
            check_artifact(art["private_compute"], "manual-full")
        else:
            check_artifact(art, method)
        worker = json.loads((folder / f"consumer-{i}.json").read_text())
        for row in worker["rows"]:
            trace = row["composition"]
            assert row["admission_ns"] <= trace["enrolled_ns"] <= trace["a_submitted_ns"] <= trace["c_prefix_submitted_ns"] <= row["read_done_ns"]
            assert row["native_shape"] == [1, 128] and row["complete_ab_outputs"]
            assert row["output_done_ns"] <= row["invocation_retired_ns"] <= row["sink_enqueue_ns"]
            receipt = receipts[(row["tick"], i)]
            assert receipt["composition"] == trace
            assert receipt["invocation_retired_ns"] == row["invocation_retired_ns"]
            assert receipt["private_copy_bytes"] == row["private_copy_bytes"]
            if method == "copy-in":
                copy_rows += 1
                assert row["private_copy_bytes"] == trace["private_copy_bytes"] == report["source_bytes"]
                assert trace["source_reader"] == "D2D-copy"
                assert trace["enrolled_ns"] <= trace["private_allocation_ns"] <= trace["copy_enqueued_ns"] <= trace["a_submitted_ns"]
                assert row["output_done_ns"] <= trace["private_compute_complete_observed_ns"] <= row["invocation_retired_ns"]
                assert math.isfinite(trace["copy_device_ms"]) and trace["copy_device_ms"] >= 0
            else:
                assert row["private_copy_bytes"] == 0
    assert all(len(ref["hashes"]) == (11 if report["cell"]["late"] else 10)
               for ref in report["references"])
    assert (copy_rows == len(sink)) if method == "copy-in" else (copy_rows == 0)
    out.update(complete_native_and_child_outputs=True, gpu_uuid=report["gpu_uuid"],
               copy_intervals_validated=copy_rows, copy_memory_metric="logical input-copy lifetime, not allocator reservation")
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    result = dict(status="RUNNING", cuda_used=False, inference_executed=False)
    try:
        assert os.environ.get("CUDA_VISIBLE_DEVICES") == ""
        validate_abc.cell = cell
        result.update(validate_admission.audit(args.run), status="COMPLETE",
                      report_sha256=sha(args.run / "report.json"), validator_sha256=sha(__file__))
    except BaseException:
        result.update(status="FAILED", traceback=traceback.format_exc())
        traceback.print_exc()
    (args.output / "validation.json").write_text(json.dumps(result, indent=2) + "\n")
    (args.output / result["status"]).write_text(result["status"] + "\n")
    print(json.dumps(result), flush=True)
    return int(result["status"] != "COMPLETE")


if __name__ == "__main__":
    raise SystemExit(main())
