"""Preserve local unit-test evidence; never executes the campaign or its audit."""
import argparse
import contextlib
import datetime
import json
from pathlib import Path
import platform
import unittest

import numpy as np

from audit import sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    args.output.mkdir(parents=True, exist_ok=False)
    suite = unittest.defaultTestLoader.discover(str(here), pattern="test_audit.py")
    with (args.output / "unittest.log").open("x", encoding="utf-8") as log:
        with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
            result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    report = dict(status="CPU_PREPARATION_COMPLETE" if result.wasSuccessful() else "CPU_PREPARATION_FAILED",
                  utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                  skipped=len(result.skipped), gpu_used=False, inference_executed=False,
                  campaign_results_validated=False, synthetic_fixtures_only=True,
                  python=platform.python_version(), numpy=np.__version__,
                  source_sha256={p.name: sha(p) for p in sorted(here.iterdir()) if p.is_file()},
                  log_sha256=sha(args.output / "unittest.log"))
    (args.output / "validation.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    (args.output / report["status"]).write_text(report["status"] + "\n", encoding="utf-8")
    print(json.dumps(report), flush=True)
    return int(not result.wasSuccessful())


if __name__ == "__main__":
    raise SystemExit(main())
