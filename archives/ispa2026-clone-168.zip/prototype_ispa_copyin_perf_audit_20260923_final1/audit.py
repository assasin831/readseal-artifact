"""Independent CPU audit of the frozen copy-in performance wave, after completion."""
import argparse
import csv
from decimal import Decimal, localcontext
import hashlib
import itertools
import json
import math
from pathlib import Path
import traceback

import numpy as np

PREPARED_SHA = "8715d718cf48bb9aff440805f3c3d985fdcafde4c99aadac2d1461b8bb838905"
CPU_SHA = "1bef916236d6d0d14244672f9afea0e27251a02409306d96655844e28c9d091d"
GPU = "GPU-f3b314a8-3058-e0be-694c-76f4227afb7d"
METHODS = ("auto-batched", "manual-early", "manual-full", "copy-in")
CONDITIONS = tuple(f"base-r1-hz{n}" for n in (10, 15, 20, 25, 30, 40)) + ("late-r1-hz30",)
PAIRS = (("copy-in", "auto-batched"), ("copy-in", "manual-full"),
         ("auto-batched", "manual-full"), ("auto-batched", "manual-early"))
COUNTS = ("arrivals", "publications", "timely", "correct_late", "producer_late",
          "pool_exhausted", "credit_exhausted", "queue_loss", "peak_outstanding")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def interval(values):
    require(len(values) == 6 and all(math.isfinite(float(x)) for x in values), "six finite runs required")
    with localcontext() as ctx:
        ctx.prec = 45
        xs = [Decimal(str(x)) for x in values]
        mean = sum(xs) / 6
        sd = (sum((x - mean) ** 2 for x in xs) / 5).sqrt()
        width = Decimal("2.570581835636305") * sd / Decimal(6).sqrt()
        return dict(n=6, mean=float(mean), sd=float(sd),
                    ci95_low=float(mean - width), ci95_high=float(mean + width))


def freshness_ms(events, begin, end):
    """Integrate the freshest generation using vectorized interval midpoints."""
    require(end > begin and events, "empty freshness history")
    ordered = sorted(events)
    require(all(g <= r for r, g in ordered), "generation after receipt")
    receipt = np.asarray([r - begin for r, _ in ordered], dtype=np.int64)
    generation = np.maximum.accumulate(np.asarray([g - begin for _, g in ordered], dtype=np.int64))
    require(receipt[0] <= 0, "missing warmup coverage")
    duration = end - begin
    edges = np.unique(np.concatenate(([0], receipt[(receipt > 0) & (receipt < duration)], [duration])))
    state = np.searchsorted(receipt, edges[:-1], side="right") - 1
    require(np.all(state >= 0), "uncovered freshness segment")
    left, width = edges[:-1], np.diff(edges)
    value = np.sum((left - generation[state] + width / 2.0) * (width / duration)) / 1e6
    return float(value)


def copy_memory(intervals, begin, end):
    """Integrate each copy separately; group simultaneous endpoints for the peak."""
    require(end > begin, "invalid memory window")
    changes, byte_ns = {}, 0
    for start, stop, size in intervals:
        require(start <= stop and size >= 0, "invalid copy interval")
        a, b = max(start, begin), min(stop, end)
        if a >= b:
            continue
        byte_ns += (b - a) * size
        changes[a] = changes.get(a, 0) + size
        changes[b] = changes.get(b, 0) - size
    active = peak = 0
    for timestamp in sorted(changes):
        active += changes[timestamp]
        require(active >= 0, "negative live copy size")
        peak = max(peak, active)
    require(active == 0, "unclosed clipped copy intervals")
    return dict(mean_mib=byte_ns / (end - begin) / 2**20, peak_mib=peak / 2**20)


def metrics(report, sink):
    begin, end = report["cohort_start_ns"], report["cohort_end_ns"]
    duration = (end - begin) / 1e9
    require(duration > 0 and duration == report["cell"]["measure_seconds"], "window mismatch")
    require(report["wrong_outputs"] == report["source_unknown"] == 0, "wrong/unknown result")
    consumers = report["cell"]["consumers"]
    require(len({(r["tick"], r["consumer"]) for r in sink}) == len(sink), "duplicate receipt")
    for row in sink:
        require(all(row[k] is True for k in ("output_equal", "provenance_verified", "finite", "published")),
                "unverified receipt")
        require(0 <= row["consumer"] < consumers, "unexpected consumer")
        require(row["scheduled_ns"] <= row["publish_ns"], "negative receipt latency")
        require(row["cohort"] == (begin <= row["scheduled_ns"] < end), "cohort label not schedule-derived")
        size = row["private_copy_bytes"]
        require(size == (report["source_bytes"] if report["method"] == "copy-in" else 0), "copy size mismatch")
    cohort = [r for r in sink if begin <= r["scheduled_ns"] < end]
    require(cohort, "empty source cohort")
    latency_ns = np.asarray([r["publish_ns"] - r["scheduled_ns"] for r in cohort], dtype=np.int64)
    latencies = latency_ns / 1e6
    ages = [freshness_ms([(r["publish_ns"], r["scheduled_ns"]) for r in sink if r["consumer"] == c], begin, end)
            for c in range(consumers)]
    copies = [(r["composition"]["private_allocation_ns"], r["invocation_retired_ns"], r["private_copy_bytes"])
              for r in sink if r["private_copy_bytes"]]
    memory = copy_memory(copies, begin, end)
    timings = [r["composition"]["copy_device_ms"] for r in cohort if r["private_copy_bytes"]]
    require(all(math.isfinite(t) and t >= 0 for t in timings), "invalid D2D timing")
    result = dict(receipt_capacity_hz=sum(begin <= r["publish_ns"] < end for r in sink) / duration,
                  cohort_delivered_hz=len(cohort) / duration,
                  mean_age_ms=float(np.mean(ages)),
                  p50_latency_ms=float(np.quantile(latencies, .5)),
                  p99_latency_ms=float(np.quantile(latencies, .99)),
                  device_peak_mib=report["device_peak_bytes"] / 2**20,
                  protected_mib=report["protected_byte_seconds"] / duration / 2**20,
                  private_copy_mean_mib=memory["mean_mib"], private_copy_peak_mib=memory["peak_mib"],
                  copy_p50_device_ms=float(np.quantile(timings, .5)) if timings else 0,
                  copy_p99_device_ms=float(np.quantile(timings, .99)) if timings else 0,
                  summed_consumer_allocated_peaks_mib=sum(r["stats"]["allocated_peak_bytes"] for r in report["allocator_stats"]) / 2**20,
                  summed_consumer_reserved_peaks_mib=sum(r["stats"]["reserved_peak_bytes"] for r in report["allocator_stats"]) / 2**20)
    for deadline in (50, 75, 100, 150):
        result[f"timely_{deadline}ms_hz"] = int(np.count_nonzero(latency_ns <= deadline * 1_000_000)) / duration
    require(all(math.isfinite(float(v)) for v in result.values()), "nonfinite metric")
    require(math.isclose(result["timely_100ms_hz"], report["goodput_hz"], rel_tol=0, abs_tol=1e-10), "goodput mismatch")
    return result


def expected_members(phase):
    require(phase in ("smoke", "formal"), "unknown phase")
    conditions = ("base-r1-hz20", "late-r1-hz30") if phase == "smoke" else CONDITIONS
    return set(itertools.product(conditions, METHODS, range(1 if phase == "smoke" else 6)))


def check_schedule(rows, phase):
    members = [(r["condition"], r["method"], r["repeat"]) for r in rows]
    require(len(members) == len(set(members)) and set(members) == expected_members(phase), "schedule membership mismatch")
    require(len({r["name"] for r in rows}) == len(rows), "duplicate run path")
    for row in rows:
        condition = row["condition"]
        cell = dict(model="transfusion", consumers=4, queue=8, ring=1, outstanding_cap=0,
                    deadline_ms=100, warmup_seconds=1 if phase == "smoke" else 10,
                    measure_seconds=3 if phase == "smoke" else 30, id=condition,
                    rate_hz=int(condition.rsplit("hz", 1)[1]), late=condition.startswith("late-"))
        require(row["cell"] == cell, "changed condition parameters")
        require(row["name"] == f"{phase}-r{row['repeat']:02d}-{condition}-{row['method']}", "unexpected run name")


class Auditor:
    def __init__(self):
        self.checks = 0

    def check(self, condition, message):
        require(condition, message)
        self.checks += 1

    def close(self, actual, expected, message):
        self.check(math.isfinite(float(actual)) and math.isclose(float(actual), float(expected), rel_tol=2e-10, abs_tol=1e-8), message)

    def csv(self, path, keys):
        with path.open(newline="", encoding="utf-8") as stream:
            rows = list(csv.DictReader(stream))
        keyed = {tuple(r[k] for k in keys): r for r in rows}
        self.check(len(keyed) == len(rows), f"duplicate CSV keys: {path.name}")
        return keyed

    def phase(self, folder, prepared):
        campaign = read(folder / "report.json")
        phase = campaign["phase"]
        self.check(campaign["status"] == "COMPLETE" and (folder / "COMPLETE").exists(), "phase incomplete")
        self.check(campaign["prepared_sha256"] == PREPARED_SHA, "phase prepared lineage mismatch")
        self.check(campaign["plan"] == prepared["plan"], "phase plan drift")
        self.check(campaign["schedule"] == prepared["schedules"][phase], "frozen order drift")
        check_schedule(campaign["schedule"], phase)
        check_schedule(campaign["runs"], phase)
        analysis = folder / "analysis"
        aggregate = read(analysis / "validation.json")
        self.check(aggregate["status"] == "COMPLETE" and (analysis / "COMPLETE").exists(), "aggregate incomplete")
        self.check(aggregate["cuda_used"] is False and aggregate["inference_executed"] is False, "non-CPU aggregate")
        self.check(aggregate["campaign_sha256"] == sha(folder / "report.json"), "aggregate campaign hash drift")
        self.check(aggregate["runs"] == len(campaign["runs"]) and aggregate["phase"] == phase, "aggregate count drift")
        source = folder.parent.parent.parent / "prototype_ispa_copyin_perf_20260923_attempt1"
        self.check(aggregate["analysis_sha256"] == prepared["bindings"][str(source / "analyze.py")], "analysis source lineage")
        self.check(aggregate["metrics_sha256"] == prepared["bindings"][str(source / "performance_metrics.py")], "metrics source lineage")
        expected_files = {"per_run.csv"} if phase == "smoke" else {"per_run.csv", "summary_t95.csv", "paired_t95.csv"}
        self.check(set(aggregate["csv_sha256"]) == expected_files, "CSV inventory mismatch")
        for name, digest in aggregate["csv_sha256"].items():
            self.check(sha(analysis / name) == digest, "aggregate CSV hash drift")
        csv_rows = self.csv(analysis / "per_run.csv", ("run",))
        self.check(set(csv_rows) == {(r["name"],) for r in campaign["runs"]}, "per-run CSV membership")
        measured = []
        for item, planned in zip(campaign["runs"], campaign["schedule"]):
            self.check(all(item[k] == v for k, v in planned.items()), "run order drift")
            run = folder / item["name"]
            proof_path = folder / (item["name"] + "-validation") / "validation.json"
            proof = read(proof_path)
            self.check(proof["status"] == "COMPLETE" and proof["cuda_used"] is False, "per-run proof incomplete")
            self.check(proof["inference_executed"] is False, "per-run validator inferred")
            self.check(proof["validator_sha256"] == prepared["bindings"][str(source / "validate_pipeline.py")], "per-run validator lineage")
            self.check((proof_path.parent / "COMPLETE").exists(), "per-run validation marker missing")
            self.check(sha(proof_path) == item["validation_sha256"], "per-run proof hash drift")
            self.check(sha(run / "report.json") == item["report_sha256"] == proof["report_sha256"], "report hash drift")
            self.check(sha(run / "sink.json") == item["sink_sha256"] == proof["sink_sha256"], "sink hash drift")
            report, sink = read(run / "report.json"), read(run / "sink.json")
            self.check(report["cell"] == item["cell"] and report["method"] == item["method"], "run configuration drift")
            self.check(report["gpu_uuid"] == GPU, "GPU UUID mismatch")
            values = metrics(report, sink)
            values.update({k: proof[k] for k in COUNTS})
            self.close(values["timely"], values["timely_100ms_hz"] * report["cell"]["measure_seconds"], "timely count")
            self.close(values["correct_late"] + values["timely"], values["cohort_delivered_hz"] * report["cell"]["measure_seconds"], "delivery count")
            saved = csv_rows[(item["name"],)]
            self.check(set(saved) == {"run", "condition", "method", "repeat"} | set(values), "per-run columns")
            self.check(saved["condition"] == item["condition"] and saved["method"] == item["method"] and int(saved["repeat"]) == item["repeat"], "CSV run identity")
            for key, value in values.items():
                self.close(saved[key], value, f"{item['name']}: {key}")
            measured.append(dict(condition=item["condition"], method=item["method"], repeat=item["repeat"], values=values))
        if phase == "formal":
            self.summaries(analysis, measured)
        return dict(runs=len(measured), analysis_sha256=sha(analysis / "validation.json"),
                    per_run_metric_count=len(measured[0]["values"]))

    def summaries(self, folder, rows):
        metrics_keys = set(rows[0]["values"])
        summary = self.csv(folder / "summary_t95.csv", ("condition", "method", "metric"))
        paired = self.csv(folder / "paired_t95.csv", ("condition", "a_method", "b_method", "metric"))
        self.check(set(summary) == set(itertools.product(CONDITIONS, METHODS, metrics_keys)), "summary grid")
        self.check(set(paired) == {(c, a, b, m) for c in CONDITIONS for a, b in PAIRS for m in metrics_keys}, "paired grid")
        grouped = {(c, m): sorted([r for r in rows if r["condition"] == c and r["method"] == m], key=lambda r: r["repeat"])
                   for c in CONDITIONS for m in METHODS}
        for key, group in grouped.items():
            self.check([r["repeat"] for r in group] == list(range(6)), "paired repetitions")
            for metric in metrics_keys:
                recomputed = interval([r["values"][metric] for r in group])
                for field, value in recomputed.items():
                    self.close(summary[(*key, metric)][field], value, f"summary {key} {metric} {field}")
        for condition in CONDITIONS:
            for a, b in PAIRS:
                for metric in metrics_keys:
                    differences = [x["values"][metric] - y["values"][metric]
                                   for x, y in zip(grouped[(condition, a)], grouped[(condition, b)])]
                    for field, value in interval(differences).items():
                        self.close(paired[(condition, a, b, metric)][field], value, f"paired {condition} {metric} {field}")


def run(base, output):
    require(output.resolve() != base.resolve() and base.resolve() not in output.resolve().parents, "audit output must be separate")
    output.mkdir(parents=True, exist_ok=False)
    auditor = Auditor()
    result = dict(status="RUNNING", cuda_used=False, inference_executed=False, embedded_validation=False,
                  experimental_unit="whole run; paired by repetition; n=6",
                  intervals="pointwise t95 df5, no multiplicity correction or equivalence test",
                  validator_sha256=sha(__file__), numpy_version=np.__version__)
    try:
        require(sha(base / "prepared.json") == PREPARED_SHA, "unexpected frozen manifest")
        frozen = read(base / "prepared.json")
        auditor.check(frozen["gpu_uuid"] == GPU and len(frozen["bindings"]) == 148, "manifest identity")
        for path, digest in frozen["bindings"].items():
            auditor.check(sha(path) == digest, f"changed binding: {path}")
        cpu = base.parent / "ispa_copyin_perf_cpu_validation_20260923_attempt1" / "validation.json"
        auditor.check(sha(cpu) == CPU_SHA and read(cpu)["status"] == "COMPLETE", "CPU preflight proof")
        controller = base / "controller"
        auditor.check((controller / "exit_code").read_text().strip() == "0", "controller did not exit successfully")
        state = read(controller / "status.json")
        auditor.check((controller / "COMPLETE").exists() and state["status"] == "COMPLETE", "controller not complete")
        auditor.check(state["active"] is None, "controller has active run")
        actual = [(r["phase"], r["name"]) for r in state["completed"]]
        expected = [(phase, r["name"]) for phase in ("smoke", "formal") for r in frozen["schedules"][phase]]
        auditor.check(actual == expected, "controller completion inventory mismatch")
        auditor.check([p["phase"] for p in state["phases"]] == ["smoke", "formal"], "controller phase inventory")
        for proof in state["phases"]:
            auditor.check(proof["validation_sha256"] == sha(base / proof["phase"] / "analysis/validation.json"), "controller aggregate hash")
        auditor.check(not list(base.rglob("FAILED")) and not list(base.rglob("STOPPED*")), "failure/stop marker in campaign")
        results = {phase: auditor.phase(base / phase, frozen) for phase in ("smoke", "formal")}
        result.update(status="COMPLETE", phases=results, prepared_sha256=PREPARED_SHA,
                      bounds="Raw-sink metrics recomputed; tensor/source/reuse/credit checks are hash-bound per-run proofs. Protected byte-time and memory samples use audited run reports.")
    except Exception:
        result.update(status="FAILED", traceback=traceback.format_exc())
    result["checks"] = auditor.checks
    (output / "validation.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    (output / result["status"]).write_text(result["status"] + "\n", encoding="utf-8")
    print(json.dumps(result), flush=True)
    return int(result["status"] != "COMPLETE")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    raise SystemExit(run(args.base, args.output))
