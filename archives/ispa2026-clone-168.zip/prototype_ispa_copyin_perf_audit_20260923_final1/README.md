# Independent copy-in performance audit preparation

CPU-only preparation, separate from the 148 frozen campaign bindings. This code
does not import any campaign implementation and cannot execute inference. It
must only audit the completed campaign; never run it against partial outputs and
mistake the expected missing-data failure for an inference failure.

Run after the controller, smoke, formal, and both aggregate analyses are COMPLETE:

```text
python -B audit.py --base /www/readseal_ipdps_revision_v6/results/ispa_copyin_performance_20260923_attempt1 --output /www/readseal_ipdps_revision_v6/results/ispa_copyin_performance_independent_audit_20260923_final1
```

The output directory must be new and separate from the campaign. Runtime
dependencies are Python and NumPy, already present in the pinned remote runtime.
SciPy is used only for a local test of the fixed df=5 critical value.

Checks include the exact prepared SHA, all 148 bindings, CPU preflight proof,
both schedules, all 176 proof/report/sink hashes, run configurations and GPU UUID,
source-cohort versus wall-window membership, valid/unique receipts, raw latency
quantiles and four deadlines, freshest-result integrals, logical copy lifetimes,
all per-run CSVs, six whole-run intervals, and paired differences by repetition.
Freshness is independently integrated with vectorized interval midpoints;
copy-byte time sums separately clipped lifetimes; interval moments use Decimal.

Boundary: source/tensor/reference/reuse/credit correctness remains established
by the existing hash-bound per-run auditors; this is not a second inference or
a new tensor reference. Protected-memory integrals and sampled device/allocator
peaks use those audited reports, not reconstructed GPU memory telemetry. Logical
input-copy bytes and sums of per-process maxima are not total or simultaneous
device memory. The intervals are pointwise, with n=6 runs, not receipts, and no
equivalence or multiple-comparison claim. This is not embedded-device validation.

All synthetic histories in tests are explicitly unit-test fixtures, never paper
measurements. No GPU configuration or active campaign file is changed.
