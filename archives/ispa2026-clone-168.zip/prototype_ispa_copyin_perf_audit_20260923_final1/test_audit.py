"""Synthetic unit fixtures only; no GPU or experimental observations."""
import copy
import csv
import importlib.util
import math
from pathlib import Path
import random
import tempfile
import unittest

import numpy as np

import audit


def production_module(name):
    path = Path(__file__).resolve().parent.parent / "ispa_copyin_perf_20260923" / (name + ".py")
    spec = importlib.util.spec_from_file_location("frozen_" + name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def fixture():
    begin = 1_000_000_000
    rows = []
    for tick, (scheduled, published) in enumerate(((-20_000_000, -10_000_000), (0, 100_000_000), (980_000_000, 1_100_000_000))):
        rows.append(dict(tick=tick, consumer=0, scheduled_ns=begin + scheduled,
                         publish_ns=begin + published, cohort=0 <= scheduled < 1_000_000_000,
                         output_equal=True, provenance_verified=True, finite=True, published=True,
                         private_copy_bytes=0))
    report = dict(cohort_start_ns=begin, cohort_end_ns=begin + 1_000_000_000,
                  cell=dict(measure_seconds=1, consumers=1), wrong_outputs=0, source_unknown=0,
                  source_bytes=1024, method="auto-batched", device_peak_bytes=4096,
                  protected_byte_seconds=1024, allocator_stats=[dict(stats=dict(allocated_peak_bytes=2048, reserved_peak_bytes=4096))],
                  goodput_hz=1.0)
    return report, rows


class IndependentMetricTests(unittest.TestCase):
    def test_freshness_exact_integral(self):
        self.assertEqual(audit.freshness_ms([(-1, -2), (2, 1)], 0, 4), 2.5 / 1e6)

    def test_out_of_order_generations_do_not_reset_age(self):
        base = [(-1, -2), (2, 1)]
        self.assertEqual(audit.freshness_ms(base + [(3, 0)], 0, 4), audit.freshness_ms(base, 0, 4))

    def test_simultaneous_receipts_use_freshest(self):
        self.assertEqual(audit.freshness_ms([(-1, -2), (2, -1), (2, 1)], 0, 4), 2.5 / 1e6)

    def test_missing_warmup_fails(self):
        with self.assertRaisesRegex(ValueError, "warmup"):
            audit.freshness_ms([(1, 0)], 0, 4)

    def test_future_generation_fails(self):
        with self.assertRaisesRegex(ValueError, "generation"):
            audit.freshness_ms([(-1, 0)], 0, 4)

    def test_memory_clipping_and_overlap(self):
        self.assertEqual(audit.copy_memory([(-2, 3, 4), (2, 7, 8)], 0, 5),
                         dict(mean_mib=36 / 5 / 2**20, peak_mib=12 / 2**20))

    def test_adjacent_copies_are_not_simultaneously_live(self):
        self.assertEqual(audit.copy_memory([(0, 2, 4), (2, 4, 8)], 0, 4)["peak_mib"], 8 / 2**20)

    def test_invalid_copy_interval_fails(self):
        with self.assertRaisesRegex(ValueError, "invalid copy"):
            audit.copy_memory([(3, 1, 4)], 0, 5)

    def test_source_cohort_is_distinct_from_wall_receipts(self):
        report, sink = fixture()
        out = audit.metrics(report, sink)
        self.assertEqual(out["cohort_delivered_hz"], 2)
        self.assertEqual(out["receipt_capacity_hz"], 1)
        self.assertEqual(out["timely_100ms_hz"], 1)
        self.assertEqual(out["timely_150ms_hz"], 2)
        self.assertEqual(out["p50_latency_ms"], 110)

    def test_duplicate_receipts_fail(self):
        report, sink = fixture()
        with self.assertRaisesRegex(ValueError, "duplicate"):
            audit.metrics(report, sink + [sink[-1]])

    def test_tampered_cohort_flag_fails(self):
        report, sink = fixture()
        sink[-1]["cohort"] = False
        with self.assertRaisesRegex(ValueError, "cohort label"):
            audit.metrics(report, sink)

    def test_unverified_receipt_fails(self):
        report, sink = fixture()
        sink[0]["provenance_verified"] = False
        with self.assertRaisesRegex(ValueError, "unverified"):
            audit.metrics(report, sink)

    def test_undeclared_private_copy_fails(self):
        report, sink = fixture()
        sink[0]["private_copy_bytes"] = 1024
        with self.assertRaisesRegex(ValueError, "copy size"):
            audit.metrics(report, sink)

    def test_copy_in_metrics_match_independent_implementation(self):
        report, sink = fixture()
        report["method"] = "copy-in"
        for row in sink:
            row.update(private_copy_bytes=report["source_bytes"], invocation_retired_ns=row["publish_ns"] - 1,
                       composition=dict(private_allocation_ns=row["scheduled_ns"], copy_device_ms=.1))
        expected = production_module("performance_metrics").calculate(report, sink)
        for key, value in audit.metrics(report, sink).items():
            self.assertAlmostEqual(value, expected[key], places=9, msg=key)

    def test_random_histories_against_frozen_metric_code(self):
        original = production_module("performance_metrics")
        rng = random.Random(26092331)
        for _ in range(100):
            events = [(-1, -3)] + [(r, r - rng.randrange(30)) for r in sorted(rng.choices(range(101), k=30))]
            self.assertAlmostEqual(audit.freshness_ms(events, 0, 100), original.age(events, 0, 100)["mean_ms"], places=12)
            intervals = [(a, a + rng.randrange(20), rng.randrange(100)) for a in rng.choices(range(-10, 110), k=30)]
            self.assertEqual(audit.copy_memory(intervals, 0, 100), original.byte_lifetime(intervals, 0, 100))

    def test_interval_rejects_receipt_pseudoreplication(self):
        with self.assertRaisesRegex(ValueError, "six"):
            audit.interval(list(range(100)))

    def test_interval_constant_values(self):
        self.assertEqual(audit.interval([3] * 6), dict(n=6, mean=3, sd=0, ci95_low=3, ci95_high=3))

    def test_critical_value_and_interval_against_local_scipy(self):
        try:
            from scipy.stats import t
        except ImportError:
            self.skipTest("SciPy is a local test dependency only")
        self.assertAlmostEqual(float(t.ppf(.975, 5)), 2.570581835636305, places=12)
        values = np.array([1.1, -2.5, .03, 7.2, -8.3, 10.7])
        out = audit.interval(values)
        width = t.ppf(.975, 5) * np.std(values, ddof=1) / math.sqrt(6)
        self.assertAlmostEqual(out["ci95_low"], np.mean(values) - width, places=12)
        self.assertAlmostEqual(out["ci95_high"], np.mean(values) + width, places=12)


class ScheduleTests(unittest.TestCase):
    def test_frozen_schedules_match_independent_cartesian_membership(self):
        plan = production_module("plan")
        for phase, count in (("smoke", 8), ("formal", 168)):
            rows = plan.schedule(phase)
            self.assertEqual(len(rows), count)
            audit.check_schedule(rows, phase)

    def test_missing_or_duplicate_configuration_fails(self):
        rows = production_module("plan").schedule("formal")
        for changed in (rows[:-1], rows[:-1] + [rows[0]]):
            with self.assertRaisesRegex(ValueError, "membership"):
                audit.check_schedule(changed, "formal")

    def test_changed_ring_fails(self):
        rows = copy.deepcopy(production_module("plan").schedule("smoke"))
        rows[0]["cell"]["ring"] = 2
        with self.assertRaisesRegex(ValueError, "parameters"):
            audit.check_schedule(rows, "smoke")

    def test_aggregate_and_pair_audit_detects_unpaired_comparison(self):
        rows = [dict(condition=c, method=m, repeat=r, values={"metric": r * (audit.METHODS.index(m) + 1)})
                for c, m, r in sorted(audit.expected_members("formal"))]
        summary = [dict(condition=c, method=m, metric="metric", **audit.interval([r["values"]["metric"] for r in rows if r["condition"] == c and r["method"] == m]))
                   for c in audit.CONDITIONS for m in audit.METHODS]
        pairs = [dict(condition=c, a_method=a, b_method=b, metric="metric",
                      **audit.interval([r * (audit.METHODS.index(a) - audit.METHODS.index(b)) for r in range(6)]))
                 for c in audit.CONDITIONS for a, b in audit.PAIRS]
        with tempfile.TemporaryDirectory(prefix="unit-fixture-", dir=Path(__file__).parent) as temporary:
            folder = Path(temporary)
            for name, records in (("summary_t95.csv", summary), ("paired_t95.csv", pairs)):
                with (folder / name).open("w", newline="", encoding="utf-8") as stream:
                    writer = csv.DictWriter(stream, fieldnames=list(records[0]))
                    writer.writeheader()
                    writer.writerows(records)
            audit.Auditor().summaries(folder, rows)
            # Preserve marginal samples, but break repetition pairing in one method.
            changed = copy.deepcopy(rows)
            selected = [r for r in changed if r["condition"] == audit.CONDITIONS[0] and r["method"] == "manual-full"]
            for r in selected:
                r["values"]["metric"] = (5 - r["repeat"]) * 3
            with self.assertRaisesRegex(ValueError, "paired"):
                audit.Auditor().summaries(folder, changed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
