# ReadSeal ISPA: copy-in performance wave 1

## Scope and verification

The frozen campaign completed on 2026-09-23 at 22:03:37 UTC, exit 0:
8 smoke cases and 168 formal runs. The separate CPU audit passed 14,540 checks.
All 148 frozen source/input bindings match. All runs have zero wrong or unknown
outputs. No inference was restarted, no condition was removed, and no GPU
partition, clock, power or MPS configuration was changed.

These are native A100 measurements, NOT embedded measurements or a Jetson/DRIVE
simulation. No board was available. Four recipients execute identical composed
workloads; they are NOT four heterogeneous autonomous-driving nodes.

Each condition has six whole-run repetitions, paired by repetition, with
randomized order within the frozen schedule. R=1, queue=8, outstanding K
unlimited, 10 s warmup and 30 s measurement. The primary endpoint is correct
100 ms timely source-cohort goodput measured from scheduled arrivals. A source
publication requests four recipient bundles. Wall-window receipts, latency,
information age and memory are separate endpoints.

## Complete primary results

Mean correct-timely recipient bundles/s, not source publications/s:

| Condition (source/s) | ReadSeal | Manual early | Full | Copy-in |
|---|---:|---:|---:|---:|
| Base 10 | 40.00 | 40.00 | 40.00 | 40.00 |
| Base 15 | 60.00 | 59.98 | 60.00 | 60.00 |
| Base 20 | 78.24 | 78.33 | 40.00 | 77.79 |
| Base 25 | 74.96 | 74.93 | 50.00 | 77.71 |
| Base 30 | 78.60 | 78.56 | 60.00 | 77.92 |
| Base 40 | 79.11 | 79.08 | 53.33 | 78.16 |
| Late read 30 | 60.00 | 60.00 | 60.00 | 76.39 |

Copy-in minus ReadSeal paired differences (pointwise 95% t intervals):

| Condition | Difference (bundles/s) | Interval |
|---|---:|---:|
| Base 10 | 0.00 | [0.00, 0.00] |
| Base 15 | 0.00 | [0.00, 0.00] |
| Base 20 | -0.44 | [-0.71, -0.18] |
| Base 25 | +2.75 | [+2.47, +3.03] |
| Base 30 | -0.68 | [-0.77, -0.59] |
| Base 40 | -0.94 | [-1.71, -0.18] |
| Late read 30 | +16.39 | [+16.06, +16.72] |

Copy-in is a competitive baseline, not uniformly inferior. In particular it
delivers more timely bundles at base 25/s and with late reads. ReadSeal does
not establish a universal throughput advantage over copying.

## Latency, freshness and memory trade-offs

At base 30/s, ReadSeal / Full / copy-in have mean per-run P99 receipt latencies
of 90.16 / 68.21 / 100.35 ms and mean information ages of
94.56 / 91.23 / 102.43 ms. Thus ReadSeal improves timely throughput over Full
but worsens age here by 3.32 ms (paired interval [2.84, 3.81]).
At base 20/s it improves age over Full by 13.76 ms
(ReadSeal minus Full interval [-14.29, -13.22]). Higher goodput is not a uniform
freshness or tail-latency improvement.

For late-read 30/s, copy-in / ReadSeal yield 76.39 / 60.00 timely bundles/s,
but P99 latency is 101.12 / 68.66 ms and mean age is 103.89 / 90.88 ms.
The copy-in age penalty is 13.01 ms [12.50, 13.52]; its P99 penalty is
32.46 ms [31.84, 33.09]. These are different performance objectives, not
contradictory measures of the same objective.

The observed device-memory peak is 5,334 MiB for copy-in and 5,078 MiB for all
three non-copy methods in every formal run, a difference of 256 MiB. A private
input is 66,355,200 bytes (63.28125 MiB). Logical live-copy mean memory ranges
from about 127 to 248 MiB across the conditions; this is NOT allocator-reserved
or total device memory. Sums of per-process allocation peaks are also NOT
simultaneous device peaks.

Mean per-run median D2D CUDA-event elapsed time is approximately 0.102-0.108 ms
in these pipeline runs. This is not the as-yet-unperformed isolated copy-cost
benchmark and does not establish cost on shared-DRAM embedded hardware.

## Evidence and statistical boundaries

The archive contains exact schedules, immutable manifests, per-run validation
records, all per-run/summary/paired CSVs, the independent audit and relevant
source. Raw tensors, worker traces and sink histories remain on the experiment
host. `raw_files_manifest.json` records their current byte counts and SHA-256
hashes; they are deliberately excluded from this compact archive.

The independent completion auditor recomputed raw-sink cohort goodput,
wall-window receipts, quantiles, freshness and logical copy memory. It checked
the full schedule, report/sink/proof lineage, six-run means and paired intervals.
Tensor/reference/identity/reuse/credit correctness is established by the
hash-bound per-run CPU validators. Protected byte-time and sampled device and
allocator memory use audited run reports, not an independent reconstruction
of GPU telemetry. The packaging inventory is an additional integrity snapshot,
not a second inference experiment.

Intervals use whole runs as n=6, df=5, and t(0.975,5)=2.570581835636305, without
multiplicity correction. They are pointwise descriptive uncertainty summaries,
not simultaneous guarantees, tests of equivalence or proof of zero variability.
The small sample limits assessment of distributional assumptions. Equal or
zero-width observed intervals at deterministic arrival rates do not prove
population equivalence. Per-run P99 values are averaged, not pooled into one
receipt-level quantile. No missing formal runs or post-hoc exclusions occurred.

The previous high-ring capacity tranche is separate: about 79.1 wall-window
bundles/s for all three tested methods, but zero 100 ms timely goodput there.
Do not combine its receipt capacity with this wave's timely throughput or turn
its descriptive plateau into an equivalence proof.

## Still pending

The broader supplementary program is not complete: slot/K design space,
isolated copy/component cost, controlled non-GPU gaps, genuinely heterogeneous
recipients, latest-only cancellation, jitter/bursts, live hazard ablations,
integration/fault/overhead work and physical embedded validation remain.
The separate CPU resource envelope is analytical sensitivity only, not
end-to-end device simulation. No manuscript acceptance claim is supported.
