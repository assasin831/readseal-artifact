"""Package completed evidence only; leave bulky raw tensors and traces in place."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

PREPARED = "8715d718cf48bb9aff440805f3c3d985fdcafde4c99aadac2d1461b8bb838905"
AUDITOR = "bec3a157625a050d6923e8cfa7caedaf3ac1073752eeb74d5a113175a1045a33"


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    root, output = args.root.resolve(), args.output.resolve()
    base = root / "results/ispa_copyin_performance_20260923_attempt1"
    audit = root / "results/ispa_copyin_performance_independent_audit_20260923_final1"
    assert output.is_relative_to(root) and not output.is_relative_to(base)
    assert sha(base / "prepared.json") == PREPARED
    frozen, state, proof = read(base / "prepared.json"), read(base / "controller/status.json"), read(audit / "validation.json")
    assert state["status"] == proof["status"] == "COMPLETE" and state["active"] is None
    assert (base / "controller/exit_code").read_text().strip() == "0"
    assert proof["validator_sha256"] == AUDITOR and proof["checks"] == 14540
    assert not proof["cuda_used"] and not proof["inference_executed"]
    assert all(sha(Path(p)) == h for p, h in frozen["bindings"].items())
    output.mkdir(parents=True, exist_ok=False)
    selected, raw, totals = {}, {}, {}

    def include(path):
        assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(root)
        assert path.stat().st_size < 4 * 2**20, str(path)
        selected[path.relative_to(root).as_posix()] = path

    for path in [base / "prepared.json", base / "PREPARED", *sorted((base / "controller").iterdir())]:
        if path.is_file():
            include(path)
    for phase, count in (("smoke", 8), ("formal", 168)):
        folder = base / phase
        campaign = read(folder / "report.json")
        assert campaign["status"] == "COMPLETE" and len(campaign["runs"]) == count
        totals[phase] = dict(runs=count, valid_receipts_all_periods=0, valid_receipts_in_window=0,
                             wrong_outputs=0, source_unknown=0, copy_intervals=0, reuse_checks=0)
        for item in campaign["runs"]:
            run = folder / item["name"]
            validation = folder / (item["name"] + "-validation") / "validation.json"
            assert (run / "COMPLETE").exists() and (validation.parent / "COMPLETE").exists()
            assert sha(run / "report.json") == item["report_sha256"]
            assert sha(run / "sink.json") == item["sink_sha256"]
            assert sha(validation) == item["validation_sha256"]
            report, sink, validation_data = read(run / "report.json"), read(run / "sink.json"), read(validation)
            assert report["status"] == validation_data["status"] == "COMPLETE"
            assert report["wrong_outputs"] == report["source_unknown"] == report["final_outstanding"] == 0
            assert validation_data["complete_native_and_child_outputs"]
            assert validation_data["gpu_uuid"] == frozen["gpu_uuid"]
            assert not validation_data["cuda_used"] and not validation_data["inference_executed"]
            totals[phase]["valid_receipts_all_periods"] += len(sink)
            totals[phase]["valid_receipts_in_window"] += sum(report["cohort_start_ns"] <= r["publish_ns"] < report["cohort_end_ns"] for r in sink)
            totals[phase]["copy_intervals"] += validation_data["copy_intervals_validated"]
            totals[phase]["reuse_checks"] += validation_data["actual_reuse_recipient_checks"]
            for path in sorted(run.iterdir()):
                if path.is_file():
                    raw[path.relative_to(root).as_posix()] = dict(bytes=path.stat().st_size, sha256=sha(path))
            include(validation)
            include(validation.parent / "COMPLETE")
        for path in [folder / "report.json", folder / "COMPLETE", *sorted((folder / "analysis").iterdir())]:
            if path.is_file():
                include(path)
    for path in sorted(audit.iterdir()):
        if path.is_file():
            include(path)
    cpu = root / "results/ispa_copyin_perf_cpu_validation_20260923_attempt1"
    for path in sorted(cpu.iterdir()):
        if path.is_file() and path.stat().st_size < 2**20:
            include(path)
    for value in frozen["bindings"]:
        path = Path(value)
        if path.is_relative_to(root) and path.suffix in (".py", ".md", ".cpp", ".h"):
            include(path)
    for source in (root / "prototype_ispa_copyin_perf_audit_20260923_final1", Path(__file__).resolve().parent):
        for path in sorted(source.iterdir()):
            if path.is_file():
                include(path)
    raw_path = output / "raw_files_manifest.json"
    raw_path.write_text(json.dumps(raw, indent=2) + "\n", encoding="utf-8")
    record = dict(status="COMPLETE", utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  counts=totals, prepared_sha256=PREPARED, independent_validation_sha256=sha(audit / "validation.json"),
                  frozen_bindings=len(frozen["bindings"]), raw_files=len(raw), raw_bytes=sum(v["bytes"] for v in raw.values()),
                  inference_executed=False, cuda_used=False, embedded_validation=False,
                  raw_tensors_and_traces_packaged=False,
                  scope="Compact summaries and hash-bound validation evidence; raw payloads preserved remotely.")
    validation_path = output / "packaging_validation.json"
    validation_path.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    include(raw_path)
    include(validation_path)
    assert sum(p.stat().st_size for p in selected.values()) < 25 * 2**20
    manifest = {name: dict(bytes=p.stat().st_size, sha256=sha(p)) for name, p in sorted(selected.items())}
    archive = output / "ispa_copyin_performance_results_20260923.zip"
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, path in sorted(selected.items()):
            z.write(path, name)
        z.writestr("MANIFEST.json", json.dumps(manifest, indent=2) + "\n")
    assert archive.stat().st_size < 5 * 2**20
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(manifest) + 1
        for name, expected in manifest.items():
            data = z.read(name)
            assert len(data) == expected["bytes"] and hashlib.sha256(data).hexdigest() == expected["sha256"]
    result = dict(status="COMPLETE", archive=str(archive), bytes=archive.stat().st_size,
                  sha256=sha(archive), entries=len(manifest) + 1,
                  independent_validation_sha256=record["independent_validation_sha256"], counts=totals)
    (output / "bundle_result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
