"""Verify a downloaded compact ZIP before extracting into a fresh evidence folder."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", required=True, type=Path)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    digest = hashlib.sha256(args.archive.read_bytes()).hexdigest()
    assert digest == args.sha256
    with zipfile.ZipFile(args.archive) as z:
        names = z.namelist()
        assert len(names) == len(set(names)) and z.testzip() is None
        manifest = json.loads(z.read("MANIFEST.json"))
        assert set(names) == set(manifest) | {"MANIFEST.json"}
        for name, expected in manifest.items():
            path = PurePosixPath(name)
            assert not path.is_absolute() and ".." not in path.parts and ":" not in name and "\\" not in name
            data = z.read(name)
            assert len(data) == expected["bytes"] and hashlib.sha256(data).hexdigest() == expected["sha256"]
        args.output.mkdir(parents=True, exist_ok=False)
        z.extractall(args.output / "evidence")
    result = dict(status="COMPLETE", archive_sha256=digest, bytes=args.archive.stat().st_size,
                  entries=len(names), file_hashes_verified=len(manifest), crc_verified=True,
                  inference_executed=False, embedded_validation=False)
    (args.output / "DOWNLOAD_VALIDATION.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
