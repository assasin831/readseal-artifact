"""Fresh, hash-frozen serial calibration using the unchanged complete executor."""
import argparse
import datetime
import fcntl
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time
import traceback

ROOT = Path("/www/readseal_ipdps_revision_v6")
HERE = Path(__file__).resolve().parent
OLD = ROOT/"prototype_borrowplan_v11_grouped_attempt1"
BASE = ROOT/"results/ispa_capacity_20260923_attempt1"
sys.path.insert(0, str(OLD))
import launch_grouped_formal as original
from protocol import PLAN, schedule


def save(path, data):
    path.write_text(json.dumps(data, indent=2)+"\n")


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def duplicate_scripts():
    names = (b"run_grouped", b"campaign.py", b"launch_grouped", b"supervisor.py")
    found = []
    for proc in Path("/proc").glob("[0-9]*"):
        try:
            args = (proc/"cmdline").read_bytes().split(b"\0")
            scripts = [Path(a.decode(errors="replace")).name for a in args
                       if a.endswith(b".py") and any(n in a for n in names)]
            if int(proc.name) == os.getppid() and b"dispatch" in args and scripts == [Path(__file__).name]:
                continue
            if scripts and int(proc.name) != os.getpid():
                found.append(dict(pid=int(proc.name), scripts=scripts))
        except OSError:
            pass
    return found


def preflight():
    with (ROOT/"borrowplan_gpu0.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        busy, dup = original.compute(), duplicate_scripts()
        assert not busy and not dup, (busy, dup)
        free = shutil.disk_usage(ROOT).free/2**30
        assert free >= PLAN["minimum_free_gib"], free
        return dict(status="IDLE", utc=utc(), free_gib=free, compute=busy, duplicates=dup)


def prepare():
    audit = preflight()
    prior = ROOT/"results/npc_v12_short_20260915_attempt1/prepared.json"
    frozen = json.loads(prior.read_text())
    proof = ROOT/"results/npc_v12_short_20260915_attempt1/controller/status.json"
    assert json.loads(proof.read_text())["status"] == "COMPLETE"
    assert all(original.sha(p) == h for p,h in frozen["bindings"].items())
    bindings = dict(frozen["bindings"])
    for path in [prior,proof,*sorted(HERE.glob("*.py")),HERE/"PROTOCOL.md"]:
        bindings[str(path)] = original.sha(path)
    BASE.mkdir(parents=True,exist_ok=False)
    save(BASE/"prepared.json",dict(status="PREPARED",utc=utc(),preflight=audit,
        plan=PLAN,schedules={k:schedule(k) for k in ("smoke","formal")},bindings=bindings,
        gpu_uuid=original.GPU,inference_executed=False))
    (BASE/"PREPARED").write_text("Frozen before new inference.\n")
    print(json.dumps(dict(status="PREPARED",sha256=original.sha(BASE/"prepared.json"),counts=PLAN["expected_runs"])))


def dispatch():
    preflight()
    frozen=json.loads((BASE/"prepared.json").read_text())
    assert frozen["plan"] == PLAN and all(original.sha(p)==h for p,h in frozen["bindings"].items())
    control=BASE/"controller"
    control.mkdir(exist_ok=False)
    with (control/"launcher.log").open("x") as log:
        p=subprocess.Popen([sys.executable,"-B","-u",str(Path(__file__)),"run"],cwd=ROOT,
            env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1"),stdin=subprocess.DEVNULL,
            stdout=log,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
    save(control/"dispatch.json",dict(pid=p.pid,utc=utc(),no_retry=True))
    print(json.dumps(dict(status="DISPATCHED",pid=p.pid,output=str(BASE))))


def telemetry(stop, samples, errors):
    while not stop.is_set():
        try:
            begin=time.monotonic_ns()
            raw=subprocess.check_output(["nvidia-smi", "--id="+original.GPU,
                "--query-gpu=uuid,utilization.gpu,utilization.memory,memory.used,power.draw,temperature.gpu",
                "--format=csv,noheader,nounits"],text=True,timeout=10)
            end=time.monotonic_ns()
            values=[v.strip() for v in raw.strip().split(",")]
            assert values[0] == original.GPU and len(values)==6, raw
            samples.append(dict(time_ns=(begin+end)//2,query_duration_ns=end-begin,
                gpu_uuid=values[0],gpu_util_pct=float(values[1]),memory_util_pct=float(values[2]),
                memory_mib=float(values[3]),power_w=float(values[4]),temperature_c=float(values[5])))
        except BaseException:
            errors.append(traceback.format_exc())
        stop.wait(2)


def run():
    control=BASE/"controller"
    frozen=json.loads((BASE/"prepared.json").read_text())
    status=dict(status="RUNNING",utc_start=utc(),active=None,completed=[],phases=[])
    rc=2
    phase_report=None
    folder=None
    try:
        with (ROOT/"borrowplan_gpu0.lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
            assert not original.compute() and not duplicate_scripts()
            for phase in ("smoke","formal"):
                folder=BASE/phase
                folder.mkdir(exist_ok=False)
                phase_report=dict(status="RUNNING",phase=phase,runs=[],schedule=schedule(phase),
                    prepared_sha256=original.sha(BASE/"prepared.json"),plan=PLAN)
                assert phase_report["schedule"]==frozen["schedules"][phase]
                env=dict(os.environ,PYTHONPATH=":".join(map(str,original.DEPS)),
                    CUDA_VISIBLE_DEVICES=original.GPU,PYTHONDONTWRITEBYTECODE="1",
                    OMP_NUM_THREADS="1",MKL_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1",
                    CUDA_CACHE_PATH=str(folder/"cuda-cache"))
                for item in phase_report["schedule"]:
                    assert all(original.sha(p)==h for p,h in frozen["bindings"].items()), "frozen input changed"
                    if original.compute():
                        status.update(status="PAUSED_BEFORE_INFERENCE",next_unstarted=item["name"])
                        raise RuntimeError("foreign compute before inference; no automatic resume")
                    assert shutil.disk_usage(ROOT).free/2**30 >= PLAN["minimum_free_gib"], "disk reserve"
                    status["active"]=dict(phase=phase,run=item["name"])
                    save(control/"status.json",status)
                    save(folder/"report.json",phase_report)
                    samples, errors, stop=[],[],threading.Event()
                    thread=threading.Thread(target=telemetry,args=(stop,samples,errors),daemon=True)
                    started=time.monotonic()
                    thread.start()
                    try:
                        with (folder/(item["name"]+".log")).open("x") as log:
                            code=subprocess.run([sys.executable,"-B",str(OLD/"run_grouped_admission.py"),
                                "--output",str(folder/item["name"]),"--cell",json.dumps(item["cell"]),
                                "--method",item["method"]],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
                    finally:
                        stop.set()
                        thread.join(15)
                        save(folder/(item["name"]+"-telemetry.json"),dict(samples=samples,errors=errors,
                            gpu_uuid=original.GPU,interval_seconds=2,clock="monotonic_ns"))
                    assert code==0, item["name"]+" inference failed; no retry"
                    assert not errors, "telemetry failed; preserve run without retry"
                    validation=folder/(item["name"]+"-validation")
                    with (folder/(item["name"]+"-validation.log")).open("x") as log:
                        code=subprocess.run([sys.executable,"-B",str(OLD/"validate_grouped_pipeline.py"),
                            "--run",str(folder/item["name"]),"--output",str(validation),"--kind","cell"],
                            cwd=ROOT,env=dict(env,CUDA_VISIBLE_DEVICES=""),stdout=log,stderr=subprocess.STDOUT).returncode
                    assert code==0, item["name"]+" validator failed; preserve inference"
                    entry=dict(item,seconds=time.monotonic()-started,
                        report_sha256=original.sha(folder/item["name"]/"report.json"),
                        validation_sha256=original.sha(validation/"validation.json"),
                        sink_sha256=original.sha(folder/item["name"]/"sink.json"),
                        telemetry_sha256=original.sha(folder/(item["name"]+"-telemetry.json")))
                    phase_report["runs"].append(entry)
                    status["completed"].append(dict(phase=phase,name=item["name"],seconds=entry["seconds"]))
                    status["active"]=None
                    save(folder/"report.json",phase_report)
                    save(control/"status.json",status)
                    print(json.dumps(dict(status="RUN_COMPLETE",phase=phase,done=len(phase_report["runs"]),
                        total=len(phase_report["schedule"]),name=item["name"],seconds=entry["seconds"])),flush=True)
                phase_report["status"]="COMPLETE"
                save(folder/"report.json",phase_report)
                (folder/"COMPLETE").write_text("COMPLETE\n")
                with (folder/"aggregate.log").open("x") as log:
                    code=subprocess.run([sys.executable,"-B",str(HERE/"analyze_capacity.py"),
                        "--root",str(folder),"--output",str(folder/"analysis")],cwd=ROOT,
                        env=dict(env,CUDA_VISIBLE_DEVICES=""),stdout=log,stderr=subprocess.STDOUT).returncode
                assert code==0, phase+" independent summary failed; no next phase"
                status["phases"].append(dict(phase=phase,validation_sha256=original.sha(folder/"analysis/validation.json")))
            status["status"],rc="COMPLETE",0
    except BaseException:
        status.setdefault("reason",traceback.format_exc())
        if status["status"]=="RUNNING":
            status["status"]="FAILED"
        if phase_report is not None and folder is not None:
            phase_report.update(status=status["status"],failure=status["reason"])
            save(folder/"report.json",phase_report)
            (folder/status["status"]).write_text(status["status"]+"\n")
        traceback.print_exc()
    status["utc_end"]=utc()
    save(control/"status.json",status)
    (control/status["status"]).write_text(status["status"]+"\n")
    (control/"exit_code").write_text(str(rc)+"\n")
    return rc


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("action",choices=("preflight","prepare","dispatch","run"))
    a=p.parse_args()
    if a.action=="run":
        raise SystemExit(run())
    result=globals()[a.action]()
    if result is not None:
        print(json.dumps(result))
