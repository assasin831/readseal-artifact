"""Pure CPU definitions, intentionally distinct from the frozen runtime metrics."""
import math
import statistics


T95_DF5 = 2.570581835636305


def quantile(values, p):
    values = sorted(values)
    if not values:
        return None
    pos = (len(values) - 1) * p
    lo, hi = math.floor(pos), math.ceil(pos)
    return values[lo] + (pos - lo) * (values[hi] - values[lo])


def interval6(values):
    assert len(values) == 6 and all(math.isfinite(v) for v in values)
    mean = statistics.mean(values)
    sd = statistics.stdev(values)
    delta = T95_DF5 * sd / math.sqrt(6)
    return dict(n=6, mean=mean, sd=sd, ci95_low=mean-delta, ci95_high=mean+delta,
                interval="pointwise t, df=5")


def age_integral(events, start, end):
    """Events are (receipt_ns, generation_ns); no receipt means unknown age."""
    assert end > start
    state = None
    current = start
    area = 0.0
    covered = 0
    stale = 0
    initial = None
    for receipt, generation in sorted(events):
        assert generation <= receipt
        if receipt <= start:
            state = generation if state is None else max(state, generation)
            initial = state
            continue
        if receipt >= end:
            break
        if state is not None:
            delta = receipt - current
            area += (current-state)*delta + delta*delta/2
            covered += delta
        if state is not None and generation <= state:
            stale += 1
        state = generation if state is None else max(state, generation)
        current = receipt
    if state is not None:
        delta = end-current
        area += (current-state)*delta + delta*delta/2
        covered += delta
    complete = covered == end-start
    return dict(mean_age_ms=area/(end-start)/1e6 if complete else None,
                observed_age_ms=area/covered/1e6 if covered else None,
                coverage=covered/(end-start), initial_generation_ns=initial,
                stale_receipts_during_window=stale)


def deadtime_prediction(rate_hz, hold_seconds, poisson=False):
    assert rate_hz > 0 and hold_seconds > 0
    return rate_hz/(1+rate_hz*hold_seconds) if poisson else rate_hz/math.ceil(rate_hz*hold_seconds)
