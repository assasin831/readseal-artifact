# ISPA follow-up tranche 1: frozen before new inference

Date: 2026-09-23. This tranche addresses reviewer Step 0, not the full E1--E8
program. Old sources, measurements, failures and artifact packages are immutable.
The author has no Jetson/DRIVE board available. Embedded results remain missing.

## A. CPU reanalysis, specified before computation

Use all 108 E1 and 36 E2 formal runs from the restored V12 archive. Exclude the
six smoke runs from estimates; do not pool E1 and E2 or historical windows.
Check report/sink hashes against the historical campaign inventory and saved
output/reference/source flags. Do not run or retry model inference.

- Freshness: time-average age of the freshest valid result at each recipient
  sink over the entire original 12 s measured wall-clock interval. Generation
  time is the original scheduled source arrival (primary) and producer commit
  completion (secondary). Use warmup receipts for initial state; take the maximum
  generation timestamp so out-of-order old results do not reset freshness.
  Integrate the piecewise-linear age exactly. A missing initial result is
  left-censored: report coverage and do not replace the unknown age with zero.
  Give all four sink values and their equal-weight run mean.
- Latency: P50/P99 of valid receipts for measured scheduled-arrival cohorts,
  including their complete drain; linear interpolation. These are conditional
  receipt latencies, not latencies imputed to rejected requests.
- Deadline sensitivity: count the same verified receipts within 50/75/100/150 ms
  of scheduled arrival, divide by the original 12 s. This changes analysis only,
  not execution, arrivals, admission, queueing or cancellation.
- Hold decomposition at 10 and 15 source publications/s: select the last
  returning recipient of each accepted publication. Report commit-to-receive,
  receive-to-admission, admission-to-observed-read-completion, and observed-read-
  completion-to-return. The third term combines submission, GPU waiting/work and
  host event observation. GPU read time and observation delay were not logged
  separately. Per-recipient queue wait has bounds, not exact enqueue timestamps.
- Loss-model diagnostics: use only low-load E1 10 Hz Full runs to calibrate a
  fixed dead time; make predictions for all E1 rates without fitting those
  outcomes. Show source-acceptance and four-times recipient rates separately.
  h is write-start to final return (a lower bound on reservation occupancy),
  with commit-to-return as a secondary calibration. Periodic prediction is
  lambda/ceil(lambda*h); Poisson prediction is lambda/(1+lambda*h). The latter
  assumes Poisson arrivals, not Gaussian jitter. These are ideal single-slot
  dead-time models, not capacity estimates or exact variable-duration theorems.
- Independent unit: whole run (n=6 per method/condition). Report t-based 95%
  intervals (df=5), with paired t intervals for paired method differences.
  Intervals are pointwise, exploratory post-hoc summaries, not simultaneous or
  equivalence claims. Preserve per-run metrics. No outcome-driven exclusions.

## B. GPU sustained-delivery calibration, new inference

Purpose: test whether the complete existing pipeline exhibits a stable
deadline-unfiltered receipt-throughput plateau when more slots are supplied.
Do not describe a finite rate sweep as a universally established maximum.

- Original A100 GPU0 UUID, pinned models/weights/inputs and all source hashes.
- Unmodified V11 complete A/B/C runner and independent output validator.
- Methods: auto-batched, manual-early, manual-full. The four recipients are the
  existing four complete compositions, NOT heterogeneous AV nodes.
- Formal: R={4,8}, rates={30,40,60} source publications/s, per-recipient queue=8,
  global cap disabled; 10 s warmup and 30 s measured arrivals, complete drain.
  Six whole-run paired repetitions: 108 formal runs. Fixed randomized ordering.
- Smoke: R=4 and R=8 at 40/s, all three methods, 1 s warmup/3 s measurement:
  six runs, correctness/lineage gates only, never pooled into formal estimates.
- The existing runner's 100 ms deadline remains an annotation. Its source and
  queue admission do not drop based on this deadline. The PRIMARY capacity
  metric counts all valid receipts whose actual sink time lies inside the
  measured wall-clock interval, regardless of their own deadline or generation
  cohort. Do not divide drained cohort completions by 30 s as service capacity.
- Record six 5 s wall-clock throughput bins, delivered cohort rate and backlog
  change. Arrival-cohort deadline goodput remains a secondary metric. Samples
  from nvidia-smi GPU0 utilization/memory are diagnostic, not an exact kernel
  busy-time trace. Preserve time samples, maxima and all distributions.
- Report every condition. A plateau designation additionally requires all
  high-rate adjacent means and R=4/R=8 means for that policy within 5%, and the
  mean of the final two temporal bins within 5% of the first two. This is a
  descriptive stationarity gate, not an equivalence test. If any policy fails,
  do not insert a universal capacity line into the paper. Do not extend the
  sweep automatically to seek a favorable plateau.
- n=6 run-level t intervals and paired t intervals; no request resampling.

## Safety and resource boundaries

Before preparation and each run: both GPUs have no foreign compute, the
existing GPU0 experiment lock is exclusive, source hashes unchanged, enough
disk remains. Run one process family at a time on GPU0; keep GPU1 MIG untouched.
Keep at least 20 GiB free before each run. The existing monitor detects foreign
compute within runs. Preserve and stop on failure/contamination; never retry
failed inference or silently continue an interrupted matrix. Only this run's
own child processes may be cleaned up on failure.

## Subsequent experiments: not claimed by this tranche

1. Capacity-informed K sweep. K=2 cannot admit an atomic group of four in the
   current policy. Record this as structural infeasibility, not a measured GPU
   failure. Little's law is an average identity, not a hard-deadline guarantee;
   any K formula will be frozen as a tested heuristic, not asserted as a bound.
2. Copy-in and controlled non-GPU gaps require new correctness gates before
   performance. Do not substitute sleep for a measured realistic-node delay.
3. Live unsafe ablations require process-isolated runs and a validator that
   records wrong outputs rather than aborting before counting them. Never
   attribute them to correct manual or record_stream implementations.
4. Jitter/bursts/sensor replay require a frozen arrival trace with hashes and
   explicit scheduling, not just archived RGB-D metadata.
5. Real ROS 2 GPU control plane, realistic heterogeneous AV nodes, failure
   fencing and optimized admission need separate designs/audits. No invented
   real-node durations, hardware results or claims of completed E1--E8.
