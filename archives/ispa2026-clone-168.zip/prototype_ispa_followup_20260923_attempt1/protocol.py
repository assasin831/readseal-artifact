"""Fixed configurations for the first ISPA supplemental experiment tranche."""
import random

METHODS = ("auto-batched", "manual-early", "manual-full")
COMMON = dict(model="transfusion", late=False, consumers=4, queue=8,
              outstanding_cap=0, deadline_ms=100, warmup_seconds=10,
              measure_seconds=30)
CONDITIONS = [dict(id=f"r{r}-hz{hz}", ring=r, rate_hz=hz)
              for r in (4, 8) for hz in (30, 40, 60)]
PLAN = dict(schema="ispa-capacity-tranche1-v1", repetitions=6, methods=list(METHODS),
            common=COMMON, conditions=CONDITIONS, order_seeds=dict(smoke=26092301, formal=26092302),
            expected_runs=dict(smoke=6, formal=108), confidence="pointwise t-based 95%, paired whole runs",
            primary="correct receipt times inside measurement wall-clock interval, no deadline filter",
            temporal_bin_seconds=5, descriptive_plateau_tolerance=.05,
            both_gpus_quiet=True, no_inference_retry=True, minimum_free_gib=20,
            immutable_executor=True, gpu0_only=True, no_outcome_optimization=True)


def schedule(phase):
    rng = random.Random(PLAN["order_seeds"][phase])
    conditions = [c for c in CONDITIONS if c["rate_hz"] == 40] if phase == "smoke" else CONDITIONS
    rows = []
    for repeat in range(1 if phase == "smoke" else 6):
        order = list(conditions)
        rng.shuffle(order)
        for condition in order:
            methods = list(METHODS)
            rng.shuffle(methods)
            for method in methods:
                cell = dict(COMMON, **condition)
                if phase == "smoke":
                    cell.update(warmup_seconds=1, measure_seconds=3)
                rows.append(dict(name=f"{phase}-r{repeat:02d}-{condition['id']}-{method}",
                                 repeat=repeat, condition=condition["id"], method=method, cell=cell))
    assert len(rows) == PLAN["expected_runs"][phase]
    assert len({r["name"] for r in rows}) == len(rows)
    return rows
