"""Deadline-unfiltered wall-clock receipts, no drained-cohort capacity shortcut."""
import argparse
import csv
import hashlib
import json
import statistics
from pathlib import Path
from analysis_metrics import interval6
from protocol import PLAN


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def receipts_in_window(rows, start, end):
    return [r for r in rows if start<=r["publish_ns"]<end]


def csv_out(path, rows):
    if rows:
        with path.open("x",newline="") as stream:
            writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)


def main(root, out):
    out.mkdir(exist_ok=False)
    campaign=read(root/"report.json")
    phase=campaign["phase"]
    assert campaign["status"]=="COMPLETE" and len(campaign["runs"])==PLAN["expected_runs"][phase]
    rows=[]
    for entry in campaign["runs"]:
        folder=root/entry["name"]
        for name,key in [("report.json","report_sha256"),("sink.json","sink_sha256")]:
            assert sha(folder/name)==entry[key]
        assert sha(root/(entry["name"]+"-validation")/"validation.json")==entry["validation_sha256"]
        assert sha(root/(entry["name"]+"-telemetry.json"))==entry["telemetry_sha256"]
        report,sink=read(folder/"report.json"),read(folder/"sink.json")
        assert report["status"]=="COMPLETE" and report["wrong_outputs"]==report["source_unknown"]==0
        assert read(root/(entry["name"]+"-validation")/"validation.json")["status"]=="COMPLETE"
        assert all(all(s[k] for k in ("output_equal","provenance_verified","finite","published")) for s in sink)
        start,end=report["cohort_start_ns"],report["cohort_end_ns"]
        seconds=(end-start)/1e9
        inside=receipts_in_window(sink,start,end)
        cohort=[s for s in sink if s["cohort"]]
        bins=[sum(start+i*5_000_000_000<=s["publish_ns"]<min(end,start+(i+1)*5_000_000_000) for s in sink)/min(5,seconds-i*5)
              for i in range(int((seconds+4.999999)//5))]
        admitted=[s for s in sink if s["admission_ns"]<end and s["publish_ns"]>=end]
        telemetry=read(root/(entry["name"]+"-telemetry.json"))
        assert not telemetry["errors"]
        measured=[s for s in telemetry["samples"] if start<=s["time_ns"]<end]
        assert measured, "missing measurement-window telemetry"
        row=dict(run=entry["name"],repeat=entry["repeat"],condition=entry["condition"],method=entry["method"],
            ring=report["cell"]["ring"],source_rate_hz=report["cell"]["rate_hz"],
            receipt_capacity_hz=len(inside)/seconds,cohort_delivered_hz=len(cohort)/seconds,
            cohort_timely_100ms_hz=report["goodput_hz"],receipts_in_window=len(inside),
            cohort_receipts=len(cohort),admitted_unreceived_at_window_end=len(admitted),
            gpu_util_pct_mean=statistics.mean(s["gpu_util_pct"] for s in measured),
            device_peak_mib=report["device_peak_bytes"]/2**20,
            protected_mib=report["protected_byte_seconds"]/seconds/2**20,
            first_two_bin_hz=statistics.mean(bins[:2]),last_two_bin_hz=statistics.mean(bins[-2:]),
            bins_hz=json.dumps(bins),telemetry_samples=len(measured))
        rows.append(row)
    summaries,plateaus,paired=[],[],[]
    if phase=="formal":
        for condition in sorted({r["condition"] for r in rows}):
            for method in PLAN["methods"]:
                selected=[r for r in rows if r["condition"]==condition and r["method"]==method]
                assert len(selected)==6
                for metric in ["receipt_capacity_hz","cohort_delivered_hz","cohort_timely_100ms_hz",
                               "gpu_util_pct_mean","device_peak_mib","protected_mib","first_two_bin_hz","last_two_bin_hz"]:
                    summaries.append(dict(condition=condition,method=method,metric=metric,
                                          **interval6([r[metric] for r in selected])))
            for method in ("manual-early","manual-full"):
                a=sorted([r for r in rows if r["condition"]==condition and r["method"]=="auto-batched"],key=lambda r:r["repeat"])
                b=sorted([r for r in rows if r["condition"]==condition and r["method"]==method],key=lambda r:r["repeat"])
                assert [r["repeat"] for r in a]==[r["repeat"] for r in b]==list(range(6))
                for metric in ("receipt_capacity_hz","cohort_timely_100ms_hz","gpu_util_pct_mean","protected_mib"):
                    paired.append(dict(condition=condition,a_method="auto-batched",b_method=method,metric=metric,
                        **interval6([x[metric]-y[metric] for x,y in zip(a,b)])))
        for method in PLAN["methods"]:
            means={}
            for ring in (4,8):
                for hz in (30,40,60):
                    rr=[r for r in rows if r["method"]==method and r["ring"]==ring and r["source_rate_hz"]==hz]
                    means[ring,hz]={k:statistics.mean(r[k] for r in rr) for k in ["receipt_capacity_hz","first_two_bin_hz","last_two_bin_hz"]}
            comparisons=[]
            for ring in (4,8):
                for x,y in [(30,40),(40,60)]:
                    a,b=means[ring,x]["receipt_capacity_hz"],means[ring,y]["receipt_capacity_hz"]
                    comparisons.append(abs(a-b)/max(a,b))
                for hz in (30,40,60):
                    a,b=means[ring,hz]["first_two_bin_hz"],means[ring,hz]["last_two_bin_hz"]
                    comparisons.append(abs(a-b)/max(a,b))
            for hz in (30,40,60):
                a,b=means[4,hz]["receipt_capacity_hz"],means[8,hz]["receipt_capacity_hz"]
                comparisons.append(abs(a-b)/max(a,b))
            plateaus.append(dict(method=method,descriptive_plateau=all(v<=.05 for v in comparisons),
                maximum_relative_deviation=max(comparisons),not_an_equivalence_test=True,
                individual_comparisons=comparisons))
    csv_out(out/"per_run.csv",rows)
    csv_out(out/"summary_t95.csv",summaries)
    csv_out(out/"paired_t95.csv",paired)
    result=dict(status="COMPLETE",phase=phase,runs=len(rows),plateau_diagnostics=plateaus,
        campaign_sha256=sha(root/"report.json"),script_sha256=sha(Path(__file__)),no_new_inference=True,
        capacity_scope="Valid receipt timestamps inside measured wall clock; no deadline filter or drained-cohort inflation",
        inference_validator="Unmodified per-run complete-pipeline CPU validator passed before aggregation",
        csv_sha256={p.name:sha(p) for p in out.glob("*.csv")})
    (out/"validation.json").write_text(json.dumps(result,indent=2)+"\n")
    (out/"COMPLETE").write_text("COMPLETE\n")
    print(json.dumps(result,indent=2))


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--root",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True)
    a=p.parse_args()
    main(a.root,a.output)
