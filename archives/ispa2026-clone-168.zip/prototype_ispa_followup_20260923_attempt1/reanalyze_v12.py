"""Hash-bound, post-hoc Step 0 analysis of all 144 saved formal runs."""
import argparse
import csv
import hashlib
import json
import statistics
from pathlib import Path

from analysis_metrics import age_integral, deadtime_prediction, interval6, quantile


HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def csv_out(path, rows):
    with path.open("x", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def analyze(root, output):
    output.mkdir(parents=True, exist_ok=False)
    frozen = {p.name: sha(p) for p in HERE.iterdir() if p.is_file() and p.suffix in (".py", ".md")}
    save(output/"FROZEN_ANALYSIS.json", dict(kind="post-hoc saved-data reanalysis", sources=frozen,
         plan_sha256=sha(HERE/"PROTOCOL.md"), no_new_inference=True))
    run_rows, sink_rows, hold_rows, sources = [], [], [], []
    checked = 0
    for phase, count in [("e1", 108), ("e2", 36)]:
        campaign = load(root/phase/"report.json")
        original = load(root/phase/"audit/analysis.json")
        assert campaign["status"] == original["status"] == "COMPLETE"
        assert len(campaign["runs"]) == count
        assert original["campaign_report_sha256"] == sha(root/phase/"report.json")
        for item in campaign["runs"]:
            folder = root/phase/item["name"]
            for name in ["report.json", "sink.json"]:
                path = folder/name
                key = path.relative_to(root/phase).as_posix()
                assert sha(path) == original["raw_inventory"][key]
                sources.append(dict(phase=phase, run=item["name"], file=name, sha256=sha(path)))
            report, receipts = load(folder/"report.json"), load(folder/"sink.json")
            assert report["status"] == "COMPLETE" and (folder/"COMPLETE").is_file()
            assert report["wrong_outputs"] == report["source_unknown"] == 0
            assert sha(folder/"report.json") == item["report_sha256"]
            cell = report["cell"]
            pp = {p["tick"]: p for p in report["producer"]}
            assert len(pp) == len(report["producer"])
            assert len({(s["tick"], s["consumer"]) for s in receipts}) == len(receipts)
            for s in receipts:
                assert all(s[k] for k in ("output_equal", "provenance_verified", "finite", "published"))
                assert s["actual_hashes"] == report["references"][s["source_id"]]["hashes"]
                assert s["matching_reference_sources"] == [s["source_id"]]
                assert s["sequence"] == s["observed_sequence"] == pp[s["tick"]]["sequence"]
                assert s["source_id"] == s["observed_source"] == pp[s["tick"]]["source_id"]
                assert s["scheduled_ns"] == pp[s["tick"]]["scheduled_ns"]
                assert s["publish_ns"] >= s["scheduled_ns"]
                checked += 1
            start, end = report["cohort_start_ns"], report["cohort_end_ns"]
            duration = (end-start)/1e9
            assert duration == 12
            common = dict(experiment=phase, run=item["name"], repeat=item["repeat"],
                          condition=item["condition"]["id"], method=item["method"],
                          rate_hz=cell["rate_hz"], ring=cell["ring"], cap=cell["outstanding_cap"], late=cell["late"])
            mean_ages, commit_ages = [], []
            for consumer in range(cell["consumers"]):
                ss = [s for s in receipts if s["consumer"] == consumer]
                ao = age_integral([(s["publish_ns"], s["scheduled_ns"]) for s in ss], start, end)
                ac = age_integral([(s["publish_ns"], pp[s["tick"]]["commit_end_ns"]) for s in ss], start, end)
                sink_rows.append(dict(common, consumer=consumer, age_ms=ao["mean_age_ms"],
                    commit_age_ms=ac["mean_age_ms"], coverage=ao["coverage"],
                    stale_receipts=ao["stale_receipts_during_window"],
                    initial_generation_relative_ms=(ao["initial_generation_ns"]-start)/1e6
                    if ao["initial_generation_ns"] is not None else None))
                mean_ages.append(ao["mean_age_ms"])
                commit_ages.append(ac["mean_age_ms"])
            selected = [s for s in receipts if s["cohort"]]
            latencies = [(s["publish_ns"]-s["scheduled_ns"])/1e6 for s in selected]
            rr = dict(common, receipts=len(selected), offers=report["arrivals"],
                      freshness_ms=statistics.mean(mean_ages) if all(v is not None for v in mean_ages) else None,
                      commit_freshness_ms=statistics.mean(commit_ages) if all(v is not None for v in commit_ages) else None,
                      latency_p50_ms=quantile(latencies, .5), latency_p99_ms=quantile(latencies, .99),
                      delivered_cohort_hz=len(selected)/duration,
                      receipt_wallclock_hz=sum(start <= s["publish_ns"] < end for s in receipts)/duration)
            for deadline in (50, 75, 100, 150):
                rr[f"goodput_{deadline}ms_hz"] = sum(v <= deadline for v in latencies)/duration
            assert abs(rr["goodput_100ms_hz"] - report["goodput_hz"]) < 1e-10
            run_rows.append(rr)
            if phase == "e1" and cell["rate_hz"] in (10, 15):
                by_tick = {}
                for s in selected:
                    by_tick.setdefault(s["tick"], []).append(s)
                for tick, ss in by_tick.items():
                    # This recipient, not the mean recipient, determines slot return.
                    s = max(ss, key=lambda v: v["release_end_ns"])
                    p = pp[tick]
                    assert all(p["enqueued"]), "hold path needs cancellation-aware extension"
                    terms = [(s["received_ns"]-p["commit_end_ns"])/1e6,
                             (s["admission_ns"]-s["received_ns"])/1e6,
                             (s["read_done_ns"]-s["admission_ns"])/1e6,
                             (s["release_end_ns"]-s["read_done_ns"])/1e6]
                    assert min(terms) >= 0
                    hold = (s["release_end_ns"]-p["commit_end_ns"])/1e6
                    assert abs(sum(terms)-hold) < 1e-8
                    hold_rows.append(dict(common, tick=tick, last_return_consumer=s["consumer"],
                        commit_to_receive_ms=terms[0], receive_to_admission_ms=terms[1],
                        admission_to_observed_read_completion_ms=terms[2], read_done_to_return_ms=terms[3],
                        hold_ms=hold, write_to_return_ms=(s["release_end_ns"]-p["write_start_ns"])/1e6,
                        queue_wait_lower_ms=max(0, s["received_ns"]-p["producer_done_ns"])/1e6,
                        queue_wait_upper_ms=terms[0]))

    metrics = [k for k in run_rows[0] if k not in {"experiment", "run", "repeat", "condition", "method", "rate_hz", "ring", "cap", "late"}]
    summaries, paired = [], []
    conditions = sorted({(r["experiment"], r["condition"]) for r in run_rows})
    for phase, condition in conditions:
        methods = {}
        for method in ("auto-batched", "manual-early", "manual-full"):
            rows = sorted([r for r in run_rows if (r["experiment"], r["condition"], r["method"]) == (phase, condition, method)], key=lambda r:r["repeat"])
            assert [r["repeat"] for r in rows] == list(range(6))
            methods[method] = rows
            for metric in metrics:
                values = [r[metric] for r in rows]
                if all(v is not None for v in values):
                    summaries.append(dict(experiment=phase, condition=condition, method=method,
                                          metric=metric, **interval6(values)))
        for a, b in [("auto-batched", "manual-full"), ("auto-batched", "manual-early")]:
            for metric in metrics:
                if all(r[metric] is not None for r in methods[a]+methods[b]):
                    diffs = [x[metric]-y[metric] for x,y in zip(methods[a], methods[b])]
                    paired.append(dict(experiment=phase, condition=condition, a_method=a, b_method=b,
                                       metric=metric, **interval6(diffs)))
    hold_means = []
    for run in sorted({r["run"] for r in hold_rows}):
        rows = [r for r in hold_rows if r["run"] == run]
        common = {k:rows[0][k] for k in ("experiment", "run", "repeat", "condition", "method", "rate_hz")}
        hold_means.append(dict(common, accepted_publications=len(rows), **{
            k:statistics.mean(r[k] for r in rows) for k in rows[0] if k.endswith("_ms")}))
    calibration = [r for r in hold_means if r["method"] == "manual-full" and r["rate_hz"] == 10]
    assert len(calibration) == 6
    h = statistics.mean(r["write_to_return_ms"] for r in calibration)/1000
    hcommit = statistics.mean(r["hold_ms"] for r in calibration)/1000
    predictions = []
    for rate in (10, 15, 20, 25, 30, 40):
        actual = [r for r in run_rows if r["experiment"] == "e1" and r["rate_hz"] == rate and r["method"] == "manual-full"]
        predictions.append(dict(source_rate_hz=rate, calibration_write_to_return_h_ms=h*1000,
            calibration_commit_to_return_h_ms=hcommit*1000,
            periodic_source_prediction=deadtime_prediction(rate,h),
            periodic_bundle_prediction=4*deadtime_prediction(rate,h),
            poisson_source_prediction=deadtime_prediction(rate,h,True),
            poisson_bundle_prediction=4*deadtime_prediction(rate,h,True),
            measured_delivered_bundles_hz=statistics.mean(r["delivered_cohort_hz"] for r in actual),
            measured_100ms_bundles_hz=statistics.mean(r["goodput_100ms_hz"] for r in actual)))
    for name, rows in [("per_run.csv",run_rows),("per_sink_age.csv",sink_rows),("summary_t95.csv",summaries),
                       ("paired_t95.csv",paired),("hold_paths_10_15hz.csv",hold_rows),
                       ("hold_per_run.csv",hold_means),("deadtime_predictions.csv",predictions)]:
        csv_out(output/name, rows)
    report = dict(status="COMPLETE", formal_runs=len(run_rows), per_sink_records=len(sink_rows),
                  receipt_records_checked=checked, source_inventory=sources, no_new_inference=True,
                  input_root=str(root), frozen_analysis_sha256=sha(output/"FROZEN_ANALYSIS.json"),
                  csv_sha256={p.name:sha(p) for p in output.glob("*.csv")},
                  tensor_scope="saved output hashes and independent source/reference flags checked; old tensor containers not re-executed",
                  missing_gpu_read_and_host_observation_split=True,
                  age_left_censored_sinks=sum(r["coverage"] != 1 for r in sink_rows),
                  t_critical_df5=2.570581835636305)
    save(output/"validation.json",report)
    (output/"COMPLETE").write_text("CPU reanalysis only; old inference unchanged.\n")
    print(json.dumps({k:v for k,v in report.items() if k not in ("source_inventory","csv_sha256")},indent=2))


if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--root",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True)
    a=p.parse_args()
    analyze(a.root,a.output)
