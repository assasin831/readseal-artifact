import math
import unittest
from analysis_metrics import age_integral, deadtime_prediction, interval6, quantile
from protocol import schedule
from analyze_capacity import receipts_in_window


class MetricsTests(unittest.TestCase):
    def test_age_constant_generation(self):
        x = age_integral([(0, 0)], 0, 10_000_000)
        self.assertEqual(x["mean_age_ms"], 5)
        self.assertEqual(x["coverage"], 1)

    def test_fresh_update(self):
        x = age_integral([(0, 0), (5_000_000, 4_000_000)], 0, 10_000_000)
        self.assertEqual(x["mean_age_ms"], 3)

    def test_old_result_does_not_reset_age(self):
        a = age_integral([(0, 0), (5_000_000, 4_000_000)], 0, 10_000_000)
        b = age_integral([(0, 0), (5_000_000, 4_000_000), (6_000_000, 1_000_000)], 0, 10_000_000)
        self.assertEqual(a["mean_age_ms"], b["mean_age_ms"])
        self.assertEqual(b["stale_receipts_during_window"], 1)

    def test_missing_initial_is_not_zero(self):
        x = age_integral([(5_000_000, 4_000_000)], 0, 10_000_000)
        self.assertIsNone(x["mean_age_ms"])
        self.assertEqual(x["coverage"], .5)
        self.assertEqual(x["observed_age_ms"], 3.5)

    def test_boundaries(self):
        x = age_integral([(-10_000_000, -11_000_000), (0, -1_000_000), (10_000_000, 9_000_000)], 0, 10_000_000)
        self.assertEqual(x["mean_age_ms"], 6)

    def test_quantiles_and_t_interval(self):
        self.assertEqual(quantile([0, 10], .99), 9.9)
        self.assertEqual(interval6([1]*6)["ci95_low"], 1)
        x = interval6([1, 2, 3, 4, 5, 6])
        self.assertAlmostEqual(x["mean"], 3.5)
        self.assertLess(x["ci95_low"], 3.5)
        self.assertGreater(x["ci95_high"], 3.5)

    def test_prediction_units(self):
        self.assertEqual(deadtime_prediction(20, .051), 10)
        self.assertAlmostEqual(deadtime_prediction(20, .051, True), 20/2.02)

    def test_schedule(self):
        for phase, expected in [("smoke", 6), ("formal", 108)]:
            rows = schedule(phase)
            self.assertEqual(rows, schedule(phase))
            self.assertEqual(len(rows), expected)
            self.assertEqual(len({r["name"] for r in rows}), expected)
            self.assertTrue(all(r["cell"]["outstanding_cap"] == 0 for r in rows))

    def test_capacity_does_not_count_drain(self):
        rows=[dict(publish_ns=t) for t in (-1,0,5,10,100)]
        self.assertEqual([r["publish_ns"] for r in receipts_in_window(rows,0,10)], [0,5])

    def test_capacity_can_count_warmup_generations(self):
        rows=[dict(publish_ns=2,scheduled_ns=-10,deadline_met=False)]
        self.assertEqual(len(receipts_in_window(rows,0,10)),1)


if __name__ == "__main__":
    unittest.main()
