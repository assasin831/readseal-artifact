"""Materialize once, then run the unchanged complete manual-private composition."""
import torch
from manual_composition import ManualComposition
from common import now


class CopyInRejected(RuntimeError):
    pass


class CopyInComposition:
    def __init__(self, example, late):
        self.private_program = ManualComposition(example, late, full=True)
        self.artifact = dict(schema="ispa-copyin-abc-v1", private_compute=self.private_program.artifact,
            original_source_readers=["D2D-copy"], complete_private_readers=["A", "C"],
            private_copy_bytes=example.numel()*example.element_size(),
            automatic_source_read_analysis_used=False, original_source_release="copy-completion event",
            output_release="complete private native and child outputs")

    def start(self, x, publication, ready):
        return CopyInInvocation(self, x, dict(publication), ready)


class CopyInInvocation:
    def __init__(self, program, x, publication, ready):
        self.program, self.source, self.publication, self.ready = program, x, publication, ready
        self.private = None
        self.inner = None
        self.events = []
        self.stage = 0
        self.published = False
        self.stream = None
        self.trace = dict(enrolled_ns=now(), source_reader="D2D-copy")

    def submit(self, stage, stream):
        if self.published or stage != self.stage or stage not in (0, 1):
            raise CopyInRejected("invalid copy-in stage")
        if stage == 0:
            self.stream = stream
            with torch.cuda.stream(stream):
                stream.wait_event(self.ready)
                self.private = torch.empty_like(self.source, memory_format=torch.contiguous_format)
                if self.private.data_ptr() == self.source.data_ptr():
                    raise CopyInRejected("private copy aliases shared source")
                self.trace["private_allocation_ns"] = now()
                self.trace["private_copy_bytes"] = self.private.numel()*self.private.element_size()
                self.copy_begin = torch.cuda.Event(enable_timing=True)
                self.copy_done = torch.cuda.Event(enable_timing=True)
                self.copy_begin.record(stream)
                self.private.copy_(self.source, non_blocking=True)
                self.copy_done.record(stream)
                self.trace["copy_enqueued_ns"] = now()
            self.inner = self.program.private_program.start(self.private, self.publication, self.copy_done)
            self.inner.submit(0, stream)
            self.trace.update({k:v for k,v in self.inner.trace.items() if k != "enrolled_ns"})
            self.events.append(self.copy_done)
            self.source = None
        else:
            if stream != self.stream:
                raise CopyInRejected("copy-in stream changed")
            self.events.append(self.inner.events[-1])
        self.stage += 1
        return self.events[-1]

    def can_release(self):
        return self.stage >= 1 and self.copy_done.query()

    def publish(self):
        if self.published or self.stage != 2 or not self.inner.events[-1].query():
            raise CopyInRejected("incomplete or duplicate copy-in publication")
        values, identity = self.inner.publish()
        if identity != self.publication:
            raise CopyInRejected("private result identity changed")
        self.trace["copy_device_ms"] = self.copy_begin.elapsed_time(self.copy_done)
        self.trace["private_compute_complete_observed_ns"] = now()
        self.published = True
        return values, dict(identity)
