# Preparation history

The initial remote source upload is preserved as
`prototype_ispa_copyin_20260923_attempt1`.
Its CPU-only `prepare` command stopped on the capacity-manifest SHA assertion:
the expected literal was transcribed with an extra hexadecimal character
(65 characters instead of 64). No GPU context, gate output directory or
prepared manifest was created by that failed preflight.

The actual manifest was re-read using `sha256sum`. Correct value:
`0758c8cb333a856303c34cf231ca3a45429caac9f7d4fbfcbc0f2924b666f59a`.
The corrected source will be uploaded to a new `attempt2` directory.
The running capacity campaign and its source/parameters are unchanged.
This is not a repeated inference attempt.
