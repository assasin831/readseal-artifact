"""Wait for the frozen capacity run, then execute one isolated copy-in gate."""
import argparse
import datetime
import fcntl
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import traceback

ROOT = Path("/www/readseal_ipdps_revision_v6")
HERE = Path(__file__).resolve().parent
BASE = ROOT/"results/ispa_copyin_gate_20260923_attempt1"
CAPACITY = ROOT/"results/ispa_capacity_20260923_attempt1"
sys.path.insert(0, str(ROOT/"prototype_borrowplan_v11_grouped_attempt1"))
import launch_grouped_formal as prior


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, data):
    path.write_text(json.dumps(data, indent=2)+"\n")


def read_live(path):
    for attempt in range(5):
        try:
            return json.loads(path.read_text())
        except (FileNotFoundError, json.JSONDecodeError):
            if attempt == 4:
                raise
            time.sleep(0.2)


def own_family(pid):
    parents = {}
    for path in Path("/proc").glob("[0-9]*/status"):
        try:
            row = next(x for x in path.read_text().splitlines() if x.startswith("PPid:"))
            parents[int(path.parent.name)] = int(row.split()[1])
        except (OSError, StopIteration):
            pass
    family = {pid}
    while True:
        extra = {p for p, parent in parents.items() if parent in family}
        if extra <= family:
            return family
        family |= extra


def busy_rows():
    return [(row.split(",")[0].strip(), int(row.split(",")[1]))
            for row in prior.compute().splitlines() if row.strip()]


def prepare():
    frozen_path = CAPACITY/"prepared.json"
    frozen = json.loads(frozen_path.read_text())
    expected = "0758c8cb333a856303c34cf231ca3a45429caac9f7d4fbfcbc0f2924b666f59a"
    assert len(expected) == 64 and prior.sha(frozen_path) == expected
    assert all(prior.sha(p) == h for p, h in frozen["bindings"].items())
    bindings = dict(frozen["bindings"])
    bindings[str(frozen_path)] = prior.sha(frozen_path)
    for path in [*sorted(HERE.glob("*.py")), *sorted(HERE.glob("*.md"))]:
        bindings[str(path)] = prior.sha(path)
    BASE.mkdir(parents=True, exist_ok=False)
    save(BASE/"prepared.json", dict(status="PREPARED", utc=utc(), gpu_uuid=prior.GPU,
        bindings=bindings, prerequisite=str(CAPACITY), inference_executed=False,
        gate_cases=6, state_rejections=42, no_retry=True, performance_launched=False,
        maximum_wait_seconds=10800, minimum_free_gib=20, both_gpus_quiet=True))
    (BASE/"PREPARED").write_text("CPU-only preparation; no inference.\n")
    print(json.dumps(dict(status="PREPARED", sha256=prior.sha(BASE/"prepared.json"))))


def dispatch():
    frozen = json.loads((BASE/"prepared.json").read_text())
    assert all(prior.sha(p) == h for p, h in frozen["bindings"].items())
    control = BASE/"controller"
    control.mkdir(exist_ok=False)
    with (control/"launcher.log").open("x") as log:
        proc = subprocess.Popen([sys.executable, "-B", "-u", str(Path(__file__)), "run"],
            cwd=ROOT, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
            env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
            close_fds=True, start_new_session=True)
    save(control/"dispatch.json", dict(pid=proc.pid, utc=utc(), no_retry=True))
    print(json.dumps(dict(status="QUEUED_AFTER_CAPACITY", pid=proc.pid, output=str(BASE))))


def run():
    control = BASE/"controller"
    frozen = json.loads((BASE/"prepared.json").read_text())
    status = dict(status="WAITING_FOR_CAPACITY", utc_start=utc(), inference_executed=False)
    save(control/"status.json", status)
    code = 2
    child = None
    try:
        deadline = time.monotonic()+frozen["maximum_wait_seconds"]
        while True:
            state = read_live(CAPACITY/"controller/status.json")
            if state["status"] == "COMPLETE":
                break
            if state["status"] != "RUNNING":
                raise RuntimeError("prerequisite did not complete: " + state["status"])
            if time.monotonic() >= deadline:
                raise RuntimeError("prerequisite wait timeout; no inference")
            time.sleep(30)
        check_files = [CAPACITY/"controller/status.json", CAPACITY/"formal/report.json",
                       CAPACITY/"formal/analysis/validation.json"]
        assert all(json.loads(p.read_text())["status"] == "COMPLETE" for p in check_files)
        assert (CAPACITY/"controller/COMPLETE").exists()
        assert (CAPACITY/"controller/exit_code").read_text().strip() == "0"
        assert len(json.loads((CAPACITY/"formal/report.json").read_text())["runs"]) == 108
        assert all(prior.sha(p) == h for p, h in frozen["bindings"].items()), "frozen source changed"
        with (ROOT/"borrowplan_gpu0.lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            assert not busy_rows(), "foreign compute; gate not started"
            assert shutil.disk_usage(ROOT).free/2**30 >= frozen["minimum_free_gib"], "disk reserve"
            status.update(status="GATE_RUNNING", prerequisite_hashes={str(p):prior.sha(p) for p in check_files},
                          prepared_sha256=prior.sha(BASE/"prepared.json"), inference_executed=True)
            save(control/"status.json", status)
            env = dict(os.environ, PYTHONPATH=":".join(map(str, [HERE, *prior.DEPS])),
                CUDA_VISIBLE_DEVICES=prior.GPU, PYTHONDONTWRITEBYTECODE="1",
                OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
                CUDA_CACHE_PATH=str(BASE/"cuda-cache"))
            with (BASE/"gate.log").open("x") as log:
                child = subprocess.Popen([sys.executable, "-B", "-u", str(HERE/"run_copyin_gate.py"),
                    "--output", str(BASE/"gate")], cwd=ROOT, env=env, stdout=log,
                    stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True)
                while child.poll() is None:
                    family = own_family(child.pid)
                    foreign = [(gpu, pid) for gpu, pid in busy_rows()
                               if pid not in family or gpu != prior.GPU]
                    assert not foreign, "foreign compute during gate: " + repr(foreign)
                    time.sleep(0.5)
                assert child.returncode == 0, "copy-in gate failed; no retry"
            assert not busy_rows(), "foreign compute at gate exit"
            status["status"] = "VALIDATING"
            save(control/"status.json", status)
            with (BASE/"validation.log").open("x") as log:
                result = subprocess.run([sys.executable, "-B", str(HERE/"validate_copyin_gate.py"),
                    "--run", str(BASE/"gate"), "--output", str(BASE/"validation")], cwd=ROOT,
                    env=dict(env, CUDA_VISIBLE_DEVICES=""), stdout=log, stderr=subprocess.STDOUT)
            assert result.returncode == 0, "copy-in CPU validation failed; no performance launch"
            status.update(status="COMPLETE", gate_sha256=prior.sha(BASE/"gate/report.json"),
                          validation_sha256=prior.sha(BASE/"validation/validation.json"),
                          performance_launched=False)
            code = 0
    except BaseException:
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
        status.update(status="FAILED" if status["inference_executed"] else "STOPPED_BEFORE_INFERENCE",
                      reason=traceback.format_exc())
        traceback.print_exc()
    status["utc_end"] = utc()
    save(control/"status.json", status)
    (control/status["status"]).write_text(status["status"]+"\n")
    (control/"exit_code").write_text(str(code)+"\n")
    print(json.dumps(status), flush=True)
    return code


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("prepare", "dispatch", "run"))
    args = parser.parse_args()
    if args.action == "run":
        raise SystemExit(run())
    globals()[args.action]()
