"""CPU-only state tests with a fake CUDA interface; not numerical/GPU evidence."""
import contextlib
import importlib.util
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch


class Event:
    def __init__(self, **kwargs):
        self.done=False
    def record(self, stream):
        pass
    def query(self):
        return self.done
    def elapsed_time(self, other):
        return 1.0


class Tensor:
    def __init__(self, values):
        self.values=list(values)
    def data_ptr(self):
        return id(self.values)
    def numel(self):
        return len(self.values)
    def element_size(self):
        return 4
    def copy_(self, source, **kwargs):
        self.values=list(source.values)


class Stream:
    def wait_event(self, event):
        self.waited=event


class Inner:
    def __init__(self, tensor, identity, ready):
        self.tensor,self.identity,self.ready=tensor,identity,ready
        self.trace=dict(enrolled_ns=2,a_submitted_ns=3,c_prefix_submitted_ns=4)
        self.events=[Event()]
    def submit(self, stage, stream):
        assert stage==0
    def publish(self):
        assert self.events[-1].done
        return tuple(self.tensor.values),dict(self.identity)


class Manual:
    def __init__(self, example, late, full):
        assert full is True
        self.artifact=dict(no_checked_executor=True)
    def start(self, x, publication, ready):
        return Inner(x,publication,ready)


class CopyTests(unittest.TestCase):
    def setUp(self):
        fake=torch=types.SimpleNamespace(contiguous_format="contiguous",
            empty_like=lambda x,**kw:Tensor([0]*x.numel()),
            cuda=types.SimpleNamespace(Event=Event,stream=lambda s:contextlib.nullcontext()))
        deps={"torch":fake,"manual_composition":types.SimpleNamespace(ManualComposition=Manual),
              "common":types.SimpleNamespace(now=lambda:1)}
        path=Path(__file__).with_name("copyin_composition.py")
        spec=importlib.util.spec_from_file_location("copyin_under_test",path)
        self.mod=importlib.util.module_from_spec(spec)
        with patch.dict(sys.modules,deps):
            spec.loader.exec_module(self.mod)
        self.source=Tensor([1,2,3])
        self.program=self.mod.CopyInComposition(self.source,False)
        self.ready,self.stream=Event(),Stream()
        self.ex=self.program.start(self.source,dict(sequence=7),self.ready)

    def test_not_releasable_or_publishable_before_start(self):
        self.assertFalse(self.ex.can_release())
        with self.assertRaises(self.mod.CopyInRejected):
            self.ex.publish()

    def test_copy_is_only_source_reader(self):
        self.ex.submit(0,self.stream)
        self.assertIs(self.stream.waited,self.ready)
        self.assertIs(self.ex.inner.ready,self.ex.copy_done)
        self.assertIsNone(self.ex.source)
        self.assertNotEqual(self.source.data_ptr(),self.ex.private.data_ptr())
        self.assertFalse(self.ex.can_release())
        self.ex.copy_done.done=True
        self.assertTrue(self.ex.can_release())

    def test_overwrite_does_not_change_private_result(self):
        self.ex.submit(0,self.stream)
        self.ex.submit(1,self.stream)
        self.source.values[:]=[9,9,9]
        self.ex.copy_done.done=True
        self.ex.inner.events[-1].done=True
        values,identity=self.ex.publish()
        self.assertEqual(values,(1,2,3))
        self.assertEqual(identity,dict(sequence=7))
        with self.assertRaises(self.mod.CopyInRejected):
            self.ex.publish()

    def test_wrong_order_and_stream_rejected(self):
        with self.assertRaises(self.mod.CopyInRejected):
            self.ex.submit(1,self.stream)
        self.ex.submit(0,self.stream)
        with self.assertRaises(self.mod.CopyInRejected):
            self.ex.submit(1,Stream())

    def test_copy_completion_not_output_completion(self):
        self.ex.submit(0,self.stream)
        self.ex.submit(1,self.stream)
        self.ex.copy_done.done=True
        self.assertTrue(self.ex.can_release())
        with self.assertRaises(self.mod.CopyInRejected):
            self.ex.publish()


if __name__=="__main__":
    unittest.main()
