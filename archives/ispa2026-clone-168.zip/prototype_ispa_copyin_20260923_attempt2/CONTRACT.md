# Copy-in baseline: correctness gate before performance

This is a new baseline, not a modification of any frozen prior executor.
The current capacity campaign must finish successfully before its GPU gate runs.

## Semantics

Each invocation allocates a private tensor with identical shape and dtype.
The first source-reading operation is a D2D copy after the publication-ready
event on the caller stream. Only that copy borrows the shared source. The copy
completion event permits the original source loan to return. Native A and the
unchanged complete C program both consume the private copy; their completed
outputs are joined and published under the original publication identity.
The private tensor remains strongly owned until the private computation finishes.

The private computation uses the existing independently written full-retention
composition. No ReadSeal source-read analysis or checked child executor is
used to decide the copy boundary. This does not remove publication enrollment,
pool coordination, readiness, result provenance or output completion obligations.
The complete source tensor is copied in this first baseline; it is not yet a
cropped heterogeneous-consumer experiment.

## Frozen gate

- Existing GPU0, both GPUs quiet, existing exclusive experiment lock; unchanged
  pinned TransFusion weights, three stored inputs and TensorRT native extraction.
- Base and late-read variants, three distinct inputs each: six gate cases.
- Compute the old-input reference with the unchanged full-retention composition.
- Start copy-in, wait only for the private-copy event, then actually overwrite
  the original shared tensor with the next distinct input. Do not delay private
  compute to force overlap; record whether it was still incomplete at return.
- Compare every native/child output tensor exactly against the requested-input
  reference; save arrays, shapes, hashes, events/host timestamps and identities.
- Require premature publish, wrong stage and duplicate publish to reject.
  Count rejects separately from output-equivalence checks.
- Never infer performance, throughput or realistic overlap from this gate.
- Fail closed and preserve the first failed attempt; never retry inference.
  Any subsequent correction requires a new, explicitly justified code version.

Performance is NOT authorized by passing the state-machine unit tests alone.
A separate CPU tensor auditor must validate all six GPU cases first. The rate,
late-read and R/K performance matrices will be frozen after that gate and the
capacity report are available, before viewing any copy-in timing outcomes.

## Memory reporting

Record the private source-copy size and allocation/copy/publication timestamps.
The allocator/device peak remains the physical-memory metric. Dropping a Python
owner is not proof that CUDA freed bytes: child intermediates or output aliases
may retain storage. Do not subtract logical borrow bytes from allocated memory.
Memory reserved by the caching allocator is distinct from active copy storage.
