"""One-shot GPU gate. No performance inference or retry is performed here."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import traceback

import torch
from common import GPU, inventory, now, sha
from copyin_composition import CopyInComposition, CopyInRejected
from manual_composition import ManualComposition
from study_common import configure, compute_pids, inputs, cpu_values, exact


def tensor_hash(tensor):
    return hashlib.sha256(tensor.detach().cpu().contiguous().numpy().tobytes()).hexdigest()


def expect_reject(name, operation, recorded):
    try:
        operation()
    except CopyInRejected:
        recorded.append(name)
        return
    raise AssertionError(name + " did not reject")


def run(folder):
    folder.mkdir(parents=True, exist_ok=False)
    report = dict(status="RUNNING", cases=[], gpu_uuid=GPU, pid=os.getpid(),
                  inference_retry=False, capacity_or_performance_claim=False)
    try:
        assert not compute_pids(), "foreign compute before gate"
        configure()
        xs, input_hashes = inputs("transfusion")
        source_hashes = [tensor_hash(x) for x in xs]
        assert len(xs) == len(set(source_hashes)) == 3
        sources = [x.cuda() for x in xs]
        stream, other_stream, reuse_stream = (torch.cuda.Stream() for _ in range(3))
        torch.cuda.synchronize()
        for late in (False, True):
            reference_program = ManualComposition(sources[0], late, full=True)
            program = CopyInComposition(sources[0], late)
            for sid, source in enumerate(sources):
                assert all(row["pid"] == os.getpid() for row in compute_pids()), "foreign compute"
                pub = dict(epoch=987654, sequence=sid+1, generation=2*(sid+1))
                ready = torch.cuda.Event()
                ready.record()
                reference = reference_program.start(source, pub, ready)
                reference.submit(0, stream).synchronize()
                expected, reference_identity = reference.publish()
                expected = cpu_values(expected)
                assert reference_identity == pub

                shared = source.clone()
                ready = torch.cuda.Event()
                ready.record()
                ex = program.start(shared, pub, ready)
                admitted = now()
                rejections = []
                assert not ex.can_release()
                expect_reject("publish_before_submit", ex.publish, rejections)
                expect_reject("stage1_before_stage0", lambda: ex.submit(1, stream), rejections)
                ex.submit(0, stream)
                expect_reject("duplicate_stage0", lambda: ex.submit(0, stream), rejections)
                expect_reject("changed_stream", lambda: ex.submit(1, other_stream), rejections)
                expect_reject("publish_before_stage1", ex.publish, rejections)
                ex.submit(1, stream)
                ex.events[0].synchronize()
                returned = now()
                assert ex.can_release()
                unfinished_at_return = not ex.events[-1].query()
                pointers_distinct = shared.data_ptr() != ex.private.data_ptr()
                assert pointers_distinct
                overwrite_begin = now()
                with torch.cuda.stream(reuse_stream):
                    shared.copy_(sources[(sid+1) % 3], non_blocking=True)
                    replaced = torch.cuda.Event()
                    replaced.record(reuse_stream)
                replaced.synchronize()
                overwritten = now()
                overwritten_hash = tensor_hash(shared)
                private_hash = tensor_hash(ex.private)
                assert overwritten_hash == source_hashes[(sid+1) % 3] != source_hashes[sid]
                assert private_hash == source_hashes[sid]
                ex.events[-1].synchronize()
                values, identity = ex.publish()
                values = cpu_values(values)
                published = now()
                exact(values, expected)
                assert identity == pub and len(values) == (11 if late else 10)
                expect_reject("duplicate_publish", ex.publish, rejections)
                expect_reject("stage_after_publish", lambda: ex.submit(1, stream), rejections)
                key = f"copy-in-s{sid}-late{int(late)}"
                tensor_path = folder/(key+".pt")
                torch.save(dict(actual=values, expected=expected), tensor_path)
                report["cases"].append(dict(key=key, source=sid, replacement=(sid+1) % 3,
                    late=late, identity=identity, reference_identity=reference_identity,
                    admitted_ns=admitted, return_ns=returned, overwrite_begin_ns=overwrite_begin,
                    overwrite_done_ns=overwritten, published_ns=published,
                    private_unfinished_at_return=unfinished_at_return, pointers_distinct=pointers_distinct,
                    source_before_sha256=source_hashes[sid], source_after_sha256=overwritten_hash,
                    private_copy_sha256=private_hash, rejections=rejections,
                    shapes=[list(t.shape) for t in values], dtypes=[str(t.dtype) for t in values],
                    actual_hashes=[tensor_hash(t) for t in values],
                    expected_hashes=[tensor_hash(t) for t in expected],
                    tensor_file=tensor_path.name, tensor_file_sha256=sha(tensor_path),
                    trace=dict(ex.trace), artifact=program.artifact))
                print("COMPLETE " + key, flush=True)
                del ex, reference, expected, values, shared
            del program, reference_program
        assert all(row["pid"] == os.getpid() for row in compute_pids()), "foreign compute"
        report.update(status="COMPLETE", input_hashes=input_hashes,
                      input_tensor_hashes=source_hashes, sources=inventory(), gate_cases=6,
                      output_tensors=63, state_rejections=42)
    except BaseException:
        report.update(status="FAILED", reason=traceback.format_exc())
        traceback.print_exc()
    (folder/"report.json").write_text(json.dumps(report, indent=2)+"\n")
    (folder/report["status"]).write_text(report["status"]+"\n")
    return 0 if report["status"] == "COMPLETE" else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    raise SystemExit(run(parser.parse_args().output))
