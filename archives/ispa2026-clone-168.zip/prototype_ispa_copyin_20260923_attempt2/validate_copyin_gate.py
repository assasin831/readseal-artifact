"""CPU tensor audit independent of the copy-in executor and its comparisons."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import traceback

import numpy as np
import torch


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def audit(run, output):
    output.mkdir(parents=True, exist_ok=False)
    validation = dict(status="RUNNING", inference_executed=False, checks=0)

    def check(condition, label):
        validation["checks"] += 1
        if not condition:
            raise AssertionError(label)

    try:
        check(os.environ.get("CUDA_VISIBLE_DEVICES") == "", "CPU-only validator")
        report = json.loads((run/"report.json").read_text())
        check(report["status"] == "COMPLETE" and (run/"COMPLETE").is_file(), "gate completion")
        check(not (run/"FAILED").exists(), "no failure marker")
        check(report["gate_cases"] == len(report["cases"]) == 6, "six cases")
        check({(r["late"], r["source"]) for r in report["cases"]} ==
              {(late, sid) for late in (False, True) for sid in range(3)}, "exact membership")
        check(not report["inference_retry"] and not report["capacity_or_performance_claim"], "scope")
        for path, expected in {**report["sources"], **report["input_hashes"]}.items():
            check(sha(path) == expected, "input/source hash: " + path)
        hashes = []
        for path in sorted(report["input_hashes"]):
            x = torch.load(path, map_location="cpu", weights_only=False)["input"]
            check(list(x.shape) == [1, 512, 180, 180] and x.dtype == torch.float32, "source shape/dtype")
            hashes.append(hashlib.sha256(x.contiguous().numpy().tobytes()).hexdigest())
        check(hashes == report["input_tensor_hashes"] and len(set(hashes)) == 3, "distinct inputs")
        total, rejected = 0, 0
        for row in report["cases"]:
            sid, replacement = row["source"], row["replacement"]
            check(replacement == (sid+1) % 3, "replacement membership")
            check(row["source_before_sha256"] == row["private_copy_sha256"] == hashes[sid], "private copy")
            check(row["source_after_sha256"] == hashes[replacement] != hashes[sid], "actual replacement")
            check(row["pointers_distinct"], "separate allocations")
            check(row["identity"] == row["reference_identity"] ==
                  dict(epoch=987654, sequence=sid+1, generation=2*(sid+1)), "identity")
            check(row["admitted_ns"] <= row["return_ns"] <= row["overwrite_begin_ns"] <=
                  row["overwrite_done_ns"] <= row["published_ns"], "host causality")
            trace = row["trace"]
            check(trace["private_copy_bytes"] == 1*512*180*180*4, "copy bytes")
            check(trace["private_allocation_ns"] <= trace["copy_enqueued_ns"] <= row["return_ns"], "copy timing")
            check(math.isfinite(trace["copy_device_ms"]) and trace["copy_device_ms"] > 0, "copy event time")
            check(row["overwrite_done_ns"] <= trace["private_compute_complete_observed_ns"] <=
                  row["published_ns"], "publication observed after overwrite")
            check(row["rejections"] == ["publish_before_submit", "stage1_before_stage0", "duplicate_stage0",
                "changed_stream", "publish_before_stage1", "duplicate_publish", "stage_after_publish"], "state rejects")
            rejected += len(row["rejections"])
            artifact = row["artifact"]
            check(artifact["schema"] == "ispa-copyin-abc-v1", "artifact schema")
            check(artifact["original_source_readers"] == ["D2D-copy"], "copy-only shared read")
            check(artifact["complete_private_readers"] == ["A", "C"], "complete private readers")
            check(not artifact["automatic_source_read_analysis_used"] and artifact["private_compute"]["full"], "baseline policy")
            path = run/row["tensor_file"]
            check(path.parent == run and sha(path) == row["tensor_file_sha256"], "tensor file hash")
            pair = torch.load(path, map_location="cpu", weights_only=False)
            n = 11 if row["late"] else 10
            check(len(pair["actual"]) == len(pair["expected"]) == len(row["actual_hashes"]) == n, "output count")
            for i, (actual, expected) in enumerate(zip(pair["actual"], pair["expected"])):
                a, b = actual.numpy(), expected.numpy()
                check(a.shape == b.shape and list(a.shape) == row["shapes"][i], "output shape")
                check(a.dtype == b.dtype and str(actual.dtype) == row["dtypes"][i], "output dtype")
                check(np.isfinite(a).all() and np.isfinite(b).all() and np.array_equal(a, b), "exact output")
                digest = hashlib.sha256(a.tobytes()).hexdigest()
                check(digest == row["actual_hashes"][i] == row["expected_hashes"][i], "output hash")
                total += 1
        check(total == report["output_tensors"] == 63, "total outputs")
        check(rejected == report["state_rejections"] == 42, "total rejects")
        validation.update(status="COMPLETE", cases=6, exact_output_tensors=total, state_rejections=rejected,
            report_sha256=sha(run/"report.json"), auditor_sha256=sha(__file__),
            private_unfinished_at_return=sum(r["private_unfinished_at_return"] for r in report["cases"]),
            capacity_or_performance_claim=False, gpu_uuid=report["gpu_uuid"])
    except BaseException:
        validation.update(status="FAILED", reason=traceback.format_exc())
        traceback.print_exc()
    (output/"validation.json").write_text(json.dumps(validation, indent=2)+"\n")
    (output/validation["status"]).write_text(validation["status"]+"\n")
    return 0 if validation["status"] == "COMPLETE" else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    raise SystemExit(audit(args.run, args.output))
