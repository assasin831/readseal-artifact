# Grouped complete-pipeline experiment

Freeze before any V11 grouped-pipeline inference. This is a follow-up to an
observed V10 cost, not a claim that the prior results were preregistered.

## Correctness prerequisite (non-timed)

Use the frozen native A, alias-only B, and complete TransFusion C, including
all native and model output fields. Three frozen inputs, original and delayed
read graphs, four implementations: 24 cases. Wait for the joined shared-read
completion, actually overwrite source storage, then launch the private suffix.
Compare every output exactly against that graph/input's protected manual-full
reference. Verify publication identity, duplicate rejection, reader obligations,
and original grouped guard bindings. Record GPU1 cohost, no timing claims. Do
not retry failed inference. Validate saved tensors without invoking the model.

## Formal matrix (quiet host only)

Four paths: original automatic, grouped automatic, manual early return,
manual full retention. No guard removal and no parameter adaptation per method.
Complete original A/B/C graph, 4 recipients, 30 Hz producer, 100 ms scheduled-
arrival deadline, queue depth 2, 2 s warmup and 12 s measured cohort.
Four regimes: (R=1, cap=0), (R=2, cap=0), (R=2, cap=4), (R=2, cap=8).
Cap counts outstanding recipient requests and returns credits on sink receipt.
Six repeats of all four methods per regime: 96 fresh runs. Seed 111202
deterministically randomizes method order in each repeat/regime block. No
optional stopping, no tuning from new results, no replacement of old V10 data.

Both GPUs must be free before each run. Use the existing compute monitor during
the run. Stop on interference or failure and preserve the attempt. Never stop
foreign jobs or change GPU partitions. A later authorized continuation may
execute only unstarted cells in a fresh directory, never rerun a failed
inference or replace an unfavorable completed run.

## Outcomes and analysis

Primary: correct and timely sink receipts per second. Include every offered
recipient request in the scheduled cohort; source/version, reference-output,
finite-value, actual-receipt and scheduled-deadline checks must all pass.
Secondary: offered/admitted/received/late/rejected counts, protected byte-seconds,
process/device peak memory, queue-wait bounds and receipt-latency distributions.
Do not infer a practical memory quota from this sweep or equate input lifetime
with peak-memory reduction. Compare paired regime/repeat differences over
20,000 repeat-clustered bootstrap samples, fixed seed 111203; show all six repeat
values and point estimates. Latency CDFs are conditional on receipts; losses
remain visible in the primary outcome. Absolute per-invocation costs are from
the separately labeled V10 study, not substituted for end-to-end benefit.

Freeze a source/model/plan hash manifest and correctness validation before formal
launch. Save each run's hardware/process audit, complete traces and output hash
records. Independently validate before inclusion in the manuscript.
