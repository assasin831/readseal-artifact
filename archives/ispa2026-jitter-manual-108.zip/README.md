# Reviewer follow-up data

Native A100 component heterogeneity, not four independently trained AV nodes or embedded execution. All intended recipients and all scheduled publications define the primary denominator. Complete-publication latency is conditional on all-correct complete outputs; incomplete counts remain visible. Pointwise t95 df5 uses six whole runs or six paired differences, not frames as replicates. No equivalence, simultaneous coverage, outlier removal or winner-based condition selection. Memory is the observed device peak from roughly 0.5-second sampling during the worker-ready-to-drain window; it excludes earlier model/reference setup and can miss transients. Per-worker allocator peaks are separate and are not summed into a simultaneous device peak. Original raw traces and saved tensors remain at the recorded remote paths. Online exact hashes cover receipts; saved first samples have independent tensor checks. Historical Clone-on-admit wave1 is separate and is not paired across waves.

108 formal runs and 18 smoke runs passed the saved-only per-run audit. CSV blank cells represent unavailable metrics, not zeros. No confidence limits were clipped.

| Condition | Method | Complete-publication timely fraction, mean [t95] |
|---|---|---|
| heterogeneous-jitter-hz30 | auto-batched | 0.584630 [0.578016, 0.591243] |
| heterogeneous-jitter-hz30 | copy-in | 0.806852 [0.801026, 0.812678] |
| heterogeneous-jitter-hz30 | manual-checked | 0.583333 [0.578442, 0.588225] |
| heterogeneous-jitter-hz30 | manual-full | 0.575370 [0.569782, 0.580958] |
| heterogeneous-periodic-hz30 | auto-batched | 0.502593 [0.498509, 0.506677] |
| heterogeneous-periodic-hz30 | copy-in | 0.825556 [0.823223, 0.827888] |
| heterogeneous-periodic-hz30 | manual-checked | 0.502037 [0.499898, 0.504177] |
| heterogeneous-periodic-hz30 | manual-full | 0.500000 [0.500000, 0.500000] |
| homogeneous-jitter-hz30 | auto-batched | 0.635370 [0.632990, 0.637751] |
| homogeneous-jitter-hz30 | copy-in | 0.616481 [0.606911, 0.626052] |
| homogeneous-jitter-hz30 | manual-checked | 0.635000 [0.632582, 0.637418] |
| homogeneous-jitter-hz30 | manual-full | 0.480185 [0.476118, 0.484252] |
| homogeneous-periodic-hz30 | auto-batched | 0.655370 [0.654224, 0.656517] |
| homogeneous-periodic-hz30 | copy-in | 0.633333 [0.626820, 0.639846] |
| homogeneous-periodic-hz30 | manual-checked | 0.654444 [0.653707, 0.655182] |
| homogeneous-periodic-hz30 | manual-full | 0.500000 [0.500000, 0.500000] |
| late-periodic-hz30 | auto-batched | 0.500000 [0.500000, 0.500000] |
| late-periodic-hz30 | manual-checked | 0.499815 [0.499339, 0.500291] |
